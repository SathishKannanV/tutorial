package com.aetna.prvrte.rteintranet.dto;



import java.io.Serializable;

public class LongRunTransReport3DTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String startDate = "";
	private String startTime = "";
	private String endTime = "";
	private String zeroTimeTaken ="";
	private String oneTimeTaken="";
	private String twoTimeTaken ="";
	private String threeTimeTaken="";
	private String fourTimeTaken ="";
	private String fiveTimeTaken="";
	private String sixTimeTaken="";
	private String sevenTimeTaken="";
	
	public LongRunTransReport3DTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	


	public LongRunTransReport3DTO(String startDate, String startTime,
			String endTime, String zeroTimeTaken, String oneTimeTaken,
			String twoTimeTaken, String threeTimeTaken, String fourTimeTaken,
			String fiveTimeTaken, String sixTimeTaken, String sevenTimeTaken) {
		super();
		this.startDate = startDate;
		this.startTime = startTime;
		this.endTime = endTime;
		this.zeroTimeTaken = zeroTimeTaken;
		this.oneTimeTaken = oneTimeTaken;
		this.twoTimeTaken = twoTimeTaken;
		this.threeTimeTaken = threeTimeTaken;
		this.fourTimeTaken = fourTimeTaken;
		this.fiveTimeTaken = fiveTimeTaken;
		this.sixTimeTaken = sixTimeTaken;
		this.sevenTimeTaken = sevenTimeTaken;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndTime() {
		return endTime;
	}







	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}







	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getZeroTimeTaken() {
		return zeroTimeTaken;
	}

	public void setZeroTimeTaken(String zeroTimeTaken) {
		this.zeroTimeTaken = zeroTimeTaken;
	}

	public String getOneTimeTaken() {
		return oneTimeTaken;
	}

	public void setOneTimeTaken(String oneTimeTaken) {
		this.oneTimeTaken = oneTimeTaken;
	}

	public String getTwoTimeTaken() {
		return twoTimeTaken;
	}

	public void setTwoTimeTaken(String twoTimeTaken) {
		this.twoTimeTaken = twoTimeTaken;
	}

	public String getThreeTimeTaken() {
		return threeTimeTaken;
	}

	public void setThreeTimeTaken(String threeTimeTaken) {
		this.threeTimeTaken = threeTimeTaken;
	}

	public String getFourTimeTaken() {
		return fourTimeTaken;
	}

	public void setFourTimeTaken(String fourTimeTaken) {
		this.fourTimeTaken = fourTimeTaken;
	}

	public String getFiveTimeTaken() {
		return fiveTimeTaken;
	}

	public void setFiveTimeTaken(String fiveTimeTaken) {
		this.fiveTimeTaken = fiveTimeTaken;
	}

	public String getSixTimeTaken() {
		return sixTimeTaken;
	}

	public void setSixTimeTaken(String sixTimeTaken) {
		this.sixTimeTaken = sixTimeTaken;
	}

	public String getSevenTimeTaken() {
		return sevenTimeTaken;
	}

	public void setSevenTimeTaken(String sevenTimeTaken) {
		this.sevenTimeTaken = sevenTimeTaken;
	}

	
	
}

