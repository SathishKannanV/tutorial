package com.aetna.prvrte.rteintranet.web.controller;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.aetna.prvrte.rteintranet.dto.TosctDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.TosctVO;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/tosct/*")
public class TosctController {
	/*
	 * Tile name of the tosct Home view.
	 */
	public static final String TOSCT_HOME = ".tosctHome";
	/*
	 * Tile name of the tosct Display view.
	 */
	public static final String TOSCT_LOOKUP = ".tosctLookUpDisplay";
	/*
	 * Tile name of the Add New tosct Form view.
	 */
	public static final String TOSCT_ADD = ".tosctAdd";
	/*
	 * Tile name of the Help page.
	 */
	public static final String TOSCT_HELP = ".tosctHelp";
	/*
	 * Constant name used for COPY indicator.
	 */
	public static final char COPY = 'C';

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(TosctController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errormav;
	
	/**
	 * Method to getTosctLookUpHome view
	 * 
	 * @param model
	 * 
	 * @return view of tosctLookUp, if fails return error page
	 */
	@RequestMapping(value="/tosctHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getTosctLookUpHome(final HttpServletRequest request,Model model) {	   
		log.warn("Entered TosctController - getTosctLookUpHome()");
		String securityLevel ="";
		try {
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(TOSCT_HOME, "tosctVO",  new TosctVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("TosctController - securityLevel: "+ securityLevel);
		log.warn("Exit from TosctController - getTosctLookUpHome()");
		return mav;
		} catch (ApplicationException e){
			log.error("Exception occured in TosctController - getTosctLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * Method to get the loadTosctHelp List from data store.
	 * 
	 * @return view of Tosct help page
	 */
	@RequestMapping(value="/tosctHelp")
	public String loadTosctHelp() {   
		return TOSCT_HELP;
	}
	
	

	/**
	 * Method to get the tosctLookUp List from data store.
	 * 
	 * @param tosctVO
	 *            form view object of tosct.
	 * @return view of tosctDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherTosct", method = RequestMethod.POST)
	public ModelAndView getTosctLookUpTable(HttpServletRequest request,@ModelAttribute("tosctForm")TosctVO tosctVO){
		String securityLevel ="";
		ModelAndView mav ;
		Map tosctResultMap = new HashMap();
		List<TosctVO> tosctList = new LinkedList<TosctVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			TosctDTO tosctDTO = RTETranslator.toTosctDTO(tosctVO);
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			tosctResultMap = facade.getTosctLookUpTable(tosctDTO);
			List<TosctDTO> tosctDTOList = (List<TosctDTO>) tosctResultMap.get("tosctList");
			tosctList = (List<TosctVO>) RTETranslator.toTosctVOList(tosctDTOList);
			lookUpListVO.setTosctVOList(tosctList);
			facade.getApplicationState().setTosctList(tosctList);
			mav = new ModelAndView(TOSCT_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("tosctMessage", tosctResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("getTosctLookUpTable - tosctMessage: "+ tosctResultMap.get("newMessage"));
			log.warn("Exit from TosctController - getTosctLookUpTable()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in TosctController - getTosctLookUpTable() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="getTosctLookUpTable() :"+ApplicationConstants.ERROR_GET_LOOKUP + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	
	/**
	 * Method to display get add new Tosct form home view.
	 * 
	 * @return view of loadAddNewTosctRowScreen, if fails return error page
	 */
	@RequestMapping(value="/AddNewTosctRow")
	public ModelAndView loadAddNewTosctVORowScreen(final HttpServletRequest request,Model model) {	   
		ModelAndView mav = new ModelAndView(TOSCT_ADD, "tosctVO",  new TosctVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in TosctController - loadAddNewTosctVORowScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (loadAddNewTosctVORowScreen). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		log.warn("Exit from TosctController - loadAddNewTosctVORowScreen()");
		return mav;
	}

	
	/**
	 * Method to add the data database
	 * 
	 * @param tosctVO form view object of Tosct.
	 * @return view of tosctDisplay, if fails return error page
	 * 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddTosct", method = RequestMethod.POST)
	public ModelAndView addNewTosct(@ModelAttribute("addTosctForm")TosctVO tosctVO,final HttpServletRequest request){
		log.warn("Entered TosctController - addNewTosct()");
		ModelAndView mav ;
		Map tosctResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<TosctDTO> tosctDtoList = new LinkedList<TosctDTO>();
		List<TosctVO> tosctVoList = new LinkedList<TosctVO>();
		String securityLevel ="";
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			tosctVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
			TosctDTO tosctDTO = RTETranslator.toTosctDTO(tosctVO);
			tosctResultMap = facade.addNewTosct(tosctDTO);
			if(tosctResultMap.get("tosctList")!=null){
				tosctDtoList = (List<TosctDTO>) tosctResultMap.get("tosctList");
				tosctVoList = RTETranslator.toTosctVOList(tosctDtoList);
			}
			lookUpListVO.setTosctVOList(tosctVoList);
			facade.getApplicationState().setTosctList(tosctVoList);
			mav = new ModelAndView(TOSCT_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("securityLevel", securityLevel);
			mav.addObject("tosctMessage", tosctResultMap.get("tosctMessage"));
			log.warn("addNewTosct - tosctMessage: "+ tosctResultMap.get("tosctMessage"));
			log.warn("Exit from TosctController - addNewTosct()");			
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in TosctController - addNewTosct() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addNewTosct() :"+ApplicationConstants.ERROR_ADD_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	
	/**
	 * Method to delete the Tosct List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of tosctDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteTosct", method = RequestMethod.POST)
	public ModelAndView deleteTosct(final HttpServletRequest request,@ModelAttribute("tosctDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String tosctMsg = "";
		boolean isTosctDeleted = true;
		String securityLevel ="";
		Map tosctResultMap = new HashMap();
		List<TosctVO> tosctList = new LinkedList<TosctVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			tosctList = lookUpListVO.getTosctVOList();
			int i;
			if ((tosctList != null) && (takeAction != null)) {
				
				for(TosctVO tosctVO : tosctList){
					if(tosctVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						tosctVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					TosctVO editedTosct = (TosctVO) tosctList.get(i);
					if (editedTosct.getDbUpdatedInd() != ApplicationConstants.COPY) {
						TosctDTO tosctDTO = RTETranslator.toTosctDTO(editedTosct);
						tosctResultMap = facade.deleteTosct(tosctDTO);
						tosctMsg = (String) tosctResultMap.get("tosctMsg");
						isTosctDeleted = (Boolean) tosctResultMap.get("isTosctDeleted");
						
						if(isTosctDeleted == true){
							tosctList.remove(i);
						}else{
							j = 0;
						}
					}else{
						tosctList.remove(i);
					}				
			}
				if(isTosctDeleted == true)
					tosctMsg = "Rows selected were Deleted in the database/list";
		}else
			tosctMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setTosctList(tosctList);
			lookUpListVO.setTosctVOList(tosctList);
			mav = new ModelAndView(TOSCT_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("tosctMessage",tosctMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteTosct - tosctMessage: "+ tosctMsg);
		    log.warn("Exit from TosctController - deleteTosct()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in TosctController - deleteTosct() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteTosct() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}

	
	/**
	 * Method to copy the Tosct List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of tosctDisplay, if fails return error page
	 */
	@RequestMapping(value="/copyTosct", method = RequestMethod.POST)
	public ModelAndView copyTosct(final HttpServletRequest request,@ModelAttribute("tosctDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String tosctMsg = "";
		String securityLevel ="";
		int i;
		List<TosctVO> tosctList = new LinkedList<TosctVO>();
		try{
			//String postedDate =RteIntranetUtils.getPostedDate(); //Initialize Posted Date to today's date
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			tosctList = lookUpListVO.getTosctVOList();
			if ((tosctList != null) && (takeAction != null)) {
				for(TosctVO tosctVO : tosctList){
					if(tosctVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						tosctVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					i = Integer.parseInt(takeAction[j]);
					TosctVO existingTosct = (TosctVO) tosctList.get(i);
					TosctVO copyTosct = new TosctVO(existingTosct.getDbSvcTypeCd() , existingTosct.getDbPntfrmageNo() , 
							existingTosct.getDbPnttoageNo() , existingTosct.getDbPatientsxCd() , existingTosct.getDbTosCd() ,
							existingTosct.getDbPosCd() , existingTosct.getDbSpclcovgCd() , existingTosct.getDbADACd() ,
							existingTosct.getDbAxcelInd() , existingTosct.getDbToscatCd() , existingTosct.getDbPcpcovInd() , 
							existingTosct.getDbUsageCode() ,  COPY);
					tosctList.add(copyTosct);
				}
				tosctMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				tosctMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setTosctList(tosctList);
			lookUpListVO.setTosctVOList(tosctList);
			mav = new ModelAndView(TOSCT_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("tosctMessage",tosctMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyTosct - tosctMessage: "+ tosctMsg);
		    log.warn("Exit from TosctController - copyTosct()");
			return mav;		
		}catch (Exception e){
			log.error("Exception occured in TosctController - copyTosct() method:"+e.getMessage());
			String errorMsg ="copyTosct() :"+ApplicationConstants.ERROR_COPY_ROW + RteIntranetUtils.getTrimmedString(e.getMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}


	/**
	 * Method to Add/Update the Tosct List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of tosctDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateTosct", method = RequestMethod.POST)
	public ModelAndView addUpdateTosct(final HttpServletRequest request,@ModelAttribute("tosctDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered from TosctController - addUpdateTosct()");
		ModelAndView mav ;
		String tosctMsg = "";
		String securityLevel ="";
		List<TosctVO> updatedTosctList = facade.getApplicationState().getTosctList();
		List<TosctDTO> updatedTosctDtoList = new LinkedList<TosctDTO>();
		List<TosctVO> tosctVoList = new LinkedList<TosctVO>();
		List<TosctVO> modifiedTosctVoList = new LinkedList<TosctVO>();
		List<TosctDTO> tosctDtoList = new LinkedList<TosctDTO>(); 
		boolean isTosctAddOrUpdated = false;
		Map tosctResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			 tosctVoList = facade.getApplicationState().getTosctList();
			 modifiedTosctVoList = lookUpListVO.getTosctVOList();
			int i;
			if (takeAction != null && takeAction.length != 0) {
				if(tosctVoList != null && tosctVoList.size() != 0 
						&& modifiedTosctVoList.size() != 0 && modifiedTosctVoList != null){
				for(TosctVO tosctVO : tosctVoList){
					if(tosctVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						tosctVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				tosctDtoList = RTETranslator.toTosctDTOList(tosctVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					TosctVO selectedTosct = (TosctVO)tosctVoList.get(i);
					TosctVO editedTosct = (TosctVO) modifiedTosctVoList.get(i);
					TosctVO editedTosctVO = new TosctVO(editedTosct.getDbSvcTypeCd() , editedTosct.getDbPntfrmageNo() , 
							editedTosct.getDbPnttoageNo() , editedTosct.getDbPatientsxCd() , editedTosct.getDbTosCd() ,
							editedTosct.getDbPosCd() , editedTosct.getDbSpclcovgCd() , editedTosct.getDbADACd() ,
							editedTosct.getDbAxcelInd() , editedTosct.getDbToscatCd() , editedTosct.getDbPcpcovInd() , 
							editedTosct.getDbUsageCode() , updatedInd);
					TosctDTO editedTosctDTO = RTETranslator.toTosctDTO(editedTosctVO);
					tosctResultMap = facade.addUpdateTosct(editedTosctDTO, tosctDtoList, i , selectedTosct.getDbUpdatedInd());
					updatedTosctDtoList = (List<TosctDTO>) tosctResultMap.get("tosctDtoList");
					updatedTosctList = RTETranslator.toTosctVOList(updatedTosctDtoList);
					isTosctAddOrUpdated = (Boolean) tosctResultMap.get("isTosctAddorUpdated") ;
					tosctMsg = (String) tosctResultMap.get("tosctMsg") ;
					if(isTosctAddOrUpdated!= true){
						j = takeAction.length;
					}
				}
				lookUpListVO.setTosctVOList(updatedTosctList);
				facade.getApplicationState().setTosctList(updatedTosctList);
			} else {
				throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	
			}
		}else{
			tosctMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setTosctVOList(tosctVoList);
			facade.getApplicationState().setTosctList(tosctVoList);
		}
			mav = new ModelAndView(TOSCT_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("tosctMessage",tosctMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateTosct - tosctMessage: "+ tosctMsg);
		    log.warn("Exit from TosctController - addUpdateTosct()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in TosctController - addUpdateTosct() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addUpdateTosct() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	/**
     * Method to export Tosct look up table to excel work book
     * 
      * @param lookUpTableListVO
     *            list of tosct object.
     * @param response
     *            response object to return
     * @return exported file to view.
     */
     @RequestMapping(value = "/tosctExport", method = RequestMethod.POST)
     public ModelAndView tosctExport(HttpServletResponse response){
           List<TosctVO> tosctList = new LinkedList<TosctVO>();
           LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
     String tosctMsg="";
           try{
                 tosctList = facade.getApplicationState().getTosctList();
                 if(tosctList != null && tosctList.size() != 0){
                 // Key map to create header
                 Map<String,String> keyMap = new LinkedHashMap<String,String>();
                 keyMap.put("dbSvcTypeCd", "Svc Type Cd");
                 keyMap.put("dbADACd", "ADA Cd");
                 keyMap.put("dbPntfrmageNo", "Patient From Age");
                 keyMap.put("dbPnttoageNo", "Patient To Age");
                 keyMap.put("dbPatientsxCd", "Patient Sex Cd");
                 keyMap.put("dbTosCd", "TOS Cd");
                 keyMap.put("dbPosCd", "POS Cd");
                 keyMap.put("dbSpclcovgCd", "Special Coverage Cd");
                 keyMap.put("dbAxcelInd", "Axcel Ind");
                 keyMap.put("dbToscatCd", "TOS Cat Cd");
                 keyMap.put("dbPcpcovInd", "PCP Cov Ind");
                 keyMap.put("dbUsageCode", "Usage code");                 
                 RteIntranetUtils.exportToExcel(response, tosctList, keyMap);
                 tosctMsg = "LookUp table exported successfully.";
                 } else {
                       tosctMsg = "No data found.";
                 }
                 lookUpTableListVO.setTosctVOList(tosctList);
	             mav = new ModelAndView(TOSCT_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
	             mav.addObject("tosctMessage",tosctMsg);
                 return mav;
           }catch (ApplicationException e) {
                 log.error("Exception occured in TosctController - tosctExport() method:"
                             + e.getMessage());
                 String errorMsg = "Error encountered while export to excel. ";
                 errorMsg.concat(e.toString());
                 errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
                 errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
                 return errormav;
           }
     }
	

}
