package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.SitemsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


/**
 * @author N624926
 * Cognizant_Offshore
 */
public class SitemsgDisplayAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(SitemsgDisplayAdapter.class);
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public SitemsgDisplayAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.IN_SITE_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_SVCTYP_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR3, new RowMapper(){
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;				//Used by SiteMsgDisplay, not on database
				SitemsgDTO sitemsgDTO = new SitemsgDTO();
				sitemsgDTO.setDbAuthCertCd(rs.getString(DBConstants.SITEMSG_AUTHCRT_CD));
				sitemsgDTO.setDbResponseCd(rs.getString(DBConstants.SITEMSG_BENRSP_CD));
				sitemsgDTO.setDbCompanyCd(rs.getString(DBConstants.SITEMSG_COMP_CD));
				sitemsgDTO.setDbCustServText(rs.getString(DBConstants.SITEMSG_CUSTSM_TXT));
				sitemsgDTO.setDbInOutNetInd(rs.getString(DBConstants.SITEMSG_IONTWK_CD));
				sitemsgDTO.setDbNetworkIdNo(rs.getString(DBConstants.SITEMSG_NTWK_ID_NO));
				sitemsgDTO.setDbPCPInd(rs.getString(DBConstants.SITEMSG_PCP_IND));
				sitemsgDTO.setDbPlanNtwkCd(rs.getString(DBConstants.SITEMSG_PLNNTW_CD));
				sitemsgDTO.setDbPlanTypeCd(rs.getString(DBConstants.SITEMSG_PLNTYP_CD));
				sitemsgDTO.setDbPostedDate(rs.getString(DBConstants.SITEMSG_POSTED_DT));
				sitemsgDTO.setDbPrvdrText(rs.getString(DBConstants.SITEMSG_PRVDRM_TXT));
				sitemsgDTO.setDbSeqNo(rs.getString(DBConstants.SITEMSG_SEQ_NO));
				sitemsgDTO.setDbSiteCd(rs.getString(DBConstants.SITEMSG_SITE_CD));
				sitemsgDTO.setDbSvcTypeCd(rs.getString(DBConstants.SITEMSG_SVCTYP_CD));
				sitemsgDTO.setDbUpdatedInd(updatedInd);
				return sitemsgDTO;
			}

		}));

	}
	
	
	
	/**
	 * Method to get the SITEMSG list from data store.
	 * 
	 * @param siteCd
	 * 			siteCd parameter
	 * @param svcTypeCode
	 * 			svcTypeCode parameter
	 * 
	 * @return Map of SITEMSG list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map getSitemsgLookUpTable (String siteCd, String svcTypeCode) throws ApplicationException {
		log.warn("Entered SitemsgDisplayAdapter  - getSitemsgLookUpTable");
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map sitemsgMap = new HashMap();
		params.put(DBConstants.IN_SITE_CD, RteIntranetUtils.getTrimmedString(siteCd));
		params.put(DBConstants.IN_SVCTYP_CD, RteIntranetUtils.getTrimmedString(svcTypeCode));
		log.warn(params);
		Map results = null;
		List<SitemsgDTO> sitemsgList = new LinkedList<SitemsgDTO>();
		String newMessage="";
		try {
			log.warn("SitemsgDisplayAdapter: Executing stored procedure : " + "siteCd : " + siteCd + " ; svcTypeCode : "+svcTypeCode);
			results = execute(params);
			log.warn("SitemsgAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results.get(DBConstants.OUT_CODE));
			sitemsgList = (List<SitemsgDTO>) results.get(DBConstants.READ_CURSOR3);	

			if (sitemsgList.isEmpty()){
				
				if (ApplicationConstants.ZERO_0.equals(sqlCode)) {
					newMessage ="No Data on database for Site: " + siteCd + 
							" and Service Type: " + svcTypeCode; 

				} else {
					newMessage = "Problem in DB2. sqlcode: " + sqlCode + " Site: " + siteCd + 
							" Svc Typ Cd: " + svcTypeCode; 
				}			  		  		  
			} else {
				newMessage = "Data found on database for Site: " + siteCd + 
						" and Service Type: " + svcTypeCode;
			}
			sitemsgMap.put("newMessage", newMessage);
			sitemsgMap.put("sitemsgList",sitemsgList);
			return sitemsgMap;
		}catch (Exception exception){
			log.error("SitemsgDisplayAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
		
}	