package com.aetna.prvrte.rteintranet.copybookbean;


public class Dependent {

	Name name;
	String dob;
	String gender;
	String relationship;
	String terminationDate;
	public Name getName() {
		return name;
	}
	public void setName(Name name) {
		this.name = name;
	}
	public String getDob() {
		
		return dob;
	}
	public void setDob(String dob) {
		dob=dob.replaceAll("-", "");
		this.dob = dob;
	}
	public String getGender() {
		
		return gender;
	}
	public void setGender(String gender) {
		
		this.gender = gender;
	}
	public String getRelationship() {
		
		return relationship;
	}
	public void setRelationship(String relationship) {
		
		this.relationship = relationship;
	}
	public String getTerminationDate() {
		
		return terminationDate;
	}
	public void setTerminationDate(String terminationDate) {
		terminationDate=terminationDate.replaceAll("-", "");
		
		this.terminationDate = terminationDate;
	}
	public StringBuilder getDependent(){
		return new StringBuilder(name.getName())
		.append(getDob())
		.append(getDob())
		.append(getGender())
		.append(getRelationship())
		.append(getTerminationDate());
	}
}
