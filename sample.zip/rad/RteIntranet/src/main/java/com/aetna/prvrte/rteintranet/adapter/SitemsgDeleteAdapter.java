package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.SitemsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class SitemsgDeleteAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(SitemsgDeleteAdapter.class);

	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public SitemsgDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		declareParameter(new SqlParameter(DBConstants.LS_COMP_CD, Types.CHAR));// param1
		declareParameter(new SqlParameter(DBConstants.LS_NTWK_ID_NO, Types.INTEGER));// param2
		declareParameter(new SqlParameter(DBConstants.LS_PCP_IND, Types.CHAR));// param3
		declareParameter(new SqlParameter(DBConstants.LS_PLNNTW_CD, Types.CHAR));// param4
		declareParameter(new SqlParameter(DBConstants.LS_PLNTYP_DT, Types.CHAR));// param5
		declareParameter(new SqlParameter(DBConstants.LS_SEQ_NO, Types.SMALLINT));// param6
		declareParameter(new SqlParameter(DBConstants.LS_SITE_CD, Types.CHAR));// param7
		declareParameter(new SqlParameter(DBConstants.LS_SVCTYP_CD, Types.CHAR));// param8
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));// param OUT
	}
	
	
	/**
	 * Method to delete the Sitemsg data from data store.
	 * 
	 * @param sitemsgDTO
	 * 
	 * @return Map of flag to delete the data from Sitemsg list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map deleteSitemsg(SitemsgDTO sitemsgDTO) throws ApplicationException {
		
		log.warn("Entered SitemsgDeleteAdapter  - deleteSitemsg");
		boolean isSitemsgDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map sitemsgMap = new HashMap();
		params.put(DBConstants.LS_COMP_CD, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbCompanyCd()));
		params.put(DBConstants.LS_NTWK_ID_NO, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbNetworkIdNo()));
		params.put(DBConstants.LS_PCP_IND, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbPCPInd()));
		params.put(DBConstants.LS_PLNNTW_CD, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbPlanNtwkCd()));
		params.put(DBConstants.LS_PLNTYP_DT, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbPlanTypeCd()));
		params.put(DBConstants.LS_SEQ_NO, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbSeqNo()));
		params.put(DBConstants.LS_SITE_CD, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbSiteCd()));
		params.put(DBConstants.LS_SVCTYP_CD, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbSvcTypeCd()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("SitemsgAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) 
				isSitemsgDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			sitemsgMap.put("sitemsgMsg", newMessage);
			sitemsgMap.put("isSitemsgDeleted", isSitemsgDeleted);
			return sitemsgMap;
		}catch (Exception exception){
			log.error("SitemsgAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	
}
