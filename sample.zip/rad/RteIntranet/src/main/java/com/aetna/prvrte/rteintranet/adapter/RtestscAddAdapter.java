/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RtestscDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


public class RtestscAddAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RtestscAddAdapter.class);
	
	private static final String SVC_TYP_CD = "SVC_TYP_CD";
	private static final String SCSR_SVC_TYP_CD = "SCSR_SVC_TYP_CD";
	private static final String SCSR_SERVICE_CD = "SCSR_SERVICE_CD";
	private static final String RTE_STSC_EFF_DT = "RTE_STSC_EFF_DT";
	private static final String RTE_STSC_DESC_TXT = "RTE_STSC_DESC_TXT";
	private static final String RTE_STSC_EXP_DT = "RTE_STSC_EXP_DT";
	private static final String RTE_STSC_POSTED_DTS = "RTE_STSC_POSTED_DTS";
	private static final String APPL_USER_ID = "APPL_USER_ID";
	private static final String LS_ADD_UPDATE = "LS_ADD_UPDATE";
	private static final String LS_SQLCODE = "LS_SQLCODE";
	
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtestscAddAdapter(DataSource datasource, String storedProc) throws SQLException{
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(SVC_TYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(SCSR_SVC_TYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(SCSR_SERVICE_CD, Types.CHAR));
		declareParameter(new SqlParameter(RTE_STSC_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(RTE_STSC_DESC_TXT, Types.VARCHAR));
		declareParameter(new SqlParameter(RTE_STSC_EXP_DT, Types.DATE));
		declareParameter(new SqlParameter(RTE_STSC_POSTED_DTS, Types.TIMESTAMP));
		declareParameter(new SqlParameter(APPL_USER_ID, Types.CHAR));
		
		declareParameter(new SqlOutParameter(LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(LS_SQLCODE, Types.INTEGER));
		
	}
	
	
	/**
	 * 
	 * @param rtestscDTO	
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	public Map addNewRtestsc(RtestscDTO rtestscDTO) throws ApplicationException {
		
		log.warn("Entered RtestscAddAdapter  - addNewRtestsc");
		
		String newMessage ="";
		Map results = null;
		Map<String, Object> params = new java.util.HashMap<String, Object>();
		Map rtestscMap = new HashMap();
		
		params.put(SVC_TYP_CD, RteIntranetUtils.getTrimmedString(rtestscDTO.getSvcTypeCd()));
		params.put(SCSR_SVC_TYP_CD, RteIntranetUtils.getTrimmedString(rtestscDTO.getScsrSvcTypeCd()));
		params.put(SCSR_SERVICE_CD, RteIntranetUtils.getTrimmedString(rtestscDTO.getScsrServiceCd()));
		params.put(RTE_STSC_EFF_DT, RteIntranetUtils.getTrimmedString(rtestscDTO.getEffDate()));
		params.put(RTE_STSC_DESC_TXT, RteIntranetUtils.getTrimmedString(rtestscDTO.getStscDescTxt()));
		params.put(RTE_STSC_EXP_DT, RteIntranetUtils.getTrimmedString(rtestscDTO.getExpDate()));
		params.put(RTE_STSC_POSTED_DTS, RteIntranetUtils.getTrimmedString(rtestscDTO.getPostedDateTimestamp()));
		params.put(APPL_USER_ID, RteIntranetUtils.getTrimmedString(rtestscDTO.getUserId()));
		log.warn(params);	
		
		try {
					
			results = execute(params);
			log.warn("RtestscAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(LS_SQLCODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) {
				
				List<RtestscDTO> rtestscList = new LinkedList<RtestscDTO>();
				rtestscList.add(rtestscDTO);
				rtestscMap.put("rtestscList", rtestscList);
				if (" ".equalsIgnoreCase(actionCode)) {
					newMessage = "This row added to the database";
				}else {
					newMessage ="Row already exists on the database. It was updated with these values.";					
					rtestscDTO.setUpdatedInd(ApplicationConstants.COPY);
				}				
				}
			else {
				newMessage = "Unable to add row to the database. SQLCODE = " + sqlCode;
			}
			
			rtestscMap.put("rtestscMessage", newMessage);
							
		return rtestscMap;
	}catch (Exception exception){
		log.error("RtestscAddAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}
	
	
	@SuppressWarnings("unchecked")
	public Map addUpdateRtestsc(RtestscDTO existingRtestsc,
			List<RtestscDTO> rtestscDtoList, int index, char currUpdateInd) throws ApplicationException{
		log.warn("Entered RtestscAddAdapter  - addUpdateRtestsc");
		boolean isRtestscAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, Object> params = new java.util.HashMap<String, Object>();
		Map rtestscMap = new HashMap();
		

		params.put(SVC_TYP_CD, RteIntranetUtils.getTrimmedString(existingRtestsc.getSvcTypeCd()));
		params.put(SCSR_SVC_TYP_CD, RteIntranetUtils.getTrimmedString(existingRtestsc.getScsrSvcTypeCd()));
		params.put(SCSR_SERVICE_CD, RteIntranetUtils.getTrimmedString(existingRtestsc.getScsrServiceCd()));
		params.put(RTE_STSC_EFF_DT, RteIntranetUtils.getTrimmedString(existingRtestsc.getEffDate()));
		params.put(RTE_STSC_DESC_TXT, RteIntranetUtils.getTrimmedString(existingRtestsc.getStscDescTxt()));
		params.put(RTE_STSC_EXP_DT, RteIntranetUtils.getTrimmedString(existingRtestsc.getExpDate()));
		params.put(RTE_STSC_POSTED_DTS, RteIntranetUtils.getTrimmedString(existingRtestsc.getPostedDateTimestamp()));
		params.put(APPL_USER_ID, RteIntranetUtils.getTrimmedString(existingRtestsc.getUserId()));
		log.warn(params);	
		
		try {
					
			results = execute(params);
			log.warn("RtestscAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(LS_SQLCODE));
			if ("0".equalsIgnoreCase(sqlCode)) {
				isRtestscAddorUpdated = true;
				if ("A".equalsIgnoreCase(actionCode)) {
					
					if (currUpdateInd == ApplicationConstants.COPY)						
						rtestscDtoList.set(index, existingRtestsc);						
					else
						rtestscDtoList.add(existingRtestsc);
				}
				else
					rtestscDtoList.set(index, existingRtestsc);
				
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			rtestscMap.put("rtestscMessage",newMessage);
			rtestscMap.put("rtestscDtoList",rtestscDtoList);
			rtestscMap.put("isrtestscAddorUpdated", isRtestscAddorUpdated);
			return rtestscMap;
		}catch (Exception exception){
			log.error("RtestscAddAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
}
