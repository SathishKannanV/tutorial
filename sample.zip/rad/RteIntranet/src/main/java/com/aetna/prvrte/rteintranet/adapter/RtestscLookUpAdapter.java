/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RtestscDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;

public class RtestscLookUpAdapter extends StoredProcedure {

	private final Log log = LogFactory.getLog(RtestscLookUpAdapter.class);
	
	private static final String SVC_TYPE_CD = "SVC_TYPE_CD";
	private static final String SCSR_SVC_TYP_CD = "SCSR_SVC_TYP_CD";
	private static final String SCSR_SERVICE_CD = "SCSR_SERVICE_CD";
	private static final String LS_SQLCODE = "LS_SQLCODE";
	private static final String READ_CURSOR = "READ_CURSOR1";
	
	
	public RtestscLookUpAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(SVC_TYPE_CD, Types.CHAR));
		declareParameter(new SqlParameter(SCSR_SVC_TYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(SCSR_SERVICE_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(LS_SQLCODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;			//Used by RBBCDisplay, not on database
				RtestscDTO rtestscDTO = new RtestscDTO();
				rtestscDTO.setSvcTypeCd(rs.getString("SVC_TYPE_CD"));
				rtestscDTO.setScsrSvcTypeCd(rs.getString("SCSR_SVC_TYP_CD"));
				rtestscDTO.setScsrServiceCd(rs.getString("SCSR_SERVICE_CD"));
				rtestscDTO.setEffDate(rs.getString("RTE_STSC_EFF_DT"));
				rtestscDTO.setStscDescTxt(rs.getString("RTE_STSC_DESC_TXT"));
				rtestscDTO.setExpDate(rs.getString("RTE_STSC_EXP_DT"));
				rtestscDTO.setPostedDateTimestamp(rs.getString("RTE_STSC_POSTED_DTS"));
				rtestscDTO.setUserId(rs.getString("APPL_USER_ID"));
				rtestscDTO.setUpdatedInd(updatedInd);
				return rtestscDTO;
			}

		}));

	}
	
	@SuppressWarnings("unchecked")
	public Map getRtestscLookUpTable (RtestscDTO rtestscDTO) throws ApplicationException {
		log.warn("Entered RtestscLookUpAdapter  - getRtestscLookUp");
		//It fetches rtestsc list based on the criteria selected by user
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map rtestscMap = new HashMap();
		String querySvcTypeCd =rtestscDTO.getSvcTypeCd();
		String queryScsrSvcTypeCd = rtestscDTO.getScsrSvcTypeCd();
		String queryScsrServiceCd = rtestscDTO.getScsrServiceCd();
		params.put(SVC_TYPE_CD, querySvcTypeCd);
		params.put(SCSR_SVC_TYP_CD, queryScsrSvcTypeCd);
		params.put(SCSR_SERVICE_CD,queryScsrServiceCd );
		log.warn(params);
		Map results = null;
		
		List<RtestscDTO> rtestscList = new LinkedList<RtestscDTO>();
		String newMessage="";
		
		try {
			
			results = execute(params);
			log.warn("RtestscLookUpAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(LS_SQLCODE));
			
			rtestscList = (List<RtestscDTO>) results
					.get(READ_CURSOR);	
			if (null != results) {
			if (rtestscList.isEmpty()){
				
				if ("0".equals(sqlCode)) {
					newMessage = "No Data on database for SVC Type Cd: " + querySvcTypeCd
							+ ", SCSR SVC Type Cd: " + queryScsrSvcTypeCd
							+ ", SCSR Service Cd: " + queryScsrServiceCd;
				} else {
					newMessage = "Problem in DB2. sqlcode: " + sqlCode +
							" SVC Type Cd: " + querySvcTypeCd
							+ ", SCSR SVC Type Cd: " + queryScsrSvcTypeCd
							+ ", SCSR Service Cd: " + queryScsrServiceCd; 
				}			  		  		  
			} else {
				newMessage = "Data found on database for SVC Type Cd: " + querySvcTypeCd
						+ ", SCSR SVC Type Cd: " + queryScsrSvcTypeCd
						+ ", SCSR Service Cd: " + queryScsrServiceCd;
			}
			}else{
				newMessage = "No Data found on the table.";
			}
			rtestscMap.put("rtestscMessage", newMessage);
			rtestscMap.put("rtestscList",rtestscList);
			return rtestscMap;
		}catch (Exception exception){
			log.error("RtestscLookUpAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
		
	}
}
