package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;

public class SbmrdepVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2248471048148932448L;
	private String convIdCode = new String();
	private String vanIdCd = new String();
	private String typeCd = new String();
	private String	cumbIdNo =new String();
	private String tranType = new String();
	private String postedDt = new String();
	public SbmrdepVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SbmrdepVO(String convIdCode, String vanIdCd, String typeCd,
			String cumbIdNo, String tranType, String postedDt) {
		super();
		this.convIdCode = convIdCode;
		this.vanIdCd = vanIdCd;
		this.typeCd = typeCd;
		this.cumbIdNo = cumbIdNo;
		this.tranType = tranType;
		this.postedDt = postedDt;
	}
	public String getConvIdCode() {
		return convIdCode;
	}
	public void setConvIdCode(String convIdCode) {
		this.convIdCode = convIdCode;
	}
	public String getVanIdCd() {
		return vanIdCd;
	}
	public void setVanIdCd(String vanIdCd) {
		this.vanIdCd = vanIdCd;
	}
	public String getTypeCd() {
		return typeCd;
	}
	public void setTypeCd(String typeCd) {
		this.typeCd = typeCd;
	}
	public String getCumbIdNo() {
		return cumbIdNo;
	}
	public void setCumbIdNo(String cumbIdNo) {
		this.cumbIdNo = cumbIdNo;
	}
	public String getTranType() {
		return tranType;
	}
	public void setTranType(String tranType) {
		this.tranType = tranType;
	}
	public String getPostedDt() {
		return postedDt;
	}
	public void setPostedDt(String postedDt) {
		this.postedDt = postedDt;
	}
	

}
