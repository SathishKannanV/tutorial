/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class AetCtlsDisplayAdapter extends StoredProcedure {

	public AetCtlsDisplayAdapter() {}

	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(AetCtlsDisplayAdapter.class);
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	@SuppressWarnings("rawtypes")
	public AetCtlsDisplayAdapter(DataSource datasource, String storedProc)
			throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of AdasvctAdapter : " + storedProc);
		declareParameter(new SqlParameter(DBConstants.IN_CTL_NO, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));

		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR4, new RowMapper() {
			/*
			 * (non-Javadoc)
			 * 
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet , int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				String  aeCtl = RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.AETCTLS_CTL_NO));
				return aeCtl;
			}
		}));
	}
	
	/**
	 * Method to get the AetCtls list from data store.
	 * 
	 * @param aetCtl
	 *            String of aetna id.
	 * @return Map of AetCtls list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getAetCtlsLookUpList(String aetCtl) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering getAdasvctLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, String> params = new LinkedHashMap<String, String>();
		List<String> aetCtlsList = new ArrayList<String>();
		String newMessage = "";
		try {
			params.put(DBConstants.IN_CTL_NO, aetCtl);
			log.info("Params for getting Adasvct LookUp List : " + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.OUT_CODE));
				if ("0".equals(sqlCode)){
					aetCtlsList =  (ArrayList<String>) results.get(DBConstants.READ_CURSOR4);
					if (aetCtlsList.isEmpty()){
						newMessage = "Control # " + aetCtl + " not found on database.";
					} else {
						newMessage = aetCtlsList.size() + " Control(s) found on the Database.";
					}
				} else {
					newMessage = "Problem in DB2. sqlcode: " + sqlCode + ". You asked for Control # " + aetCtl;
				}
			resultMap.put("aetCtlsMsg", newMessage);
			resultMap.put("aetCtlsList", aetCtlsList);
			return resultMap;
			
		} catch (DataAccessException dae) {
			log.error("AetCtlsDisplayAdapter : Data access excpetion occured " + dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("AetCtlsDisplayAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} finally {

		}
	}
}
