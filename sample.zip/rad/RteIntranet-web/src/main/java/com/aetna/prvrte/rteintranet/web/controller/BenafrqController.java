/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.BenafrqDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.BenafrqVO;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;

/**
 * <h1>Benafrq Controller</h1> The Benafrq Controller is responsible for handling
 * the actual request from DispatcherServlet and returning an appropriate
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * @version 0.0.0
 * @since November 10, 2014
 * @author N726899 
 * 
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/benafrq/*")
public class BenafrqController {
	/*
	 * Instance of logger for BenafrqController.
	 */
	private static final Log log = LogFactory.getLog(BenafrqController.class);
	/*
	 * Tile name of the Benafrq home view.
	 */
	public static final String BENAFRQ_HOME = ".benafrqHome";
	/*
	 * Tile name of the Benafrq display view.
	 */
	public static final String BENAFRQ_DISPLAY = ".benafrqDisplay";
	/*
	 * Tile name of the  add new Benafrq form view.
	 */
	public static final String BENAFRQ_ADD_NEW = ".addBenafrq";
	/*
	 * Instance of Facade.
	 */
	@Autowired(required = true)
	private Facade facade;
	/*
	 * Model and view of success operation.
	 */
	private ModelAndView modelAndView;
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errorModelAndView;

	/**
	 * Method to display benafrqLookup view.
	 * 
	 * @param model
	 *            model to set the instance of benafrq for view
	 * 
	 * @return view of benafrqLookUp, if fails return error page
	 */
	@RequestMapping(value = "/benafrqHome", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView getBenafrqLookUp(HttpServletRequest request) {
		try {
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView = new ModelAndView(BENAFRQ_HOME, "benafrqVO", new BenafrqVO());
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in BenafrqController - getBenafrqLookUp() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_LOOKUP_VIEW + "(BenafrqController)" + RteIntranetUtils.getTrimmedString(e.getMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}
	

	/**
	 * Method to get the benafrqLookUp List from data store.
	 * 
	 * @param benafrqVO
	 *            form view object of benafrq.
	 * @return view of benafrqDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/benafrqLookUp", method = RequestMethod.POST)
	public ModelAndView getBenafrqLookUpList(@ModelAttribute("benafrqForm") BenafrqVO benafrqVO,
			HttpServletRequest request) {
		try {
			BenafrqDTO benafrqDTO = RTETranslator.toBenafrqDTO(benafrqVO);
			Map<String, Object> benafrqlookUpMap = facade.getBenafrqLookUpList(benafrqDTO);
			
			//set AvasvctVOList in application state, after getting look up list.
			List<BenafrqVO> benafrqList = (List<BenafrqVO>) benafrqlookUpMap.get("benafrqList");
			LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
			lookUpTableListVO.setBenafrqVOList(benafrqList);
			facade.getApplicationState().setBenafrqVOList(benafrqList);
			
			modelAndView = new ModelAndView(BENAFRQ_DISPLAY, "lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("benafrqMsg",benafrqlookUpMap.get("benafrqMsg"));
			modelAndView.addObject("benafrqList", benafrqList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e) {
			log.error("Exception occured in BenafrqController - getBenafrqLookUp() method:"	+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(BenafrqController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to display get add new Benafrq form home view.
	 * 
	 * @return view of addBenafrqForm, if fails return error page
	 */
	@RequestMapping(value = "/addBenafrqForm", method = RequestMethod.POST)
	public ModelAndView getAddNewBenafrqFormHome(HttpServletRequest request) {
		try {
			modelAndView = new ModelAndView(BENAFRQ_ADD_NEW, "benafrqVO", new BenafrqVO());
			String securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in BenafrqController - getAddNewBenafrqFormHome() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_VIEW + "(BenafrqController)" + e.toString();
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the benafrqLookUp List from data store.
	 * 
	 * @param benafrqVO
	 *            form view object of benafrq.
	 * @return view of benafrqDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addBenafrq", method = RequestMethod.POST)
	public ModelAndView addBenafrq(final HttpServletRequest request, @ModelAttribute("addBenafrqForm") BenafrqVO benafrqVO) {
		try {
			BenafrqDTO benafrqDTO = RTETranslator.toBenafrqDTO(benafrqVO);
			Map<String, Object> benafrqlookUpMap = facade.addBenafrqToDb(benafrqDTO);
			List<BenafrqVO> benafrqList = (List<BenafrqVO>) benafrqlookUpMap.get("benafrqList");
			LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
			lookUpTableListVO.setBenafrqVOList(benafrqList);
			modelAndView = new ModelAndView(BENAFRQ_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("benafrqMsg", benafrqlookUpMap.get("benafrqMsg"));
			modelAndView.addObject("benafrqList", benafrqList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e) {
			log.error("Exception occured in BenafrqController - addBenafrq() method:"+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_ROW + "(BenafrqController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the benafrqLookUp List from data store.
	 * 
	 * @param benafrqVO
	 *            form view object of benafrq.
	 * @param model
	 *            model to set the instance of benafrq for view
	 * @param takeAction
	 * 
	 * @return view of benafrqDisplay
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/deleteBenafrq", method = RequestMethod.POST)
	public ModelAndView deleteBenafrq(@RequestParam(required = false) String[] takeAction,
		HttpServletRequest request,	@ModelAttribute("benafrqDisplay")LookUpTableListVO lookUpTableListVO) {
		try {
			int index;
			boolean isBenafrqDeleted = true;
			Map<String, Object> benafrqlookUpMap = new HashedMap();
			List<BenafrqVO> benafrqList = new LinkedList<BenafrqVO>();
			String benafrqMsg = "";
			benafrqList = lookUpTableListVO.getBenafrqVOList();
			if(takeAction != null && takeAction.length != 0){
				if (benafrqList != null && benafrqList.size() != 0) {
					List<BenafrqDTO> updatedBenafrqList = RTETranslator.toBenafrqDTOList(benafrqList);
					for (int j = takeAction.length - 1; j >= 0; j--) {
						index = Integer.parseInt(takeAction[j]);
						BenafrqDTO existingBenafrq = (BenafrqDTO) updatedBenafrqList.get(index);
						if (existingBenafrq.getUpdatedInd() != ApplicationConstants.COPY) {
							String defacumAccumCd = existingBenafrq.getDefacumAccumCd();
							String benafrqAfreqCd = existingBenafrq.getBenafrqAfreqCd();
							String hmobBenefitCd = existingBenafrq.getHmobBenefitCd();
							benafrqlookUpMap = facade.deleteBenafrq(defacumAccumCd, benafrqAfreqCd,hmobBenefitCd);
							benafrqMsg = (String) benafrqlookUpMap.get("benafrqMsg");
							isBenafrqDeleted = (Boolean) benafrqlookUpMap.get("isBenafrqDeleted");
							
							if(isBenafrqDeleted == true){
								benafrqList.remove(index);
							}else{
								j = 0;
							}
						} else { //update ind = 'C'. Change not written to DB yet, just delete from local object.
							benafrqList.remove(index);
						}
						
					}
					if(isBenafrqDeleted == true)
						benafrqMsg = ApplicationConstants.ROWS_DELETED;
				}
			} else {
				benafrqMsg = ApplicationConstants.NO_ACTION_TAKEN;
			}
			//update benafrqList in application state.
			facade.getApplicationState().setBenafrqVOList(benafrqList);
			modelAndView = new ModelAndView(BENAFRQ_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("benafrqMsg",benafrqMsg);
			modelAndView.addObject("benafrqList",benafrqList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in BenafrqController - deleteBenafrq() method:"+e.getErrorMessage());
            String errorMsg =ApplicationConstants.ERROR_GET_LOOKUP + "(BenafrqController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
      }
	}

	/**
	 * Method to get the benafrqLookUp List from data store.
	 * 
	 * @param benafrqVO
	 *            form view object of benafrq.
	 * @param actionTaken
	 *            List of takeAction to copy the row
	 * @return view of benafrqDisplay
	 */
	@RequestMapping(value = "/copyBenafrq", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView copyBenafrq(@ModelAttribute("benafrqDisplay")LookUpTableListVO lookUpTableListVO,@RequestParam(required = false) String[] takeAction
			, HttpServletRequest request) {
		int index;
		String benafrqMsg ="";
		List<BenafrqVO> benafrqList = new LinkedList<BenafrqVO>();
		try {
			benafrqList = lookUpTableListVO.getBenafrqVOList();
			if(takeAction != null && takeAction.length != 0){
				if(benafrqList != null && benafrqList.size() != 0){
					for (int j = 0; j < takeAction.length; j++) {
						index = Integer.parseInt(takeAction[j]);
						BenafrqVO existingBenafrq = (BenafrqVO) benafrqList.get(index);
						BenafrqVO copiedBenafrqVO =  (BenafrqVO) SerializationUtils.clone(existingBenafrq);
						String postedDateTimestamp = RteIntranetUtils.getTodaysDateTime();
						copiedBenafrqVO.setUpdatedInd(ApplicationConstants.COPY);
						copiedBenafrqVO.setPostedDateTimestamp(postedDateTimestamp);
						benafrqList.add(copiedBenafrqVO);
					}
					benafrqMsg = ApplicationConstants.ROWS_COPIED;
				}
			} else {
				benafrqMsg = ApplicationConstants.NO_ACTION_TAKEN;
			}
			//update benafrqVOList in application state.
			facade.getApplicationState().setBenafrqVOList(benafrqList);
			lookUpTableListVO.setBenafrqVOList(benafrqList);
			modelAndView = new ModelAndView(BENAFRQ_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("benafrqMsg",benafrqMsg);
			modelAndView.addObject("benafrqList",benafrqList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in BenafrqController - copyBenafrq() method:"
					+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(BenafrqController)" + RteIntranetUtils.getTrimmedString(e.getMessage());
			modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,
					errorMsg);
			return modelAndView;
		}
	}

	/**
	 * Method to get the benafrqLookUp List from data store.
	 * 
	 * @param takeAction
	 *            list of selected indexes from view.
	 * @param request
	 *            request object.
	 * @return view of benafrqDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addUpdateBenafrq", method = RequestMethod.POST)
	public ModelAndView addUpdateBenafrq(@RequestParam(required = false) String[] takeAction,
			@ModelAttribute("benafrqDisplay")LookUpTableListVO lookUpTableListVO,HttpServletRequest request) {
		int index;
		
		List<BenafrqVO> benafrqList = new LinkedList<BenafrqVO>();
		List<BenafrqVO> modifiedBenafrqList = new LinkedList<BenafrqVO>();
		Map<String, Object> benafrqlookUpMap = new HashedMap();
		String benafrqMsg = "";
		boolean isAddUpdateCleanUp = false;
		try {
			modifiedBenafrqList = lookUpTableListVO.getBenafrqVOList();
			//get Benafrq VO list from application state to update the display record.
			benafrqList = facade.getApplicationState().getBenafrqVOList();
			if(benafrqList != null && benafrqList.size() != 0){
				for(BenafrqVO benafrqVO : benafrqList){
					if(benafrqVO.getUpdatedInd() == ApplicationConstants.UPDATE_IND_Y){
						benafrqVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
			}
			
			if(takeAction != null && takeAction.length != 0){ 
				List<BenafrqDTO> benafrqDTOList = RTETranslator.toBenafrqDTOList(benafrqList);
				if (benafrqDTOList != null && benafrqDTOList.size() != 0
						&& modifiedBenafrqList != null && modifiedBenafrqList.size() != 0) {
					String userId = RteIntranetUtils.getUserId(request); //Ex: n242716
						for (int j = 0; j < takeAction.length; j++) {
							index = Integer.parseInt(takeAction[j]);
							BenafrqDTO updatedBenafrqDTO = RTETranslator.toBenafrqDTO(modifiedBenafrqList.get(index));
							updatedBenafrqDTO.setUserId(userId);
							benafrqlookUpMap = facade.addUpdateBenafrq(updatedBenafrqDTO, benafrqDTOList, index);
							List<BenafrqDTO> benafrqDtoList = (List<BenafrqDTO>) benafrqlookUpMap.get("benafrqList");
							benafrqList = RTETranslator.toBenafrqVOList(benafrqDtoList);
							boolean isBenafrqAddorUpdated = (Boolean) benafrqlookUpMap.get("isBenafrqAddorUpdated");
							benafrqMsg = (String) benafrqlookUpMap.get("benafrqMsg");
							isAddUpdateCleanUp = (Boolean) benafrqlookUpMap.get("isAddUpdateCleanUp");
							if(isBenafrqAddorUpdated){
								j = takeAction.length;
							}
						}
						if(isAddUpdateCleanUp){
							benafrqMsg = ApplicationConstants.ADD_UPDATE_ROWS;
							
							String xHmoBenefitCd, yHmoBenefitCd, xEffDate, yEffDate;
							for (int x = benafrqList.size() - 1 ; x > 0;  x--) {
								BenafrqVO xBenafrq = (BenafrqVO) benafrqList.get(x);
								xHmoBenefitCd = xBenafrq.getHmobBenefitCd();
								xEffDate = xBenafrq.getEffDate();
								if (xBenafrq.getUpdatedInd() != ApplicationConstants.COPY) {
									for (int y = x - 1; y > -1; y--) {
										BenafrqVO aBenafrq = (BenafrqVO) benafrqList.get(y);
										yHmoBenefitCd = aBenafrq.getHmobBenefitCd();
										yEffDate = aBenafrq.getEffDate();
										if (xHmoBenefitCd.equals(yHmoBenefitCd) && xEffDate.equals(yEffDate)) {
											benafrqList.remove(y); 
											x--;
										}
									}
								}
							}
						}
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);
				}
			} else {
				benafrqMsg = ApplicationConstants.NO_ACTION_TAKEN;
			}
			//update AvasvctVOList in application state.
			facade.getApplicationState().setBenafrqVOList(benafrqList);
			
			lookUpTableListVO.setBenafrqVOList(benafrqList);
			modelAndView = new ModelAndView(BENAFRQ_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("benafrqMsg",benafrqMsg);
			modelAndView.addObject("benafrqList",benafrqList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in BenafrqController - addUpdateBenafrq() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(BenafrqController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
      }
	}
	
	/**
	 * Method to export Benafrq look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of benafrq object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/benafrqExport", method = RequestMethod.POST)
	public ModelAndView benafrqExport(HttpServletResponse response){
		String benafrqMsg="";
		List<BenafrqVO> benafrqList = new LinkedList<BenafrqVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		try{
			benafrqList = facade.getApplicationState().getBenafrqVOList();
			if(benafrqList != null && benafrqList.size() != 0){
				// Key map to create header
				Map<String,String> keyMap = new LinkedHashMap<String,String>();
				keyMap.put("defacumAccumCd", "Accum CD");
				keyMap.put("benafrqAfreqCd", "Frequency CD");
				keyMap.put("hmobBenefitCd", "Benefit CD");
				keyMap.put("benafrqLmtTxt", "Freq Lmt Txt");
				keyMap.put("rtebeplmEplcCd", "EPLC Cd");
				keyMap.put("effDate", "Effective Date");
				keyMap.put("expDate", "Expiration Date");
				keyMap.put("postedDateTimestamp", "Posted Date");
				keyMap.put("userId", "User Id");
				
				RteIntranetUtils.exportToExcel(response, benafrqList, keyMap);
				benafrqMsg = ApplicationConstants.EXPORT_SUCCESS;
			} else {
				benafrqMsg = ApplicationConstants.NO_DATA;;
			}
			lookUpTableListVO.setBenafrqVOList(benafrqList);
	        modelAndView = new ModelAndView(BENAFRQ_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
	        modelAndView.addObject("benafrqMsg",benafrqMsg);
		    return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in BenafrqController - benafrqExport() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_EXPOT_TABLE + "(BenafrqController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
      }
	}
}
