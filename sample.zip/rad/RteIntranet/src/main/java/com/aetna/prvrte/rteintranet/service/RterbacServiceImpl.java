/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.aetna.prvrte.rteintranet.dao.RterbacDAO;
import com.aetna.prvrte.rteintranet.dto.RterbacDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import org.springframework.stereotype.Service;

@Service
public class RterbacServiceImpl implements RterbacService {

	@Autowired(required=true)
	private RterbacDAO rterbacDAO;

	@Override
	public Map getRterbacLookUp(RterbacDTO rterbacDTO) throws ApplicationException {
		return rterbacDAO.getRterbacLookUp(rterbacDTO);
	}

	@Override
	public Map addNewRterbac(RterbacDTO rterbacDTO) throws ApplicationException {
		return rterbacDAO.addNewRterbac(rterbacDTO);
	}

	@Override
	public Map deleteRterbac(RterbacDTO rterbacDTO)
			throws ApplicationException {
		return rterbacDAO.deleteRterbac(rterbacDTO);
	}

	@Override
	public Map addUpdateRterbac(RterbacDTO modifiedRterbacDTO, List<RterbacDTO> rterbacDtoList,
			int index) throws ApplicationException {
		return rterbacDAO.addUpdateRterbac(modifiedRterbacDTO,rterbacDtoList, index);
	}
}
