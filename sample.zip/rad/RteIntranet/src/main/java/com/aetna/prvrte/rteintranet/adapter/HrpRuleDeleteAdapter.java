package com.aetna.prvrte.rteintranet.adapter;



import java.sql.Types;

import java.util.HashMap;

import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;

import org.apache.commons.logging.LogFactory;

import org.springframework.jdbc.core.SqlOutParameter;

import org.springframework.jdbc.core.SqlParameter;

import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.HrpRuleDTO;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;

import com.aetna.prvrte.rteintranet.util.ApplicationConstants;

import com.aetna.prvrte.rteintranet.util.DBConstants;

import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;



/**

 * @author N801539

 * Cognizant_Offshore

 */

public class HrpRuleDeleteAdapter extends StoredProcedure{

	/**

	 * Instance of Log Factory.

	 */

	private final Log log = LogFactory.getLog(HrpRuleDeleteAdapter.class);





	/**

	 * 

	 * @param datasource

	 * @param storedProc

	 * @throws SQLException

	 */

	public HrpRuleDeleteAdapter(DataSource datasource, String storedProc) {

		super(datasource, storedProc);

		declareParameter(new SqlParameter(DBConstants.HRPRL_SVTYP_CD, Types.CHAR));// param1

		declareParameter(new SqlParameter(DBConstants.HRPRL_RL_CD, Types.CHAR));// param2

		declareParameter(new SqlParameter(DBConstants.HRPRL_EFF_DT, Types.DATE));// param3
		
		declareParameter(new SqlParameter(DBConstants.HRPRL_TERM_DT, Types.DATE));// param4

		declareParameter(new SqlParameter(DBConstants.HRPRL_ST_CD, Types.CHAR));// param5

		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));// param OUT

	}

	

	/**

	 * Method to delete the HrpRule data from data store.

	 * 

	 * @param hrpruleDTO

	 * 

	 * @return Map of flag to delete the data from HrpRule list and success or

	 *         error message.

	 * @exception ApplicationException

	 *             if deletion fails.

	 */

	@SuppressWarnings("unchecked")

	public Map deleteHrpRule(HrpRuleDTO hrpruleDTO) throws ApplicationException {

		

		log.warn("Entered HrpRuleDeleteAdapter  - deleteHrpRule");

		boolean isHrpRuleDeleted = false;

		String newMessage ="";

		Map results = null;

		Map<String, String> params = new java.util.LinkedHashMap<String, String>();

		Map hrpruleMap = new HashMap();

		params.put(DBConstants.HRPRL_SVTYP_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlSvcTyp()));

		params.put(DBConstants.HRPRL_RL_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlRulecd()));

		params.put(DBConstants.HRPRL_EFF_DT, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlEffdt()));
		
		params.put(DBConstants.HRPRL_TERM_DT, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlTermdt()));

		params.put(DBConstants.HRPRL_ST_CD,  RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlStatecd()));

		log.warn(params);	

		try {
			
			log.warn("HrpRuleAdapter: Starting stored procedure");

			results = execute(params);

			log.warn("HrpRuleAdapter: Executed stored procedure");


			String sqlCode =  String.valueOf(results.get(DBConstants.LS_SQLCODE));

			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) 

				isHrpRuleDeleted = true;

			else {

				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;

			}

			hrpruleMap.put("hrpruleMsg", newMessage);

			hrpruleMap.put("isHrpRuleDeleted", isHrpRuleDeleted);

			return hrpruleMap;

		}catch (Exception exception){

			

			log.error("HrpRuleAdapter : generic error occured  "+exception);

			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);

		}

	}

	

}

