/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.RbbcDAO;
import com.aetna.prvrte.rteintranet.dto.RbbcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author n657186
 * Cognizant_Offshore
 */

@Service
public class RbbcServiceImpl implements RbbcService{
	@Autowired(required=true)
	private RbbcDAO rbbcDAO;

	@Override
	public Map getRbbcLookUp(RbbcDTO rbbcDTO) throws ApplicationException {
		return rbbcDAO.getRbbcLookUp(rbbcDTO);
	}

	@Override
	public Map addNewRbbc(RbbcDTO rbbcDTO) throws ApplicationException {
		return rbbcDAO.addNewRbbc(rbbcDTO);
	}

	@Override
	public Map deleteRbbc(String rbbcCd, String svcTypeCd)
			throws ApplicationException {
		return rbbcDAO.deleteRbbc(rbbcCd,svcTypeCd);
	}

	@Override
	public Map addUpdateRbbc(RbbcDTO existRbbcDTO, List<RbbcDTO> rbbcDtoList,
			int index, char updateInd) throws ApplicationException {
		return rbbcDAO.addUpdateRbbc(existRbbcDTO,rbbcDtoList, index, updateInd);
	}

}
