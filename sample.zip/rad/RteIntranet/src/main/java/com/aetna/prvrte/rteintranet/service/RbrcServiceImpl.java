/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.RbrcDAO;
import com.aetna.prvrte.rteintranet.dto.RbrcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 * Cognizant_Offshore
 */

@Service
public class RbrcServiceImpl implements RbrcService {

	@Autowired(required=true)
	private RbrcDAO rbrcDAO;

	@Override
	public Map getRbrcLookUp(RbrcDTO rbrcDTO) throws ApplicationException {
		return rbrcDAO.getRbrcLookUp(rbrcDTO);
	}

	@Override
	public Map addNewRbrc(RbrcDTO rbrcDTO) throws ApplicationException {
		return rbrcDAO.addNewRbrc(rbrcDTO);
	}

	@Override
	public Map deleteRbrc(RbrcDTO rbrcDTO)
			throws ApplicationException {
		return rbrcDAO.deleteRbrc(rbrcDTO);
	}

	@Override
	public Map addUpdateRbrc(RbrcDTO existRbrcDTO, List<RbrcDTO> rbrcDtoList,
			int index, char updateInd) throws ApplicationException {
		return rbrcDAO.addUpdateRbrc(existRbrcDTO,rbrcDtoList, index, updateInd);
	}
}
