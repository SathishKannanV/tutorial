/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.RtedictrAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.RtedictrDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.RtedictrLookUpAdapter;
import com.aetna.prvrte.rteintranet.dto.RtedictrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 * Cognizant_Offshore
 */
@Repository
public class RtedictrDAOImpl implements RtedictrDAO {

	@Autowired(required=true)
	private RtedictrLookUpAdapter rtedictrLookUpAdapter;
	
	@Autowired(required=true)
	private RtedictrAddAdapter rtedictrAddAdapter;
	
	@Autowired(required=true)
	private RtedictrDeleteAdapter rtedictrDeleteAdapter;
	
	@Override
	public Map getRtedictrLookUp(RtedictrDTO rtedictrDTO) throws ApplicationException {
		return rtedictrLookUpAdapter.getRtedictrLookUpTable(rtedictrDTO);
	}
	@Override
	public Map addNewRtedictr(RtedictrDTO rtedictrDTO) throws ApplicationException {
		return rtedictrAddAdapter.addNewRtedictr(rtedictrDTO);
	}
	

	@Override
	public Map deleteRtedictr(RtedictrDTO rtedictrDTO)
			throws ApplicationException {
		return rtedictrDeleteAdapter.deleteRtedictr(rtedictrDTO);
	}

	@Override
	public Map addUpdateRtedictr(RtedictrDTO existRtedictrDTO,
			List<RtedictrDTO> rtedictrDtoList, int index) throws ApplicationException {
		return rtedictrAddAdapter.addUpdateRtedictr(existRtedictrDTO, rtedictrDtoList, index);
	}
}
