/**
 * 
 */
package com.aetna.prvrte.rteintranet.dto;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class ProcexDTO {
	private String dbProcexCd = "";
	private String dbSvcTypeCd = "";
	private String dbDescTxt = "";
	private String dbPostedDate = "";
	private char dbUpdatedInd;
	/**
	 * @return the dbProcexCd
	 */
	public String getDbProcexCd() {
		return dbProcexCd;
	}
	/**
	 * @param dbProcexCd the dbProcexCd to set
	 */
	public void setDbProcexCd(String dbProcexCd) {
		this.dbProcexCd = dbProcexCd;
	}
	/**
	 * @return the dbSvcTypeCd
	 */
	public String getDbSvcTypeCd() {
		return dbSvcTypeCd;
	}
	/**
	 * @param dbSvcTypeCd the dbSvcTypeCd to set
	 */
	public void setDbSvcTypeCd(String dbSvcTypeCd) {
		this.dbSvcTypeCd = dbSvcTypeCd;
	}
	/**
	 * @return the dbDescTxt
	 */
	public String getDbDescTxt() {
		return dbDescTxt;
	}
	/**
	 * @param dbDescTxt the dbDescTxt to set
	 */
	public void setDbDescTxt(String dbDescTxt) {
		this.dbDescTxt = dbDescTxt;
	}
	/**
	 * @return the dbPostedDate
	 */
	public String getDbPostedDate() {
		return dbPostedDate;
	}
	/**
	 * @param dbPostedDate the dbPostedDate to set
	 */
	public void setDbPostedDate(String dbPostedDate) {
		this.dbPostedDate = dbPostedDate;
	}
	/**
	 * @return the dbUpdatedInd
	 */
	public char getDbUpdatedInd() {
		return dbUpdatedInd;
	}
	/**
	 * @param dbUpdatedInd the dbUpdatedInd to set
	 */
	public void setDbUpdatedInd(char dbUpdatedInd) {
		this.dbUpdatedInd = dbUpdatedInd;
	}
	
	
}
