/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.RtetprlDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 *
 */
public interface RtetprlService {

	/**
	 * 
	 * @param rtetprlDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map getRtetprlLookUpTable(RtetprlDTO rtetprlDTO) throws ApplicationException ;

	/**
	 * 
	 * @param rtetprlDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map addNewRtetprl(RtetprlDTO rtetprlDTO)throws ApplicationException ;

	/**
	 * 
	 * @param rtetprlDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map deleteRtetprl(RtetprlDTO rtetprlDTO)throws ApplicationException ;

	/**
	 * 
	 * @param editedRtetprlDTO
	 * @param rtetprlDtoList
	 * @param index
	 * @param updateInd
	 * @return
	 * @throws ApplicationException
	 */
	Map addUpdateRtetprl(RtetprlDTO editedRtetprlDTO,
			List<RtetprlDTO> rtetprlDtoList, int index,char updateInd)throws ApplicationException ;


}
