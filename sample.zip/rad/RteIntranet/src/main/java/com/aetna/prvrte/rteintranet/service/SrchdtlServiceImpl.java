package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.SrchdtlDAO;
import com.aetna.prvrte.rteintranet.dto.SrchcolDTO;
import com.aetna.prvrte.rteintranet.dto.SrchdtlDTO;
import com.aetna.prvrte.rteintranet.dto.SrcherrDTO;
import com.aetna.prvrte.rteintranet.dto.SrchresDTO;
import com.aetna.prvrte.rteintranet.dto.SrchscDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.vo.SrchcolVO;
import com.aetna.prvrte.rteintranet.vo.SrchdtlVO;
import com.aetna.prvrte.rteintranet.vo.SrcherrVO;
import com.aetna.prvrte.rteintranet.vo.SrchresVO;
import com.aetna.prvrte.rteintranet.vo.SrchscVO;
@Service
public class SrchdtlServiceImpl implements SrchdtlService {

	@Autowired(required=true)
	private SrchdtlDAO srchdtlDAO;
	@Override
	public Map getSrchdtlLookUpTable(String srchscFirstId, String srchscSecondId,String srcherrCd,String srchcolCd)
			throws ApplicationException {
		
		return srchdtlDAO.getSrchdtlLookUpTable(srchscFirstId, srchscSecondId,srcherrCd,srchcolCd);
	}
	
	@Override
	public Map<String, Object> deleteSrchdtl(List<SrchdtlVO> srchdtlVOList,
			String[] selectedIndexes) throws ApplicationException {
		// TODO Auto-generated method stub
		return srchdtlDAO.deleteSrchdtl(srchdtlVOList, selectedIndexes);
	}
	@Override
	public Map deleteSrchdtl(SrchdtlDTO srchdtlDTO) throws ApplicationException {
		return srchdtlDAO.deleteSrchdtl(srchdtlDTO);
	}

	@Override
	public Map addUpdateSrchdtl(SrchdtlDTO editedSrchdtlDTO,
			List<SrchdtlDTO> srchdtlDtoList, int i, char updateInd)
			throws ApplicationException {
		// TODO Auto-generated method stub
		return srchdtlDAO.addUpdateSrchdtl(editedSrchdtlDTO,srchdtlDtoList, i,updateInd);
	}

	@Override
	public Map getSrchcolLookUpTable(String srchcolCd)
			throws ApplicationException {
		
		return srchdtlDAO.getSrchcolLookUpTable(srchcolCd);
	}


	@Override
	public Map getSrchscLookUpTable(String srchscId)
			throws ApplicationException {
		
		return srchdtlDAO.getSrchscLookUpTable(srchscId);
	}
	@Override
	public Map getSrcherrLookUpTable(String srcherrCd)
			throws ApplicationException {
		
		return srchdtlDAO.getSrcherrLookUpTable(srcherrCd);
	}

	@Override
	public Map getSrchresLookUpTable(String srchresCd)
			throws ApplicationException {
		
		return srchdtlDAO.getSrchresLookUpTable(srchresCd);
	}


	
	@Override
	public Map deleteSrchcol(SrchcolDTO srchcolDTO) throws ApplicationException {
		return srchdtlDAO.deleteSrchcol(srchcolDTO);
	}
	@Override
	public Map deleteSrchsc(SrchscDTO srchscDTO) throws ApplicationException {
		return srchdtlDAO.deleteSrchsc(srchscDTO);
	}

	@Override
	public Map deleteSrcherr(SrcherrDTO srcherrDTO) throws ApplicationException {
		return srchdtlDAO.deleteSrcherr(srcherrDTO);
	}

	@Override
	public Map deleteSrchres(SrchresDTO srchresDTO) throws ApplicationException {
		return srchdtlDAO.deleteSrchres(srchresDTO);
	}


	
	@Override
	public Map addUpdateSrchcol(SrchcolDTO editedSrchcolDTO,
			List<SrchcolDTO> srchcolDtoList, int index,char updateInd)
			throws ApplicationException {
		return srchdtlDAO.addUpdateSrchcol( editedSrchcolDTO,srchcolDtoList, index, updateInd);
	}
	@Override
	public Map addUpdateSrchsc(SrchscDTO editedSrchscDTO,
			List<SrchscDTO> srchscDtoList, int index,char updateInd)
			throws ApplicationException {
		return srchdtlDAO.addUpdateSrchsc( editedSrchscDTO,srchscDtoList, index, updateInd);
	}
	@Override
	public Map addUpdateSrcherr(SrcherrDTO editedSrcherrDTO,
			List<SrcherrDTO> srcherrDtoList, int index,char updateInd)
			throws ApplicationException {
		return srchdtlDAO.addUpdateSrcherr( editedSrcherrDTO,srcherrDtoList, index, updateInd);
	}

	@Override
	public Map addUpdateSrchres(SrchresDTO editedSrchresDTO,
			List<SrchresDTO> srchresDtoList, int index, char updateInd)
			throws ApplicationException {
		// TODO Auto-generated method stub
		return srchdtlDAO.addUpdateSrchres( editedSrchresDTO,srchresDtoList, index, updateInd);
	}



}
