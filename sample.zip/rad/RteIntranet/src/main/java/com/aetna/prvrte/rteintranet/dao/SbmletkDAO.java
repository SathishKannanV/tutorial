package com.aetna.prvrte.rteintranet.dao;

import java.util.Map;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;

public interface SbmletkDAO {

	Map getSbmletkLookUpTable(String convIdCode, String vanIdCd,String tranType,String postedDt,String seconds) throws ApplicationException ;
}
