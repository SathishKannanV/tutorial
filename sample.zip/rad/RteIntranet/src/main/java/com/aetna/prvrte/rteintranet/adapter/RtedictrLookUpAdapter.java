/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RtedictrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RtedictrLookUpAdapter extends StoredProcedure{
	private final Log log = LogFactory.getLog(RtedictrLookUpAdapter.class);
	
	public RtedictrLookUpAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.RTESTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.RTEDICTR_DITEM_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.RTEDICTR_DICT_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR1, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N; //Used by RTEDICTRDisplay, not on database
				RtedictrDTO rtedictrDTO = new RtedictrDTO();
				rtedictrDTO.setRtestypCd(RteIntranetUtils.getTrimmedString(rs.getString("RTESTYP_CD")));
				rtedictrDTO.setDitemCd(RteIntranetUtils.getTrimmedString(rs.getString("RTEDICTR_DITEM_CD")));
				rtedictrDTO.setDictCd(RteIntranetUtils.getTrimmedString(rs.getString("RTEDICTR_DICT_CD")));
				rtedictrDTO.setEffDt(RteIntranetUtils.getTrimmedString(rs.getString("RTEDICTR_EFF_DATE")));
				rtedictrDTO.setExpDt(RteIntranetUtils.getTrimmedString(rs.getString("RTEDICTRL_EXP_DT")));
				rtedictrDTO.setPostedDateTimeStamp(RteIntranetUtils.getTrimmedString(rs.getString("RTEDICTR_PSTD_DTS")));
				rtedictrDTO.setUserId(RteIntranetUtils.getTrimmedString(rs.getString("APPL_USER_ID")));
				rtedictrDTO.setMessageId(rs.getInt("ERSPMSG_ID"));
				rtedictrDTO.setMessageTypeCd(RteIntranetUtils.getTrimmedString(rs.getString("ERSPMSG_MSGTYP_CD")));
				rtedictrDTO.setShortText(RteIntranetUtils.getTrimmedString(rs.getString("ERSPMSG_SHORT_TXT")));
				rtedictrDTO.setFullText(RteIntranetUtils.getTrimmedString(rs.getString("ERSPMSG_LONG_TXT")));
				rtedictrDTO.setUpdatedInd(updatedInd);
				return rtedictrDTO;
			}

		}));

	}
	
	@SuppressWarnings("unchecked")
	public Map getRtedictrLookUpTable (RtedictrDTO rtedictrDTO) throws ApplicationException {
		log.warn("Entered RtedictrLookUpAdapter  - getRtedictrLookUp");
		//It fetches rtedictr list based on the criteria selected by user
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map rtedictrMap = new HashMap();
		
		Map results = null;		
		List<RtedictrDTO> rtedictrList = new LinkedList<RtedictrDTO>();
		String newMessage="";
		
		String stypCd = RteIntranetUtils.getTrimmedString(rtedictrDTO.getRtestypCd());
		String ditemCd = RteIntranetUtils.getTrimmedString(rtedictrDTO.getDitemCd());
		String dictCd = RteIntranetUtils.getTrimmedString(rtedictrDTO.getDictCd());
		
		params.put(DBConstants.RTESTYP_CD, stypCd);
		params.put(DBConstants.RTEDICTR_DITEM_CD, ditemCd);
		params.put(DBConstants.RTEDICTR_DICT_CD, dictCd);
		log.warn(params);		
		
		try {
			log.warn("RtedictrLookUpAdapter: Executing stored procedure : " + "stypCd : " + stypCd + " ; ditemCd : "+ditemCd
					+ " ; dictCd : "+dictCd);
					
			results = execute(params);
			log.warn("RtedictrLookUpAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			rtedictrList = (List<RtedictrDTO>) results
					.get(DBConstants.READ_CURSOR1);	
	
			if (stypCd.equals("")){
				stypCd = "0";
			}
			
			//if (null != results) {
			if (rtedictrList.isEmpty()){
				
				if ("0".equals(sqlCode)) {
					newMessage = "No Data on database for Rtestyp Code: " + stypCd
							+ ", Ditem Code: " + ditemCd
							+ ", Dict Code: " + dictCd;
					
				} else {
					newMessage = "Problem in DB2. Sqlcode: " + sqlCode +
							" Rtestyp Code: " + stypCd
							+ ", Ditem Code: " + ditemCd
							+ ", Dict Code: " + dictCd;
					
				}			  		  		  
			} else {
				newMessage = "Data found on database for Rtestyp Code: " + stypCd
						+ ", Ditem Code: " + ditemCd
						+ ", Dict Code: " + dictCd;
			}
			/*}else{
				newMessage = "No Data found on the table.";
			}*/
			rtedictrMap.put("rtedictrMessage", newMessage);
			rtedictrMap.put("rtedictrList",rtedictrList);
			return rtedictrMap;
		}catch (Exception exception){
			log.error("RtedictrLookUpAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
		
	}
	
}
