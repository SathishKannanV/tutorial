package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.SrchcolDTO;
import com.aetna.prvrte.rteintranet.dto.SrchscDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


/**
 * @author N731694
 * Cognizant_Offshore
 */
public class SrchscUpdateAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(SrchscUpdateAdapter.class);
	
	private static final String LS_SRCHSC_ID = "LS_SRCHSC_ID";
	private static final String LS_SRCHSC_DESC = "LS_SRCHSC_DESC";
	private static final String LS_SRCHSC_EFF_DT = "LS_SRCHSC_EFF_DT";
	private static final String LS_SRCHSC_EXP_DT = "LS_SRCHSC_EXP_DT";
	private static final String LS_SRCHSC_POSTED_DT = "LS_SRCHSC_POSTED_DT";
	
	private static final String LS_ADD_UPDATE = "LS_ADD_UPDATE";
	private static final String LS_SQLCODE = "LS_SQLCODE";
	private static final String READ_CURSOR = "READ_CURSOR3";
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public SrchscUpdateAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(LS_SRCHSC_ID, Types.SMALLINT));
		declareParameter(new SqlParameter(LS_SRCHSC_DESC, Types.CHAR));
		declareParameter(new SqlParameter(LS_SRCHSC_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(LS_SRCHSC_EXP_DT, Types.DATE));
		declareParameter(new SqlParameter(LS_SRCHSC_POSTED_DT, Types.DATE));
	
		declareParameter(new SqlOutParameter(LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(LS_SQLCODE, Types.INTEGER));
	}
	
	
	

	
	@SuppressWarnings("unchecked")
	public Map addUpdateSrchsc(SrchscDTO existingSrchsc,
			List<SrchscDTO> srchscDtoList, int index,char updateInd) throws ApplicationException{
		log.debug("Entered SrchscupateAdapter  - addUpdateSrchsc");
		boolean isSrchscAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map srchscMap = new HashMap();
		Date todaysDate = new Date(System.currentTimeMillis());
		String postedDate = todaysDate.toString();
		existingSrchsc.setPostedDate(postedDate);

		params.put(LS_SRCHSC_ID, RteIntranetUtils.getTrimmedString(existingSrchsc.getSrchscId()));
		params.put(LS_SRCHSC_DESC, RteIntranetUtils.getTrimmedString(existingSrchsc.getSrchscDesc()));
		params.put(LS_SRCHSC_EFF_DT, RteIntranetUtils.getTrimmedString(existingSrchsc.getEffDate()));
		params.put(LS_SRCHSC_EXP_DT, RteIntranetUtils.getTrimmedString(existingSrchsc.getExpDate()));
		params.put(LS_SRCHSC_POSTED_DT, RteIntranetUtils.getTrimmedString(existingSrchsc.getPostedDate()));
		
		log.debug(params);	
		
		try {
					
			results = execute(params);
			log.debug("SrchcolUpdateAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(LS_SQLCODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
							isSrchscAddorUpdated = true;
							existingSrchsc.setSrchscId((actionCode));
							srchscDtoList.set(index, existingSrchsc);	
				
				newMessage = "All rows that changed the database are highlighted.";
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			srchscMap.put("srchscMsg",newMessage);
			srchscMap.put("srchscDtoList",srchscDtoList);
			srchscMap.put("isSrchscAddorUpdated", isSrchscAddorUpdated);
			return srchscMap;
		}catch (Exception exception){
			log.error("Srchsc Update Adapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
}