/**

 * 

 */

package com.aetna.prvrte.rteintranet.service;



import java.util.List;

import java.util.Map;



import com.aetna.prvrte.rteintranet.dto.HrpRuleDTO;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;



/**

 * @author N801539

 *

 */

public interface HrpRuleService {



	

	/**

	 * 

	 * @param hrpruleDTO

	 * @return

	 * @throws ApplicationException

	 */

	Map getHrpRuleLookUpTable(HrpRuleDTO hrpruleDTO) throws ApplicationException ;





	/**

	 * 

	 * @param hrpruleDTO

	 * @return

	 * @throws ApplicationException

	 */

	Map addNewHrprule(HrpRuleDTO hrpruleDTO)throws ApplicationException ;







	/**

	 * 

	 * @param hrpruleDTO

	 * @return

	 * @throws ApplicationException

	 */

	Map deleteHrpRule(HrpRuleDTO hrpruleDTO)throws ApplicationException ;



	/**

	 * 

	 * @param editedHrpRuleDTO

	 * @param hrpruleDtoList

	 * @param index

	 * @param updateInd

	 * @return

	 * @throws ApplicationException

	 */

	Map addUpdateHrpRule(HrpRuleDTO editedHrpRuleDTO,

			List<HrpRuleDTO> hrpruleDtoList, int index,char updateInd)throws ApplicationException;







}

