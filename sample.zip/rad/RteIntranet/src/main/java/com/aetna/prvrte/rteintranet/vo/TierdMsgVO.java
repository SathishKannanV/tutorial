
package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class TierdMsgVO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4023025914935899067L;
	private String tierdMsgtypCd = ""; 
	private String tierdTierstCd = ""; 
	private String effDt = ""; 
	private String expDt = ""; 
	private String postedDateTimeStamp = "";
	private String userId = "";
	private int    messageId; 
	private String messageTypeCd = ""; 
	private String shortText = ""; 
	private String fullText = "";
	private char   updatedInd;
	
	
	public TierdMsgVO(String tierdMsgtypCd, String tierdTierstCd, String effDt,
			String expDt, String postedDateTimeStamp, String userId,
			int messageId, String messageTypeCd, String shortText,
			String fullText, char updatedInd) {
		super();
		this.tierdMsgtypCd = tierdMsgtypCd;
		this.tierdTierstCd = tierdTierstCd;
		this.effDt = effDt;
		this.expDt = expDt;
		this.postedDateTimeStamp = postedDateTimeStamp;
		this.userId = userId;
		this.messageId = messageId;
		this.messageTypeCd = messageTypeCd;
		this.shortText = shortText;
		this.fullText = fullText;
		this.updatedInd = updatedInd;
	}


	public TierdMsgVO() {
		super();
	}
	
	
	/**
	 * @return the tierdMsgtypCd
	 */
	public String getTierdMsgtypCd() {
		return tierdMsgtypCd;
	}
	/**
	 * @return the tierdTierstCd
	 */
	public String getTierdTierstCd() {
		return tierdTierstCd;
	}
	/**
	 * @return the effDt
	 */
	public String getEffDt() {
		return effDt;
	}
	/**
	 * @return the expDt
	 */
	public String getExpDt() {
		return expDt;
	}
	/**
	 * @return the postedDateTimeStamp
	 */
	public String getPostedDateTimeStamp() {
		return postedDateTimeStamp;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @return the messageId
	 */
	public int getMessageId() {
		return messageId;
	}
	/**
	 * @return the messageTypeCd
	 */
	public String getMessageTypeCd() {
		return messageTypeCd;
	}
	/**
	 * @return the shortText
	 */
	public String getShortText() {
		return shortText;
	}
	/**
	 * @return the fullText
	 */
	public String getFullText() {
		return fullText;
	}
	/**
	 * @return the updatedInd
	 */
	public char getUpdatedInd() {
		return updatedInd;
	}
	/**
	 * @param tierdMsgtypCd the tierdMsgtypCd to set
	 */
	public void setTierdMsgtypCd(String tierdMsgtypCd) {
		this.tierdMsgtypCd = tierdMsgtypCd;
	}
	/**
	 * @param tierdTierstCd the tierdTierstCd to set
	 */
	public void setTierdTierstCd(String tierdTierstCd) {
		this.tierdTierstCd = tierdTierstCd;
	}
	/**
	 * @param effDt the effDt to set
	 */
	public void setEffDt(String effDt) {
		this.effDt = effDt;
	}
	/**
	 * @param expDt the expDt to set
	 */
	public void setExpDt(String expDt) {
		this.expDt = expDt;
	}
	/**
	 * @param postedDateTimeStamp the postedDateTimeStamp to set
	 */
	public void setPostedDateTimeStamp(String postedDateTimeStamp) {
		this.postedDateTimeStamp = postedDateTimeStamp;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @param messageId the messageId to set
	 */
	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}
	/**
	 * @param messageTypeCd the messageTypeCd to set
	 */
	public void setMessageTypeCd(String messageTypeCd) {
		this.messageTypeCd = messageTypeCd;
	}
	/**
	 * @param shortText the shortText to set
	 */
	public void setShortText(String shortText) {
		this.shortText = shortText;
	}
	/**
	 * @param fullText the fullText to set
	 */
	public void setFullText(String fullText) {
		this.fullText = fullText;
	}
	/**
	 * @param updatedInd the updatedInd to set
	 */
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}	
	
}
