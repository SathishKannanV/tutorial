package com.aetna.prvrte.rteintranet.copybookbean;

import java.util.List;

import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

public class ProcedureInfoSet {
	String procedureInfoCtr;
	List<ProcedureInfo> procedureInfo;
	public String getProcedureInfoCtr() {
		
		return procedureInfoCtr;
	}
	public void setProcedureInfoCtr(String procedureInfoCtr) {
		this.procedureInfoCtr = procedureInfoCtr;
	}
	public List<ProcedureInfo> getProcedureInfo() {
		return procedureInfo;
	}
	public void setProcedureInfo(List<ProcedureInfo> procedureInfo) {
		this.procedureInfo = procedureInfo;
	}

	public StringBuilder getProcedure(){

		int popCount;
		StringBuilder type = new StringBuilder();
        popCount = getProcedureInfo().size();
       
		for(int i=0; i<popCount; i++) {
			type.append(getProcedureInfo().get(i).getProcedureInfo());
		}
		for(int i=popCount; i<10; i++) {
			type.append(RteIntranetUtils.spaceFiller(13));
	}
		return type;
	
	}
}
