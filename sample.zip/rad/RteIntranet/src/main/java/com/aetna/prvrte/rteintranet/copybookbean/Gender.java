package com.aetna.prvrte.rteintranet.copybookbean;

public class Gender {

	String male;
	String female;
	String unknown;
	public String getMale() {
		return male;
	}
	public void setMale(String male) {
		this.male = male;
	}
	public String getFemale() {
		return female;
	}
	public void setFemale(String female) {
		this.female = female;
	}
	public String getUnknown() {
		return unknown;
	}
	public void setUnknown(String unknown) {
		this.unknown = unknown;
	}
	public StringBuilder getGender(){
		return new StringBuilder(getMale())
		.append(getFemale())
		.append(getUnknown());
		
	}
}
