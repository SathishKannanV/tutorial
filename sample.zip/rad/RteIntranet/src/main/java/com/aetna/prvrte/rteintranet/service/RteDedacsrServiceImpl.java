/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.RteDedacsrDAO;
import com.aetna.prvrte.rteintranet.dto.DedacsrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.service.RteDedacsrService
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Service
public class RteDedacsrServiceImpl implements RteDedacsrService {
	/*
	 * Instance of RteDedacsrDAO.
	 */
	@Autowired(required=true)
	private RteDedacsrDAO rteDedacsrDAO;
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteDedacsrService#getDedacsrLookUpList(com.aetna.prvrte.rteintranet.dto.DedacsrDTO)
	 */
	@Override
	public Map<String, Object> getDedacsrLookUpList(DedacsrDTO dedacsrDTO) throws ApplicationException {
		return rteDedacsrDAO.getDedacsrLookUpList(dedacsrDTO);
	}

	@Override
	public Map<String, Object> addDedacsrToDb(DedacsrDTO dedacsrDTO)
			throws ApplicationException {
		return rteDedacsrDAO.addDedacsrToDb(dedacsrDTO);
	}

	@Override
	public Map<String, Object> deleteDedacsr(String dbSvcTypeCd, String dbDefAccumCd) throws ApplicationException {
		return rteDedacsrDAO.deleteDedacsr(dbSvcTypeCd, dbDefAccumCd);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteDedacsrService#addUpdateDedacsr(com.aetna.prvrte.rteintranet.dto.DedacsrDTO, java.util.List, int)
	 */
	@Override
	public Map<String, Object> addUpdateDedacsr(DedacsrDTO dedacsrDTO, List<DedacsrDTO> dedacsrList, int index) throws ApplicationException {
		return rteDedacsrDAO.addUpdateDedacsr(dedacsrDTO, dedacsrList, index);
	}
	

}
