/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;



/**
 * @author N657186
 * Cognizant_Offshore
 */
public class ProcexPRX2Adapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(ProcexPRX2Adapter.class);

	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public ProcexPRX2Adapter(DataSource datasource, String storedProc) throws SQLException{
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.IN_PROCEX_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_SVCTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_DESC_TXT, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_POSTED_DATE, Types.DATE));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
	}
	
	
	@SuppressWarnings("unchecked")
	public Map addNewProcex(ProcexDTO procexDTO) throws ApplicationException {
		
		log.warn("Entered ProcexPRX2Adapter  - addNewProcex");
		//boolean isProcexAdded = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map procexMap = new HashMap();
		Date todaysDate = new Date(System.currentTimeMillis());
		String postedDate = todaysDate.toString();
		procexDTO.setDbPostedDate(postedDate);
		procexDTO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
		params.put(DBConstants.IN_PROCEX_CD, RteIntranetUtils.getTrimmedString(procexDTO.getDbProcexCd()));
		params.put(DBConstants.IN_SVCTYP_CD, RteIntranetUtils.getTrimmedString(procexDTO.getDbSvcTypeCd()));
		params.put(DBConstants.IN_DESC_TXT, RteIntranetUtils.getTrimmedString(procexDTO.getDbDescTxt()));
		params.put(DBConstants.IN_POSTED_DATE, RteIntranetUtils.getTrimmedString(procexDTO.getDbPostedDate()));
		
		log.warn(params);	
		
		try {
			
					
			results = execute(params);
			log.warn("ProcexPRX2Adapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) {
				//isProcexAdded = true;
				List<ProcexDTO> procexList = new LinkedList<ProcexDTO>();
				procexList.add(procexDTO);
				procexMap.put("ProcexList", procexList);
				if ("0".equalsIgnoreCase(actionCode)) {
					newMessage = "This row added to the database";
				}else {
					newMessage ="Row already exists on the database. It was updated with these values.";					
					procexDTO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_Y); 
				}				
				}
			else {
				newMessage = "Unable to add row to the database. SQLCODE = " + sqlCode;
			}
			
			procexMap.put("procexMessage", newMessage);
			//procexMap.put("isProcexAdded", isProcexAdded);				
		return procexMap;
	}catch (Exception exception){
		log.error("ProcexAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}


	@SuppressWarnings("unchecked")
	public Map addUpdateProcex(ProcexDTO modifiedProcex,
			List<ProcexDTO> procexDtoList, int index, char updateInd) throws ApplicationException{
		log.warn("Entered ProcexPRX2Adapter  - addUpdateProcex");
		boolean isProcxAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map procexMap = new HashMap();
		params.put(DBConstants.IN_PROCEX_CD, RteIntranetUtils.getTrimmedString(modifiedProcex.getDbProcexCd()));
		params.put(DBConstants.IN_SVCTYP_CD, RteIntranetUtils.getTrimmedString(modifiedProcex.getDbSvcTypeCd()));
		params.put(DBConstants.IN_DESC_TXT, RteIntranetUtils.getTrimmedString(modifiedProcex.getDbDescTxt()));
		params.put(DBConstants.IN_POSTED_DATE, RteIntranetUtils.getTrimmedString(modifiedProcex.getDbPostedDate()));
		
		log.warn(params);	
		
		try {
					
			results = execute(params);
			log.warn("ProcexPRX2Adapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			if ("0".equalsIgnoreCase(sqlCode)) {
				isProcxAddorUpdated = true;
				if ("0".equalsIgnoreCase(actionCode)) {
					
					if (updateInd == ApplicationConstants.COPY)						
						procexDtoList.set(index, modifiedProcex);						
					else
						procexDtoList.add(modifiedProcex);
				}
				else
					procexDtoList.set(index, modifiedProcex);
				
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			procexMap.put("procexMsg",newMessage);
			procexMap.put("procexDtoList",procexDtoList);
			procexMap.put("isProcxAddorUpdated", isProcxAddorUpdated);
			return procexMap;
		}catch (Exception exception){
			log.error("ProcexAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
}