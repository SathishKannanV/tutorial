package com.aetna.prvrte.rteintranet.web.controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.RterbacDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.RterbacVO;
import com.aetna.prvrte.rteintranet.vo.UserVO;

/**
 * @author N657186
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/rterbac/*")
public class RterbacController {

	public static final String RTERBAC_HOME = ".rterbacHome";
	public static final String RTERBAC_LOOKUP = ".rterbacLookUp";
	public static final String RTERBAC_ADD = ".rterbacAdd";
	
	
	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(RterbacController.class);
	
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/rterbacHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRterbacLookUpHome(final HttpServletRequest request, Model model) {
		log.warn("Entered RterbacController - getRterbacLookUpHome()");
		String securityLevel ="";
		try{
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(RTERBAC_HOME, "rterbacVO",  new RterbacVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("RterbacController - securityLevel: "+ securityLevel);
		log.warn("Exit from RterbacController - getRterbacLookUpHome()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RterbacController - getRterbacLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (RterbacList). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rterbacVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherRterbac", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRterbacLookUp(final HttpServletRequest request,@ModelAttribute("rterbacForm")RterbacVO rterbacVO){
		log.warn("Entered RterbacController - getRterbacLookUp()");
		ModelAndView mav ;
		String securityLevel ="";
		Map rterbacResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<RterbacDTO> rterbacDtoList = new LinkedList<RterbacDTO>();
		List<RterbacVO> rterbacVoList = new LinkedList<RterbacVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			String accuCode = (rterbacVO.getAccuCd()!=null && rterbacVO.getAccuCd()!="")?rterbacVO.getAccuCd():" ";
			rterbacVO.setAccuCd(accuCode);
		RterbacDTO rterbacDTO = RTETranslator.toRterbacDTO(rterbacVO);
		rterbacResultMap = facade.getRterbacLookUp(rterbacDTO);
		
		rterbacDtoList = (List<RterbacDTO>) rterbacResultMap.get("rterbacList");
		rterbacVoList = RTETranslator.toRterbacVOList(rterbacDtoList);
		lookUpListVO.setRterbacVOList(rterbacVoList);
		facade.getApplicationState().setRterbacList(rterbacVoList);
		log.warn("getRterbacLookUp - rterbacMessage: "+ rterbacResultMap.get("rterbacMessage"));
		mav = new ModelAndView(RTERBAC_LOOKUP, "lookUpListVO", lookUpListVO);
		mav.addObject("rterbacMessage", rterbacResultMap.get("rterbacMessage"));
		mav.addObject("securityLevel", securityLevel);
		log.warn("Exit from RterbacController - getRterbacLookUp()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in rterbacController - getrterbacLookUp() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (RterbacList)."+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	@RequestMapping(value="/AddNewRterbacRow", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView loadAddNewRterbacRowScreen(final HttpServletRequest request,Model model) {	
		log.warn("Entered RterbacController - loadAddNewRterbacRowScreen()");
		ModelAndView mav = new ModelAndView(RTERBAC_ADD, "rterbacVO",  new RterbacVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in RterbacController - loadAddNewRterbacRowScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (loadAddNewRterbacRowScreen). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		log.warn("Exit from RterbacController - loadAddNewRterbacRowScreen()");
		return mav;
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddRterbac", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addNewRterbac(HttpServletRequest request,@ModelAttribute("addRterbacForm")RterbacVO rterbacVO){
		log.warn("Entered RterbacController - addNewRterbac()");
		String securityLevel ="";
		Map rterbacResultMap = new HashMap();
		List<RterbacDTO> rterbacDtoList = new LinkedList<RterbacDTO>();
		List<RterbacVO> rterbacVoList = new LinkedList<RterbacVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			String userId ="";
			userId = RteIntranetUtils.getUserId(request);
			rterbacVO.setUserId(userId);
			rterbacVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
			rterbacVO.setMessageId(String.valueOf(ApplicationConstants.ZERO));
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDateTimeStamp = currentTS.toString(); //Initialize Posted Date to the current timestamp
			rterbacVO.setPostedDateTimeStamp(postedDateTimeStamp);
			
			RterbacDTO rterbacDTO = RTETranslator.toRterbacDTO(rterbacVO);
			rterbacResultMap = facade.addNewRterbac(rterbacDTO);
			
			if(rterbacResultMap.get("rterbacList")!=null){
				rterbacDtoList = (List<RterbacDTO>) rterbacResultMap.get("rterbacList");
				rterbacVoList = RTETranslator.toRterbacVOList(rterbacDtoList);
			}
			lookUpListVO.setRterbacVOList(rterbacVoList);
			facade.getApplicationState().setRterbacList(rterbacVoList);
			
			mav = new ModelAndView(RTERBAC_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("rterbacMessage", rterbacResultMap.get("rterbacMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("addNewRterbac - rterbacMessage: "+ rterbacResultMap.get("rterbacMessage"));
			log.warn("Exit from RterbacController - addNewRterbac()");
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in RterbacController - addNewRterbac() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when adding a row to the database (AddRTERBAC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * @param rterbacVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteRterbac", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView deleteRterbac(final HttpServletRequest request,@ModelAttribute("rterbacDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RterbacController - deleteRterbac()");
		ModelAndView mav ;
		String rterbacMsg = "";
		boolean isRterbacDeleted = true;
		Map rterbacResultMap = new HashMap();
		String securityLevel ="";
		List<RterbacVO> rterbacVoList = new LinkedList<RterbacVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			int i;
			rterbacVoList= lookUpListVO.getRterbacVOList();
			if ((rterbacVoList != null) && (takeAction != null)) {
				for(RterbacVO rterbacVo : rterbacVoList){
					if(rterbacVo.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rterbacVo.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
			
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);

					RterbacVO existingRterbac = (RterbacVO) rterbacVoList.get(i);
					if (existingRterbac.getUpdatedInd() != ApplicationConstants.COPY) {
						RterbacDTO rterbacDTO = RTETranslator.toRterbacDTO(existingRterbac);
						
						rterbacResultMap = facade.deleteRterbac(rterbacDTO);
						rterbacMsg = (String) rterbacResultMap.get("rterbacMessage");
						isRterbacDeleted = (Boolean) rterbacResultMap.get("isRterbacDeleted");
						
						if(isRterbacDeleted){
							rterbacVoList.remove(i);
						}else{
							j = 0;
						}
					}else{
						rterbacVoList.remove(i);
					}				
			}
				
				if(isRterbacDeleted){
					rterbacMsg = "Rows selected were Deleted in the database/list";
				}
		}else
			rterbacMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRterbacList(rterbacVoList);
			lookUpListVO.setRterbacVOList(rterbacVoList);
			
			mav = new ModelAndView(RTERBAC_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rterbacMessage",rterbacMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteRterbac - rterbacMessage: "+ rterbacMsg);
		    log.warn("Exit from RterbacController - deleteRterbac()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RterbacController - deleteRterbac() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (RterbacListChange). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rterbacVO
	 * @param takeAction
	 * @return
	 */
	@RequestMapping(value="/copyRterbac", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView copyRterbac(HttpServletRequest request,@ModelAttribute("rterbacDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RterbacController - copyRterbac()");
		ModelAndView mav ;
		String rterbacMsg = "";
		String securityLevel ="";
		int i;
		List<RterbacVO> rterbacList = new LinkedList<RterbacVO>();
		try{
			String userId ="";
			userId = RteIntranetUtils.getUserId(request);
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDateTimeStamp = currentTS.toString(); 
			rterbacList = lookUpListVO.getRterbacVOList();
			
			if ((rterbacList != null) && (takeAction != null)) {
				for(RterbacVO rterbacVO : rterbacList){
					if(rterbacVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rterbacVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					RterbacVO existingRterbac = (RterbacVO) rterbacList.get(i);
					RterbacVO copyRterbac = new RterbacVO(existingRterbac.getAccuCd(), existingRterbac.getBenCd(), 
							existingRterbac.getResInd(), existingRterbac.getEffDt(),
							existingRterbac.getExpDt(),postedDateTimeStamp,userId, existingRterbac.getMessageId(), 
							existingRterbac.getMessageTypeCd(), existingRterbac.getShortText(),
							existingRterbac.getFullText(),ApplicationConstants.COPY);
					rterbacList.add(copyRterbac);
				}
				rterbacMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				rterbacMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRterbacList(rterbacList);
			lookUpListVO.setRterbacVOList(rterbacList);
			
			mav = new ModelAndView(RTERBAC_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rterbacMessage",rterbacMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyRterbac - rterbacMessage: "+ rterbacMsg);
		    log.warn("Exit from RterbacController - copyRterbac()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in RterbacController - copyRterbac() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRterbac). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	/**
	 * @param request
	 * @param rterbacVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateRterbac", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addUpdateRterbac(final HttpServletRequest request, @ModelAttribute("rterbacDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RterbacController - addUpdateRterbac()");
		ModelAndView mav ;
		String rterbacMsg = "";
		String securityLevel="";
		List<RterbacVO> updatedRterbacList = new LinkedList<RterbacVO>();
		List<RterbacDTO> updatedRterbacDtoList = new LinkedList<RterbacDTO>();
		List<RterbacVO> rterbacVoList = new LinkedList<RterbacVO>();
		List<RterbacVO> modifiedRterbacVoList = new LinkedList<RterbacVO>();
		List<RterbacDTO> rterbacDtoList = new LinkedList<RterbacDTO>(); 
		RterbacDTO editedRterbacDTO = new RterbacDTO();
		boolean isRterbacAddOrUpdated = false;
		Map rterbacResultMap = new HashMap();
		try{
			rterbacVoList = facade.getApplicationState().getRterbacList();
			modifiedRterbacVoList = lookUpListVO.getRterbacVOList();
			
			int i;
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			String userId ="";
			userId = RteIntranetUtils.getUserId(request);
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDateTimeStamp = currentTS.toString(); 
			if (takeAction != null && takeAction.length != 0) {
				if(rterbacVoList != null && rterbacVoList.size() != 0 
						&& modifiedRterbacVoList.size() != 0 && modifiedRterbacVoList != null){
						
				for(RterbacVO rterbacVO : rterbacVoList){
					if(rterbacVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rterbacVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				
				rterbacDtoList = RTETranslator.toRterbacDTOList(rterbacVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					RterbacVO seletedRterbac = (RterbacVO) rterbacVoList.get(i);
					RterbacVO editedRterbac = (RterbacVO) modifiedRterbacVoList.get(i);
					RterbacVO editedRterbacVO = new RterbacVO(editedRterbac.getAccuCd(),editedRterbac.getBenCd(),editedRterbac.getResInd(),
							editedRterbac.getEffDt(),editedRterbac.getExpDt(),postedDateTimeStamp,editedRterbac.getUserId(),
							editedRterbac.getMessageId(),editedRterbac.getMessageTypeCd(),editedRterbac.getShortText(),editedRterbac.getFullText(),updatedInd);
					
					if(editedRterbacVO!=null){
					editedRterbacDTO = RTETranslator.toRterbacDTO(editedRterbacVO);
					}
					rterbacResultMap = facade.addUpdateRterbac(editedRterbacDTO, rterbacDtoList, i);
					updatedRterbacDtoList = (List<RterbacDTO>) rterbacResultMap.get("rterbacDtoList");
					if(updatedRterbacDtoList!=null){
					updatedRterbacList = RTETranslator.toRterbacVOList(updatedRterbacDtoList);
					}
					isRterbacAddOrUpdated = (Boolean) rterbacResultMap.get("isrterbacAddorUpdated");
					rterbacMsg = (String) rterbacResultMap.get("rterbacMessage") ;
					if(!isRterbacAddOrUpdated){
						j = takeAction.length;
					}
				}
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);				
				}
		}else
			rterbacMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRterbacList(updatedRterbacList);
			lookUpListVO.setRterbacVOList(updatedRterbacList);
			
			mav = new ModelAndView(RTERBAC_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rterbacMessage",rterbacMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateRterbac - rterbacMessage: "+ rterbacMsg);
		    log.warn("Exit from RterbacController - addUpdateRterbac()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RterbacController - deleteRterbac() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRTERBAC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	
	/**
	 * Method to export Rterbac look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of rterbac object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/rterbacExport", method = RequestMethod.POST)
	public ModelAndView rterbacExport(HttpServletResponse response){
		List<RterbacVO> rterbacList = new LinkedList<RterbacVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String rterbacMsg="";
		try{
			rterbacList = facade.getApplicationState().getRterbacList();
			if(rterbacList != null && rterbacList.size() != 0){
			// Key map to create header
			Map<String,String> keyMap = new LinkedHashMap<String,String>();
			keyMap.put("accuCd", "Accumulator Code");
			keyMap.put("benCd", "Benefit Code");
			keyMap.put("resInd", "Restricted indicator");
			keyMap.put("effDt", "Eff Dt");
			keyMap.put("expDt", "Exp Dt");
			keyMap.put("postedDateTimeStamp", "Posted DateTimestamp");
			keyMap.put("userId", "User Id");
			keyMap.put("messageId", "Message Id");
			keyMap.put("messageTypeCd", "Message Type Cd");
			keyMap.put("shortText", "Short Provider Text");
			keyMap.put("fullText", "Long Provider Text");
			
			
			RteIntranetUtils.exportToExcel(response, rterbacList, keyMap);
			rterbacMsg = "LookUp table exported successfully.";
			} else {
				rterbacMsg = "No data found.";
			}
			lookUpTableListVO.setRterbacVOList(rterbacList);
	        mav = new ModelAndView(RTERBAC_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
		    mav.addObject("rterbacMessage",rterbacMsg);
			return mav;
		}catch (ApplicationException e) {
			log.error("Exception occured in RterbacController - rterbacExport() method:"
					+ e.getErrorMessage());
			String errorMsg = "Error encountered while export to excel. "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errormav;
		}
	}
	
}
