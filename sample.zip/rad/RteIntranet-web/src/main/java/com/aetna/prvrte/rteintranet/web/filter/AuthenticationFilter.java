package com.aetna.prvrte.rteintranet.web.filter;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;

import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.vo.UserVO;


/**
 * @author n657186
 * Cognizant_Offshore
 */
public class AuthenticationFilter implements Filter{
	protected FilterConfig filterConfig;
	private static final Log log = LogFactory.getLog(AuthenticationFilter.class);

	@Override
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {
		try{
	    	
		       log.warn("Inside AuthenticationFilter Start");
		      
		       HttpServletRequest request = (HttpServletRequest) req;
		       
		       /*Enumeration headerNames = request.getHeaderNames();
			   	while (headerNames.hasMoreElements()) {
			   		String key = (String) headerNames.nextElement();
			   		String value = request.getHeader(key);
			   		log.warn("header name - key : " + key +" ;; value : "+value);
			   	}*/
			  log.warn("path info ::::: "+request.getPathInfo()); 	
				HttpSession session = request.getSession(true);
				
		      if(session != null){
		    	   log.warn("SecurityContextHolder.getContext() ::::: "+SecurityContextHolder.getContext().toString());
		    	   SecurityContext ss= SecurityContextHolder.getContext();
		    	   
		    	   if((ss!=null && ss.getAuthentication()!=null && (!ss.getAuthentication().getPrincipal().toString().equalsIgnoreCase("anonymous")))){
		    		   
		    		   UserVO siteMinderUser = (UserVO) ss.getAuthentication().getPrincipal();
			    	   log.warn("siteMinderUser.getMemberOf()::::: "+ siteMinderUser.getMemberOf());
		    		   if(siteMinderUser.getMemberOf()!=null){
			    		   
			    		   session.setAttribute(ApplicationConstants.RTE_INTRANET_USER_ROLE, "");		    	    	   
		    	    	   
		    	    	   if(siteMinderUser.getMemberOf().contains(ApplicationConstants.RTEWrite)){		    	    		   
		    	    		   session.setAttribute(ApplicationConstants.RTE_INTRANET_USER_ROLE, "RW");
			    	    	  
		    	    	   }else if(siteMinderUser.getMemberOf().contains(ApplicationConstants.MDDRteDb2)){
		    	    		   session.setAttribute(ApplicationConstants.RTE_INTRANET_USER_ROLE, "R");
		    	    	   }
		    		   }
		    		   log.warn("user role ::::: "+session.getAttribute(ApplicationConstants.RTE_INTRANET_USER_ROLE));
			    	   session.setAttribute("user", siteMinderUser);
		    	   }
		       }
		           chain.doFilter(req, res);
				 log.warn("Inside AuthenticationFilter End");
		       	}
		       	catch(Exception e){
		       		log.error("Exception occured in AuthenticationFilter : "+e.getMessage());
		       		log.warn("Exception in AuthenticationFilter:"+e.getMessage());
		       	}
	}
	@Override
	public void init(FilterConfig config) throws ServletException {
		this.filterConfig = config;
		
	}

	@Override
	public void destroy() {
		this.filterConfig = null;
		
	}
}
