/**
 * 
 */
package com.aetna.prvrte.rteintranet.vo;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RtebeplmVO {

	private String hmoBenefitCd = ""; 
	private String frequencyInd = "";
	private String eligPerLimitCd = ""; 
	private String effDate = "";
	private String expDate = "";
	private String postedDateTimestamp = "";
	private char   updatedInd;
	/**
	 * @param hmoBenefitCd
	 * @param frequencyInd
	 * @param eligPerLimitCd
	 * @param effDate
	 * @param expDate
	 * @param postedDateTimestamp
	 * @param updatedInd
	 */
	public RtebeplmVO(String hmoBenefitCd, String frequencyInd,
			String eligPerLimitCd, String effDate, String expDate,
			String postedDateTimestamp, char updatedInd) {
		this.hmoBenefitCd = hmoBenefitCd;
		this.frequencyInd = frequencyInd;
		this.eligPerLimitCd = eligPerLimitCd;
		this.effDate = effDate;
		this.expDate = expDate;
		this.postedDateTimestamp = postedDateTimestamp;
		this.updatedInd = updatedInd;
	}
	public RtebeplmVO() {
		super();
	}
	/**
	 * @return the hmoBenefitCd
	 */
	public String getHmoBenefitCd() {
		return hmoBenefitCd;
	}
	/**
	 * @param hmoBenefitCd the hmoBenefitCd to set
	 */
	public void setHmoBenefitCd(String hmoBenefitCd) {
		this.hmoBenefitCd = hmoBenefitCd;
	}
	/**
	 * @return the frequencyInd
	 */
	public String getFrequencyInd() {
		return frequencyInd;
	}
	/**
	 * @param frequencyInd the frequencyInd to set
	 */
	public void setFrequencyInd(String frequencyInd) {
		this.frequencyInd = frequencyInd;
	}
	/**
	 * @return the eligPerLimitCd
	 */
	public String getEligPerLimitCd() {
		return eligPerLimitCd;
	}
	/**
	 * @param eligPerLimitCd the eligPerLimitCd to set
	 */
	public void setEligPerLimitCd(String eligPerLimitCd) {
		this.eligPerLimitCd = eligPerLimitCd;
	}
	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}
	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	/**
	 * @return the expDate
	 */
	public String getExpDate() {
		return expDate;
	}
	/**
	 * @param expDate the expDate to set
	 */
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	/**
	 * @return the postedDateTimestamp
	 */
	public String getPostedDateTimestamp() {
		return postedDateTimestamp;
	}
	/**
	 * @param postedDateTimestamp the postedDateTimestamp to set
	 */
	public void setPostedDateTimestamp(String postedDateTimestamp) {
		this.postedDateTimestamp = postedDateTimestamp;
	}
	/**
	 * @return the updatedInd
	 */
	public char getUpdatedInd() {
		return updatedInd;
	}
	/**
	 * @param updatedInd the updatedInd to set
	 */
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}

	

}

