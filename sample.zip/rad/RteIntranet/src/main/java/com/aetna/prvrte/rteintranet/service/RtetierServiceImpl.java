/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.aetna.prvrte.rteintranet.dao.RtetierDAO;
import com.aetna.prvrte.rteintranet.dto.RtetierDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

@Service
public class RtetierServiceImpl implements RtetierService {
	@Autowired(required=true)
	private RtetierDAO rtetierDAO;

	@Override
	public Map getRtetierLookUp(RtetierDTO rtetierDTO) throws ApplicationException {
		return rtetierDAO.getRtetierLookUp(rtetierDTO);
	}

	@Override
	public Map addNewRtetier(RtetierDTO rtetierDTO) throws ApplicationException {
		return rtetierDAO.addNewRtetier(rtetierDTO);
	}

	@Override
	public Map deleteRtetier(RtetierDTO rtetierDTO)
			throws ApplicationException {
		return rtetierDAO.deleteRtetier(rtetierDTO);
	}

	@Override
	public Map addUpdateRtetier(RtetierDTO modifiedRtetierDTO, List<RtetierDTO> rtetierDtoList,
			int index, char updateInd) throws ApplicationException {
		return rtetierDAO.addUpdateRtetier(modifiedRtetierDTO,rtetierDtoList, index, updateInd);
	}
}
