package com.aetna.prvrte.rteintranet.adapter;



import java.sql.SQLException;

import java.sql.Timestamp;

import java.sql.Types;

import java.util.Calendar;

import java.util.HashMap;

import java.util.LinkedList;

import java.util.List;

import java.util.Map;

import java.util.regex.Pattern;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;

import org.apache.commons.logging.LogFactory;

import org.springframework.jdbc.core.SqlOutParameter;

import org.springframework.jdbc.core.SqlParameter;

import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.HrpRuleDTO;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;

import com.aetna.prvrte.rteintranet.util.ApplicationConstants;

import com.aetna.prvrte.rteintranet.util.DBConstants;

import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;



/**

 * @author N624926

 * Cognizant_Offshore

 */

public class HrpRuleAddAdapter extends StoredProcedure{

	/**

	 * Instance of Log Factory.

	 */

	private final Log log = LogFactory.getLog(HrpRuleAddAdapter.class);

	//private static final Pattern p = Pattern.compile("\\s");	

	//private static final String EXPDT = "9999-12-31";

	//private static final int MESSAGE_ID = 0;	

	

	

	/**

	 * 

	 * @param datasource

	 * @param storedProc

	 * @throws SQLException

	 */

	public HrpRuleAddAdapter(DataSource datasource, String storedProc) throws SQLException{

		super(datasource, storedProc);

		declareParameter(new SqlParameter(DBConstants.HRPRL_SVTYP_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_RL_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_EFF_DT, Types.DATE));

		declareParameter(new SqlParameter(DBConstants.HRPRL_TERM_DT, Types.DATE));

		declareParameter(new SqlParameter(DBConstants.HRPRL_RLE_DESC, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_CNSPF_IND, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_RLCTG_IND, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_CVG_IND, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_TXSD_IND, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_PSTS_IND, Types.CHAR));
		
		declareParameter(new SqlParameter(DBConstants.HRPRL_TYP_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_PLSVC_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_ST_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_AMTRFT_IND, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL01_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL02_CD, Types.CHAR));
		
		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL03_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL04_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL05_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL06_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL07_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL08_CD, Types.CHAR));
		
		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL09_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL10_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL11_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL12_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL13_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL14_CD, Types.CHAR));
		
		declareParameter(new SqlParameter(DBConstants.HRPRL_BUSRL15_CD, Types.CHAR));



		//declareParameter(new SqlOutParameter(DBConstants.ADD_UPD_IND, Types.DECIMAL));

		//declareParameter(new SqlOutParameter(DBConstants.OUT_ERSPMSG_ID, Types.DECIMAL));

		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));

	}

	

	/**

	 * Method to add new HRPRULE to data store.

	 * 

	 * @param hrpruleDTO

	 *            hrpruleDTO object.

	 * @return Map of added HRPRULE data and success or error message.

	 * 

	 * @exception ApplicationException

	 *                if insertion fails.

	 */

	@SuppressWarnings("unchecked")

	public Map addNewHrpRule(HrpRuleDTO hrpruleDTO) throws ApplicationException {

		

		log.warn("Entered HrpRuleAddAdapter  - addNewHrpRule");

		String newMessage ="";

		//String effDt=getCurrentDate();

		//String expDt = EXPDT;

		Map results = null;

		Map<String, String> params = new java.util.LinkedHashMap<String, String>();

		Map hrpruleMap = new HashMap();

		//Timestamp currentTS = new Timestamp(System.currentTimeMillis());

		//String postedDate = currentTS.toString(); 

		//tierdmsgDTO.setPostedDateTimeStamp(postedDate);

		//tierdmsgDTO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);

		//tierdmsgDTO.setMessageId(MESSAGE_ID);

		//tierdmsgDTO.setEffDt(effDt);

		//tierdmsgDTO.setExpDt(expDt);
		
		params.put(DBConstants.HRPRL_SVTYP_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlSvcTyp()));

		params.put(DBConstants.HRPRL_RL_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlRulecd()));

		params.put(DBConstants.HRPRL_EFF_DT, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlEffdt()));
		
		params.put(DBConstants.HRPRL_TERM_DT, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlTermdt()));
		
		params.put(DBConstants.HRPRL_RLE_DESC, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlRuledesc()));

		params.put(DBConstants.HRPRL_CNSPF_IND, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlCondspec()));

		params.put(DBConstants.HRPRL_RLCTG_IND, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlRulectgry()));
		
		params.put(DBConstants.HRPRL_CVG_IND, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlCovgind()));
		
		params.put(DBConstants.HRPRL_TXSD_IND, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlTextsnd()));

		params.put(DBConstants.HRPRL_PSTS_IND, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlPosTob()));

		params.put(DBConstants.HRPRL_TYP_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlTobcd()));
		
		params.put(DBConstants.HRPRL_PLSVC_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlPoscd()));
		
		params.put(DBConstants.HRPRL_ST_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlStatecd()));

		params.put(DBConstants.HRPRL_AMTRFT_IND, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlAmntrfmt()));

		params.put(DBConstants.HRPRL_BUSRL01_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus01()));
		
		params.put(DBConstants.HRPRL_BUSRL02_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus02()));
		
		params.put(DBConstants.HRPRL_BUSRL03_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus03()));

		params.put(DBConstants.HRPRL_BUSRL04_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus04()));

		params.put(DBConstants.HRPRL_BUSRL05_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus05()));
		
		params.put(DBConstants.HRPRL_BUSRL06_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus06()));
		
		params.put(DBConstants.HRPRL_BUSRL07_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus07()));

		params.put(DBConstants.HRPRL_BUSRL08_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus08()));

		params.put(DBConstants.HRPRL_BUSRL09_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus09()));
		
		params.put(DBConstants.HRPRL_BUSRL10_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus10()));
		
		params.put(DBConstants.HRPRL_BUSRL11_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus11()));

		params.put(DBConstants.HRPRL_BUSRL12_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus12()));

		params.put(DBConstants.HRPRL_BUSRL13_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus13()));
		
		params.put(DBConstants.HRPRL_BUSRL14_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus14()));
		
		params.put(DBConstants.HRPRL_BUSRL15_CD, RteIntranetUtils.getTrimmedString(hrpruleDTO.getHrprlBus15()));


		log.warn(params);	

		try {

			log.warn("HrpRuleAddAdapter: Starting stored procedure");
			
			results = execute(params);

			log.warn("HrpRuleAddAdapter: Executed stored procedure");

			
			//String actionCode =  String.valueOf(results.get(DBConstants.ADD_UPD_IND));

			//String returnId =  String.valueOf(results.get(DBConstants.OUT_ERSPMSG_ID));

			
			String sqlCode =  String.valueOf(results.get(DBConstants.LS_SQLCODE));


			if ((ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) || ("100".equalsIgnoreCase(sqlCode))) {

				//tierdmsgDTO.setMessageId(Integer.parseInt(returnId));

				List<HrpRuleDTO> hrpruleList = new LinkedList<HrpRuleDTO>();

				hrpruleList.add(hrpruleDTO);

				hrpruleMap.put("hrpruleList", hrpruleList);

				if ("100".equalsIgnoreCase(sqlCode))

					newMessage ="Row added to HRPRULE table";

				else 

					if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode))

						newMessage ="Row updated on HRPRULE table";	

				}

			else {

				newMessage = "Unable to add or update row to the database. SQLCODE = " + sqlCode;

			}

			hrpruleMap.put("hrpruleMessage", newMessage);

		return hrpruleMap;

	}catch (Exception exception){

		log.error("HrpRuleAddAdapter : generic error occured  "+exception);

		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);

	}



}

	

	/**

	 * Method to add/update list of HRPRULE to data store.

	 * 

	 * @param existingHrpRule

	 *            

	 * @param hrpruleDtoList

	 *            list of HrpRuleDTO object.

	 * @param index

	 *            index to update the data

	 * @param updateInd

	 * 			  update indicator to update the data

	 * @return Map of flag to delete the data from HRPRULE list, success or

	 *         error message and list of HRPRULE.

	 * @exception ApplicationException

	 *                if insertion or update fails.

	 */

	@SuppressWarnings("unchecked")

	public Map addUpdateHrpRule(HrpRuleDTO existingHrpRule,

			List<HrpRuleDTO> hrpruleDtoList, int index,char updateInd) throws ApplicationException{

		log.warn("Entered HrpRuleAddAdapter  - addUpdateHrpRule");

		boolean isHrpRuleAddorUpdated = false;

		String newMessage ="";

		String msg = "All rows that changed the database are highlighted.";

		Map results = null;

		Map<String, String> params = new java.util.LinkedHashMap<String, String>();

		Map hrpruleMap = new HashMap();

		//Timestamp currentTS = new Timestamp(System .currentTimeMillis());

		//String postedDate  = currentTS.toString();

		//existingTierdMsg.setPostedDateTimeStamp(postedDate);

	try {
		
			params.put(DBConstants.HRPRL_SVTYP_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlSvcTyp()));
	
			params.put(DBConstants.HRPRL_RL_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlRulecd()));
	
			params.put(DBConstants.HRPRL_EFF_DT, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlEffdt()));
			
			params.put(DBConstants.HRPRL_TERM_DT, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlTermdt()));
			
			params.put(DBConstants.HRPRL_RLE_DESC, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlRuledesc()));
	
			params.put(DBConstants.HRPRL_CNSPF_IND, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlCondspec()));
	
			params.put(DBConstants.HRPRL_RLCTG_IND, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlRulectgry()));
			
			params.put(DBConstants.HRPRL_CVG_IND, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlCovgind()));
			
			params.put(DBConstants.HRPRL_TXSD_IND, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlTextsnd()));
	
			params.put(DBConstants.HRPRL_PSTS_IND, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlPosTob()));
	
			params.put(DBConstants.HRPRL_TYP_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlTobcd()));
			
			params.put(DBConstants.HRPRL_PLSVC_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlPoscd()));
			
			params.put(DBConstants.HRPRL_ST_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlStatecd()));
	
			params.put(DBConstants.HRPRL_AMTRFT_IND, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlAmntrfmt()));
	
			params.put(DBConstants.HRPRL_BUSRL01_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus01()));
			
			params.put(DBConstants.HRPRL_BUSRL02_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus02()));
			
			params.put(DBConstants.HRPRL_BUSRL03_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus03()));
	
			params.put(DBConstants.HRPRL_BUSRL04_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus04()));
	
			params.put(DBConstants.HRPRL_BUSRL05_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus05()));
			
			params.put(DBConstants.HRPRL_BUSRL06_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus06()));
			
			params.put(DBConstants.HRPRL_BUSRL07_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus07()));
	
			params.put(DBConstants.HRPRL_BUSRL08_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus08()));
	
			params.put(DBConstants.HRPRL_BUSRL09_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus09()));
			
			params.put(DBConstants.HRPRL_BUSRL10_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus10()));
			
			params.put(DBConstants.HRPRL_BUSRL11_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus11()));
	
			params.put(DBConstants.HRPRL_BUSRL12_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus12()));
	
			params.put(DBConstants.HRPRL_BUSRL13_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus13()));
			
			params.put(DBConstants.HRPRL_BUSRL14_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus14()));
			
			params.put(DBConstants.HRPRL_BUSRL15_CD, RteIntranetUtils.getTrimmedString(existingHrpRule.getHrprlBus15()));
		
		
		/*
		

			params.put(DBConstants.TIERDMSG_TYPE_CD, containsUnprintableCharacters(existingTierdMsg.getTierdMsgtypCd()));

			params.put(DBConstants.TIERDMSG_TIERST_CD, containsUnprintableCharacters(existingTierdMsg.getTierdTierstCd()));

			params.put(DBConstants.TIERDMSG_EFF_DT, containsUnprintableCharacters(existingTierdMsg.getEffDt()));

			params.put(DBConstants.TIERDMSG_EXP_DT, containsUnprintableCharacters(existingTierdMsg.getExpDt()));

			params.put(DBConstants.ERSPMSG_ID, String.valueOf(existingTierdMsg.getMessageId()));

			params.put(DBConstants.ERSPMSG_MSGTYP_CD, containsUnprintableCharacters(existingTierdMsg.getMessageTypeCd()));

			params.put(DBConstants.ERSPMSG_SHORT_TXT, containsUnprintableCharacters(existingTierdMsg.getShortText()));

			params.put(DBConstants.ERSPMSG_LONG_TXT, containsUnprintableCharacters(existingTierdMsg.getFullText()));

			params.put(DBConstants.TIERDMSG_PSTD_DTS, RteIntranetUtils.getTrimmedString(existingTierdMsg.getPostedDateTimeStamp()));

			params.put(DBConstants.TIERDMSG_USER_ID, RteIntranetUtils.getTrimmedString(existingTierdMsg.getUserId()));
			
			
		*/

			log.warn(params);	

			log.warn("HrpRuleAddAdapter: Starting stored procedure");
			
			results = execute(params);

			log.warn("HrpRuleAddAdapter: Executed stored procedure");

			
			//String updatedInd =  String.valueOf(results.get(DBConstants.ADD_UPD_IND));

			//String returnId =  String.valueOf(results.get(DBConstants.OUT_ERSPMSG_ID));

			
			String sqlCode =  String.valueOf(results.get(DBConstants.LS_SQLCODE));

			if ((ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) || ("100".equalsIgnoreCase(sqlCode))){

				isHrpRuleAddorUpdated = true;

					//existingTierdMsg.setMessageId(Integer.parseInt(returnId));

					//if (!updatedInd.equalsIgnoreCase(ApplicationConstants.ZERO_0))

					//	hrpruleDtoList.set(index, existingHrpRule);
				
				if ("100".equalsIgnoreCase(sqlCode)) {

					if (updateInd == ApplicationConstants.COPY)						

						hrpruleDtoList.set(index, existingHrpRule);						

					else

						hrpruleDtoList.add(existingHrpRule);
					
					newMessage ="Row added to HRPRULE table";
					
				}

				else 

					if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {

						hrpruleDtoList.set(index, existingHrpRule);	
						
						newMessage ="Row updated on HRPRULE table";	

					}

			} else {

				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;

			}

			hrpruleMap.put("hrpruleMsg",newMessage);

			hrpruleMap.put("hrpruleDtoList",hrpruleDtoList);

			hrpruleMap.put("isHrpRuleAddorUpdated", isHrpRuleAddorUpdated);

			return hrpruleMap;

		}catch (Exception exception){

			log.error("HrpRuleAdapter : generic error occured  "+exception);

			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);

		}



	}

	
	/*

		private String getCurrentDate(){

			Calendar calendar = Calendar.getInstance() ;

			String curDate=null;

			int year =calendar.get(Calendar.YEAR);

			int month =calendar.get(Calendar.MONTH)+1;

			int day =calendar.get(Calendar.DAY_OF_MONTH);

			curDate=""+year+"-"+formatDate(month)+"-"+formatDate(day);

			return curDate;

		}

		private  String formatDate(int value){

			String fdate;

			if (value <10){

				fdate ="0"+value;

			}else{

				fdate =""+value;

			}

			return fdate;

		}


	*/


		/**

		 * This method is used replace the expression (\s) with whit space.

		 * 

		 * @param input

		 * @return

		 */

	/*
		private String replaceLinearWhiteSpace(String input) {

			return p.matcher(input).replaceAll(" ");

		}

	*/

		/**

		 * This method is used identify the unprintable characters in input string.

		 * 

		 * @param input

		 * @return

		 * @throws Exception

		 */

	/*
		private String containsUnprintableCharacters(String input) throws Exception {



			String s = input;

			int id = -1;

			char ch = 0;

			if (null != input) {

				s = replaceLinearWhiteSpace(input);



				for (int i = 0; i < s.length(); ++i) {

					ch = s.charAt(i);

					if ((ch < ' ') || (ch > '~')) {

						id = ch;

						break;

					}

				}

			}

			if (id != -1)

				throw new Exception(

						"Invalid parameter - Input parameter contains unprintable character.");

			else

				return s;

		}



		private String[] containsUnprintableCharacters(String[] input)

				throws Exception {

			int id = -1;

			char ch = 0;

			for (int j = 0; j < input.length; j++) {

				String s = replaceLinearWhiteSpace(input[j]);

				input[j] = s;



				for (int i = 0; i < s.length(); ++i) {

					ch = s.charAt(i);

					if ((ch < ' ') || (ch > '~')) {

						id = ch;

						break;

					}

				}

				if (id != -1)

					break;



			}



			if (id != -1)

				throw new Exception(

						"Invalid parameter - Input parameter contains unprintable character.");

			else

				return input;

		}


   */


}