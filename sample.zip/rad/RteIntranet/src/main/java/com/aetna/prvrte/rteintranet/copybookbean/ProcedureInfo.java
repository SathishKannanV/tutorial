package com.aetna.prvrte.rteintranet.copybookbean;

import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


public class ProcedureInfo {

	String procedureCode;
	String qualifier;
	public String getProcedureCode() {
		
		return procedureCode;
	}
	public void setProcedureCode(String procedureCode) {
		
		this.procedureCode = procedureCode;
	}
	public String getQualifier() {
		
		return qualifier;
	}
	public void setQualifier(String qualifier) {
		
		this.qualifier = qualifier;
	}
	
	public StringBuilder getProcedureInfo(){
		return new StringBuilder(RteIntranetUtils.spaceFiller(11, getProcedureCode()))
		.append(RteIntranetUtils.spaceFiller(2, getQualifier()));
	}
}
