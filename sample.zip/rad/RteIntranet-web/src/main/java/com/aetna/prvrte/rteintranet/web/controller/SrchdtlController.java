/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.SrchcolDTO;
import com.aetna.prvrte.rteintranet.dto.SrchdtlDTO;
import com.aetna.prvrte.rteintranet.dto.SrcherrDTO;
import com.aetna.prvrte.rteintranet.dto.SrchresDTO;
import com.aetna.prvrte.rteintranet.dto.SrchscDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.SrchcolVO;
import com.aetna.prvrte.rteintranet.vo.SrchdtlVO;
import com.aetna.prvrte.rteintranet.vo.SrcherrVO;
import com.aetna.prvrte.rteintranet.vo.SrchresVO;
import com.aetna.prvrte.rteintranet.vo.SrchscVO;

/**
 * @author N731694
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/srchdtl/*")
public class SrchdtlController {

	public static final String SRCHDTL_HOME = ".srchdtlHome";
	public static final String SRCHDTL_LOOKUP = ".srchdtlLookUpDisplay";
	public static final String SRCHCOL_DISPLAY = ".srchcolDisplay";
	public static final String SRCHSC_DISPLAY = ".srchscDisplay";
	public static final String SRCHERR_DISPLAY = ".srcherrDisplay";
	public static final String SRCHRES_DISPLAY = ".srchresDisplay";
	public static final String SRCHCOL_DISPLAY_LINK = ".srchcolDisplayLink";
	public static final String SRCHSC_DISPLAY_LINK = ".srchscDisplayLink";
	public static final String SRCHRES_DISPLAY_LINK = ".srchresDisplayLink";
	public static final String SRCHERR_DISPLAY_LINK = ".srcherrDisplayLink";
	

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(SrchdtlController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;
	
	@RequestMapping(value="/srchdtlHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getSrchdtlLookUpHome(final HttpServletRequest request,Model model) {	
		log.debug("Entered SrchdtlController - getSrchdtlLookUpHome()");
		String securityLevel ="";
		try {
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(SRCHDTL_HOME, "SrchdtlVO",  new SrchdtlVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("ProcexController - securityLevel: "+ securityLevel);
		log.debug("Exit from SrchdtlController - getSrchdtlLookUpHome()");
		return mav;
		}
		 catch (ApplicationException e){
				log.error("Exception occured in SrchdtlController - getSrchdtlLookUpTable() method:"+e.getErrorMessage());
				String errorMsg ="Error encountered when extracting data from the database (srchdtlHome). "+
						RteIntranetUtils.getTrimmedString(e.getErrorMessage());
				errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
				errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
				return errormav;
			}
	}
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSrchdtl", method = RequestMethod.POST)
	public ModelAndView getSrchdtlkLookUpTable(final HttpServletRequest request,@ModelAttribute("srchdtlForm")SrchdtlVO srchdtlVO){
		log.debug("Entered SrchdtlController - getSrchdtlkLookUpTable()");
		String srchscFirstId="" ;
		String srchscSecondId ="";
		String srcherrCd ="";
		String srchcolCd ="";	
		String securityLevel ="";
		ModelAndView mav ;
		Map srchdtlResultMap = new HashMap();
		List<SrchdtlVO> srchdtlList = new LinkedList<SrchdtlVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchscFirstId = srchdtlVO.getSrchscFirstId();
			srchscSecondId =srchdtlVO.getSrchscSecondId();
			srcherrCd=srchdtlVO.getSrcherrCd();
			srchcolCd=srchdtlVO.getSrchcolCd();
			srchdtlResultMap = facade.getSrchdtlLookUpTable(srchscFirstId, srchscSecondId,srcherrCd,srchcolCd);
		
			srchdtlList = (List<SrchdtlVO>) srchdtlResultMap.get("srchdtlList");
		    lookUpListVO.setSrchdtlVOList(srchdtlList);
		
			facade.getApplicationState().setSrchdtlList(srchdtlList);
			mav = new ModelAndView(SRCHDTL_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("srchdtlMessage", srchdtlResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.debug("getSrchdtlLookUpTable - srchdtlMessage: "+ srchdtlResultMap.get("newMessage"));
			log.debug("Exit from SrchdtlController - getSrchdtlLookUpTable()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in SrchdtlController - getSrchdtlLookUpTable() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (SrchdtlList).";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/DeleteSrchdtl", method = RequestMethod.POST)
	public ModelAndView deleteSrchdtl(final HttpServletRequest request,@ModelAttribute("srchdtlDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String srchdtlMsg = "";
		boolean issrchdtlDeleted = true;
		String securityLevel ="";
		Map srchdtlResultMap = new HashMap();
		List<SrchdtlVO> srchdtlList = new LinkedList<SrchdtlVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchdtlList = lookUpListVO.getSrchdtlVOList();
			int i;
			if ((srchdtlList != null) && (takeAction != null)) {
				for(SrchdtlVO srchdtlVO : srchdtlList){
					if(srchdtlVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						srchdtlVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					SrchdtlVO editedSrchdtl = (SrchdtlVO) srchdtlList.get(i);
					if (editedSrchdtl.getUpdatedInd() != ApplicationConstants.COPY) {
						SrchdtlDTO srchdtlDTO = RTETranslator.toSrchdtlDTO(editedSrchdtl);
						srchdtlResultMap = facade.deleteSrchdtl(srchdtlDTO);
						srchdtlMsg = (String) srchdtlResultMap.get("srchdtlMsg");
						issrchdtlDeleted = (Boolean) srchdtlResultMap.get("isSrchdtlDeleted");
						
						if(issrchdtlDeleted == true){
							srchdtlList.remove(i);
						}else{
							j = 0;
						}
					}else{
						srchdtlList.remove(i);
					}				
			}
				if(issrchdtlDeleted == true)
					srchdtlMsg = "Rows selected were Deleted in the database/list";
		}else
			srchdtlMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSrchdtlList(srchdtlList);
			lookUpListVO.setSrchdtlVOList(srchdtlList);
			mav = new ModelAndView(SRCHDTL_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("srchdtlMessage",srchdtlMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.debug("deleteSrchdtl - srchdtlMessage: "+ srchdtlMsg);
		    log.debug("Exit from SrchdtlController - deleteSrchdtl()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SrchdtlController - deleteSrchdtl() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteSrchdtl() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	@RequestMapping(value="/copySrchdtl", method = RequestMethod.POST)
	public ModelAndView copySrchdtl(final HttpServletRequest request,@ModelAttribute("srchdtlDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.debug("Entered from SrchdtlController - copySrchdtl()");
		ModelAndView mav ;
		String srchdtlMsg = "";
		String securityLevel ="";
		int i;
		List<SrchdtlVO> srchdtlList = new LinkedList<SrchdtlVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			String postedDate = RteIntranetUtils.getTodaysDate();

			srchdtlList = lookUpListVO.getSrchdtlVOList();
			if ((srchdtlList != null) && (takeAction != null)) {
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					SrchdtlVO existingSrchdtl = (SrchdtlVO) srchdtlList.get(i);
					String srchdtlId="0";
					SrchdtlVO copySrchdtl = new SrchdtlVO(existingSrchdtl.getSrchscFirstId(), existingSrchdtl.getSrchcolCd(),existingSrchdtl.getSrchresCd(),
							existingSrchdtl.getSrchscSecondId(),existingSrchdtl.getSrchdtlStCd(),existingSrchdtl.getSrcherrCd(),existingSrchdtl.getcmRollCode(),existingSrchdtl.getEffDate(),
							existingSrchdtl.getExpDate(),postedDate,srchdtlId,				
							ApplicationConstants.COPY);
					srchdtlList.add(copySrchdtl);
				}
				srchdtlMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				srchdtlMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSrchdtlList(srchdtlList);
			lookUpListVO.setSrchdtlVOList(srchdtlList);
			mav = new ModelAndView(SRCHDTL_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("srchdtlMessage",srchdtlMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.debug("copySrchdtl - srchdtlMessage: "+ srchdtlMsg);
		    log.debug("Exit from SrchdtlController - copySrchdtl()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in SrchdtlController - copySrchdtl() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (Copy Srchdtl). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateSrchdtl", method = RequestMethod.POST)
	public ModelAndView addUpdateSrchdtl(final HttpServletRequest request,@ModelAttribute("srchdtlDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.debug("Entered from SrchdtlController - addUpdateSrchdtl()");
		ModelAndView mav ;
		String srchdtlMsg = "";
		String securityLevel ="";
		List<SrchdtlVO> updatedSrchdtlList = new LinkedList<SrchdtlVO>();
		List<SrchdtlDTO> updatedSrchdtlDtoList = new LinkedList<SrchdtlDTO>();
		List<SrchdtlVO> srchdtlVoList = new LinkedList<SrchdtlVO>();
		List<SrchdtlVO> modifiedSrchdtlVoList = new LinkedList<SrchdtlVO>();
		List<SrchdtlDTO> srchdtlDtoList = new LinkedList<SrchdtlDTO>(); 
		boolean isSrchdtlAddOrUpdated = false;
		Map srchdtlResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchdtlVoList = facade.getApplicationState().getSrchdtlList();
			modifiedSrchdtlVoList = lookUpListVO.getSrchdtlVOList();
			int i;
			String postedDate = RteIntranetUtils.getTodaysDate();
			if (takeAction != null && takeAction.length != 0) {
				if(srchdtlVoList != null && srchdtlVoList.size() != 0 
						&& modifiedSrchdtlVoList.size() != 0 && modifiedSrchdtlVoList != null){
				for(SrchdtlVO srchdtlVO : srchdtlVoList){
					if(srchdtlVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						srchdtlVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				srchdtlDtoList = RTETranslator.toSrchdtlDTOList(srchdtlVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					SrchdtlVO seletedSrchdtl = (SrchdtlVO) srchdtlVoList.get(i);
					SrchdtlVO editedSrchdtl = (SrchdtlVO) modifiedSrchdtlVoList.get(i);
					SrchdtlVO editedSrchdtlVO = new SrchdtlVO(editedSrchdtl.getSrchscFirstId(), editedSrchdtl.getSrchcolCd(),editedSrchdtl.getSrchresCd(),
							editedSrchdtl.getSrchscSecondId(),editedSrchdtl.getSrchdtlStCd(),editedSrchdtl.getSrcherrCd(),editedSrchdtl.getcmRollCode(),editedSrchdtl.getEffDate(),
							editedSrchdtl.getExpDate(),postedDate,editedSrchdtl.getSrchdtlId()	,  updatedInd);
					SrchdtlDTO editedSrchdtlDTO = RTETranslator.toSrchdtlDTO(editedSrchdtlVO);
					srchdtlResultMap = facade.addUpdateSrchdtl(editedSrchdtlDTO, srchdtlDtoList, i , seletedSrchdtl.getUpdatedInd());
					updatedSrchdtlDtoList = (List<SrchdtlDTO>) srchdtlResultMap.get("srchdtlDtoList");
					updatedSrchdtlList = RTETranslator.toSrchdtlVOList(updatedSrchdtlDtoList);
					isSrchdtlAddOrUpdated = srchdtlResultMap.get("isSrchdtlAddOrUpdated") != null ;
					srchdtlMsg = (String) srchdtlResultMap.get("srchdtlMsg") ;
					if(isSrchdtlAddOrUpdated!= true){
						j = takeAction.length;
					}
				}
			
				lookUpListVO.setSrchdtlVOList(updatedSrchdtlList);
				facade.getApplicationState().setSrchdtlList(updatedSrchdtlList);
			} else {
				throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	
			}
		}else{
			srchdtlMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setSrchdtlVOList(srchdtlVoList);
			facade.getApplicationState().setSrchdtlList(srchdtlVoList);
		}
			mav = new ModelAndView(SRCHDTL_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("srchdtlMessage",srchdtlMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.debug("addUpdateSrchdtl - srchdtlMessage: "+ srchdtlMsg);
		    log.debug("Exit from SrchdtlController - addUpdateSrchdtl()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SrchdtlController - addUpdateSrchdtl() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addUpdateRtetpbr() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSrchcol", method = RequestMethod.POST)
	public ModelAndView getSrchcolLookUpTable(final HttpServletRequest request,@ModelAttribute("srchcolDisplayForm")SrchcolVO srchcolVO){
		log.debug("Entered SrchdtlController - getSrchcolLookUpTable()");
		String srchcolCd="" ;
		String securityLevel ="";
		
		ModelAndView mav ;
		Map srchcolResultMap = new HashMap();
		List<SrchcolVO> srchcolList = new LinkedList<SrchcolVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchcolCd=srchcolVO.getSrchcolCd();
			srchcolResultMap = facade.getSrchcolLookUpTable(srchcolCd);
		
			srchcolList = (List<SrchcolVO>) srchcolResultMap.get("srchcolList");
		    lookUpListVO.setSrchcolVOList(srchcolList);
		
			facade.getApplicationState().setSrchcolList(srchcolList);
			mav = new ModelAndView(SRCHCOL_DISPLAY, "lookUpListVO", lookUpListVO);
			mav.addObject("srchcolMessage", srchcolResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.debug("getSrchcolLookUpTable - srchcolMessage: "+ srchcolResultMap.get("newMessage"));
			log.debug("Exit from SrchcolController - getSrchcolLookUpTable()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in SrchdtlController - getSrchdtlLookUpTable() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSrchdtlml). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSrchcolLink", method = RequestMethod.GET)
	public ModelAndView getSrchcolLinkLookUpTable(final HttpServletRequest request,@ModelAttribute("srchdtlDisplayForm")SrchcolVO srchcolVO){
		log.debug("Entered SrchdtlController - getSrchcolLookUpTable()");
		String srchcolCd="" ;
		String securityLevel ="";
		
		ModelAndView mav ;
		Map srchcolResultMap = new HashMap();
		List<SrchcolVO> srchcolList = new LinkedList<SrchcolVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchcolCd=srchcolVO.getSrchcolCd();
			srchcolResultMap = facade.getSrchcolLookUpTable(srchcolCd);
		
			srchcolList = (List<SrchcolVO>) srchcolResultMap.get("srchcolList");
		    lookUpListVO.setSrchcolVOList(srchcolList);
		
			facade.getApplicationState().setSrchcolList(srchcolList);
			mav = new ModelAndView(SRCHCOL_DISPLAY_LINK, "lookUpListVO", lookUpListVO);
			mav.addObject("srchcolMessage", srchcolResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.debug("getSrchcolLookUpTable - srchcolMessage: "+ srchcolResultMap.get("newMessage"));
			log.debug("Exit from SrchcolController - getSrchcolLookUpTable()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in SrchdtlController - getSrchdtlLookUpTable() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSrchdtlml). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSrchsc", method = RequestMethod.POST)
	public ModelAndView getSrchscLookUpTable(final HttpServletRequest request,@ModelAttribute("srchcolDisplayForm")SrchscVO srchscVO){
		log.debug("Entered SrchdtlController - getSrchscLookUpTable()");
		String srchscId="";
		String securityLevel ="";
		
		ModelAndView mav ;
		Map srchscResultMap = new HashMap();
		List<SrchscVO> srchscList = new LinkedList<SrchscVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchscId=srchscVO.getSrchscId();
					srchscResultMap = facade.getSrchscLookUpTable(srchscId);
		
			srchscList = (List<SrchscVO>) srchscResultMap.get("srchscList");
		    lookUpListVO.setSrchscVOList(srchscList);
		
			facade.getApplicationState().setSrchscList(srchscList);
			mav = new ModelAndView(SRCHSC_DISPLAY, "lookUpListVO", lookUpListVO);
			mav.addObject("srchscMessage", srchscResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.debug("getSrchscLookUpTable - srchscMessage: "+ srchscResultMap.get("newMessage"));
			log.debug("Exit from SrchdtlController - getSrchscLookUpTable()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in SrchdtlController - getSrchdtlLookUpTable() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSrchdtlml). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSrchscLink", method = RequestMethod.GET)
	public ModelAndView getSrchscLinkLookUpTable(final HttpServletRequest request,@ModelAttribute("srchcolDisplayForm")SrchscVO srchscVO){
		log.debug("Entered SrchdtlController - getSrchscLookUpTable()");
		String srchscId="";
		String securityLevel ="";
		
		ModelAndView mav ;
		Map srchscResultMap = new HashMap();
		List<SrchscVO> srchscList = new LinkedList<SrchscVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchscId=srchscVO.getSrchscId();
					srchscResultMap = facade.getSrchscLookUpTable(srchscId);
		
			srchscList = (List<SrchscVO>) srchscResultMap.get("srchscList");
		    lookUpListVO.setSrchscVOList(srchscList);
		
			facade.getApplicationState().setSrchscList(srchscList);
			mav = new ModelAndView(SRCHSC_DISPLAY_LINK, "lookUpListVO", lookUpListVO);
			mav.addObject("srchscMessage", srchscResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.debug("getSrchscLookUpTable - srchscMessage: "+ srchscResultMap.get("newMessage"));
			log.debug("Exit from SrchdtlController - getSrchscLookUpTable()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in SrchdtlController - getSrchdtlLookUpTable() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSrchdtlml). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSrcherr", method = RequestMethod.POST)
	public ModelAndView getSrcherrLookUpTable(final HttpServletRequest request,@ModelAttribute("srcherrDisplayForm")SrcherrVO srcherrVO){
		log.debug("Entered SrchdtlController - getSrcherrLookUpTable()");
		String srcherrCd="";
		String securityLevel ="";
		ModelAndView mav ;
		Map srcherrResultMap = new HashMap();
		List<SrcherrVO> srcherrList = new LinkedList<SrcherrVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srcherrCd=srcherrVO.getSrcherrCd();
			srcherrResultMap = facade.getSrcherrLookUpTable(srcherrCd);
		
			srcherrList = (List<SrcherrVO>) srcherrResultMap.get("srcherrList");
		    lookUpListVO.setSrcherrVOList(srcherrList);
		
			facade.getApplicationState().setSrcherrList(srcherrList);
			mav = new ModelAndView(SRCHERR_DISPLAY, "lookUpListVO", lookUpListVO);
			mav.addObject("srcherrMessage", srcherrResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.debug("getSrcherrLookUpTable - srcherrMessage: "+ srcherrResultMap.get("newMessage"));
			log.debug("Exit from SrchdtlController - getSrcherrLookUpTable()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in SrchdtlController - getSrcherrLookUpTable() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSrchdtl). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSrcherrLink", method = RequestMethod.GET)
	public ModelAndView getSrcherrLinkLookUpTable(final HttpServletRequest request,@ModelAttribute("srcherrDisplayForm")SrcherrVO srcherrVO){
		log.debug("Entered SrchdtlController - getSrcherrLookUpTable()");
		String srcherrCd="";
		String securityLevel ="";
		ModelAndView mav ;
		Map srcherrResultMap = new HashMap();
		List<SrcherrVO> srcherrList = new LinkedList<SrcherrVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srcherrCd=srcherrVO.getSrcherrCd();
			srcherrResultMap = facade.getSrcherrLookUpTable(srcherrCd);
		
			srcherrList = (List<SrcherrVO>) srcherrResultMap.get("srcherrList");
		    lookUpListVO.setSrcherrVOList(srcherrList);
		
			facade.getApplicationState().setSrcherrList(srcherrList);
			mav = new ModelAndView(SRCHERR_DISPLAY_LINK, "lookUpListVO", lookUpListVO);
			mav.addObject("srcherrMessage", srcherrResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.debug("getSrcherrLookUpTable - srcherrMessage: "+ srcherrResultMap.get("newMessage"));
			log.debug("Exit from SrchdtlController - getSrcherrLookUpTable()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in SrchdtlController - getSrcherrLookUpTable() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSrchdtl). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSrchres", method = RequestMethod.POST)
	public ModelAndView getSrchresLookUpTable(final HttpServletRequest request,@ModelAttribute("srchresDisplayForm")SrchresVO srchresVO){
		log.debug("Entered SrchdtlController - getSrchresLookUpTable()");
		String srchresCd="";
		String securityLevel ="";
		ModelAndView mav ;
		Map srchresResultMap = new HashMap();
		List<SrchresVO> srchresList = new LinkedList<SrchresVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchresCd=srchresVO.getSrchresCd();
			srchresResultMap = facade.getSrchresLookUpTable(srchresCd);
		
			srchresList = (List<SrchresVO>) srchresResultMap.get("srchresList");
		    lookUpListVO.setSrchresVOList(srchresList);
		
			facade.getApplicationState().setSrchresList(srchresList);
			mav = new ModelAndView(SRCHRES_DISPLAY, "lookUpListVO", lookUpListVO);
			mav.addObject("srchresMessage", srchresResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.debug("getSrchresLookUpTable - srchresMessage: "+ srchresResultMap.get("newMessage"));
			log.debug("Exit from SrchdtlController - getSrchresLookUpTable()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in SrchdtlController - getSrcherrLookUpTable() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSrchdtl). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSrchresLink", method = RequestMethod.GET)
	public ModelAndView getSrchresLinkLookUpTable(final HttpServletRequest request,@ModelAttribute("srchresDisplayForm")SrchresVO srchresVO){
		log.debug("Entered SrchdtlController - getSrchresLookUpTable()");
		String srchresCd="";
		String securityLevel ="";
		ModelAndView mav ;
		Map srchresResultMap = new HashMap();
		List<SrchresVO> srchresList = new LinkedList<SrchresVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchresCd=srchresVO.getSrchresCd();
			srchresResultMap = facade.getSrchresLookUpTable(srchresCd);
		
			srchresList = (List<SrchresVO>) srchresResultMap.get("srchresList");
		    lookUpListVO.setSrchresVOList(srchresList);
		
			facade.getApplicationState().setSrchresList(srchresList);
			mav = new ModelAndView(SRCHRES_DISPLAY_LINK, "lookUpListVO", lookUpListVO);
			mav.addObject("srchresMessage", srchresResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.debug("getSrchresLookUpTable - srchresMessage: "+ srchresResultMap.get("newMessage"));
			log.debug("Exit from SrchdtlController - getSrchresLookUpTable()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in SrchdtlController - getSrcherrLookUpTable() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSrchdtl). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/DeleteSrchcol", method = RequestMethod.POST)
	public ModelAndView deleteSrchcol(final HttpServletRequest request,@ModelAttribute("srchcolDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String srchcolMsg = "";
		String securityLevel ="";
		boolean isSrchcolDeleted = true;
		Map srchcolResultMap = new HashMap();
		List<SrchcolVO> srchcolList = new LinkedList<SrchcolVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchcolList = lookUpListVO.getSrchcolVOList();
			int i;
			if ((srchcolList != null) && (takeAction != null)) {
				for(SrchcolVO srchcolVO : srchcolList){
					if(srchcolVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						srchcolVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					SrchcolVO editedSrchcol = (SrchcolVO) srchcolList.get(i);
					if (editedSrchcol.getUpdatedInd() != ApplicationConstants.COPY) {
						SrchcolDTO srchcolDTO = RTETranslator.toSrchcolDTO(editedSrchcol);
						srchcolResultMap = facade.deleteSrchcol(srchcolDTO);
						srchcolMsg = (String) srchcolResultMap.get("srchcolMsg");
						isSrchcolDeleted = (Boolean) srchcolResultMap.get("isSrchcolDeleted");
						
						if(isSrchcolDeleted == true){
							srchcolList.remove(i);
						}else{
							j = 0;
						}
					}else{
						srchcolList.remove(i);
					}				
			}
				if(isSrchcolDeleted == true)
					srchcolMsg = "Rows selected were Deleted in the database/list";
		}else
			srchcolMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSrchcolList(srchcolList);
			lookUpListVO.setSrchcolVOList(srchcolList);
			mav = new ModelAndView(SRCHCOL_DISPLAY, "lookUpListVO", lookUpListVO);
		    mav.addObject("srchcolMessage",srchcolMsg);
			mav.addObject("securityLevel", securityLevel);
		    log.debug("deleteSrchcol - srchcolMessage: "+ srchcolMsg);
		    log.debug("Exit from SrchdtlController - deleteSrchcol()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SrchdtlController - deleteSrchcol() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteSrchcol() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/DeleteSrchsc", method = RequestMethod.POST)
	public ModelAndView deleteSrchsc(final HttpServletRequest request,@ModelAttribute("srchscDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String srchscMsg = "";
		String securityLevel ="";
		boolean isSrchscDeleted = true;
		Map srchscResultMap = new HashMap();
		List<SrchscVO> srchscList = new LinkedList<SrchscVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchscList = lookUpListVO.getSrchscVOList();
			int i;
			if ((srchscList != null) && (takeAction != null)) {
				for(SrchscVO srchscVO : srchscList){
					if(srchscVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						srchscVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					SrchscVO editedSrchsc = (SrchscVO) srchscList.get(i);
					if (editedSrchsc.getUpdatedInd() != ApplicationConstants.COPY) {
						SrchscDTO srchscDTO = RTETranslator.toSrchscDTO(editedSrchsc);
						srchscResultMap = facade.deleteSrchsc(srchscDTO);
						srchscMsg = (String) srchscResultMap.get("srchscMsg");
						isSrchscDeleted = (Boolean) srchscResultMap.get("isSrchscDeleted");
						
						if(isSrchscDeleted == true){
							srchscList.remove(i);
						}else{
							j = 0;
						}
					}else{
						srchscList.remove(i);
					}				
			}
				if(isSrchscDeleted == true)
					srchscMsg = "Rows selected were Deleted in the database/list";
		}else
			srchscMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSrchscList(srchscList);
			lookUpListVO.setSrchscVOList(srchscList);
			mav = new ModelAndView(SRCHSC_DISPLAY, "lookUpListVO", lookUpListVO);
		    mav.addObject("srchscMessage",srchscMsg);
			mav.addObject("securityLevel", securityLevel);
		    log.debug("deleteSrchsc - srchscMessage: "+ srchscMsg);
		    log.debug("Exit from SrchdtlController - deleteSrchsc()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SrchdtlController - deleteSrchsc() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteSrchsc() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/DeleteSrcherr", method = RequestMethod.POST)
	public ModelAndView deleteSrcherr(final HttpServletRequest request,@ModelAttribute("srcherrDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String srcherrMsg = "";
		String securityLevel ="";
		boolean isSrcherrDeleted = true;
		Map srcherrResultMap = new HashMap();
		List<SrcherrVO> srcherrList = new LinkedList<SrcherrVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srcherrList = lookUpListVO.getSrcherrVOList();
			int i;
			if ((srcherrList != null) && (takeAction != null)) {
				for(SrcherrVO srcherrVO : srcherrList){
					if(srcherrVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						srcherrVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					SrcherrVO editedSrcherr = (SrcherrVO) srcherrList.get(i);
					if (editedSrcherr.getUpdatedInd() != ApplicationConstants.COPY) {
						SrcherrDTO srcherrDTO = RTETranslator.toSrcherrDTO(editedSrcherr);
						srcherrResultMap = facade.deleteSrcherr(srcherrDTO);
						srcherrMsg = (String) srcherrResultMap.get("srcherrMsg");
						isSrcherrDeleted = (Boolean) srcherrResultMap.get("isSrcherrDeleted");
						
						if(isSrcherrDeleted == true){
							srcherrList.remove(i);
						}else{
							j = 0;
						}
					}else{
						srcherrList.remove(i);
					}				
			}
				if(isSrcherrDeleted == true)
					srcherrMsg = "Rows selected were Deleted in the database/list";
		}else
			srcherrMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSrcherrList(srcherrList);
			lookUpListVO.setSrcherrVOList(srcherrList);
			mav = new ModelAndView(SRCHERR_DISPLAY, "lookUpListVO", lookUpListVO);
		    mav.addObject("srcherrMessage",srcherrMsg);
			mav.addObject("securityLevel", securityLevel);
		    log.debug("deleteSrcherr - srcherrMessage: "+ srcherrMsg);
		    log.debug("Exit from SrchdtlController - deleteSrcherr()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SrchdtlController - deleteSrcherr() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteSrcherr() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/DeleteSrchres", method = RequestMethod.POST)
	public ModelAndView deleteSrchres(final HttpServletRequest request,@ModelAttribute("srchresDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String srchresMsg = "";
		String securityLevel ="";
		boolean isSrchresDeleted = true;
		Map srchresResultMap = new HashMap();
		List<SrchresVO> srchresList = new LinkedList<SrchresVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchresList = lookUpListVO.getSrchresVOList();
			int i;
			if ((srchresList != null) && (takeAction != null)) {
				for(SrchresVO srchresVO : srchresList){
					if(srchresVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						srchresVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					SrchresVO editedSrchres = (SrchresVO) srchresList.get(i);
					if (editedSrchres.getUpdatedInd() != ApplicationConstants.COPY) {
						SrchresDTO srchresDTO = RTETranslator.toSrchresDTO(editedSrchres);
						srchresResultMap = facade.deleteSrchres(srchresDTO);
						srchresMsg = (String) srchresResultMap.get("srchresMsg");
						isSrchresDeleted = (Boolean) srchresResultMap.get("isSrchresDeleted");
						
						if(isSrchresDeleted == true){
							srchresList.remove(i);
						}else{
							j = 0;
						}
					}else{
						srchresList.remove(i);
					}				
			}
				if(isSrchresDeleted == true)
					srchresMsg = "Rows selected were Deleted in the database/list";
		}else
			srchresMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSrchresList(srchresList);
			lookUpListVO.setSrchresVOList(srchresList);
			mav = new ModelAndView(SRCHRES_DISPLAY, "lookUpListVO", lookUpListVO);
		    mav.addObject("srchresMessage",srchresMsg);
			mav.addObject("securityLevel", securityLevel);
		    log.debug("deleteSrchcol - srchcolMessage: "+ srchresMsg);
		    log.debug("Exit from SrchdtlController - deleteSrchcol()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SrchdtlController - deleteSrchres() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteSrchres() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@RequestMapping(value="/copySrchcol", method = RequestMethod.POST)
	public ModelAndView copySrchcol(final HttpServletRequest request,@ModelAttribute("srchcolDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.debug("Entered from SrchdtlController - srchcolDisplayForm()");
		ModelAndView mav ;
		String srchcolMsg = "";
		String securityLevel ="";
		int i;
		List<SrchcolVO> srchcolList = new LinkedList<SrchcolVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			String postedDate = RteIntranetUtils.getTodaysDate();
			srchcolList = lookUpListVO.getSrchcolVOList();
			if ((srchcolList != null) && (takeAction != null)) {
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					SrchcolVO existingSrchcol = (SrchcolVO) srchcolList.get(i);
					
					SrchcolVO copySrchcol = new SrchcolVO(existingSrchcol.getSrchcolCd(),existingSrchcol.getSrchcolDesc(),
							existingSrchcol.getEffDate(),existingSrchcol.getExpDate(),postedDate,				
							ApplicationConstants.COPY);
					srchcolList.add(copySrchcol);
				}
				srchcolMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				srchcolMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSrchcolList(srchcolList);
			lookUpListVO.setSrchcolVOList(srchcolList);
			mav = new ModelAndView(SRCHCOL_DISPLAY, "lookUpListVO", lookUpListVO);
		    mav.addObject("srchcolMessage",srchcolMsg);
			mav.addObject("securityLevel", securityLevel);
		    log.debug("copySrchcol - srchcolMessage: "+ srchcolMsg);
		    log.debug("Exit from SrchdtlController - copySrchcol()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in SrchdtlController - copySrchcol() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (Copy Srchcol). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	@RequestMapping(value="/copySrchsc", method = RequestMethod.POST)
	public ModelAndView copySrchsc(final HttpServletRequest request,@ModelAttribute("srchscDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.debug("Entered from SrchdtlController - srchscDisplayForm()");
		ModelAndView mav ;
		String srchscMsg = "";
		String securityLevel ="";
		int i;
		List<SrchscVO> srchscList = new LinkedList<SrchscVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			String postedDate = RteIntranetUtils.getTodaysDate();
			srchscList = lookUpListVO.getSrchscVOList();
			if ((srchscList != null) && (takeAction != null)) {
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					SrchscVO existingSrchsc = (SrchscVO) srchscList.get(i);
					
					SrchscVO copySrchsc = new SrchscVO(existingSrchsc.getSrchscId(),existingSrchsc.getSrchscDesc(),
							existingSrchsc.getEffDate(),existingSrchsc.getExpDate(),postedDate,				
							ApplicationConstants.COPY);
					srchscList.add(copySrchsc);
				}
				srchscMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				srchscMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSrchscList(srchscList);
			lookUpListVO.setSrchscVOList(srchscList);
			mav = new ModelAndView(SRCHSC_DISPLAY, "lookUpListVO", lookUpListVO);
		    mav.addObject("srchscMessage",srchscMsg);
			mav.addObject("securityLevel", securityLevel);
		    log.debug("copySrchsc - srchscMessage: "+ srchscMsg);
		    log.debug("Exit from SrchdtlController - copySrchsc()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in SrchdtlController - copySrchsc() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (Copy Srchsc). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	@RequestMapping(value="/copySrcherr", method = RequestMethod.POST)
	public ModelAndView copySrcherr(final HttpServletRequest request,@ModelAttribute("srcherrDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.debug("Entered from SrchdtlController - srcherrDisplayForm()");
		ModelAndView mav ;
		String srcherrMsg = "";
		String securityLevel ="";
		int i;
		List<SrcherrVO> srcherrList = new LinkedList<SrcherrVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			String postedDate = RteIntranetUtils.getTodaysDate();
			srcherrList = lookUpListVO.getSrcherrVOList();
			if ((srcherrList != null) && (takeAction != null)) {
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					SrcherrVO existingSrcherr = (SrcherrVO) srcherrList.get(i);
					
					SrcherrVO copySrcherr = new SrcherrVO(existingSrcherr.getSrcherrCd(),existingSrcherr.getSrcherrCustInd(),existingSrcherr.getSrcherrDesc(),
							existingSrcherr.getEffDate(),existingSrcherr.getExpDate(),postedDate,				
							ApplicationConstants.COPY);
					srcherrList.add(copySrcherr);
				}
				srcherrMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				srcherrMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSrcherrList(srcherrList);
			lookUpListVO.setSrcherrVOList(srcherrList);
			mav = new ModelAndView(SRCHERR_DISPLAY, "lookUpListVO", lookUpListVO);
		    mav.addObject("srcherrMessage",srcherrMsg);
			mav.addObject("securityLevel", securityLevel);
		    log.debug("copySrcherr - srchscMessage: "+ srcherrMsg);
		    log.debug("Exit from SrchdtlController - copySrcherr()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in SrchdtlController - copySrchsc() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (Copy Srchsc). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}

	@RequestMapping(value="/copySrchres", method = RequestMethod.POST)
	public ModelAndView copySrchres(final HttpServletRequest request,@ModelAttribute("srchresDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.debug("Entered from SrchdtlController - srchresDisplayForm()");
		ModelAndView mav ;
		String srchresMsg = "";
		String securityLevel ="";
		int i;
		List<SrchresVO> srchresList = new LinkedList<SrchresVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			String postedDate = RteIntranetUtils.getTodaysDate();
			srchresList = lookUpListVO.getSrchresVOList();
			if ((srchresList != null) && (takeAction != null)) {
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					SrchresVO existingSrchres = (SrchresVO) srchresList.get(i);
					
					SrchresVO copySrchres = new SrchresVO(existingSrchres.getSrchresCd(),existingSrchres.getSrchresDesc(),
							existingSrchres.getEffDate(),existingSrchres.getExpDate(),postedDate,				
							ApplicationConstants.COPY);
					srchresList.add(copySrchres);
				}
				srchresMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				srchresMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSrchresList(srchresList);
			lookUpListVO.setSrchresVOList(srchresList);
			mav = new ModelAndView(SRCHRES_DISPLAY, "lookUpListVO", lookUpListVO);
		    mav.addObject("srchresMessage",srchresMsg);
			mav.addObject("securityLevel", securityLevel);
		    log.debug("copySrchres - srchresMessage: "+ srchresMsg);
		    log.debug("Exit from SrchdtlController - copySrcherr()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in SrchdtlController - copySrchres() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (Copy Srchres). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateSrchcol", method = RequestMethod.POST)
	public ModelAndView addUpdateSrchcol(final HttpServletRequest request,@ModelAttribute("srchcolDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.debug("Entered from SrchdtlController - addUpdateSrchcol()");
		ModelAndView mav ;
		String srchcolMsg = "";
		String securityLevel ="";
		List<SrchcolVO> updatedSrchcolList = facade.getApplicationState().getSrchcolList();
		List<SrchcolDTO> updatedSrchcolDtoList = new LinkedList<SrchcolDTO>();
		List<SrchcolVO> srchcolVoList = new LinkedList<SrchcolVO>();
		List<SrchcolVO> modifiedSrchcolVoList = new LinkedList<SrchcolVO>();
		List<SrchcolDTO> srchcolDtoList = new LinkedList<SrchcolDTO>(); 
		boolean isSrchcolAddOrUpdated = false;
		Map srchcolResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchcolVoList = facade.getApplicationState().getSrchcolList();
			modifiedSrchcolVoList = lookUpListVO.getSrchcolVOList();
			int i;
			String postedDate = RteIntranetUtils.getTodaysDate();
			if (takeAction != null && takeAction.length != 0) {
				if(srchcolVoList != null && srchcolVoList.size() != 0 
						&& modifiedSrchcolVoList.size() != 0 && modifiedSrchcolVoList != null){
				for(SrchcolVO srchcolVO : srchcolVoList){
					if(srchcolVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						srchcolVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				srchcolDtoList = RTETranslator.toSrchcolDTOList(srchcolVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					SrchcolVO selectedSrchcol = (SrchcolVO)srchcolVoList.get(i);
					SrchcolVO editedSrchcol = (SrchcolVO) modifiedSrchcolVoList.get(i);
					SrchcolVO editedSrchcolVO = new SrchcolVO(  editedSrchcol.getSrchcolCd(),editedSrchcol.getSrchcolDesc() ,  editedSrchcol.getEffDate() ,
							editedSrchcol.getExpDate() ,postedDate  , updatedInd);
					SrchcolDTO editedSrchcolDTO = RTETranslator.toSrchcolDTO(editedSrchcolVO);
					srchcolResultMap = facade.addUpdateSrchcol(editedSrchcolDTO, srchcolDtoList, i , selectedSrchcol.getUpdatedInd());
					updatedSrchcolDtoList = (List<SrchcolDTO>) srchcolResultMap.get("srchcolDtoList");
					updatedSrchcolList = RTETranslator.toSrchcolVOList(updatedSrchcolDtoList);
					isSrchcolAddOrUpdated = srchcolResultMap.get("isSrchcolAddOrUpdated") != null ;
					srchcolMsg = (String) srchcolResultMap.get("srchcolMsg") ;
					if(isSrchcolAddOrUpdated!= true){
						j = takeAction.length;
					}
				}
				lookUpListVO.setSrchcolVOList(updatedSrchcolList);
				facade.getApplicationState().setSrchcolList(updatedSrchcolList);
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	
				}
		}else{
			srchcolMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setSrchcolVOList(srchcolVoList);
			facade.getApplicationState().setSrchcolList(srchcolVoList);
		}
			mav = new ModelAndView(SRCHCOL_DISPLAY, "lookUpListVO", lookUpListVO);
		    mav.addObject("srchcolMessage",srchcolMsg);
		    log.debug("addUpdateSrchcol - SrchcolMessage: "+ srchcolMsg);
			mav.addObject("securityLevel", securityLevel);
		    log.debug("Exit from SrchdtlController - SrchdtlController()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SrchdtlController - addUpdateSrchcol() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addUpdateSrchcol() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateSrcherr", method = RequestMethod.POST)
	public ModelAndView addUpdateSrcherr(final HttpServletRequest request,@ModelAttribute("srcherrDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.debug("Entered from SrchdtlController - addUpdateSstypa()");
		ModelAndView mav ;
		String srcherrMsg = "";
		String securityLevel ="";
		List<SrcherrVO> updatedSrcherrList = facade.getApplicationState().getSrcherrList();
		List<SrcherrDTO> updatedSrcherrDtoList = new LinkedList<SrcherrDTO>();
		List<SrcherrVO> srcherrVoList = new LinkedList<SrcherrVO>();
		List<SrcherrVO> modifiedSrcherrVoList = new LinkedList<SrcherrVO>();
		List<SrcherrDTO> srcherrDtoList = new LinkedList<SrcherrDTO>(); 
		boolean isSrcherrAddOrUpdated = false;
		Map srcherrResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srcherrVoList = facade.getApplicationState().getSrcherrList();
			modifiedSrcherrVoList = lookUpListVO.getSrcherrVOList();
			int i;
			String postedDate = RteIntranetUtils.getTodaysDate();
			if (takeAction != null && takeAction.length != 0) {
				if(srcherrVoList != null && srcherrVoList.size() != 0 
						&& modifiedSrcherrVoList.size() != 0 && modifiedSrcherrVoList != null){
				for(SrcherrVO srcherrVO : srcherrVoList){
					if(srcherrVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						srcherrVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				srcherrDtoList = RTETranslator.toSrcherrDTOList(srcherrVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					SrcherrVO selectedSrcherr = (SrcherrVO)srcherrVoList.get(i);
					SrcherrVO editedSrcherr = (SrcherrVO) modifiedSrcherrVoList.get(i);
					SrcherrVO editedSrcherrVO = new SrcherrVO(  editedSrcherr.getSrcherrCd(),editedSrcherr.getSrcherrCustInd(),editedSrcherr.getSrcherrDesc() ,  editedSrcherr.getEffDate() ,
							editedSrcherr.getExpDate() ,postedDate  , updatedInd);
					SrcherrDTO editedSrcherrDTO = RTETranslator.toSrcherrDTO(editedSrcherrVO);
					srcherrResultMap = facade.addUpdateSrcherr(editedSrcherrDTO, srcherrDtoList, i , selectedSrcherr.getUpdatedInd());
					updatedSrcherrDtoList = (List<SrcherrDTO>) srcherrResultMap.get("srcherrDtoList");
					updatedSrcherrList = RTETranslator.toSrcherrVOList(updatedSrcherrDtoList);
					isSrcherrAddOrUpdated = srcherrResultMap.get("isSrcherrAddOrUpdated") != null ;
					srcherrMsg = (String) srcherrResultMap.get("srcherrMsg") ;
					if(isSrcherrAddOrUpdated!= true){
						j = takeAction.length;
					}
				}
				lookUpListVO.setSrcherrVOList(updatedSrcherrList);
				facade.getApplicationState().setSrcherrList(updatedSrcherrList);
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	
				}
		}else{
			srcherrMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setSrcherrVOList(srcherrVoList);
			facade.getApplicationState().setSrcherrList(srcherrVoList);
		}
			mav = new ModelAndView(SRCHERR_DISPLAY, "lookUpListVO", lookUpListVO);
		    mav.addObject("srcherrMessage",srcherrMsg);
			mav.addObject("securityLevel", securityLevel);
		    log.debug("addUpdateSrcherr - SrcherrMessage: "+ srcherrMsg);
		    log.debug("Exit from SrchdtlController - SrchdtlController()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SrchdtlController - addUpdateSrcherr() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addUpdateSrcherr() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateSrchres", method = RequestMethod.POST)
	public ModelAndView addUpdateSrchres(final HttpServletRequest request,@ModelAttribute("srchresDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.debug("Entered from SrchdtlController - addUpdateSrchres()");
		ModelAndView mav ;
		String srchresMsg = "";
		String securityLevel ="";
		List<SrchresVO> updatedSrchresList = facade.getApplicationState().getSrchresList();
		List<SrchresDTO> updatedSrchresDtoList = new LinkedList<SrchresDTO>();
		List<SrchresVO> srchresVoList = new LinkedList<SrchresVO>();
		List<SrchresVO> modifiedSrchresVoList = new LinkedList<SrchresVO>();
		List<SrchresDTO> srchresDtoList = new LinkedList<SrchresDTO>(); 
		boolean isSrchresAddOrUpdated = false;
		Map srchresResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			srchresVoList = facade.getApplicationState().getSrchresList();
			modifiedSrchresVoList = lookUpListVO.getSrchresVOList();
			int i;
			String postedDate = RteIntranetUtils.getTodaysDate();
			if (takeAction != null && takeAction.length != 0) {
				if(srchresVoList != null && srchresVoList.size() != 0 
						&& modifiedSrchresVoList.size() != 0 && modifiedSrchresVoList != null){
				for(SrchresVO srchresVO : srchresVoList){
					if(srchresVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						srchresVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				srchresDtoList = RTETranslator.toSrchresDTOList(srchresVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					SrchresVO selectedSrchres = (SrchresVO)srchresVoList.get(i);
					SrchresVO editedSrchres = (SrchresVO) modifiedSrchresVoList.get(i);
					SrchresVO editedSrchresVO = new SrchresVO(  editedSrchres.getSrchresCd(),editedSrchres.getSrchresDesc() ,  editedSrchres.getEffDate() ,
							editedSrchres.getExpDate() ,postedDate  , updatedInd);
					SrchresDTO editedSrchresDTO = RTETranslator.toSrchresDTO(editedSrchresVO);
					srchresResultMap = facade.addUpdateSrchres(editedSrchresDTO, srchresDtoList, i , selectedSrchres.getUpdatedInd());
					updatedSrchresDtoList = (List<SrchresDTO>) srchresResultMap.get("srchresDtoList");
					updatedSrchresList = RTETranslator.toSrchresVOList(updatedSrchresDtoList);
					isSrchresAddOrUpdated = srchresResultMap.get("isSrchresAddOrUpdated") != null ;
					srchresMsg = (String) srchresResultMap.get("srchresMsg") ;
					if(isSrchresAddOrUpdated!= true){
						j = takeAction.length;
					}
				}
				lookUpListVO.setSrchresVOList(updatedSrchresList);
				facade.getApplicationState().setSrchresList(updatedSrchresList);
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	
				}
		}else{
			srchresMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setSrchresVOList(srchresVoList);
			facade.getApplicationState().setSrchresList(srchresVoList);
		}
			mav = new ModelAndView(SRCHRES_DISPLAY, "lookUpListVO", lookUpListVO);
		    mav.addObject("srchresMessage",srchresMsg);
			mav.addObject("securityLevel", securityLevel);
		    log.debug("addUpdateSrchres - SrchresMessage: "+ srchresMsg);
		    log.debug("Exit from SrchdtlController - SrchdtlController()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SrchdtlController - addUpdateSrchres() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addUpdateSrchres() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	  @RequestMapping(value = "/srchdtlExport", method = RequestMethod.POST)
	     public ModelAndView srchdtlExport(@ModelAttribute("srchdtlForm")LookUpTableListVO lookUpTableListVO,HttpServletResponse response){
	           List<SrchdtlVO> srchdtlList = new LinkedList<SrchdtlVO>();
	     String srchdtlMsg="";
	           try{
	                 //srchdtlList = lookUpTableListVO.getSrchdtlVOList();
	        	   	srchdtlList = facade.getApplicationState().getSrchdtlList();
	                 if(srchdtlList != null && srchdtlList.size() != 0){
	                 // Key map to create header
	                 Map<String,String> keyMap = new LinkedHashMap<String,String>();
	                 keyMap.put("srchscFirstId", "1st Scenario Id");
	                 keyMap.put("srchcolCd", "Column Code");
	                 keyMap.put("srchresCd", "Result Code");
	                 keyMap.put("srchscSecondId", "2nd Scenario Id");
	                 keyMap.put("srchdtlStCd", "State Code");
	                 keyMap.put("srcherrCd", "AAA Error Code");
	                 keyMap.put("cmRollCode", "CM Roll Code");
	                 keyMap.put("effDate", "Effective Date");
	                 keyMap.put("expDate", "Expiration Date");
	                 keyMap.put("postedDate", "Posted Date");
	                 keyMap.put("srchdtlId", "Detail Id");
	                 RteIntranetUtils.exportToExcel(response, srchdtlList, keyMap);
	                 srchdtlMsg = "LookUp table exported successfully.";
	                 } else {
	                	 srchdtlMsg = "No data found.";
	                 }
	                 
	                 mav = new ModelAndView(SRCHDTL_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
	                 mav.addObject("srchdtlMessage",srchdtlMsg);
	                 return mav;
	           }catch (Exception e) {
	                 log.error("Exception occured in SrchdtlController - srchdtlExport() method:" + e.getMessage());
	                 String errorMsg = "Error encountered while export to excel. ";
	                 errorMsg.concat(e.toString());
	                 errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
	                 errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
	                 return errormav;
	           }
	     }

}
