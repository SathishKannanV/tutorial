/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.ProcexAdapter;
import com.aetna.prvrte.rteintranet.adapter.ProcexPRX2Adapter;
import com.aetna.prvrte.rteintranet.adapter.ProcexPRX3Adapter;
import com.aetna.prvrte.rteintranet.adapter.RtetprlAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.RtetprlDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.RtetprlDisplayAdapter;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.RtetprlDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Repository
public class RtetprlDAOImpl implements RtetprlDAO {
	
	@Autowired(required=true)
	private RtetprlDisplayAdapter rtetprlDisplayAdapter;
	
	@Autowired(required=true)
	private RtetprlAddAdapter rtetprlAddAdapter;
	
	@Autowired(required=true)
	private RtetprlDeleteAdapter rtetprlDeleteAdapter;
	
	@Override
	public Map getRtetprlLookUpTable(RtetprlDTO rtetprlDTO)
			throws ApplicationException {
		
		return rtetprlDisplayAdapter.getRtetprlLookUpTable(rtetprlDTO);
	}

	@Override
	public Map addNewRtetprl(RtetprlDTO rtetprlDTO) throws ApplicationException {
		return rtetprlAddAdapter.addNewRtetprl(rtetprlDTO);
	}

	@Override
	public Map deleteRtetprl(RtetprlDTO rtetprlDTO) throws ApplicationException {
		return rtetprlDeleteAdapter.deleteRtetprl(rtetprlDTO);
	}

	@Override
	public Map addUpdateRtetprl(RtetprlDTO editedRtetprlDTO,
			List<RtetprlDTO> rtetprlDtoList, int index,char updateInd)
			throws ApplicationException {
		return rtetprlAddAdapter.addUpdateRtetprl( editedRtetprlDTO, rtetprlDtoList,  index, updateInd);
	}


}
