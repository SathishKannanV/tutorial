/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.vo;

public class RtetierVO {
	private String rtetierSavingsCd = "";  
	private String rtetierCd = "";
	private String effDate = "";
	private String rtetierDescTxt = "";
	private String expDate = "";
	private String postedDateTimestamp = "";
	private String userId = "";
	private char   updatedInd;
	
	/**
	 * @param rtetierSavingsCd
	 * @param rtetierCd
	 * @param effDate
	 * @param rtetierDescTxt
	 * @param expDate
	 * @param postedDateTimestamp
	 * @param userId
	 * @param updatedInd
	 */
	public RtetierVO(String rtetierSavingsCd, String rtetierCd, String effDate,
			String rtetierDescTxt, String expDate, String postedDateTimestamp,
			String userId, char updatedInd) {
		this.rtetierSavingsCd = rtetierSavingsCd;
		this.rtetierCd = rtetierCd;
		this.effDate = effDate;
		this.rtetierDescTxt = rtetierDescTxt;
		this.expDate = expDate;
		this.postedDateTimestamp = postedDateTimestamp;
		this.userId = userId;
		this.updatedInd = updatedInd;
	}
	/**
	 * 
	 */
	public RtetierVO() {
		super();
		
	}
	
	/**
	 * @return the rtetierSavingsCd
	 */
	public String getRtetierSavingsCd() {
		return rtetierSavingsCd;
	}
	/**
	 * @param rtetierSavingsCd the rtetierSavingsCd to set
	 */
	public void setRtetierSavingsCd(String rtetierSavingsCd) {
		this.rtetierSavingsCd = rtetierSavingsCd;
	}
	/**
	 * @return the rtetierCd
	 */
	public String getRtetierCd() {
		return rtetierCd;
	}
	/**
	 * @param rtetierCd the rtetierCd to set
	 */
	public void setRtetierCd(String rtetierCd) {
		this.rtetierCd = rtetierCd;
	}
	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}
	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	/**
	 * @return the rtetierDescTxt
	 */
	public String getRtetierDescTxt() {
		return rtetierDescTxt;
	}
	/**
	 * @param rtetierDescTxt the rtetierDescTxt to set
	 */
	public void setRtetierDescTxt(String rtetierDescTxt) {
		this.rtetierDescTxt = rtetierDescTxt;
	}
	/**
	 * @return the expDate
	 */
	public String getExpDate() {
		return expDate;
	}
	/**
	 * @param expDate the expDate to set
	 */
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	/**
	 * @return the postedDateTimestamp
	 */
	public String getPostedDateTimestamp() {
		return postedDateTimestamp;
	}
	/**
	 * @param postedDateTimestamp the postedDateTimestamp to set
	 */
	public void setPostedDateTimestamp(String postedDateTimestamp) {
		this.postedDateTimestamp = postedDateTimestamp;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the updatedInd
	 */
	public char getUpdatedInd() {
		return updatedInd;
	}
	/**
	 * @param updatedInd the updatedInd to set
	 */
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}
	
	
	
}
