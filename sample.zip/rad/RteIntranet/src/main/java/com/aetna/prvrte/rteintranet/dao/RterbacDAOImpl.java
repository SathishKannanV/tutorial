/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.RterbacAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.RterbacDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.RterbacLookUpAdapter;
import com.aetna.prvrte.rteintranet.dto.RterbacDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

@Repository
public class RterbacDAOImpl implements RterbacDAO {
	@Autowired(required=true)
	private RterbacLookUpAdapter rterbacLookUpAdapter;
	
	@Autowired(required=true)
	private RterbacAddAdapter rterbacAddAdapter;
	
	@Autowired(required=true)
	private RterbacDeleteAdapter rterbacDeleteAdapter;
	
	@Override
	public Map getRterbacLookUp(RterbacDTO rterbacDTO) throws ApplicationException {
		return rterbacLookUpAdapter.getRterbacLookUpTable(rterbacDTO);
	}
	@Override
	public Map addNewRterbac(RterbacDTO rterbacDTO) throws ApplicationException {
		return rterbacAddAdapter.addNewRterbac(rterbacDTO);
	}
	
	@Override
	public Map deleteRterbac(RterbacDTO rterbacDTO)
			throws ApplicationException {
		return rterbacDeleteAdapter.deleteRterbac(rterbacDTO);
	}

	@Override
	public Map addUpdateRterbac(RterbacDTO existRterbacDTO,
			List<RterbacDTO> rterbacDtoList, int index) throws ApplicationException {
		return rterbacAddAdapter.addUpdateRterbac(existRterbacDTO, rterbacDtoList, index);
	}
	
	
}
