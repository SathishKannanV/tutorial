package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.TosctDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.TosctVO;


/**
 * @author N624926
 * Cognizant_Offshore
 */
public class TosctDisplayAdapter extends StoredProcedure{

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(TosctDisplayAdapter.class);
	private static final String SQL_TYPE = "1";
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public TosctDisplayAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_STC_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_TOS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_POS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_ADA_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_SQL_TYPE, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR3, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd =  ApplicationConstants.UPDATE_IND_N;			//Used by TosctDisplay, not on database
				TosctDTO tosctDTO = new TosctDTO();
				tosctDTO.setDbSvcTypeCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOSCT_SVC_TYPE_CD)));
				tosctDTO.setDbPntfrmageNo(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOSCT_PNTFRMAGE_NO)));
				tosctDTO.setDbPnttoageNo(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOSCT_PNTTOAGE_NO)));
				tosctDTO.setDbPatientsxCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOSCT_PATIENTSX_CD)));
				tosctDTO.setDbTosCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOSCT_TOS_CD)));
				tosctDTO.setDbPosCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOSCT_POS_CD)));
				tosctDTO.setDbSpclcovgCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOSCT_SPCLCOVG_CD)));
				tosctDTO.setDbADACd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOSCT_ADA_CODE)));
				tosctDTO.setDbAxcelInd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOSCT_AEXCEL_IND)));
				tosctDTO.setDbToscatCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOSCT_TOSCAT_CD)));
				tosctDTO.setDbPcpcovInd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOSCT_PCPCVG_IND)));
				tosctDTO.setDbUsageCode(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOSCT_USAGE_CD)));			
				tosctDTO.setDbUpdatedInd(updatedInd);
				return tosctDTO;
			}

		}));

	}
	
	/**
	 * Method to get the TOSCT list from data store.
	 * 
	 * @param tosctDTO
	 * 			tosctDTO parameter
	 * 
	 * @return Map of TOSCT list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map getTosctLookUpTable (TosctDTO tosctDTO) throws ApplicationException {
		log.warn("Entered TosctAdapter  - getTosctLookUpTable");
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		String querySvcType = RteIntranetUtils.getTrimmedString(tosctDTO.getDbSvcTypeCd());
		String queryADA = RteIntranetUtils.getTrimmedString(tosctDTO.getDbADACd());
		String queryTos = RteIntranetUtils.getTrimmedString(tosctDTO.getDbTosCd());
		String queryPos = RteIntranetUtils.getTrimmedString(tosctDTO.getDbPosCd());
		Map tosctMap = new HashMap();
		params.put(DBConstants.LS_STC_CD, querySvcType);
		params.put(DBConstants.LS_TOS_CD, queryTos);
		params.put(DBConstants.LS_POS_CD, queryPos);
		params.put(DBConstants.LS_ADA_CD, queryADA);
		params.put(DBConstants.LS_SQL_TYPE, RteIntranetUtils.getTrimmedString(SQL_TYPE));
		log.warn(params);
		Map results = null;
		List<TosctVO> tosctList= new LinkedList<TosctVO>();
		String newMessage="";
		try {
			log.warn("TosctAdapter: Executing stored procedure : ");
					
			results = execute(params);
			log.warn("TosctAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_CODE));
			
			tosctList = (List<TosctVO>) results
					.get(DBConstants.READ_CURSOR3);	
	
			if (queryTos.equals ("")){
				queryTos = "**";}
			if (queryPos.equals ("")){
				queryPos = "**";}
			if (querySvcType.equals("")){
				querySvcType = "**";}
			if (queryADA.equals("")){
				queryADA = "**";}
			
			if (tosctList.isEmpty()){
				
				if (ApplicationConstants.ZERO_0.equals(sqlCode)) {

					newMessage = "No Data on database for Tos: " + queryTos + " || Pos: " + queryPos + " || Svc Type Cd: " + querySvcType;
				} else {
					newMessage = "Problem in DB2. SQL Code: " + sqlCode + " || Tos: " + queryTos + " || Pos: " + queryPos +  " || Svc Type Cd: " + querySvcType;
				}			  		  		  
			} else {
				newMessage = "Data found on database for Tos: " + queryTos + " || Pos: " + queryPos +  " || Svc Type Cd: " + querySvcType +  " ||  Rows found: " + tosctList.size();
				}
			tosctMap.put("newMessage", newMessage);
			tosctMap.put("tosctList",tosctList);
			return tosctMap;
		}catch (Exception exception){
			log.error("TosctAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
		
}
