/**

 * 

 */

package com.aetna.prvrte.rteintranet.service;



import java.util.List;

import java.util.Map;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;



import com.aetna.prvrte.rteintranet.dao.HrpRuleDAO;

import com.aetna.prvrte.rteintranet.dto.HrpRuleDTO;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;



/**

 * @author N801539

 * Cognizant_Offshore

 */

@Service

public class HrpRuleServiceImpl implements HrpRuleService {

	@Autowired(required=true)

	private HrpRuleDAO hrpruleDAO;

	

	

	/**

	 * 

	 * @param hrpruleDTO

	 * @return

	 * @throws ApplicationException

	 */

	@Override

	public Map getHrpRuleLookUpTable(HrpRuleDTO hrpruleDTO)

			throws ApplicationException {

		

		return hrpruleDAO.getHrpRuleLookUpTable(hrpruleDTO);

	}



	/**

	 * 

	 * @param hrpruleDTO

	 * @return

	 * @throws ApplicationException

	 */

	@Override

	public Map addNewHrprule(HrpRuleDTO hrpruleDTO) throws ApplicationException {

		return hrpruleDAO.addNewHrprule(hrpruleDTO);

	}



	/**

	 * 

	 * @param hrpruleDTO

	 * @return

	 * @throws ApplicationException

	 */

	@Override

	public Map deleteHrpRule(HrpRuleDTO hrpruleDTO) throws ApplicationException {

		return hrpruleDAO.deleteHrpRule(hrpruleDTO);

	}



	/**

	 * 

	 * @param editedHrpRuleDTO

	 * @param hrpruleDtoList

	 * @param index

	 * @param  updateInd

	 * @return

	 * @throws ApplicationException

	 */

	@Override

	public Map addUpdateHrpRule(HrpRuleDTO editedHrpRuleDTO,

			List<HrpRuleDTO> hrpruleDtoList, int index,char updateInd)

			throws ApplicationException {

		return hrpruleDAO.addUpdateHrpRule( editedHrpRuleDTO,hrpruleDtoList, index, updateInd);

	}



}

