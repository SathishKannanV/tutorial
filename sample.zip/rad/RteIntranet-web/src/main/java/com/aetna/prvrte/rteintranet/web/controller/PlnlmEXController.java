/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.PlnlmEXDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.PlnlmEXVO;

/**
 * <h1>PlnlmEX Controller</h1> The PlnlmEX Controller is responsible for handling
 * the actual request from DispatcherServlet and returning an appropriate
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * @version 0.0.0
 * @since November 27, 2014
 * @author N726899 
 * 
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/plnlmEX/*")
public class PlnlmEXController {
	/*
	 * Instance of logger for PlnlmEXController.
	 */
	private static final Log log = LogFactory.getLog(PlnlmEXController.class);
	/*
	 * Tile name of the plnlmEX home view.
	 */
	public static final String PLNLMEX_HOME = ".plnlmEXHome";
	/*
	 * Tile name of the plnlmEX display view.
	 */
	public static final String PLNLMEX_DISPLAY = ".plnlmEXDisplay";
	/*
	 * Tile name of the  add new plnlmEX form view.
	 */
	public static final String PLNLMEX_ADD_NEW = ".addPlnlmEX";
	/*
	 * Instance of Facade.
	 */
	@Autowired(required = true)
	private Facade facade;
	/*
	 * Model and view of success operation.
	 */
	private ModelAndView modelAndView;
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errorModelAndView;

	/**
	 * Method to display plnlmEXLookup view.
	 * 
	 * @return view of plnlmEXLookUp, if fails return error page
	 */
	@RequestMapping(value = "/plnlmEXHome", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView getPlnlmEXLookUp(HttpServletRequest request) {
		try {
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView = new ModelAndView(PLNLMEX_HOME, "plnlmEXVO", new PlnlmEXVO());
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in PlnlmEXController - getPlnlmEXLookUp() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_LOOKUP_VIEW + "(PlnlmEXController)" + RteIntranetUtils.getTrimmedString(e.getMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}
	

	/**
	 * Method to get the plnlmEXLookUp List from data store.
	 * 
	 * @param plnlmEXVO
	 *            form view object of plnlmEX.
	 * @return view of plnlmEXDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/plnlmEXLookUp", method = RequestMethod.POST)
	public ModelAndView getPlnlmEXLookUpList(@ModelAttribute("plnlmEXForm") PlnlmEXVO plnlmEXVO,
			HttpServletRequest request) {
		try {
			PlnlmEXDTO plnlmEXDTO = RTETranslator.toPlnlmEXDTO(plnlmEXVO);
			
			Map<String, Object> plnlmEXMap = facade.getPlnlmEXLookUpList(plnlmEXDTO);
			//set PlnlmEXVOList in application state.
			List<PlnlmEXVO> plnlmEXList = (List<PlnlmEXVO>) plnlmEXMap.get("plnlmEXList");
			LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
			lookUpTableListVO.setPlnlmEXVOList(plnlmEXList);
			facade.getApplicationState().setPlnlmEXList(plnlmEXList);
			
			modelAndView = new ModelAndView(PLNLMEX_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("plnlmEXMsg",plnlmEXMap.get("plnlmEXMsg"));
			modelAndView.addObject("plnlmEXList", plnlmEXList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e) {
			log.error("Exception occured in PlnlmEXController - getPlnlmEXLookUpList() method:"	+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(PlnlmEXController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to display get add new PlnlmEX form home view.
	 * 
	 * @return view of addPlnlmEXForm, if fails return error page
	 */
	@RequestMapping(value = "/addPlnlmEXForm", method = RequestMethod.POST)
	public ModelAndView getAddNewPlnlmEXFormHome(HttpServletRequest request) {
		try {
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView = new ModelAndView(PLNLMEX_ADD_NEW, "plnlmEXVO", new PlnlmEXVO());
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in PlnlmEXController - getAddNewPlnlmEXFormHome() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_VIEW + e.toString();
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the plnlmEXLookUp List from data store.
	 * 
	 * @param plnlmEXVO
	 *            form view object of plnlmEX.
	 * @return view of plnlmEXDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addPlnlmEX", method = RequestMethod.POST)
	public ModelAndView addPlnlmEX(final HttpServletRequest request, @ModelAttribute("addPlnlmEXForm")PlnlmEXVO plnlmEXVO) {
		try {
			PlnlmEXDTO plnlmEXDTO = RTETranslator.toPlnlmEXDTO(plnlmEXVO);
			Map<String, Object> plnlmEXMap = facade.addPlnlmEXToDb(plnlmEXDTO);
			
			//set PlnlmEXVOList in application state.
			List<PlnlmEXVO> plnlmEXList = (List<PlnlmEXVO>) plnlmEXMap.get("plnlmEXList");
			facade.getApplicationState().setPlnlmEXList(plnlmEXList);
			LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
			lookUpTableListVO.setPlnlmEXVOList(plnlmEXList);
			modelAndView = new ModelAndView(PLNLMEX_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("plnlmEXMsg",plnlmEXMap.get("plnlmEXMsg"));
			modelAndView.addObject("plnlmEXList",plnlmEXList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e) {
			log.error("Exception occured in PlnlmEXController - addPlnlmEX() method:"+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_ROW + "(PlnlmEXController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the plnlmEXLookUp List from data store.
	 * @param request
	 *            request object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of plnlmEXDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/deletePlnlmEX", method = RequestMethod.POST)
	public ModelAndView deletePlnlmEX(@RequestParam(required = false) String[] takeAction,
			@ModelAttribute("plnlmEXDisplay")LookUpTableListVO lookUpTableListVO, HttpServletRequest request) {
		List<PlnlmEXVO> plnlmEXList = new LinkedList<PlnlmEXVO>();
		try {
			int index;
			boolean isAdasvcDeleted = true;
			Map<String, Object> plnlmEXMap = new HashedMap();
			String plnlmEXMsg = "";
			plnlmEXList = lookUpTableListVO.getPlnlmEXVOList();
			if(takeAction != null && takeAction.length != 0){
				if (plnlmEXList != null && plnlmEXList.size() != 0) {
					List<PlnlmEXDTO> updatedPlnlmEXList = RTETranslator.toPlnlmEXDTOList(plnlmEXList);
					for (int j = takeAction.length - 1; j >= 0; j--) {
						index = Integer.parseInt(takeAction[j]);
						PlnlmEXDTO existingPlnlmEX = (PlnlmEXDTO) updatedPlnlmEXList.get(index);
						if (existingPlnlmEX.getDbUpdatedInd() != ApplicationConstants.COPY) {
							String dbExplntCd = existingPlnlmEX.getDbExplntCd();
							plnlmEXMap = facade.deletePlnlmEX(dbExplntCd);
							plnlmEXMsg = (String) plnlmEXMap.get("plnlmEXMsg");
							isAdasvcDeleted = (Boolean) plnlmEXMap.get("isPlnlmEXDeleted");
							
							if(isAdasvcDeleted == true){
								plnlmEXList.remove(index);
							}else{
								j = 0;
							}
						} else{
							plnlmEXList.remove(index);
						}
						
					}
					if(isAdasvcDeleted == true)
					plnlmEXMsg = ApplicationConstants.ROWS_DELETED;
				
				}
			} else
				plnlmEXMsg = ApplicationConstants.NO_ACTION_TAKEN;
			
			//update PlnlmEXVOList in application state, after delete operation.
			facade.getApplicationState().setPlnlmEXList(plnlmEXList);
			modelAndView = new ModelAndView(PLNLMEX_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("plnlmEXMsg",plnlmEXMsg);
			modelAndView.addObject("plnlmEXList",plnlmEXList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in PlnlmEXController - deletePlnlmEX() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(PlnlmEXController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
		}
	}

	/**
	 * Method to get the plnlmEXLookUp List from data store.
	 * 
	 * @param plnlmEXVO
	 *            form view object of plnlmEX.
	 * @param takeAction
	 *          List of takeAction to copy the row
	 * @return view of plnlmEXDisplay, if fails return error page
	 */
	@RequestMapping(value = "/copyPlnlmEX", method = RequestMethod.POST)
	public ModelAndView copyPlnlmEX(@RequestParam(required = false) String[] takeAction,
			@ModelAttribute("plnlmEXDisplay")LookUpTableListVO lookUpTableListVO, HttpServletRequest request) {
			int index;
			String plnlmEXMsg ="";
			List<PlnlmEXVO> updatedPlnlmEXVOList = new LinkedList<PlnlmEXVO>();
		try {
			updatedPlnlmEXVOList = lookUpTableListVO.getPlnlmEXVOList();
			if(takeAction != null && takeAction.length != 0){
				if(updatedPlnlmEXVOList != null && updatedPlnlmEXVOList.size() != 0){
					for (int j = 0; j < takeAction.length; j++) {
						index = Integer.parseInt(takeAction[j]);
						PlnlmEXVO existingPlnlmEX = (PlnlmEXVO) updatedPlnlmEXVOList.get(index);
						PlnlmEXVO copiedPlnlmEXVO =  (PlnlmEXVO) SerializationUtils.clone(existingPlnlmEX);
						copiedPlnlmEXVO.setDbUpdatedInd(ApplicationConstants.COPY);
						updatedPlnlmEXVOList.add(copiedPlnlmEXVO);
					}
					plnlmEXMsg = ApplicationConstants.ROWS_COPIED;
				}
			} else {
				plnlmEXMsg = ApplicationConstants.NO_ACTION_TAKEN;
			}
			//update PlnlmEXVOList in application state, after copy operation.
			facade.getApplicationState().setPlnlmEXList(updatedPlnlmEXVOList);
			lookUpTableListVO.setPlnlmEXVOList(updatedPlnlmEXVOList);
			modelAndView = new ModelAndView(PLNLMEX_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("plnlmEXMsg",plnlmEXMsg);
			modelAndView.addObject("plnlmEXList",updatedPlnlmEXVOList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in PlnlmEXController - copyPlnlmEX() method:" + e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(PlnlmEXController)" + RteIntranetUtils.getTrimmedString(e.getMessage());
			modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);
			return modelAndView;
		}
	}

	/**
	 * Method to get the plnlmEXLookUp List from data store.
	 * 
	 * @param takeAction
	 *            list of selected indexes from view.
	 * @param request
	 *            request object.
	 * @return view of plnlmEXDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addUpdatePlnlmEX", method = RequestMethod.POST)
	public ModelAndView addUpdatePlnlmEX(@RequestParam(required = false) String[] takeAction,
			@ModelAttribute("plnlmEXDisplay")LookUpTableListVO lookUpTableListVO, HttpServletRequest request) {
		int i;
		boolean isAddorUpdateCleanUp = false;
		String plnlmEXMsg ="";
		List<PlnlmEXVO> plnlmEXList = new LinkedList<PlnlmEXVO>();
		List<PlnlmEXVO> modifiedPlnlmEXVOList = new LinkedList<PlnlmEXVO>();
		try {
			plnlmEXList = facade.getApplicationState().getPlnlmEXList();
			modifiedPlnlmEXVOList = lookUpTableListVO.getPlnlmEXVOList();
			if(takeAction != null && takeAction.length != 0){
				for(PlnlmEXVO plnlmEXVO : plnlmEXList){
					if(plnlmEXVO.getDbUpdatedInd() == ApplicationConstants.UPDATE_IND_Y){
						plnlmEXVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				if(plnlmEXList != null && plnlmEXList.size() != 0
						&& modifiedPlnlmEXVOList != null && modifiedPlnlmEXVOList.size() != 0){
					Map<String, Object> plnlmEXMap = new HashedMap();
					List<PlnlmEXDTO> plnlmEXDTOList = RTETranslator.toPlnlmEXDTOList(plnlmEXList);
					List<PlnlmEXDTO> modifiedPlnlmEXDTOList = RTETranslator.toPlnlmEXDTOList(modifiedPlnlmEXVOList);
					for (int j = 0; j < takeAction.length; j++) {
						i = Integer.parseInt(takeAction[j]);
						PlnlmEXDTO updatedPlnlmEXDTO = modifiedPlnlmEXDTOList.get(i);
						plnlmEXMap = facade.addUpdatePlnlmEX(updatedPlnlmEXDTO, plnlmEXDTOList, i);
						List<PlnlmEXDTO> procexDtoList1 = (List<PlnlmEXDTO>) plnlmEXMap.get("plnlmEXList");
						plnlmEXList = RTETranslator.toPlnlmEXVOList(procexDtoList1);
						boolean isPlnlmEXAddorUpdated = (Boolean) plnlmEXMap.get("isPlnlmEXAddorUpdated");
						isAddorUpdateCleanUp = (Boolean) plnlmEXMap.get("isAddUpdateCleanUp");
						plnlmEXMsg = (String) plnlmEXMap.get("plnlmEXMsg") ;
						if(isPlnlmEXAddorUpdated){
							j = takeAction.length;
						} 
					}
					if(isAddorUpdateCleanUp) {
						plnlmEXMsg = ApplicationConstants.ADD_UPDATE_ROWS;
						
						String xExplntCd, yExplntCd;
						for (int x = plnlmEXList.size() - 1 ; x > 0;  x--) {
							PlnlmEXVO xPlnlmEX = (PlnlmEXVO) plnlmEXList.get(x);
							xExplntCd = xPlnlmEX.getDbExplntCd();
							if (xPlnlmEX.getDbUpdatedInd() != ApplicationConstants.COPY) {
								for (int y = x - 1; y > -1; y--) {
									PlnlmEXVO yPlnlmEX = (PlnlmEXVO) plnlmEXList.get(y);
									yExplntCd = yPlnlmEX.getDbExplntCd();
									if (xExplntCd.equals(yExplntCd)) {
											plnlmEXList.remove(y); 
										x--;
									}
								}
							}
						}
					}
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);
				}
			} else {
				plnlmEXMsg = ApplicationConstants.NO_ACTION_TAKEN;
			}
			//update PlnlmEXVOList in application state, after add/update operation.
			facade.getApplicationState().setPlnlmEXList(plnlmEXList);
			lookUpTableListVO.setPlnlmEXVOList(plnlmEXList);
			modelAndView = new ModelAndView(PLNLMEX_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("plnlmEXMsg",plnlmEXMsg);
			modelAndView.addObject("plnlmEXList",plnlmEXList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in PlnlmEXController - addUpdatePlnlmEX() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(PlnlmEXController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
		}
	}
	
	/**
	 * Method to export PlnlmEX look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of plnlmEX object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/plnlmEXExport", method = {RequestMethod.POST,RequestMethod.GET})
	public ModelAndView plnlmEXExport(HttpServletResponse response){
		List<PlnlmEXVO> plnlmEXList = new LinkedList<PlnlmEXVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String plnlmEXMsg="";
		try{
			plnlmEXList = facade.getApplicationState().getPlnlmEXList();
			if(plnlmEXList != null && plnlmEXList.size() != 0){
				// Key map to create header
				Map<String,String> keyMap = new LinkedHashMap<String,String>();
				keyMap.put("dbExplntCd", "Explanation CD");
				keyMap.put("dbQlfrCd", "Qualifier CD");
				keyMap.put("dbRspnstpCd", "Response CD");
				keyMap.put("dbRspnstpTxt", "Response Text");
				keyMap.put("dbEligPerLmtCd", "Elig Period Limit Cd");
				keyMap.put("dbTxtSndCd", "Text Send Code");
				keyMap.put("dbPlnLvlInd", "Plan Level Ind");
				keyMap.put("dbFdbInd", "FDB Ind");
				
				RteIntranetUtils.exportToExcel(response, plnlmEXList, keyMap);
				plnlmEXMsg = ApplicationConstants.EXPORT_SUCCESS;
			} else {
				plnlmEXMsg = ApplicationConstants.NO_DATA;
			}
			lookUpTableListVO.setPlnlmEXVOList(plnlmEXList);
	        modelAndView = new ModelAndView(PLNLMEX_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
	        modelAndView.addObject("plnlmEXMsg",plnlmEXMsg);
		    return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in PlnlmEXController - plnlmEXExport() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_EXPOT_TABLE + "(PlnlmEXController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
       }
	}
	
}
