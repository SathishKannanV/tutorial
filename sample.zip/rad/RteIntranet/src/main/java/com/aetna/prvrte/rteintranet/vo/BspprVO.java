package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;


public class BspprVO implements Serializable {
	private short dbSeqNo;
	private String dbAcasRecTyp = "";
	private String dbAcasFldNo = "";
	private String dbAcasFldVal = "";
	private short dbProcessRule;
	private char   dbUpdatedInd;

	/**
	 * Constructor for Bspl
	 */

	public BspprVO() {
		super();
	}
	
	public BspprVO(short seqNo, String acasRecTyp, String acasFldNo, 
					String acasFldVal, short processRule,  char updateInd) {
		super();
		
		setSeqNo(seqNo);
		setAcasRecTyp(acasRecTyp);
		setAcasFldNo(acasFldNo);
		setAcasFldVal(acasFldVal);
		setProcessRule(processRule);
		setUpdatedInd(updateInd);
	}
	
	public short getSeqNo(){
		return dbSeqNo;
	}
	
	public String getAcasRecTyp(){
		return dbAcasRecTyp;
	}

	public String getAcasFldNo(){
		return dbAcasFldNo;
	}
	
	public String getAcasFldVal(){
		return dbAcasFldVal;
	}
	
	public short getProcessRule(){
		return dbProcessRule;
	}

	public char getUpdatedInd(){
		return dbUpdatedInd;
	}
	
	public void setSeqNo(short seqNo){
		dbSeqNo = seqNo;
	}
	
	public void setAcasRecTyp(String acasRecTyp){
		dbAcasRecTyp = acasRecTyp;
	}

	public void setAcasFldNo(String acasFldNo){
		dbAcasFldNo = acasFldNo;
	}
	
	public void setAcasFldVal(String acasFldVal){
		dbAcasFldVal = acasFldVal;
	}
	
	public void setProcessRule(short processRule){
		dbProcessRule = processRule;
	}
	
	public void setUpdatedInd(char updateInd){
		dbUpdatedInd = updateInd;
	}

}

