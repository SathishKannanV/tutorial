/**
 * 
 */
package com.aetna.prvrte.rteintranet.dto;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RbrcDTO {

	private String dbSiteCd = "";
	private String dbRiderCd = "";
	private String dbSvcTypeCd = "";
	private String dbPostedDate = "";
	private String dbDescTxt = "";
	private String dbIONtwkCd = "";
	private String dbTOSCd = "";
	private String dbHMOSrcBnInd = "";
	private String textSendInd = "";
	private String prevCareInd = "";
	private String genderCd = "";
	private char   dbUpdatedInd;
	
	/**
	 * @return the dbSiteCd
	 */
	public String getDbSiteCd() {
		return dbSiteCd;
	}
	/**
	 * @param dbSiteCd the dbSiteCd to set
	 */
	public void setDbSiteCd(String dbSiteCd) {
		this.dbSiteCd = dbSiteCd;
	}
	/**
	 * @return the dbRiderCd
	 */
	public String getDbRiderCd() {
		return dbRiderCd;
	}
	/**
	 * @param dbRiderCd the dbRiderCd to set
	 */
	public void setDbRiderCd(String dbRiderCd) {
		this.dbRiderCd = dbRiderCd;
	}
	/**
	 * @return the dbSvcTypeCd
	 */
	public String getDbSvcTypeCd() {
		return dbSvcTypeCd;
	}
	/**
	 * @param dbSvcTypeCd the dbSvcTypeCd to set
	 */
	public void setDbSvcTypeCd(String dbSvcTypeCd) {
		this.dbSvcTypeCd = dbSvcTypeCd;
	}
	/**
	 * @return the dbPostedDate
	 */
	public String getDbPostedDate() {
		return dbPostedDate;
	}
	/**
	 * @param dbPostedDate the dbPostedDate to set
	 */
	public void setDbPostedDate(String dbPostedDate) {
		this.dbPostedDate = dbPostedDate;
	}
	/**
	 * @return the dbDescTxt
	 */
	public String getDbDescTxt() {
		return dbDescTxt;
	}
	/**
	 * @param dbDescTxt the dbDescTxt to set
	 */
	public void setDbDescTxt(String dbDescTxt) {
		this.dbDescTxt = dbDescTxt;
	}
	/**
	 * @return the dbIONtwkCd
	 */
	public String getDbIONtwkCd() {
		return dbIONtwkCd;
	}
	/**
	 * @param dbIONtwkCd the dbIONtwkCd to set
	 */
	public void setDbIONtwkCd(String dbIONtwkCd) {
		this.dbIONtwkCd = dbIONtwkCd;
	}
	/**
	 * @return the dbTOSCd
	 */
	public String getDbTOSCd() {
		return dbTOSCd;
	}
	/**
	 * @param dbTOSCd the dbTOSCd to set
	 */
	public void setDbTOSCd(String dbTOSCd) {
		this.dbTOSCd = dbTOSCd;
	}
	/**
	 * @return the dbHMOSrcBnInd
	 */
	public String getDbHMOSrcBnInd() {
		return dbHMOSrcBnInd;
	}
	/**
	 * @param dbHMOSrcBnInd the dbHMOSrcBnInd to set
	 */
	public void setDbHMOSrcBnInd(String dbHMOSrcBnInd) {
		this.dbHMOSrcBnInd = dbHMOSrcBnInd;
	}
	/**
	 * @return the textSendInd
	 */
	public String getTextSendInd() {
		return textSendInd;
	}
	/**
	 * @param textSendInd the textSendInd to set
	 */
	public void setTextSendInd(String textSendInd) {
		this.textSendInd = textSendInd;
	}
	/**
	 * @return the prevCareInd
	 */
	public String getPrevCareInd() {
		return prevCareInd;
	}
	/**
	 * @param prevCareInd the prevCareInd to set
	 */
	public void setPrevCareInd(String prevCareInd) {
		this.prevCareInd = prevCareInd;
	}
	/**
	 * @return the genderCd
	 */
	public String getGenderCd() {
		return genderCd;
	}
	/**
	 * @param genderCd the genderCd to set
	 */
	public void setGenderCd(String genderCd) {
		this.genderCd = genderCd;
	}
	/**
	 * @return the dbUpdatedInd
	 */
	public char getDbUpdatedInd() {
		return dbUpdatedInd;
	}
	/**
	 * @param dbUpdatedInd the dbUpdatedInd to set
	 */
	public void setDbUpdatedInd(char dbUpdatedInd) {
		this.dbUpdatedInd = dbUpdatedInd;
	}
	
	
}
