/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.IndmntrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.IndmntrpVO;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class IndmntrpAddAdapter extends StoredProcedure {

	public IndmntrpAddAdapter() {}
	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(IndmntrpAddAdapter.class);
	
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public IndmntrpAddAdapter(DataSource datasource, String storedProc) throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of IndmntrpAdapter : " + storedProc);
		//Input Params declaration
		declareParameter(new SqlParameter(DBConstants.LS_INDMNTY_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_RFRL_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_PRCRT_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_SHRT_NM, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_NM, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_SELRQ_IND, Types.CHAR));
		
		//Output Params declaration
		declareParameter(new SqlOutParameter(DBConstants.LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));

	}
	/**
	 * Method to add new Indmntrp to data store.
	 * 
	 * @param indmntrp
	 *            String of aetna id.
	 * @return Map of Indmntrp list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	public Map<String, Object> addIndmntrpToDb(IndmntrpDTO indmntrpDTO)throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<IndmntrpVO> indmntrpList = new LinkedList<IndmntrpVO>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String indmntrpMsg = "";
		try {
			String dbIndmntyCd = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyCd());
			String dbIndmntyRFRLInd = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyRFRLInd());
			String dbIndmntyPRCRTInd = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyPRCRTInd());
			String dbIndmntyShrtNm = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyShrtNm());
			String dbIndmntyNm = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyNm());
			String dbPcpSelReqInd = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbPcpSelReqInd());
			char updatedInd= ApplicationConstants.UPDATE_IND_N;	
			
			//Query params
			params.put(DBConstants.LS_INDMNTY_CD, dbIndmntyCd);
			params.put(DBConstants.LS_RFRL_IND, dbIndmntyRFRLInd);
			params.put(DBConstants.LS_PRCRT_IND, dbIndmntyPRCRTInd);
			params.put(DBConstants.LS_SHRT_NM, dbIndmntyShrtNm);
			params.put(DBConstants.LS_NM, dbIndmntyNm);
			params.put(DBConstants.LS_SELRQ_IND, dbPcpSelReqInd);
			log.info("Params for getting Indmntrp LookUp List : " + params);
			
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			String actionCode = String.valueOf(results.get(DBConstants.LS_ADD_UPDATE));
			if ("0".equals(sqlCode)) {
				if ("0".equals(actionCode)){
					indmntrpMsg = ApplicationConstants.ROW_ADDED;
				} else {
					indmntrpMsg = ApplicationConstants.ROW_ALREADY_EXISTS;
					updatedInd = ApplicationConstants.UPDATE_IND_Y;
				}
				
				IndmntrpVO indmntrpObj = new IndmntrpVO(dbIndmntyCd,
						dbIndmntyRFRLInd, dbIndmntyPRCRTInd, dbIndmntyShrtNm,
						dbIndmntyNm, dbPcpSelReqInd, updatedInd);
				indmntrpList.add(indmntrpObj);
			} else {
				indmntrpMsg = ApplicationConstants.ADD_ROW_FAILS + sqlCode;
				
			}
			resultMap.put("indmntrpMsg", indmntrpMsg);
			resultMap.put("indmntrpList", indmntrpList);
		} catch (DataAccessException dae) {
			log.error("IndmntrpAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("IndmntrpAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
		return resultMap;
	}
	
	/**
	 * Method to add/update list of Indmntrp to data store.
	 * 
	 * @param indmntrpList
	 *            List of indmntrp.
	 * @param takeAction
	 *            List of selected indexes to delete.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from Indmntrp list, success or
	 *         error message and list of Indmntrp.
	 * @throws ApplicationException
	 *             if insertion or update fails.
	 */
	public Map<String, Object> addUpdateIndmntrp(IndmntrpDTO indmntrpDTO, List<IndmntrpDTO> indmntrpList, int index) throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String indmntrpMsg = "";
		boolean isIndmntrpAddorUpdated = false;
		try{
			String dbIndmntyCd = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyCd());
			String dbIndmntyRFRLInd = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyRFRLInd());
			String dbIndmntyPRCRTInd = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyPRCRTInd());
			String dbIndmntyShrtNm = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyShrtNm());
			String dbIndmntyNm = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyNm());
			String dbPcpSelReqInd = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbPcpSelReqInd());
			
			//Query params
			params.put(DBConstants.LS_INDMNTY_CD, dbIndmntyCd);
			params.put(DBConstants.LS_RFRL_IND, dbIndmntyRFRLInd);
			params.put(DBConstants.LS_PRCRT_IND, dbIndmntyPRCRTInd);
			params.put(DBConstants.LS_SHRT_NM, dbIndmntyShrtNm);
			params.put(DBConstants.LS_NM, dbIndmntyNm);
			params.put(DBConstants.LS_SELRQ_IND, dbPcpSelReqInd);
			
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			String actionCode =  String.valueOf(results.get(DBConstants.LS_ADD_UPDATE));
			if ("0".equalsIgnoreCase(sqlCode)) {
				IndmntrpDTO aIndmntrpDTO = new IndmntrpDTO(dbIndmntyCd,
						dbIndmntyRFRLInd, dbIndmntyPRCRTInd, dbIndmntyShrtNm,
						dbIndmntyNm, dbPcpSelReqInd,
						ApplicationConstants.UPDATE_IND_Y); 
				indmntrpMsg = ApplicationConstants.ADD_UPDATE_ROWS;
				if ("0".equals(actionCode)){
					if (indmntrpDTO.getDbUpdatedInd() == ApplicationConstants.COPY){
						indmntrpList.set(index, aIndmntrpDTO);
					} else {
						indmntrpList.add(aIndmntrpDTO);
					}
				} else {
					indmntrpList.set(index, aIndmntrpDTO);
				}
			}else {
				isIndmntrpAddorUpdated = true;
				indmntrpMsg = ApplicationConstants.ADD_UPDATE_ROW_FAILS + sqlCode;
			}
			resultMap.put("indmntrpMsg", indmntrpMsg);
			resultMap.put("indmntrpList", indmntrpList);
			resultMap.put("isIndmntrpAddorUpdated", isIndmntrpAddorUpdated);
			return resultMap;
		}catch (DataAccessException dae) {
			log.error("IndmntrpAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("IndmntrpAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		}
	}
}
