package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;
/**
 * 
 * @author N726899
 * Cognizant_Offshore
 */
public class BenafrqVO implements Serializable {
	/**
	 * Constant serialized ID used for compatibility.
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * String of defacumAccumCd
	 */
	private String defacumAccumCd = "";
	/**
	 * String of benafrqAfreqCd
	 */
	private String benafrqAfreqCd = "";
	/**
	 * String of hmobBenefitCd
	 */
	private String hmobBenefitCd = "";
	/**
	 * String of benafrqLmtTxt
	 */
	private String benafrqLmtTxt = "";
	/**
	 * String of rtebeplmEplcCd
	 */
	private String rtebeplmEplcCd = "";
	/**
	 * String of effDate
	 */
	private String effDate = "";
	/**
	 * String of expDate
	 */
	private String expDate = "";
	/**
	 * String of postedDateTimestamp(yyy-MM-dd HH:mm:ss)
	 */
	private String postedDateTimestamp = "";
	/**
	 * String of userId
	 */
	private String userId = "";
	/**
	 * char of index to update the record.
	 */
	private char updatedInd;
	/**
	 * Default Constructor.
	 */
	public BenafrqVO() {
		super();
	}

	/**
	 * Creates a new BenafrqVO
	 * 
	 * @param defacumAccumCd
	 *            the value for {@link defacumAccumCd}
	 * @param benafrqAfreqCd
	 *            the value for {@link benafrqAfreqCd}
	 * @param hmobBenefitCd
	 *            the value for {@link hmobBenefitCd}
	 * @param benafrqLmtTxt
	 *            the value for {@link benafrqLmtTxt}
	 * @param rtebeplmEplcCd
	 *            the value for {@link rtebeplmEplcCd}
	 * @param effDate
	 *            the value for {@link effDate}
	 * @param expDate
	 *            the value for {@link expDate}
	 * @param postedDateTimestamp
	 *            the value for {@link postedDateTimestamp}
	 * @param userId
	 *            the value for {@link userId}
	 * @param updatedInd
	 *            the value for {@link updatedInd}
	 */
	public BenafrqVO(String defacumAccumCd, String benafrqAfreqCd,
			String hmobBenefitCd, String benafrqLmtTxt, String rtebeplmEplcCd,
			String effDate, String expDate, String postedDateTimestamp,
			String userId, char updatedInd) {
		super();
		this.defacumAccumCd = defacumAccumCd;
		this.benafrqAfreqCd = benafrqAfreqCd;
		this.hmobBenefitCd = hmobBenefitCd;
		this.benafrqLmtTxt = benafrqLmtTxt;
		this.rtebeplmEplcCd = rtebeplmEplcCd;
		this.effDate = effDate;
		this.expDate = expDate;
		this.postedDateTimestamp = postedDateTimestamp;
		this.userId = userId;
		this.updatedInd = updatedInd;
	}

	/**
	 * @return the defacumAccumCd
	 */
	public String getDefacumAccumCd() {
		return defacumAccumCd;
	}

	/**
	 * @param defacumAccumCd the defacumAccumCd to set
	 */
	public void setDefacumAccumCd(String defacumAccumCd) {
		this.defacumAccumCd = defacumAccumCd;
	}

	/**
	 * @return the benafrqAfreqCd
	 */
	public String getBenafrqAfreqCd() {
		return benafrqAfreqCd;
	}

	/**
	 * @param benafrqAfreqCd the benafrqAfreqCd to set
	 */
	public void setBenafrqAfreqCd(String benafrqAfreqCd) {
		this.benafrqAfreqCd = benafrqAfreqCd;
	}

	/**
	 * @return the hmobBenefitCd
	 */
	public String getHmobBenefitCd() {
		return hmobBenefitCd;
	}

	/**
	 * @param hmobBenefitCd the hmobBenefitCd to set
	 */
	public void setHmobBenefitCd(String hmobBenefitCd) {
		this.hmobBenefitCd = hmobBenefitCd;
	}

	/**
	 * @return the benafrqLmtTxt
	 */
	public String getBenafrqLmtTxt() {
		return benafrqLmtTxt;
	}

	/**
	 * @param benafrqLmtTxt the benafrqLmtTxt to set
	 */
	public void setBenafrqLmtTxt(String benafrqLmtTxt) {
		this.benafrqLmtTxt = benafrqLmtTxt;
	}

	/**
	 * @return the rtebeplmEplcCd
	 */
	public String getRtebeplmEplcCd() {
		return rtebeplmEplcCd;
	}

	/**
	 * @param rtebeplmEplcCd the rtebeplmEplcCd to set
	 */
	public void setRtebeplmEplcCd(String rtebeplmEplcCd) {
		this.rtebeplmEplcCd = rtebeplmEplcCd;
	}

	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}

	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	/**
	 * @return the expDate
	 */
	public String getExpDate() {
		return expDate;
	}

	/**
	 * @param expDate the expDate to set
	 */
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	/**
	 * @return the postedDateTimestamp
	 */
	public String getPostedDateTimestamp() {
		return postedDateTimestamp;
	}

	/**
	 * @param postedDateTimestamp the postedDateTimestamp to set
	 */
	public void setPostedDateTimestamp(String postedDateTimestamp) {
		this.postedDateTimestamp = postedDateTimestamp;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the updatedInd
	 */
	public char getUpdatedInd() {
		return updatedInd;
	}

	/**
	 * @param updatedInd the updatedInd to set
	 */
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}

}
