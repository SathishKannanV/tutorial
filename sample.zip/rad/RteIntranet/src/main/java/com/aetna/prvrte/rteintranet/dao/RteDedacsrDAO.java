/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.DedacsrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * 
 * <h1>RteDedacsrService</h1> The RteDedacsrService is responsible for handling
 * the business logic of DEDACSR Look up.
 * 
 * @author N726899 Cognizant_Offshore
 * 
 */
public interface RteDedacsrDAO {
	/**
	 * Method to get the DEDACSR list from data store.
	 * 
	 * @param dedacsrDTO
	 * 			dedacsrDTO object.
	 * @return Map of DEDACSR list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	Map<String, Object> getDedacsrLookUpList(DedacsrDTO dedacsrDTO) throws ApplicationException;
	/**
	 * Method to add new DEDACSR to data store.
	 * 
	 * @param dedacsrDTO
	 *            dedacsrDTO object.
	 * @return Map of added DEDACSR data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	Map<String, Object> addDedacsrToDb(DedacsrDTO dedacsrDTO) throws ApplicationException;
	/**
	 * Method to delete the DEDACSR data from data store.
	 * 
	 * @param dbSvcTypeCd
	 *            String of dbSvcTypeCd.
	 * @param dbDefAccumCd
	 *            String of dbDefAccumCd.
	 * @return Map of flag to delete the data from DEDACSR list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	Map<String, Object> deleteDedacsr(String dbSvcTypeCd, String dbDefAccumCd) throws ApplicationException;
	
	/**
	 * Method to add/update list of DEDACSR to data store.
	 * 
	 * @param dedacsrDTO
	 *            dedacsrDTO object.
	 * @param dedacsrDTOList
	 *            list of dedacsrDTO object.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from DEDACSR list, success or
	 *         error message and list of DEDACSR.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	Map<String, Object> addUpdateDedacsr(DedacsrDTO dedacsrDTO,	List<DedacsrDTO> dedacsrDTOList, int index)throws ApplicationException;
}
