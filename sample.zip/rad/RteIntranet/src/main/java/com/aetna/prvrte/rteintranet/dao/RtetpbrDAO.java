/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.RtetpbrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public interface RtetpbrDAO {

	Map getRtetpbrLookUpTable (String idNo , String effDate) throws ApplicationException ;

	Map addNewRtetpbr(RtetpbrDTO rtetpbrDTO) throws ApplicationException;

	Map deleteRtetpbr(String rtetpbrIdNo, String rtetpbrEffDate)throws ApplicationException;

	Map addUpdateRtetpbr(RtetpbrDTO editedProcexDTO,
			List<RtetpbrDTO> rtetpbrDtoList, int index, char updateInd) throws ApplicationException;



}
