/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class AetCtlsAddAdapter extends StoredProcedure {

	public AetCtlsAddAdapter() {}
	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(AetCtlsAddAdapter.class);
	
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public AetCtlsAddAdapter(DataSource datasource, String aetCtlsStoredProc)
			throws SQLException {
		super(datasource, aetCtlsStoredProc);
		log.info(" ------------------> " + aetCtlsStoredProc);
		//SQL Params(Input)
		declareParameter(new SqlParameter(DBConstants.IN_CTL_NO, Types.CHAR));
		//Out Params
		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));
		declareParameter(new SqlOutParameter(DBConstants.OUT_ACTION_CD, Types.CHAR));

	}
	/**
	 * Method to add new AetCtls to data store.
	 * 
	 * @param aetCtl
	 *            String of aetna id.
	 * @return Map of AetCtls list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	public Map<String, Object> addAetCtlsToDb(String aetCtl)throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<String> aetCtlsList = new LinkedList<String>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String newMessage = "";
		try {
			//query params		
			String padAetnaControl = RteIntranetUtils.getTrimmedString(aetCtl);
			for (int l = 0; (l + aetCtl.length() < 9); l++){
				padAetnaControl = "0" + padAetnaControl;
			}
			params.put(DBConstants.IN_CTL_NO, RteIntranetUtils.getTrimmedString(padAetnaControl));
			
			log.info("Params to put new adavsct : " + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.OUT_CODE));
			if ("0".equals(sqlCode)) {
				aetCtlsList.add(aetCtl);
			} else {
				newMessage = ApplicationConstants.ADD_UPDATE_ROW_FAILS + sqlCode;
			}
			
			resultMap.put("aetCtlsMsg", newMessage);
			resultMap.put("aetCtlsList", aetCtlsList);
		} catch (DataAccessException dae) {
			log.error("AetCtlsAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("AetCtlsAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
		return resultMap;
	}
	
	/**
	 * Method to add/update list of AetCtls to data store.
	 * 
	 * @param aetCtlsList
	 *            List of aetna ids.
	 * @param takeAction
	 *            List of selected indexes to delete aetna id.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from AetCtls list, success or
	 *         error message and list of AetCtls.
	 * @throws ApplicationException
	 *             if insertion or update fails.
	 */
	public Map<String, Object> addUpdateAetCtls(List<String> aetCtlsList, String aetCtl, int index) throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String newMessage = "";
		String sqlCode ="";
		boolean isAetCtlsAddorUpdated = false;
		
		String aetnaContol = RteIntranetUtils.getTrimmedString(aetCtl);
		//query params		
		params.put(DBConstants.IN_CTL_NO, aetnaContol);

		log.info("Params to put new adavsct : " + params);
		try{
			Map<String, Object> results = execute(params);
			sqlCode = String.valueOf(results.get(DBConstants.OUT_CODE));
			
			if ("0".equals(sqlCode)) {
				aetCtlsList.add(aetCtl);
				newMessage = "Rows added were placed at the bottom of the list.";
			} else if ("-803".equals(sqlCode)) {
				isAetCtlsAddorUpdated = true;
				newMessage = "Unable to add Control, already exists on database. sqlcode = " + sqlCode;
			} else {
				isAetCtlsAddorUpdated = true;
				newMessage = "Adding of rows failed with a SQLCODE code of " + sqlCode;
			}
			resultMap.put("aetCtlsMsg", newMessage);
			resultMap.put("aetCtlsList", aetCtlsList);
			resultMap.put("isAetCtlsAddorUpdated", isAetCtlsAddorUpdated);
			return resultMap;
		}catch (DataAccessException dae) {
			log.error("AetCtlsAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("AetCtlsAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
	}
}
