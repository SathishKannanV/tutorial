/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.RtebeplmAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.RtebeplmDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.RtebeplmLookUpAdapter;
import com.aetna.prvrte.rteintranet.dto.RtebeplmDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 * Cognizant_Offshore
 */
@Repository
public class RtebeplmDAOImpl implements RtebeplmDAO{

	@Autowired(required=true)
	private RtebeplmLookUpAdapter rtebeplmLookUpAdapter;
	
	@Autowired(required=true)
	private RtebeplmAddAdapter rtebeplmAddAdapter;
	
	@Autowired(required=true)
	private RtebeplmDeleteAdapter rtebeplmDeleteAdapter;
	
	@Override
	public Map getRtebeplmLookUpTable(RtebeplmDTO rtebeplmDTO)
			throws ApplicationException {
		
		return rtebeplmLookUpAdapter.getRtebeplmLookUpTable(rtebeplmDTO);
	}
	
	@Override
	public Map deleteRtebeplm(RtebeplmDTO rtebeplmDTO)
			throws ApplicationException {
		return rtebeplmDeleteAdapter.deleteRtebeplm(rtebeplmDTO);
	}

	@Override
	public Map addUpdateRtebeplm(RtebeplmDTO existRtebeplmDTO,
			List<RtebeplmDTO> rtebeplmDtoList, int index, char updateInd) throws ApplicationException {
		return rtebeplmAddAdapter.addUpdateRtebeplm(existRtebeplmDTO, rtebeplmDtoList, index, updateInd);
	}

	
}
