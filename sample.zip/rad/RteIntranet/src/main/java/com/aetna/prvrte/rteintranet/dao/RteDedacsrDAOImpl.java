/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.DedacsrAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.DedacsrDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.DedacsrDisplayAdapter;
import com.aetna.prvrte.rteintranet.dto.DedacsrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.service.RteDedacsrService
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Repository
public class RteDedacsrDAOImpl implements RteDedacsrDAO {
	/*
	 * Instance of DedacsrDisplayAdapter.
	 */
	@Autowired(required = true)
	private DedacsrDisplayAdapter dedacsrDisplayAdapter;
	/*
	 * Instance of DedacsrAddAdapter.
	 */
	@Autowired(required = true)
	private DedacsrAddAdapter dedacsrAddAdapter;
	/*
	 * Instance of DedacsrDeleteAdapter.
	 */
	@Autowired(required = true)
	private DedacsrDeleteAdapter dedacsrDeleteAdapter;
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteDedacsrDAO#getDedacsrLookUpList(com.aetna.prvrte.rteintranet.dto.DedacsrDTO)
	 */
	@Override
	public Map<String, Object> getDedacsrLookUpList(DedacsrDTO dedacsrDTO) throws ApplicationException {
		return dedacsrDisplayAdapter.getDedacsrLookUpList(dedacsrDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteDedacsrDAO#addDedacsrToDb(com.aetna.prvrte.rteintranet.dto.DedacsrDTO)
	 */
	@Override
	public Map<String, Object> addDedacsrToDb(DedacsrDTO dedacsrDTO) throws ApplicationException {
		return dedacsrAddAdapter.addDedacsrToDb(dedacsrDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteDedacsrDAO#deleteDedacsr(java.lang.String, java.lang.String)
	 */
	@Override
	public Map<String, Object> deleteDedacsr(String dbSvcTypeCd, String dbDefAccumCd) throws ApplicationException {
		return dedacsrDeleteAdapter.deleteDedacsr(dbSvcTypeCd, dbDefAccumCd);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteDedacsrDAO#addUpdateDedacsr(com.aetna.prvrte.rteintranet.dto.DedacsrDTO, java.util.List, int)
	 */
	@Override
	public Map<String, Object> addUpdateDedacsr(DedacsrDTO dedacsrDTO, List<DedacsrDTO> dedacsrList, int index) throws ApplicationException {
		return dedacsrAddAdapter.addUpdateDedacsr(dedacsrDTO, dedacsrList, index);
	}
	

}
