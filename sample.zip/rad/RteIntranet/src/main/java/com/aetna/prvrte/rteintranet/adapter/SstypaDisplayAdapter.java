package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.SstypaDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.SstypaVO;


/**
 * @author N624926
 * Cognizant_Offshore
 */
public class SstypaDisplayAdapter extends StoredProcedure{
	
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(SstypaDisplayAdapter.class);
	
	/**
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public SstypaDisplayAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.IN_COLLECTION_CD, Types.CHAR));

		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR3, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd =  ApplicationConstants.UPDATE_IND_N;			//Used by SstypaDisplay, not on database
				SstypaDTO sstypaDTO = new SstypaDTO();
				sstypaDTO.setId(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.SSTYPA_ID)));
				sstypaDTO.setCollectionCode(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.SSTYPA_COLL_CD)));
				sstypaDTO.setIndividualCode(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.SSTYPA_INDV_CD)));
				sstypaDTO.setEffDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.SSTYPA_EFF_DT)));
				sstypaDTO.setExpDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.SSTYPA_EXP_DT)));
				sstypaDTO.setPostedDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.SSTYPA_POSTED_DT)));
				sstypaDTO.setVersionReleaseCode(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.SSTYPA_VERSNRLS_CD)));					
				sstypaDTO.setUpdatedInd(updatedInd);
				return sstypaDTO;
			}

		}));

	}
	
	
	/**
	 * Method to get the SSTYPA list from data store.
	 * 
	 * @param sstypaDTO
	 * 			sstypaDTO parameter
	 * 
	 * @return Map of SSTYPA list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map getSstypaLookUpTable (SstypaDTO sstypaDTO) throws ApplicationException {
		log.warn("Entered SstypaAdapter  - getSstypaLookUpTable");
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map sstypaMap = new HashMap();
		params.put(DBConstants.IN_COLLECTION_CD, RteIntranetUtils.getTrimmedString(sstypaDTO.getCollectionCode()));
		log.warn(params);
		Map results = null;
		
		List<SstypaVO> sstypaList= new LinkedList<SstypaVO>();
		String newMessage="";
		try {
			log.warn("SstypaAdapter: Executing stored procedure : ");
					
			results = execute(params);
			log.warn("SstypaAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_CODE));
			
			sstypaList = (List<SstypaVO>) results
					.get(DBConstants.READ_CURSOR3);	
	
			if (sstypaList.isEmpty()){
				
				if (ApplicationConstants.ZERO_0.equals(sqlCode)) {

					newMessage = "No Data on database for No Data on database for Collection Cd: " + sstypaDTO.getCollectionCode();
				} else {
					newMessage = "Problem in DB2. sqlcode: " + sqlCode + " Collection Cd: " + sstypaDTO.getCollectionCode();
				}			  		  		  
			} else {
				newMessage = "Data found on database for Collection Cd: " + sstypaDTO.getCollectionCode();
				}
			/*}else{
				newMessage = "You must enter a Sstypa Code with or without combination of Rider Code and/or Service Type Code on the Look Up page.";
			}*/
			sstypaMap.put("newMessage", newMessage);
			sstypaMap.put("sstypaList",sstypaList);
			return sstypaMap;
		}catch (Exception exception){
			log.error("SstypaAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
		
}
