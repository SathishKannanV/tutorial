/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.SbmletkEventTrackAdapter;
import com.aetna.prvrte.rteintranet.adapter.SbmrdepAdapter;
import com.aetna.prvrte.rteintranet.adapter.SbmrplnAdapter;
import com.aetna.prvrte.rteintranet.adapter.SbmrplnSbmsnr2Adapter;
import com.aetna.prvrte.rteintranet.adapter.SbmrplnSbmsnrAdapter;
import com.aetna.prvrte.rteintranet.adapter.SbmsnrAdapter;
import com.aetna.prvrte.rteintranet.adapter.SbrsrxbAdapter;
import com.aetna.prvrte.rteintranet.adapter.SpntprvAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrapidtlAdapter;
import com.aetna.prvrte.rteintranet.adapter.SubmsnAdapter;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N731694
 * Cognizant_Offshore
 */
@Repository
public class EventTrackDAOImpl implements EventTrackDAO {
	
	@Autowired(required=true)
	private SbrsrxbAdapter sbrsrxbAdapter;
	
	@Autowired(required=true)
	private SpntprvAdapter spntprvAdapter;
	@Autowired(required=true)
	private SbmrdepAdapter sbmrdepAdapter;
	@Autowired(required=true)
	private SubmsnAdapter submsnAdapter;
	@Autowired(required=true)
	private SrapidtlAdapter srapidtlAdapter;
	@Autowired(required=true)
	private SbmletkEventTrackAdapter sbmletkEvntAdapter;
	@Autowired(required=true)
	private SbmsnrAdapter sbmsnrAdapter;
	@Autowired(required=true)
	private SbmrplnAdapter smrplnAdapter;
	@Autowired(required=true)
	private SbmrplnSbmsnrAdapter smrplnSbmsnrAdapter;
	@Autowired(required=true)
	private SbmrplnSbmsnr2Adapter smrplnSbmsnr2Adapter;

	
	
	@Override
	public Map getSbrsrxbEvntTracking(String convIdCode, String vanIdCd,String typeCd,String postedDt) throws ApplicationException {
		// TODO Auto-generated method stub
		return sbrsrxbAdapter.getSbrsrxbEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
	}
	@Override
	public Map getSpntprvEvntTracking(String convIdCode, String vanIdCd,String typeCd,String postedDt) throws ApplicationException {
		// TODO Auto-generated method stub
		return spntprvAdapter.getSpntprvEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
	}
	@Override
	public Map getSbmrdepEvntTracking(String convIdCode, String vanIdCd,String typeCd,String postedDt) throws ApplicationException {
		// TODO Auto-generated method stub
		return sbmrdepAdapter.getSbmrdepEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
	}
	@Override
	public Map getSubmsnEvntTracking(String convIdCode, String vanIdCd,String typeCd,String postedDt) throws ApplicationException {
		// TODO Auto-generated method stub
		return submsnAdapter.getSubmsnEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
	}
	
	@Override
	public Map getSrapidtlEvntTracking(String convIdCode, String vanIdCd,String typeCd,String postedDt) throws ApplicationException {
		// TODO Auto-generated method stub
		return srapidtlAdapter.getSrapidtlEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
	}
	@Override
	public Map getEventTrackSbmletkLookUpTable(String convIdCode, String vanIdCd,String tranType,String postedDt,String seconds)
			throws ApplicationException {
		
		return sbmletkEvntAdapter.getEventTrackSbmletkLookUpTable(convIdCode, vanIdCd,tranType,postedDt,seconds);
	}
	@Override
	public Map getSbmsnrEvntTracking(String convIdCode, String vanIdCd,String typeCd,String postedDt) throws ApplicationException {
		// TODO Auto-generated method stub
		return sbmsnrAdapter.getSbmsnrEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
	}
	@Override
	public Map getSbmrplnEvntTracking(String convIdCode, String vanIdCd,String typeCd,String postedDt) throws ApplicationException {
		// TODO Auto-generated method stub
		return smrplnAdapter.getSbmrplnEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
	}
	@Override
	public Map getSbmrplnSbmsnrEvntTracking(String convIdCode, String vanIdCd,String typeCd,String postedDt) throws ApplicationException {
		// TODO Auto-generated method stub
		return smrplnSbmsnrAdapter.getSbmrplnSbmsnrEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
	}
	@Override
	public Map getSbmrplnSbmsnrEvntTracking(String convIdCode, String vanIdCd,String typeCd,String postedDt,String seqNo) throws ApplicationException {
		// TODO Auto-generated method stub
		return smrplnSbmsnr2Adapter.getSbmrplnSbmsnrEvntTracking(convIdCode, vanIdCd,typeCd,postedDt,seqNo);
	}

}
