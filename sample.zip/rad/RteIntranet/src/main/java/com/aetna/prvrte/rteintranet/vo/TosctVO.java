/**
 * 
 */
package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;

/**
 * @author N624926
 * Cognizant_Offshore
 */

public class TosctVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3860928296171539451L;
	private String dbSvcTypeCd = "";
	private String dbPntfrmageNo = "";
	private String dbPnttoageNo = "";
	private String dbPatientsxCd = "";
	private String dbTosCd = "";
	private String dbPosCd = "";
	private String dbSpclcovgCd = "";
	private String dbADACd = "";
	private String dbAxcelInd = "";
	private String dbToscatCd = "";
	private String dbPcpcovInd = "";
	private String dbUsageCode = "";
	private char dbUpdatedInd;
	
	public TosctVO() {
		super();
		}
	
	public TosctVO(	String svcTypeCd, String pntfrmageNo, String pnttoageNo, String patientsxCd, String tosCd, String posCd, String spclcovgCd, String adaCd, String AxcelInd, String toscatCd, String pcpcovInd, String usageCode, char updatedInd) {
			super();
			this.dbSvcTypeCd = svcTypeCd;
			this.dbPntfrmageNo = pntfrmageNo;
			this.dbPnttoageNo = pnttoageNo;
			this.dbPatientsxCd = patientsxCd;
			this.dbTosCd = tosCd;
			this.dbPosCd = posCd;
			this.dbSpclcovgCd = spclcovgCd;
			this.dbADACd = adaCd;
			this.dbAxcelInd = AxcelInd;
			this.dbToscatCd = toscatCd;
			this.dbPcpcovInd = pcpcovInd;
			this.dbUsageCode = usageCode;
			this.dbUpdatedInd = updatedInd;
	}
	
	
	/**
	 * @return the dbSvcTypeCd
	 */
	public String getDbSvcTypeCd() {
		return dbSvcTypeCd;
	}
	/**
	 * @param dbSvcTypeCd the dbSvcTypeCd to set
	 */
	public void setDbSvcTypeCd(String dbSvcTypeCd) {
		this.dbSvcTypeCd = dbSvcTypeCd;
	}
	/**
	 * @return the dbPntfrmageNo
	 */
	public String getDbPntfrmageNo() {
		return dbPntfrmageNo;
	}
	/**
	 * @param dbPntfrmageNo the dbPntfrmageNo to set
	 */
	public void setDbPntfrmageNo(String dbPntfrmageNo) {
		this.dbPntfrmageNo = dbPntfrmageNo;
	}
	/**
	 * @return the dbPnttoageNo
	 */
	public String getDbPnttoageNo() {
		return dbPnttoageNo;
	}
	/**
	 * @param dbPnttoageNo the dbPnttoageNo to set
	 */
	public void setDbPnttoageNo(String dbPnttoageNo) {
		this.dbPnttoageNo = dbPnttoageNo;
	}
	/**
	 * @return the dbPatientsxCd
	 */
	public String getDbPatientsxCd() {
		return dbPatientsxCd;
	}
	/**
	 * @param dbPatientsxCd the dbPatientsxCd to set
	 */
	public void setDbPatientsxCd(String dbPatientsxCd) {
		this.dbPatientsxCd = dbPatientsxCd;
	}
	/**
	 * @return the dbTosCd
	 */
	public String getDbTosCd() {
		return dbTosCd;
	}
	/**
	 * @param dbTosCd the dbTosCd to set
	 */
	public void setDbTosCd(String dbTosCd) {
		this.dbTosCd = dbTosCd;
	}
	/**
	 * @return the dbPosCd
	 */
	public String getDbPosCd() {
		return dbPosCd;
	}
	/**
	 * @param dbPosCd the dbPosCd to set
	 */
	public void setDbPosCd(String dbPosCd) {
		this.dbPosCd = dbPosCd;
	}
	/**
	 * @return the dbSpclcovgCd
	 */
	public String getDbSpclcovgCd() {
		return dbSpclcovgCd;
	}
	/**
	 * @param dbSpclcovgCd the dbSpclcovgCd to set
	 */
	public void setDbSpclcovgCd(String dbSpclcovgCd) {
		this.dbSpclcovgCd = dbSpclcovgCd;
	}
	/**
	 * @return the dbADACd
	 */
	public String getDbADACd() {
		return dbADACd;
	}
	/**
	 * @param dbADACd the dbADACd to set
	 */
	public void setDbADACd(String dbADACd) {
		this.dbADACd = dbADACd;
	}
	/**
	 * @return the dbAxcelInd
	 */
	public String getDbAxcelInd() {
		return dbAxcelInd;
	}
	/**
	 * @param dbAxcelInd the dbAxcelInd to set
	 */
	public void setDbAxcelInd(String dbAxcelInd) {
		this.dbAxcelInd = dbAxcelInd;
	}
	/**
	 * @return the dbToscatCd
	 */
	public String getDbToscatCd() {
		return dbToscatCd;
	}
	/**
	 * @param dbToscatCd the dbToscatCd to set
	 */
	public void setDbToscatCd(String dbToscatCd) {
		this.dbToscatCd = dbToscatCd;
	}
	/**
	 * @return the dbPcpcovInd
	 */
	public String getDbPcpcovInd() {
		return dbPcpcovInd;
	}
	/**
	 * @param dbPcpcovInd the dbPcpcovInd to set
	 */
	public void setDbPcpcovInd(String dbPcpcovInd) {
		this.dbPcpcovInd = dbPcpcovInd;
	}
	/**
	 * @return the dbUsageCode
	 */
	public String getDbUsageCode() {
		return dbUsageCode;
	}
	/**
	 * @param dbUsageCode the dbUsageCode to set
	 */
	public void setDbUsageCode(String dbUsageCode) {
		this.dbUsageCode = dbUsageCode;
	}
	/**
	 * @return the dbUpdatedInd
	 */
	public char getDbUpdatedInd() {
		return dbUpdatedInd;
	}
	/**
	 * @param dbUpdatedInd the dbUpdatedInd to set
	 */
	public void setDbUpdatedInd(char dbUpdatedInd) {
		this.dbUpdatedInd = dbUpdatedInd;
	}
	
	
	}
