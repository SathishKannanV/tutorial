/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.SitemsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 *
 */
public interface SitemsgService {

	Map getSitemsgLookUpTable(String sitemsgCode, String svcTypeCode) throws ApplicationException ;

	/**
	 * 
	 * @param sitemsgDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map addNewSitemsg(SitemsgDTO sitemsgDTO)throws ApplicationException ;

	/**
	 * 
	 * @param sitemsgDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map deleteSitemsg(SitemsgDTO sitemsgDTO)throws ApplicationException ;

	/**
	 * 
	 * @param editedSitemsgDTO
	 * @param sitemsgDtoList
	 * @param index
	 * @param updateInd
	 * @return
	 * @throws ApplicationException
	 */
	Map addUpdateSitemsg(SitemsgDTO editedSitemsgDTO,
			List<SitemsgDTO> sitemsgDtoList, int index,char updateInd)throws ApplicationException;

}
