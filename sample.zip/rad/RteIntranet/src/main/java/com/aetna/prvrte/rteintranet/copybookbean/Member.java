package com.aetna.prvrte.rteintranet.copybookbean;


public class Member {

	String identifier;
	String groupID;
	public String getIdentifier() {
		
		return identifier;
	}
	public void setIdentifier(String identifier) {
		
		this.identifier = identifier;
	}
	public String getGroupID() {
		
		return groupID;
	}
	public void setGroupID(String groupID) {
		
		this.groupID = groupID;
	}
	public StringBuilder getMember(){
		return new StringBuilder(getIdentifier())
		.append(getGroupID());
	}
}
