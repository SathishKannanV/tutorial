/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.DedacsrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.DedacsrVO;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class DedacsrAddAdapter extends StoredProcedure {

	public DedacsrAddAdapter() {}
	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(DedacsrAddAdapter.class);
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public DedacsrAddAdapter(DataSource datasource, String storedProc) throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of DedacsrAdapter : " + storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_RTESTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_DEFACUM_ACCUM_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		declareParameter(new SqlOutParameter(DBConstants.LS_ADD_UPDATE, Types.DECIMAL));
	}
	/**
	 * Method to add new Dedacsr to data store.
	 * 
	 * @param dedacsr
	 *            String of aetna id.
	 * @return Map of Dedacsr list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	public Map<String, Object> addDedacsrToDb(DedacsrDTO dedacsrDTO)throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<DedacsrVO> dedacsrList = new LinkedList<DedacsrVO>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String dedacsrMsg = "";
		char updatedInd = 'N';
		try {
			String defAccumCd = RteIntranetUtils.getTrimmedString(dedacsrDTO.getDbDefAccumCd());
			String svcTypeCd = RteIntranetUtils.getTrimmedString(dedacsrDTO.getDbSvcTypeCd());
			//Query params.
			params.put(DBConstants.LS_RTESTYP_CD, svcTypeCd);
			params.put(DBConstants.LS_DEFACUM_ACCUM_CD, defAccumCd);
			log.warn("---------------------------" + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			String actionCode =  String.valueOf(results.get(DBConstants.LS_ADD_UPDATE));
			if ("0".equals(sqlCode)) {
				if ("0".equals(actionCode)) {
					dedacsrMsg = ApplicationConstants.ROW_ADDED;
				} else {
					dedacsrMsg = ApplicationConstants.ROW_ALREADY_EXISTS;
					updatedInd = 'Y';
				}
				
				DedacsrVO dedacsrObj = new DedacsrVO(svcTypeCd, defAccumCd, updatedInd);
				dedacsrList.add(dedacsrObj);
			} else {
				dedacsrMsg = ApplicationConstants.ADD_ROW_FAILS + sqlCode;
				
			}
			resultMap.put("dedacsrMsg", dedacsrMsg);
			resultMap.put("dedacsrList", dedacsrList);
		} catch (DataAccessException dae) {
			log.error("DedacsrAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("DedacsrAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
		return resultMap;
	}
	
	/**
	 * Method to add/update list of Dedacsr to data store.
	 * 
	 * @param dedacsrList
	 *            List of aetna ids.
	 * @param takeAction
	 *            List of selected indexes to delete aetna id.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from Dedacsr list, success or
	 *         error message and list of Dedacsr.
	 * @throws ApplicationException
	 *             if insertion or update fails.
	 */
	public Map<String, Object> addUpdateDedacsr(DedacsrDTO dedacsrDTO, List<DedacsrDTO> dedacsrList, int index) throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String dedacsrMsg = "";
		boolean isDedacsrAddorUpdated = false;
		try{
			String defAccumCd = RteIntranetUtils.getTrimmedString(dedacsrDTO.getDbDefAccumCd());
			String svcTypeCd = RteIntranetUtils.getTrimmedString(dedacsrDTO.getDbSvcTypeCd());
			char updatedInd = ApplicationConstants.UPDATE_IND_Y;
			//Query params.
			params.put(DBConstants.LS_RTESTYP_CD, svcTypeCd);
			params.put(DBConstants.LS_DEFACUM_ACCUM_CD, defAccumCd);
			log.warn("---------------------------" + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			String actionCode =  String.valueOf(results.get(DBConstants.LS_ADD_UPDATE));
			if ("0".equals(sqlCode)) {
				DedacsrDTO aDedacsrDTO = new DedacsrDTO(svcTypeCd,defAccumCd,updatedInd);
				dedacsrMsg = ApplicationConstants.ADD_UPDATE_ROWS;
				if ("0".equals(actionCode)) {
					if (dedacsrDTO.getDbUpdatedInd() == ApplicationConstants.COPY)
						dedacsrList.set(index, aDedacsrDTO);
					else
						dedacsrList.add(aDedacsrDTO);
				}
				else
					dedacsrList.set(index, aDedacsrDTO);
			} else {
				isDedacsrAddorUpdated = true;
				dedacsrMsg = ApplicationConstants.ADD_UPDATE_ROW_FAILS + sqlCode;
			}
			
			resultMap.put("dedacsrMsg", dedacsrMsg);
			resultMap.put("dedacsrList", dedacsrList);
			resultMap.put("isDedacsrAddorUpdated", isDedacsrAddorUpdated);
			return resultMap;
		}catch (DataAccessException dae) {
			log.error("DedacsrAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("DedacsrAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
	}
}
