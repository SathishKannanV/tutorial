package com.aetna.prvrte.rteintranet.dto;

public class SrchresDTO {
	private String srchresCd = new String(); 
	private String srchresDesc = new String(); 
	private String effDate = new String(); 
	private String expDate = new String();
	private String postedDate = new String();
	private char   updatedInd;
	
	public SrchresDTO() {
		super();
	}

	public SrchresDTO(String srchresCd, String srchresDesc, String effDate, String expDate, String postedDate, char updatedInd) {
		super();
		this.srchresCd = srchresCd;
		this.srchresDesc = srchresDesc;
		this.effDate = effDate;
		this.expDate = expDate;
		this.postedDate = postedDate;
		this.updatedInd = updatedInd;
	}

	public String getEffDate() {
		return effDate;
	}

	public String getExpDate() {
		return expDate;
	}

	public String getPostedDate() {
		return postedDate;
	}

	public String getSrchresCd() {
		return srchresCd;
	}

	public String getSrchresDesc() {
		return srchresDesc;
	}

	public char getUpdatedInd() {
		return updatedInd;
	}

	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}

	public void setSrchresCd(String srchresCd) {
		this.srchresCd = srchresCd;
	}

	public void setSrchresDesc(String srchresDesc) {
		this.srchresDesc = srchresDesc;
	}

	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}




}
