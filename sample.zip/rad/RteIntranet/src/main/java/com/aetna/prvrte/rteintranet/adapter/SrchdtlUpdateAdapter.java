package com.aetna.prvrte.rteintranet.adapter;


import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.SrchdtlDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
public class SrchdtlUpdateAdapter extends StoredProcedure {

	private final Log log = LogFactory.getLog(SrchdtlUpdateAdapter.class);
	private static final String LS_SRCHDTL_ID = "LS_SRCHDTL_ID";
	private static final String LS_SRCHSC_FIRST_ID = "LS_SRCHSC_FIRST_ID";
	private static final String LS_SRCHDTL_CMROLE_CD = "LS_SRCHDTL_CMROLE_CD";
	private static final String LS_SRCHCOL_CD = "LS_SRCHCOL_CD";
	private static final String LS_SRCHRES_CD = "LS_SRCHRES_CD";
	private static final String LS_SRCHSC_SECOND_ID = "LS_SRCHSC_SECOND_ID";
	private static final String LS_SRCHDTL_ST_CD = "LS_SRCHDTL_ST_CD";
	private static final String LS_SRCHRR_CD = "LS_SRCHRR_CD";
	private static final String LS_SRCHDTL_EFF_DT = "LS_SRCHDTL_EFF_DT";
	private static final String LS_SRCHDTL_EXP_DT = "LS_SRCHDTL_EXP_DT";
	private static final String LS_SRCHDTL_POSTED_DT = "LS_SRCHDTL_POSTED_DT";
	private static final String LS_ADD_UPDATE = "LS_ADD_UPDATE";
	private static final String LS_SQL_CODE = "LS_SQL_CODE";

	public SrchdtlUpdateAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(LS_SRCHDTL_ID, Types.SMALLINT));
		declareParameter(new SqlParameter(LS_SRCHSC_FIRST_ID, Types.SMALLINT));
		declareParameter(new SqlParameter(LS_SRCHDTL_CMROLE_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_SRCHCOL_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_SRCHRES_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_SRCHSC_SECOND_ID, Types.SMALLINT));
		declareParameter(new SqlParameter(LS_SRCHDTL_ST_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_SRCHRR_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_SRCHDTL_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(LS_SRCHDTL_EXP_DT, Types.DATE));
		declareParameter(new SqlParameter(LS_SRCHDTL_POSTED_DT, Types.DATE));
		
		
		
		declareParameter(new SqlOutParameter(LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(LS_SQL_CODE, Types.INTEGER));
		
	}
	@SuppressWarnings("unchecked")
	public Map addUpdateSrchdtl(SrchdtlDTO modifiedSrchdtl,
			List<SrchdtlDTO> srchdtlDtoList, int index, char updateInd) throws ApplicationException{
		log.debug("Entered SrchdtlUpdateAdapter  - addUpdateSrchdtl");
		boolean isSrchdtlAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map srchdtlMap = new HashMap();
		params.put(LS_SRCHDTL_ID, String.valueOf(modifiedSrchdtl.getSrchdtlId()));
	    params.put(LS_SRCHSC_FIRST_ID, String.valueOf(modifiedSrchdtl.getSrchscFirstId()));
	    params.put(LS_SRCHDTL_CMROLE_CD, RteIntranetUtils.getTrimmedString(modifiedSrchdtl.getcmRollCode()));
		params.put(LS_SRCHCOL_CD, RteIntranetUtils.getTrimmedString(modifiedSrchdtl.getSrchcolCd()));
		params.put(LS_SRCHRES_CD, RteIntranetUtils.getTrimmedString(modifiedSrchdtl.getSrchresCd()));
		params.put(LS_SRCHSC_SECOND_ID,String.valueOf(modifiedSrchdtl.getSrchscSecondId()));
		params.put(LS_SRCHDTL_ST_CD, RteIntranetUtils.getTrimmedString(modifiedSrchdtl.getSrchdtlStCd()));
		params.put(LS_SRCHRR_CD, RteIntranetUtils.getTrimmedString(modifiedSrchdtl.getSrcherrCd()));
		params.put(LS_SRCHDTL_EFF_DT, RteIntranetUtils.getTrimmedString(modifiedSrchdtl.getEffDate()));
		params.put(LS_SRCHDTL_EXP_DT, RteIntranetUtils.getTrimmedString(modifiedSrchdtl.getExpDate()));
		params.put(LS_SRCHDTL_POSTED_DT, RteIntranetUtils.getTrimmedString(modifiedSrchdtl.getPostedDate()));
		log.debug(params);	
		try {
					
			results = execute(params);
			log.debug("SrchdtlUpdateAdapter: Executed stored procedure");
			@SuppressWarnings("unused")
			String actionCode =  String.valueOf(results
					.get(LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(LS_SQL_CODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
 				isSrchdtlAddorUpdated = true;
 		
 				srchdtlDtoList.set(index, modifiedSrchdtl);	
 	
 				newMessage = "All rows that changed the database are highlighted.";
 					} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			srchdtlMap.put("srchdtlMsg",newMessage);
			srchdtlMap.put("srchdtlDtoList",srchdtlDtoList);
			srchdtlMap.put("isSrchdtlAddorUpdated", isSrchdtlAddorUpdated);
			return srchdtlMap;
		}catch (Exception exception){
			log.error("Srchdtl Update adapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
}
