/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.DedacsrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.DedacsrVO;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class DedacsrDisplayAdapter extends StoredProcedure {

	public DedacsrDisplayAdapter() {}

	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(DedacsrDisplayAdapter.class);
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	@SuppressWarnings("rawtypes")
	public DedacsrDisplayAdapter(DataSource datasource, String storedProc)
			throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of DedacsrAdapter : " + storedProc);
		declareParameter(new SqlParameter(DBConstants.LS_RTESTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_DEFACUM_ACCUM_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));

		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR4, new RowMapper() {
			/*
			 * (non-Javadoc)
			 * 
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet , int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				DedacsrVO dedacsrVO = new DedacsrVO();
				dedacsrVO.setDbSvcTypeCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RTESTYP_CD)));
				dedacsrVO.setDbDefAccumCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.DEFACUM_ACCUM_CD)));
				dedacsrVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
				return dedacsrVO;
			}
		}));
	}
	
	/**
	 * Method to get the DEDACSR list from data store.
	 * 
	 * @param dedacsrDTO
	 * 			dedacsrDTO object.
	 * @return Map of DEDACSR list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getDedacsrLookUpList(DedacsrDTO dedacsrDTO) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering getDedacsrLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<DedacsrVO> dedacsrList = new LinkedList<DedacsrVO>();
		String newMessage = "";
		try {
			String defacumAccumCd = RteIntranetUtils.getTrimmedString(dedacsrDTO.getDbDefAccumCd());
			String svcTypeCd = RteIntranetUtils.getTrimmedString(dedacsrDTO.getDbSvcTypeCd());
			
			
			params.put(DBConstants.LS_RTESTYP_CD, svcTypeCd);
			params.put(DBConstants.LS_DEFACUM_ACCUM_CD, defacumAccumCd);
			
			log.info("Params for getting Dedacsr LookUp List : " + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			if ("0".equalsIgnoreCase(sqlCode)) {
				dedacsrList = (ArrayList<DedacsrVO>) results.get(DBConstants.READ_CURSOR4);
				if (dedacsrList.isEmpty()) {
					newMessage = "No Data on database for Service Type Code: " + svcTypeCd + " " + "Def Accumulator CD : " + defacumAccumCd;
				} else {
					newMessage = "Data found on database for Service Type Code: " + svcTypeCd + " " + "Def Accumulator CD : " + defacumAccumCd;
				}
			} else {
				newMessage = "Problem in DB2. sqlcode: " + sqlCode + " Service Type Code: " + svcTypeCd + " " + "Def Accumulator CD : " + defacumAccumCd;
			}
			resultMap.put("dedacsrMsg", newMessage);
			resultMap.put("dedacsrList", dedacsrList);
			
			return resultMap;
			
		} catch (DataAccessException dae) {
			log.error("DedacsrDisplayAdapter : Data access excpetion occured " + dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("DedacsrDisplayAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} finally {

		}
	}
}
