/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.SrchdtlVO;


/**
 * @author N731694
 * Cognizant_Offshore
 */
public class SrchdtlAdapter extends StoredProcedure{

	private final Log log = LogFactory.getLog(SrchdtlAdapter.class);
	private static final String LS_SRCHSC_FIRST_ID = "LS_SRCHSC_FIRST_ID";
	private static final String LS_SRCHCOL_CD = "LS_SRCHCOL_CD";
	private static final String LS_SRCHSC_SECOND_ID = "LS_SRCHSC_SECOND_ID";
	private static final String LS_SRCHRR_CD = "LS_SRCHRR_CD";
	private static final String LS_SQL_TYPE = "LS_SQL_TYPE";
	private static final String OUT_CODE = "OUT_CODE";
	private static final String READ_CURSOR = "READ_CURSOR3";
	
	
	public SrchdtlAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(LS_SRCHSC_FIRST_ID, Types.SMALLINT));   
		declareParameter(new SqlParameter(LS_SRCHCOL_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_SRCHSC_SECOND_ID, Types.SMALLINT));
		declareParameter(new SqlParameter(LS_SRCHRR_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(LS_SQL_TYPE, Types.INTEGER));
		
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;			
				SrchdtlVO srchdtlVO=new SrchdtlVO();
				srchdtlVO.setSrchdtlId(rs.getString("SRCHDTL_ID"));
				srchdtlVO.setSrchscFirstId(rs.getString("SRCHSC_FIRST_ID"));
				srchdtlVO.setSrchcolCd(rs.getString("SRCHCOL_CD"));
				srchdtlVO.setSrchresCd(rs.getString("SRCHRES_CD"));
				srchdtlVO.setSrchscSecondId(rs.getString("SRCHSC_SECOND_ID"));
				srchdtlVO.setSrchdtlStCd(rs.getString("SRCHDTL_ST_CD"));
				srchdtlVO.setSrcherrCd(rs.getString("SRCHERR_CD"));
				srchdtlVO.setEffDate(rs.getString("SRCHDTL_EFF_DT"));
				srchdtlVO.setExpDate(rs.getString("SRCHDTL_EXP_DT"));
				srchdtlVO.setPostedDate(rs.getString("SRCHDTL_POSTED_DT"));
				srchdtlVO.setCmRollCode(rs.getString("SRCHDTL_CMROLE_CD"));
				srchdtlVO.setUpdatedInd(updatedInd);
				
				return srchdtlVO;
			}

		}));

	}
	
	
	
	@SuppressWarnings("unchecked")
	public Map getSrchdtlLookUpTable (String srchscFirstId, String srchscSecondId,String srcherrCd,String srchcolCd) throws ApplicationException {
		log.debug("Entered SrchdtlAdapter  - getSrchdtlLookUpTable");
		String queryField="",queryValue="";
		srchscFirstId = (srchscFirstId != null && !srchscFirstId.equals(("")) ? srchscFirstId : "0");
		srchscSecondId = (srchscSecondId != null && !srchscSecondId.equals(("")) ? srchscSecondId : "0");
	
        if(!srchscFirstId.equals(""))
        {
        	queryField ="First Scenario Id: ";
			queryValue = srchscFirstId;
        }
        if(!srchscSecondId.equals(""))
        {
        	queryField ="Second Scenario Id: ";
			queryValue = srchscSecondId;
        }
        
        		
		if (!srchcolCd.equals("")){
			queryField = "Search Column Code: ";
			queryValue = srchcolCd;
		}

		if (!srcherrCd.equals("")){
			queryField = "Search Error Code: ";
			queryValue = srcherrCd;
		}
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map srchdtlMap = new HashMap();
		params.put(LS_SRCHSC_FIRST_ID, RteIntranetUtils.getTrimmedString(srchscFirstId));
		params.put(LS_SRCHCOL_CD,RteIntranetUtils.getTrimmedString(srchcolCd));
		params.put(LS_SRCHSC_SECOND_ID, RteIntranetUtils.getTrimmedString(srchscSecondId));
		params.put(LS_SRCHRR_CD, RteIntranetUtils.getTrimmedString(srcherrCd));
		
		log.debug(params);
		Map results = null;
		
		List<SrchdtlVO> srchdtlList= new LinkedList<SrchdtlVO>();
		String newMessage="";
		int noOfElements;
		try {
			log.debug("Srchdtl Adapter: Executing stored procedure : " + "srchscFirstId : " + srchscFirstId + " ; srchscSecondId : "+srchscSecondId
					+"; srcherrCd : "+ srcherrCd +"srchcolCd"+srchcolCd);
					
		 results = execute(params);
			
			log.debug("SrchdtlAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(OUT_CODE));
			
			srchdtlList = (List<SrchdtlVO>) results
					.get(READ_CURSOR);	
	
			noOfElements = srchdtlList.size();
			//if (null != results) {
			if (srchdtlList.isEmpty()){
				
				if ("0".equals(sqlCode))
					newMessage = "No Data on database for First Search Id: " + queryField + queryValue;
			//		" || Second Search Id: " + srchscSecondId + " || Triple A Error Cd: " + srcherrCd + " || Member Search Column Cd " + srchcolCd;
				else
					newMessage = "Problem in DB2. sqlcode: " + sqlCode; 
			} else {
				if (noOfElements > 1) {
			    	newMessage = noOfElements + " Rows found for   " + queryField + queryValue;;
				} else {
			    newMessage = noOfElements + " Row found for ";
				}
				//newMessage = getMessage(newMessage, bicId, prov);
			}
			/*}else{
				newMessage = "You must enter a Procex Code with or without combination of Rider Code and/or Service Type Code on the Look Up page.";
			}*/
			srchdtlMap.put("newMessage", newMessage);
			srchdtlMap.put("srchdtlList",srchdtlList);
			return srchdtlMap;
		}catch (Exception exception){
			log.error("SrchdtlAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	

}
