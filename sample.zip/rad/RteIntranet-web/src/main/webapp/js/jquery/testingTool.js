$(document).ready( function() {
	var relPath="<%=request.getContextPath()%>";
						$("#versionRels").attr("value", "RTE_5010");
$("#dependentTable").hide();
$("#counterService").hide();
$("#subscriberTable").show();						
$("#NdvEntityID").hide();
$("#NdvEntityID1").hide();
$("#NdvEntityID2").hide();
 $("#ndvName").hide();
 $("#IndvTitleDesc").show();
 $("#IndvMiddleName").show();
 $("#IndvFirstName").show();
 $("#IndvLastName").show();
$("#IndventityId").show();
$("#IndventityId1").show();
$("#IndventityId2").show();
$("#IndventityId3").show();
$("#IndventityId4").show();
$("#IndventityId5").show();
$("#counterDiagShow").hide();
$("#diagonsisTypeSetTable").show();
$("#serviceTypeSetTable").show();
$("#counterDiagShow").hide();
$("#counterDiaghide").hide();
$("#PlaceOfserviceTitle").hide();
$("#PlaceOfserviceInner").hide();
$("#procedureInfo").hide();
$("#procedureInfoInner").hide();
$("#one").hide();$("#two").hide();$("#three").hide();$("#four").hide();$("#five").hide();
$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
$("#sizeCheck").hide();

$('#entityIndicator').change(function() {
       
    var selected = $(this).val();
    if (selected == '1') { 
    	$("#NdvEntityID").hide();
    	$("#NdvEntityID1").hide();
    	$("#NdvEntityID2").hide();
 		$("#ndvName").hide();
     	$("#IndvTitleDesc").show();
 		$("#IndvMiddleName").show();
 		$("#IndvFirstName").show();
 		$("#IndvLastName").show();
  		$("#IndventityId").show(); 
  		$("#IndventityId1").show();
  		$("#IndventityId2").show();
  		$("#IndventityId3").show();
  		$("#IndventityId4").show();
  		$("#IndventityId5").show(); 
  		$("#sizeCheck").hide();
    }
    else if (selected == '2') {
    	$("#sizeCheck").show();
    	$("#NdvEntityID").show();
    	$("#NdvEntityID1").show();
    	$("#NdvEntityID2").show();
 		$("#ndvName").show();
     	$("#IndvTitleDesc").hide();
 		$("#IndvMiddleName").hide();
 		$("#IndvFirstName").hide();
 		$("#IndvLastName").hide();
  		$("#IndventityId").hide();
  		$("#IndventityId1").hide();
  		$("#IndventityId2").hide();
  		$("#IndventityId3").hide();
  		$("#IndventityId4").hide();
  		$("#IndventityId5").hide();
    }else {$("#NdvEntityID").hide();
$("#NdvEntityID1").hide();
$("#NdvEntityID2").hide();
 $("#ndvName").hide();
 $("#IndvTitleDesc").hide();
 $("#IndvMiddleName").hide();
 $("#IndvFirstName").hide();
 $("#IndvLastName").hide();
$("#IndventityId").hide();
$("#IndventityId1").hide();
$("#IndventityId2").hide();
$("#IndventityId3").hide();
$("#IndventityId4").hide();
$("#IndventityId5").hide();
$("#sizeCheck").hide();
    }
    });
    $('#setType').change(function() {
       
    var selected = $(this).val();
    if (selected == '1') { 
    	$("#serviceTypeCTR").val("");
    	$("#counterService").hide();
    	$("#diagonsisTypeSetTable").hide();
  		$("#serviceTypeSetTable").show(); 
  		 $("#counterDiaghide").hide();
  		 $("#PlaceOfserviceTitle").hide();
		$("#PlaceOfserviceInner").hide();
		$("#procedureInfo").hide();
		$("#procedureInfoInner").hide();
     $("#counterDiagShow").hide();$("#one").hide();$("#two").hide();$("#three").hide();$("#four").hide();$("#five").hide();
	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    }else if (selected == '2') { 
    	$("#diganosisCtr").val("");
    	$("#counterDiaghide").hide();
    $("#counterDiagShow").show();
    	$("#diagonsisTypeSetTable").show();
  		$("#serviceTypeSetTable").hide(); 
  		 $("#PlaceOfserviceTitle").hide();
		$("#PlaceOfserviceInner").hide();
     $("#counterDiagShow").show();
     $("#procedureInfo").hide();
		$("#procedureInfoInner").hide();$("#one").hide();$("#two").hide();$("#three").hide();$("#four").hide();$("#five").hide();
		$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
		$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
  		
    }else if (selected == '3') { 
    	$("#placeOfServiceCtr").val("");
    	 $("#PlaceOfserviceInner").hide();
    	$("#diagonsisTypeSetTable").hide();
  		$("#serviceTypeSetTable").hide(); 
  		 $("#PlaceOfserviceTitle").show();
		$("#PlaceOfserviceInner").hide();
     $("#counterDiagShow").hide();
     $("#procedureInfo").hide();
		$("#procedureInfoInner").hide();$("#one").hide();$("#two").hide();$("#three").hide();$("#four").hide();$("#five").hide();
		$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
		$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
  		
    }else if (selected == '4') { 
    	$("#procedureInfoCtr").val("");
    	 $("#procedureInfoInner").hide();
    	$("#diagonsisTypeSetTable").hide();
  		$("#serviceTypeSetTable").hide(); 
  		 $("#PlaceOfserviceTitle").hide();
		$("#PlaceOfserviceInner").hide();
     $("#counterDiagShow").hide();
     $("#procedureInfo").show();
		$("#procedureInfoInner").hide();$("#one").hide();$("#two").hide();$("#three").hide();$("#four").hide();$("#five").hide();
		$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
		$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
  		
    }
    });
$('#subsDept').change(function() {
       
    var selected = $(this).val();
    if (selected == 'Subscriber') { 
    	$("#dependentTable").hide();
  		$("#subscriberTable").show(); 
    }
    else if (selected == 'Dependent') {
    	$("#dependentTable").show();
  		$("#subscriberTable").hide();
    }else {
$("#dependentTable").hide();
$("#subscriberTable").hide();
    }
    });
$('#serviceTypeCTR').change(function() {
       
    var selected = $(this).val();
    if(selected == '0'){
    $("#counterService").hide();
    $("#one").hide();$("#two").hide();$("#three").hide();$("#four").hide();$("#five").hide();
	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    }
    else if(selected == '1'){
    	$("#one").show();$("#two").hide();$("#three").hide();$("#four").hide();$("#five").hide();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#counterService").show();$("#serviceTypeCode1").show();
    $("#Code1").show();$("#Code2").hide();$("#Code3").hide();$("#Code4").hide();$("#Code5").hide();$("#Code6").hide();$("#Code7").hide();$("#Code8").hide();
    $("#Code9").hide();$("#Code10").hide();$("#Code11").hide();$("#Code12").hide();$("#Code13").hide();
    $("#serviceTypeCode2").hide();$("#serviceTypeCode3").hide();$("#serviceTypeCode4").hide();$("#serviceTypeCode5").hide();$("#serviceTypeCode6").hide();
    $("#serviceTypeCode7").hide();$("#serviceTypeCode8").hide();$("#serviceTypeCode9").hide();$("#serviceTypeCode10").hide();$("#serviceTypeCode11").hide();
    $("#serviceTypeCode12").hide();$("#serviceTypeCode13").hide();
    }else if(selected == '2'){
    	$("#one").show();$("#two").show();$("#three").hide();$("#four").hide();$("#five").hide();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#counterService").show();$("#serviceTypeCode1").show();
    $("#Code1").show();$("#Code2").show();$("#Code3").hide();$("#Code4").hide();$("#Code5").hide();$("#Code6").hide();$("#Code7").hide();$("#Code8").hide();
    $("#Code9").hide();$("#Code10").hide();$("#Code11").hide();$("#Code12").hide();$("#Code13").hide();
    $("#serviceTypeCode2").show();$("#serviceTypeCode3").hide();$("#serviceTypeCode4").hide();$("#serviceTypeCode5").hide();$("#serviceTypeCode6").hide();
    $("#serviceTypeCode7").hide();$("#serviceTypeCode8").hide();$("#serviceTypeCode9").hide();$("#serviceTypeCode10").hide();$("#serviceTypeCode11").hide();
    $("#serviceTypeCode12").hide();$("#serviceTypeCode13").hide();
    }else if(selected == '3'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").hide();$("#five").hide();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#counterService").show();$("#serviceTypeCode1").show();
    $("#Code1").show();$("#Code2").show();$("#Code3").show();$("#Code4").hide();$("#Code5").hide();$("#Code6").hide();$("#Code7").hide();$("#Code8").hide();
    $("#Code9").hide();$("#Code10").hide();$("#Code11").hide();$("#Code12").hide();$("#Code13").hide();
    $("#serviceTypeCode2").show();$("#serviceTypeCode3").show();$("#serviceTypeCode4").hide();$("#serviceTypeCode5").hide();$("#serviceTypeCode6").hide();
    $("#serviceTypeCode7").hide();$("#serviceTypeCode8").hide();$("#serviceTypeCode9").hide();$("#serviceTypeCode10").hide();$("#serviceTypeCode11").hide();
    $("#serviceTypeCode12").hide();$("#serviceTypeCode13").hide();
    }else if(selected == '4'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").hide();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#counterService").show();$("#serviceTypeCode1").show();
    $("#Code1").show();$("#Code2").show();$("#Code3").show();$("#Code4").show();$("#Code5").hide();$("#Code6").hide();$("#Code7").hide();$("#Code8").hide();
    $("#Code9").hide();$("#Code10").hide();$("#Code11").hide();$("#Code12").hide();$("#Code13").hide();
    $("#serviceTypeCode2").show();$("#serviceTypeCode3").show();$("#serviceTypeCode4").show();$("#serviceTypeCode5").hide();$("#serviceTypeCode6").hide();
    $("#serviceTypeCode7").hide();$("#serviceTypeCode8").hide();$("#serviceTypeCode9").hide();$("#serviceTypeCode10").hide();$("#serviceTypeCode11").hide();
    $("#serviceTypeCode12").hide();$("#serviceTypeCode13").hide();
    }else if(selected == '5'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#counterService").show();$("#serviceTypeCode1").show();
    $("#Code1").show();$("#Code2").show();$("#Code3").show();$("#Code4").show();$("#Code5").show();$("#Code6").hide();$("#Code7").hide();$("#Code8").hide();
    $("#Code9").hide();$("#Code10").hide();$("#Code11").hide();$("#Code12").hide();$("#Code13").hide();
    $("#serviceTypeCode2").show();$("#serviceTypeCode3").show();$("#serviceTypeCode4").show();$("#serviceTypeCode5").show();$("#serviceTypeCode6").hide();
    $("#serviceTypeCode7").hide();$("#serviceTypeCode8").hide();$("#serviceTypeCode9").hide();$("#serviceTypeCode10").hide();$("#serviceTypeCode11").hide();
    $("#serviceTypeCode12").hide();$("#serviceTypeCode13").hide();
    }else if(selected == '6'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#counterService").show();$("#serviceTypeCode1").show();
    $("#Code1").show();$("#Code2").show();$("#Code3").show();$("#Code4").show();$("#Code5").show();$("#Code6").show();$("#Code7").hide();$("#Code8").hide();
    $("#Code9").hide();$("#Code10").hide();$("#Code11").hide();$("#Code12").hide();$("#Code13").hide();
    $("#serviceTypeCode2").show();$("#serviceTypeCode3").show();$("#serviceTypeCode4").show();$("#serviceTypeCode5").show();$("#serviceTypeCode6").show();
    $("#serviceTypeCode7").hide();$("#serviceTypeCode8").hide();$("#serviceTypeCode9").hide();$("#serviceTypeCode10").hide();$("#serviceTypeCode11").hide();
    $("#serviceTypeCode12").hide();$("#serviceTypeCode13").hide();
    }else if(selected == '7'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#counterService").show();$("#serviceTypeCode1").show();
    $("#Code1").show();$("#Code2").show();$("#Code3").show();$("#Code4").show();$("#Code5").show();$("#Code6").show();$("#Code7").show();$("#Code8").hide();
    $("#Code9").hide();$("#Code10").hide();$("#Code11").hide();$("#Code12").hide();$("#Code13").hide();
    $("#serviceTypeCode2").show();$("#serviceTypeCode3").show();$("#serviceTypeCode4").show();$("#serviceTypeCode5").show();$("#serviceTypeCode6").show();
    $("#serviceTypeCode7").show();$("#serviceTypeCode8").hide();$("#serviceTypeCode9").hide();$("#serviceTypeCode10").hide();$("#serviceTypeCode11").hide();
    $("#serviceTypeCode12").hide();$("#serviceTypeCode13").hide();
    }else if(selected == '8'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#counterService").show();$("#serviceTypeCode1").show();
    $("#Code1").show();$("#Code2").show();$("#Code3").show();$("#Code4").show();$("#Code5").show();$("#Code6").show();$("#Code7").show();$("#Code8").show();
    $("#Code9").hide();$("#Code10").hide();$("#Code11").hide();$("#Code12").hide();$("#Code13").hide();
    $("#serviceTypeCode2").show();$("#serviceTypeCode3").show();$("#serviceTypeCode4").show();$("#serviceTypeCode5").show();$("#serviceTypeCode6").show();
    $("#serviceTypeCode7").show();$("#serviceTypeCode8").show();$("#serviceTypeCode9").hide();$("#serviceTypeCode10").hide();$("#serviceTypeCode11").hide();
    $("#serviceTypeCode12").hide();$("#serviceTypeCode13").hide();
    }else if(selected == '9'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").show();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#counterService").show();$("#serviceTypeCode1").show();
    $("#Code1").show();$("#Code2").show();$("#Code3").show();$("#Code4").show();$("#Code5").show();$("#Code6").show();$("#Code7").show();$("#Code8").show();
    $("#Code9").show();$("#Code10").hide();$("#Code11").hide();$("#Code12").hide();$("#Code13").hide();
    $("#serviceTypeCode2").show();$("#serviceTypeCode3").show();$("#serviceTypeCode4").show();$("#serviceTypeCode5").show();$("#serviceTypeCode6").show();
    $("#serviceTypeCode7").show();$("#serviceTypeCode8").show();$("#serviceTypeCode9").show();$("#serviceTypeCode10").hide();$("#serviceTypeCode11").hide();
    $("#serviceTypeCode12").hide();$("#serviceTypeCode13").hide();
    }else if(selected == '10'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").show();$("#ten").show();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#counterService").show();$("#serviceTypeCode1").show();
    $("#Code1").show();$("#Code2").show();$("#Code3").show();$("#Code4").show();$("#Code5").show();$("#Code6").show();$("#Code7").show();$("#Code8").show();
    $("#Code9").show();$("#Code10").show();$("#Code11").hide();$("#Code12").hide();$("#Code13").hide();
    $("#serviceTypeCode2").show();$("#serviceTypeCode3").show();$("#serviceTypeCode4").show();$("#serviceTypeCode5").show();$("#serviceTypeCode6").show();
    $("#serviceTypeCode7").show();$("#serviceTypeCode8").show();$("#serviceTypeCode9").show();$("#serviceTypeCode10").show();$("#serviceTypeCode11").hide();
    $("#serviceTypeCode12").hide();$("#serviceTypeCode13").hide();
    }else if(selected == '11'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").show();$("#ten").show();
    	$("#eleven").show();$("#twelve").hide();$("#thirteen").hide();
    $("#counterService").show();$("#serviceTypeCode1").show();
    $("#Code1").show();$("#Code2").show();$("#Code3").show();$("#Code4").show();$("#Code5").show();$("#Code6").show();$("#Code7").show();$("#Code8").show();
    $("#Code9").show();$("#Code10").show();$("#Code11").show();$("#Code12").hide();$("#Code13").hide();
    $("#serviceTypeCode2").show();$("#serviceTypeCode3").show();$("#serviceTypeCode4").show();$("#serviceTypeCode5").show();$("#serviceTypeCode6").show();
    $("#serviceTypeCode7").show();$("#serviceTypeCode8").show();$("#serviceTypeCode9").show();$("#serviceTypeCode10").show();$("#serviceTypeCode11").show();
    $("#serviceTypeCode12").hide();$("#serviceTypeCode13").hide();
    }else if(selected == '12'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").show();$("#ten").show();
    	$("#eleven").show();$("#twelve").show();$("#thirteen").hide();
    $("#counterService").show();$("#serviceTypeCode1").show();
    $("#Code1").show();$("#Code2").show();$("#Code3").show();$("#Code4").show();$("#Code5").show();$("#Code6").show();$("#Code7").show();$("#Code8").show();
    $("#Code9").show();$("#Code10").show();$("#Code11").show();$("#Code12").show();$("#Code13").hide();
    $("#serviceTypeCode2").show();$("#serviceTypeCode3").show();$("#serviceTypeCode4").show();$("#serviceTypeCode5").show();$("#serviceTypeCode6").show();
    $("#serviceTypeCode7").show();$("#serviceTypeCode8").show();$("#serviceTypeCode9").show();$("#serviceTypeCode10").show();$("#serviceTypeCode11").show();
    $("#serviceTypeCode12").show();$("#serviceTypeCode13").hide();
    }else if(selected == '13'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").show();$("#ten").show();
    	$("#eleven").show();$("#twelve").show();$("#thirteen").show();
    $("#counterService").show();$("#serviceTypeCode1").show();
    $("#Code1").show();$("#Code2").show();$("#Code3").show();$("#Code4").show();$("#Code5").show();$("#Code6").show();$("#Code7").show();$("#Code8").show();
    $("#Code9").show();$("#Code10").show();$("#Code11").show();$("#Code12").show();$("#Code13").show();
    $("#serviceTypeCode2").show();$("#serviceTypeCode3").show();$("#serviceTypeCode4").show();$("#serviceTypeCode5").show();$("#serviceTypeCode6").show();
    $("#serviceTypeCode7").show();$("#serviceTypeCode8").show();$("#serviceTypeCode9").show();$("#serviceTypeCode10").show();$("#serviceTypeCode11").show();
    $("#serviceTypeCode12").show();$("#serviceTypeCode13").show();
    
    }
    });
    $('#procedureInfoCtr').change(function() {
       
    var selected = $(this).val();
    if(selected == '0'){
    $("#procedureInfoInner").hide();
    $("#one").hide();$("#two").hide();$("#three").hide();$("#four").hide();$("#five").hide();
	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    }
    else if(selected == '1'){
    	$("#one").show();$("#two").hide();$("#three").hide();$("#four").hide();$("#five").hide();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#procedureInfoInner").show();$("#codePCq1").show();$("#codePCq2").hide();$("#codePCq3").hide();$("#codePCq4").hide();$("#codePCq5").hide();$("#codePCq6").hide();$("#codePCq7").hide();$("#codePCq8").hide();
	$("#codePCq9").hide();$("#codePCq10").hide();
    $("#codePC1").show();$("#codePC2").hide();$("#codePC3").hide();$("#codePC4").hide();$("#codePC5").hide();$("#codePC6").hide();$("#codePC7").hide();$("#codePC8").hide();
    $("#codePC9").hide();$("#codePC10").hide();$("#posCodeLast1").show();
    $("#posCodeLast2").hide();$("#posCodeLast3").hide();$("#posCodeLast4").hide();$("#posCodeLast5").hide();$("#posCodeLast6").hide();
    $("#posCodeLast7").hide();$("#posCodeLast8").hide();$("#posCodeLast9").hide();$("#posCodeLast10").hide();
    $("#posCodeLastq1").show();$("#posCodeLastq2").hide();$("#posCodeLastq3").hide();$("#posCodeLastq4").hide();$("#posCodeLastq5").hide();$("#posCodeLastq6").hide();
	$("#posCodeLastq7").hide();$("#posCodeLastq8").hide();$("#posCodeLastq9").hide();$("#posCodeLastq10").hide();
    }else if(selected == '2'){
    	$("#one").show();$("#two").show();$("#three").hide();$("#four").hide();$("#five").hide();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#procedureInfoInner").show();$("#codePCq1").show();$("#codePCq2").show();$("#codePCq3").hide();$("#codePCq4").hide();$("#codePCq5").hide();$("#codePCq6").hide();$("#codePCq7").hide();$("#codePCq8").hide();
	$("#codePCq9").hide();$("#codePCq10").hide();
    $("#codePC1").show();$("#codePC2").show();$("#codePC3").hide();$("#codePC4").hide();$("#codePC5").hide();$("#codePC6").hide();$("#codePC7").hide();$("#codePC8").hide();
    $("#codePC9").hide();$("#codePC10").hide();$("#posCodeLast1").show();
    $("#posCodeLast2").show();$("#posCodeLast3").hide();$("#posCodeLast4").hide();$("#posCodeLast5").hide();$("#posCodeLast6").hide();
    $("#posCodeLast7").hide();$("#posCodeLast8").hide();$("#posCodeLast9").hide();$("#posCodeLast10").hide();
    $("#posCodeLastq1").show();$("#posCodeLastq2").show();$("#posCodeLastq3").hide();$("#posCodeLastq4").hide();$("#posCodeLastq5").hide();$("#posCodeLastq6").hide();
	$("#posCodeLastq7").hide();$("#posCodeLastq8").hide();$("#posCodeLastq9").hide();$("#posCodeLastq10").hide();
    }else if(selected == '3'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").hide();$("#five").hide();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#procedureInfoInner").show();$("#codePCq1").show();$("#codePCq2").show();$("#codePCq3").show();$("#codePCq4").hide();$("#codePCq5").hide();$("#codePCq6").hide();$("#codePCq7").hide();$("#codePCq8").hide();
    $("#codePCq9").hide();$("#codePCq10").hide();
    $("#codePC1").show();$("#codePC2").show();$("#codePC3").show();$("#codePC4").hide();$("#codePC5").hide();$("#codePC6").hide();$("#codePC7").hide();$("#codePC8").hide();
    $("#codePC9").hide();$("#codePC10").hide();$("#posCodeLast1").show();
    $("#posCodeLast2").show();$("#posCodeLast3").show();$("#posCodeLast4").hide();$("#posCodeLast5").hide();$("#posCodeLast6").hide();
    $("#posCodeLast7").hide();$("#posCodeLast8").hide();$("#posCodeLast9").hide();$("#posCodeLast10").hide();
    $("#posCodeLastq1").show();$("#posCodeLastq2").show();$("#posCodeLastq3").show();$("#posCodeLastq4").hide();$("#posCodeLastq5").hide();$("#posCodeLastq6").hide();
	$("#posCodeLastq7").hide();$("#posCodeLastq8").hide();$("#posCodeLastq9").hide();$("#posCodeLastq10").hide();
    }else if(selected == '4'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").hide();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#procedureInfoInner").show();$("#codePCq1").show();$("#codePCq2").show();$("#codePCq3").show();$("#codePCq4").show();$("#codePCq5").hide();$("#codePCq6").hide();$("#codePCq7").hide();$("#codePCq8").hide();
    $("#codePCq9").hide();$("#codePCq10").hide();
    $("#codePC1").show();$("#codePC2").show();$("#codePC3").show();$("#codePC4").show();$("#codePC5").hide();$("#codePC6").hide();$("#codePC7").hide();$("#codePC8").hide();
    $("#codePC9").hide();$("#codePC10").hide();$("#posCodeLast1").show();
    $("#posCodeLast2").show();$("#posCodeLast3").show();$("#posCodeLast4").show();$("#posCodeLast5").hide();$("#posCodeLast6").hide();
    $("#posCodeLast7").hide();$("#posCodeLast8").hide();$("#posCodeLast9").hide();$("#posCodeLast10").hide();
    $("#posCodeLastq1").show();$("#posCodeLastq2").show();$("#posCodeLastq3").show();$("#posCodeLastq4").show();$("#posCodeLastq5").hide();$("#posCodeLastq6").hide();
	$("#posCodeLastq7").hide();$("#posCodeLastq8").hide();$("#posCodeLastq9").hide();$("#posCodeLastq10").hide();
    }else if(selected == '5'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#procedureInfoInner").show();$("#codePCq1").show();$("#codePCq2").show();$("#codePCq3").show();$("#codePCq4").show();$("#codePCq5").show();$("#codePCq6").hide();$("#codePCq7").hide();$("#codePCq8").hide();
    $("#codePCq9").hide();$("#codePCq10").hide();
    $("#codePC1").show();$("#codePC2").show();$("#codePC3").show();$("#codePC4").show();$("#codePC5").show();$("#codePC6").hide();$("#codePC7").hide();$("#codePC8").hide();
    $("#codePC9").hide();$("#codePC10").hide();$("#posCodeLast1").show();
    $("#posCodeLast2").show();$("#posCodeLast3").show();$("#posCodeLast4").show();$("#posCodeLast5").show();$("#posCodeLast6").hide();
    $("#posCodeLast7").hide();$("#posCodeLast8").hide();$("#posCodeLast9").hide();$("#posCodeLast10").hide();
    $("#posCodeLastq1").show();$("#posCodeLastq2").show();$("#posCodeLastq3").show();$("#posCodeLastq4").show();$("#posCodeLastq5").show();$("#posCodeLastq6").hide();
	$("#posCodeLastq7").hide();$("#posCodeLastq8").hide();$("#posCodeLastq9").hide();$("#posCodeLastq10").hide();
    }else if(selected == '6'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#procedureInfoInner").show();$("#codePCq1").show();$("#codePCq2").show();$("#codePCq3").show();$("#codePCq4").show();$("#codePCq5").show();$("#codePCq6").show();$("#codePCq7").hide();$("#codePCq8").hide();
    $("#codePCq9").hide();$("#codePCq10").hide();
    $("#codePC1").show();$("#codePC2").show();$("#codePC3").show();$("#codePC4").show();$("#codePC5").show();$("#codePC6").show();$("#codePC7").hide();$("#codePC8").hide();
    $("#codePC9").hide();$("#codePC10").hide();$("#posCodeLast1").show();
    $("#posCodeLast2").show();$("#posCodeLast3").show();$("#posCodeLast4").show();$("#posCodeLast5").show();$("#posCodeLast6").show();
    $("#posCodeLast7").hide();$("#posCodeLast8").hide();$("#posCodeLast9").hide();$("#posCodeLast10").hide();
    $("#posCodeLastq1").show();$("#posCodeLastq2").show();$("#posCodeLastq3").show();$("#posCodeLastq4").show();$("#posCodeLastq5").show();$("#posCodeLastq6").show();
	$("#posCodeLastq7").hide();$("#posCodeLastq8").hide();$("#posCodeLastq9").hide();$("#posCodeLastq10").hide();
    }else if(selected == '7'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#procedureInfoInner").show();$("#codePCq1").show();$("#codePCq2").show();$("#codePCq3").show();$("#codePCq4").show();$("#codePCq5").show();$("#codePCq6").show();$("#codePCq7").show();$("#codePCq8").hide();
    $("#codePCq9").hide();$("#codePCq10").hide();
    $("#codePC1").show();$("#codePC2").show();$("#codePC3").show();$("#codePC4").show();$("#codePC5").show();$("#codePC6").show();$("#codePC7").show();$("#codePC8").hide();
    $("#codePC9").hide();$("#codePC10").hide();$("#posCodeLast1").show();
    $("#posCodeLast2").show();$("#posCodeLast3").show();$("#posCodeLast4").show();$("#posCodeLast5").show();$("#posCodeLast6").show();
    $("#posCodeLast7").show();$("#posCodeLast8").hide();$("#posCodeLast9").hide();$("#posCodeLast10").hide();
    $("#posCodeLastq1").show();$("#posCodeLastq2").show();$("#posCodeLastq3").show();$("#posCodeLastq4").show();$("#posCodeLastq5").show();$("#posCodeLastq6").show();
	$("#posCodeLastq7").show();$("#posCodeLastq8").hide();$("#posCodeLastq9").hide();$("#posCodeLastq10").hide();
    }else if(selected == '8'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#procedureInfoInner").show();$("#codePCq1").show();$("#codePCq2").show();$("#codePCq3").show();$("#codePCq4").show();$("#codePCq5").show();$("#codePCq6").show();$("#codePCq7").show();$("#codePCq8").show();
    $("#codePCq9").hide();$("#codePCq10").hide();
    $("#codePC1").show();$("#codePC2").show();$("#codePC3").show();$("#codePC4").show();$("#codePC5").show();$("#codePC6").show();$("#codePC7").show();$("#codePC8").show();
    $("#codePC9").hide();$("#codePC10").hide();$("#posCodeLast1").show();
    $("#posCodeLast2").show();$("#posCodeLast3").show();$("#posCodeLast4").show();$("#posCodeLast5").show();$("#posCodeLast6").show();
    $("#posCodeLast7").show();$("#posCodeLast8").show();$("#posCodeLast9").hide();$("#posCodeLast10").hide();
    $("#posCodeLastq1").show();$("#posCodeLastq2").show();$("#posCodeLastq3").show();$("#posCodeLastq4").show();$("#posCodeLastq5").show();$("#posCodeLastq6").show();
	$("#posCodeLastq7").show();$("#posCodeLastq8").show();$("#posCodeLastq9").hide();$("#posCodeLastq10").hide();
    }else if(selected == '9'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").show();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#procedureInfoInner").show();$("#codePCq1").show();$("#codePCq2").show();$("#codePCq3").show();$("#codePCq4").show();$("#codePCq5").show();$("#codePCq6").show();$("#codePCq7").show();$("#codePCq8").show();
    $("#codePCq9").show();$("#codePCq10").hide();
    $("#codePC1").show();$("#codePC2").show();$("#codePC3").show();$("#codePC4").show();$("#codePC5").show();$("#codePC6").show();$("#codePC7").show();$("#codePC8").show();
    $("#codePC9").show();$("#codePC10").hide();$("#posCodeLast1").show();
    $("#posCodeLast2").show();$("#posCodeLast3").show();$("#posCodeLast4").show();$("#posCodeLast5").show();$("#posCodeLast6").show();
    $("#posCodeLast7").show();$("#posCodeLast8").show();$("#posCodeLast9").show();$("#posCodeLast10").hide();
    $("#posCodeLastq1").show();$("#posCodeLastq2").show();$("#posCodeLastq3").show();$("#posCodeLastq4").show();$("#posCodeLastq5").show();$("#posCodeLastq6").show();
	$("#posCodeLastq7").show();$("#posCodeLastq8").show();$("#posCodeLastq9").show();$("#posCodeLastq10").hide();
    }else if(selected == '10'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").show();$("#ten").show();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#procedureInfoInner").show();$("#codePCq1").show();$("#codePCq2").show();$("#codePCq3").show();$("#codePCq4").show();$("#codePCq5").show();$("#codePCq6").show();$("#codePCq7").show();$("#codePCq8").show();
    $("#codePCq9").show();$("#codePCq10").show();
    $("#codePC1").show();$("#codePC2").show();$("#codePC3").show();$("#codePC4").show();$("#codePC5").show();$("#codePC6").show();$("#codePC7").show();$("#codePC8").show();
    $("#codePC9").show();$("#codePC10").show();$("#posCodeLast1").show();
    $("#posCodeLast2").show();$("#posCodeLast3").show();$("#posCodeLast4").show();$("#posCodeLast5").show();$("#posCodeLast6").show();
    $("#posCodeLast7").show();$("#posCodeLast8").show();$("#posCodeLast9").show();$("#posCodeLast10").show();
    $("#posCodeLastq1").show();$("#posCodeLastq2").show();$("#posCodeLastq3").show();$("#posCodeLastq4").show();$("#posCodeLastq5").show();$("#posCodeLastq6").show();
	$("#posCodeLastq7").show();$("#posCodeLastq8").show();$("#posCodeLastq9").show();$("#posCodeLastq10").show();
    }
    });
    $('#placeOfServiceCtr').change(function() {
       
    var selected = $(this).val();
    if(selected == '0'){
    $("#PlaceOfserviceInner").hide();
    $("#one").hide();$("#two").hide();$("#three").hide();$("#four").hide();$("#five").hide();
	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    }
    else if(selected == '1'){
    	$("#one").show();$("#two").hide();$("#three").hide();$("#four").hide();$("#five").hide();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#PlaceOfserviceInner").show();$("#posCode1").show();
    $("#Codep1").show();$("#Codep2").hide();$("#Codep3").hide();$("#Codep4").hide();$("#Codep5").hide();$("#Codep6").hide();$("#Codep7").hide();$("#Codep8").hide();
    $("#Codep9").hide();$("#Codep10").hide();$("#Codep11").hide();$("#Codep12").hide();$("#Codep13").hide();
    $("#posCode2").hide();$("#posCode3").hide();$("#posCode4").hide();$("#posCode5").hide();$("#posCode6").hide();
    $("#posCode7").hide();$("#posCode8").hide();$("#posCode9").hide();$("#posCode10").hide();$("#posCode11").hide();
    $("#posCode12").hide();$("#posCode13").hide();
    }else if(selected == '2'){
    	$("#one").show();$("#two").show();$("#three").hide();$("#four").hide();$("#five").hide();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#PlaceOfserviceInner").show();$("#posCode1").show();
    $("#Codep1").show();$("#Codep2").show();$("#Codep3").hide();$("#Codep4").hide();$("#Codep5").hide();$("#Codep6").hide();$("#Codep7").hide();$("#Codep8").hide();
    $("#Codep9").hide();$("#Codep10").hide();$("#Codep11").hide();$("#Codep12").hide();$("#Codep13").hide();
    $("#posCode2").show();$("#posCode3").hide();$("#posCode4").hide();$("#posCode5").hide();$("#posCode6").hide();
    $("#posCode7").hide();$("#posCode8").hide();$("#posCode9").hide();$("#posCode10").hide();$("#posCode11").hide();
    $("#posCode12").hide();$("#posCode13").hide();
    }else if(selected == '3'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").hide();$("#five").hide();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#PlaceOfserviceInner").show();$("#posCode1").show();
    $("#Codep1").show();$("#Codep2").show();$("#Codep3").show();$("#Codep4").hide();$("#Codep5").hide();$("#Codep6").hide();$("#Codep7").hide();$("#Codep8").hide();
    $("#Codep9").hide();$("#Codep10").hide();$("#Codep11").hide();$("#Codep12").hide();$("#Codep13").hide();
    $("#posCode2").show();$("#posCode3").show();$("#posCode4").hide();$("#posCode5").hide();$("#posCode6").hide();
    $("#posCode7").hide();$("#posCode8").hide();$("#posCode9").hide();$("#posCode10").hide();$("#posCode11").hide();
    $("#posCode12").hide();$("#posCode13").hide();
    }else if(selected == '4'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").hide();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#PlaceOfserviceInner").show();$("#posCode1").show();
    $("#Codep1").show();$("#Codep2").show();$("#Codep3").show();$("#Codep4").show();$("#Codep5").hide();$("#Codep6").hide();$("#Codep7").hide();$("#Codep8").hide();
    $("#Codep9").hide();$("#Codep10").hide();$("#Codep11").hide();$("#Codep12").hide();$("#Codep13").hide();
    $("#posCode2").show();$("#posCode3").show();$("#posCode4").show();$("#posCode5").hide();$("#posCode6").hide();
    $("#posCode7").hide();$("#posCode8").hide();$("#posCode9").hide();$("#posCode10").hide();$("#posCode11").hide();
    $("#posCode12").hide();$("#posCode13").hide();
    }else if(selected == '5'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#PlaceOfserviceInner").show();$("#posCode1").show();
    $("#Codep1").show();$("#Codep2").show();$("#Codep3").show();$("#Codep4").show();$("#Codep5").show();$("#Codep6").hide();$("#Codep7").hide();$("#Codep8").hide();
    $("#Codep9").hide();$("#Codep10").hide();$("#Codep11").hide();$("#Codep12").hide();$("#Codep13").hide();
    $("#posCode2").show();$("#posCode3").show();$("#posCode4").show();$("#posCode5").show();$("#posCode6").hide();
    $("#posCode7").hide();$("#posCode8").hide();$("#posCode9").hide();$("#posCode10").hide();$("#posCode11").hide();
    $("#posCode12").hide();$("#posCode13").hide();
    }else if(selected == '6'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#PlaceOfserviceInner").show();$("#posCode1").show();
    $("#Codep1").show();$("#Codep2").show();$("#Codep3").show();$("#Codep4").show();$("#Codep5").show();$("#Codep6").show();$("#Codep7").hide();$("#Codep8").hide();
    $("#Codep9").hide();$("#Codep10").hide();$("#Codep11").hide();$("#Codep12").hide();$("#Codep13").hide();
    $("#posCode2").show();$("#posCode3").show();$("#posCode4").show();$("#posCode5").show();$("#posCode6").show();
    $("#posCode7").hide();$("#posCode8").hide();$("#posCode9").hide();$("#posCode10").hide();$("#posCode11").hide();
    $("#posCode12").hide();$("#posCode13").hide();
    }else if(selected == '7'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#PlaceOfserviceInner").show();$("#posCode1").show();
    $("#Codep1").show();$("#Codep2").show();$("#Codep3").show();$("#Codep4").show();$("#Codep5").show();$("#Codep6").show();$("#Codep7").show();$("#Codep8").hide();
    $("#Codep9").hide();$("#Codep10").hide();$("#Codep11").hide();$("#Codep12").hide();$("#Codep13").hide();
    $("#posCode2").show();$("#posCode3").show();$("#posCode4").show();$("#posCode5").show();$("#posCode6").show();
    $("#posCode7").show();$("#posCode8").hide();$("#posCode9").hide();$("#posCode10").hide();$("#posCode11").hide();
    $("#posCode12").hide();$("#posCode13").hide();
    }else if(selected == '8'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#PlaceOfserviceInner").show();$("#posCode1").show();
    $("#Codep1").show();$("#Codep2").show();$("#Codep3").show();$("#Codep4").show();$("#Codep5").show();$("#Codep6").show();$("#Codep7").show();$("#Codep8").show();
    $("#Codep9").hide();$("#Codep10").hide();$("#Codep11").hide();$("#Codep12").hide();$("#Codep13").hide();
    $("#posCode2").show();$("#posCode3").show();$("#posCode4").show();$("#posCode5").show();$("#posCode6").show();
    $("#posCode7").show();$("#posCode8").show();$("#posCode9").hide();$("#posCode10").hide();$("#posCode11").hide();
    $("#posCode12").hide();$("#posCode13").hide();
    }else if(selected == '9'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").show();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#PlaceOfserviceInner").show();$("#posCode1").show();
    $("#Codep1").show();$("#Codep2").show();$("#Codep3").show();$("#Codep4").show();$("#Codep5").show();$("#Codep6").show();$("#Codep7").show();$("#Codep8").show();
    $("#Codep9").show();$("#Codep10").hide();$("#Codep11").hide();$("#Codep12").hide();$("#Codep13").hide();
    $("#posCode2").show();$("#posCode3").show();$("#posCode4").show();$("#posCode5").show();$("#posCode6").show();
    $("#posCode7").show();$("#posCode8").show();$("#posCode9").show();$("#posCode10").hide();$("#posCode11").hide();
    $("#posCode12").hide();$("#posCode13").hide();
    }else if(selected == '10'){
    	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
    	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").show();$("#ten").show();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
    $("#PlaceOfserviceInner").show();$("#posCode1").show();
    $("#Codep1").show();$("#Codep2").show();$("#Codep3").show();$("#Codep4").show();$("#Codep5").show();$("#Codep6").show();$("#Codep7").show();$("#Codep8").show();
    $("#Codep9").show();$("#Codep10").show();$("#Codep11").hide();$("#Codep12").hide();$("#Codep13").hide();
    $("#posCode2").show();$("#posCode3").show();$("#posCode4").show();$("#posCode5").show();$("#posCode6").show();
    $("#posCode7").show();$("#posCode8").show();$("#posCode9").show();$("#posCode10").show();$("#posCode11").hide();
    $("#posCode12").hide();$("#posCode13").hide();
    }
    });
    
    $('#diganosisCtr').change(function() {
        
        var selected = $(this).val();
        if(selected == '0'){
        $("#counterDiaghide").hide();
        $("#one").hide();$("#two").hide();$("#three").hide();$("#four").hide();$("#five").hide();
    	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
    	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
        
        }
        else if(selected == '1'){
        	$("#one").show();$("#two").hide();$("#three").hide();$("#four").hide();$("#five").hide();
        	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
        	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
       $("#counterDiaghide").show(); $("#counterDiagShow").show();$("#diganosisCode1").show();
        $("#Coded1").show();$("#Coded2").hide();$("#Coded3").hide();$("#Coded4").hide();$("#Coded5").hide();$("#Coded6").hide();$("#Coded7").hide();$("#Coded8").hide();
        $("#Coded9").hide();$("#Coded10").hide();$("#Coded11").hide();$("#Coded12").hide();$("#Coded13").hide();
        $("#diganosisCode2").hide();$("#diganosisCode3").hide();$("#diganosisCode4").hide();$("#diganosisCode5").hide();$("#diganosisCode6").hide();
        $("#diganosisCode7").hide();$("#diganosisCode8").hide();$("#diganosisCode9").hide();$("#diganosisCode10").hide();$("#diganosisCode11").hide();
        $("#diganosisCode12").hide();$("#diganosisCode13").hide();
        }else if(selected == '2'){
        	$("#one").show();$("#two").show();$("#three").hide();$("#four").hide();$("#five").hide();
        	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
        	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
        $("#counterDiaghide").show();$("#counterDiagShow").show();$("#diganosisCode1").show();
        $("#Coded1").show();$("#Coded2").show();$("#Coded3").hide();$("#Coded4").hide();$("#Coded5").hide();$("#Coded6").hide();$("#Coded7").hide();$("#Coded8").hide();
        $("#Coded9").hide();$("#Coded10").hide();$("#Coded11").hide();$("#Coded12").hide();$("#Coded13").hide();
        $("#diganosisCode2").show();$("#diganosisCode3").hide();$("#diganosisCode4").hide();$("#diganosisCode5").hide();$("#diganosisCode6").hide();
        $("#diganosisCode7").hide();$("#diganosisCode8").hide();$("#diganosisCode9").hide();$("#diganosisCode10").hide();$("#diganosisCode11").hide();
        $("#diganosisCode12").hide();$("#diganosisCode13").hide();
        }else if(selected == '3'){
        	$("#one").show();$("#two").show();$("#three").show();$("#four").hide();$("#five").hide();
        	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
        	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
        $("#counterDiaghide").show();$("#counterDiagShow").show();$("#diganosisCode1").show();
        $("#Coded1").show();$("#Coded2").show();$("#Coded3").show();$("#Coded4").hide();$("#Coded5").hide();$("#Coded6").hide();$("#Coded7").hide();$("#Coded8").hide();
        $("#Coded9").hide();$("#Coded10").hide();$("#Coded11").hide();$("#Coded12").hide();$("#Coded13").hide();
        $("#diganosisCode2").show();$("#diganosisCode3").show();$("#diganosisCode4").hide();$("#diganosisCode5").hide();$("#diganosisCode6").hide();
        $("#diganosisCode7").hide();$("#diganosisCode8").hide();$("#diganosisCode9").hide();$("#diganosisCode10").hide();$("#diganosisCode11").hide();
        $("#diganosisCode12").hide();$("#diganosisCode13").hide();
        }else if(selected == '4'){
        	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").hide();
        	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
        	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
        $("#counterDiaghide").show();$("#counterDiagShow").show();$("#diganosisCode1").show();
        $("#counterDiaghide").show();$("#counterDiagShow").show();$("#diganosisCode1").show();
        $("#Coded1").show();$("#Coded2").show();$("#Coded3").show();$("#Coded4").show();$("#Coded5").hide();$("#Coded6").hide();$("#Coded7").hide();$("#Coded8").hide();
        $("#Coded9").hide();$("#Coded10").hide();$("#Coded11").hide();$("#Coded12").hide();$("#Coded13").hide();
        $("#diganosisCode2").show();$("#diganosisCode3").show();$("#diganosisCode4").show();$("#diganosisCode5").hide();$("#diganosisCode6").hide();
        $("#diganosisCode7").hide();$("#diganosisCode8").hide();$("#diganosisCode9").hide();$("#diganosisCode10").hide();$("#diganosisCode11").hide();
        $("#diganosisCode12").hide();$("#diganosisCode13").hide();
        }else if(selected == '5'){
        	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
        	$("#six").hide();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
        	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
        $("#counterDiaghide").show();$("#counterDiagShow").show();$("#diganosisCode1").show();
        $("#Coded1").show();$("#Coded2").show();$("#Coded3").show();$("#Coded4").show();$("#Coded5").show();$("#Coded6").hide();$("#Coded7").hide();$("#Coded8").hide();
        $("#Coded9").hide();$("#Coded10").hide();$("#Coded11").hide();$("#Coded12").hide();$("#Coded13").hide();
        $("#diganosisCode2").show();$("#diganosisCode3").show();$("#diganosisCode4").show();$("#diganosisCode5").show();$("#diganosisCode6").hide();
        $("#diganosisCode7").hide();$("#diganosisCode8").hide();$("#diganosisCode9").hide();$("#diganosisCode10").hide();$("#diganosisCode11").hide();
        $("#diganosisCode12").hide();$("#diganosisCode13").hide();
        }else if(selected == '6'){
        	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
        	$("#six").show();$("#seven").hide();$("#eight").hide();$("#nine").hide();$("#ten").hide();
        	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
        $("#counterDiaghide").show();$("#counterDiagShow").show();$("#diganosisCode1").show();
        $("#Coded1").show();$("#Coded2").show();$("#Coded3").show();$("#Coded4").show();$("#Coded5").show();$("#Coded6").show();$("#Coded7").hide();$("#Coded8").hide();
        $("#Coded9").hide();$("#Coded10").hide();$("#Coded11").hide();$("#Coded12").hide();$("#Coded13").hide();
        $("#diganosisCode2").show();$("#diganosisCode3").show();$("#diganosisCode4").show();$("#diganosisCode5").show();$("#diganosisCode6").show();
        $("#diganosisCode7").hide();$("#diganosisCode8").hide();$("#diganosisCode9").hide();$("#diganosisCode10").hide();$("#diganosisCode11").hide();
        $("#diganosisCode12").hide();$("#diganosisCode13").hide();
        }else if(selected == '7'){
        	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
        	$("#six").show();$("#seven").show();$("#eight").hide();$("#nine").hide();$("#ten").hide();
        	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
        $("#counterDiaghide").show();$("#counterDiagShow").show();$("#diganosisCode1").show();
        $("#Coded1").show();$("#Coded2").show();$("#Coded3").show();$("#Coded4").show();$("#Coded5").show();$("#Coded6").show();$("#Coded7").show();$("#Coded8").hide();
        $("#Coded9").hide();$("#Coded10").hide();$("#Coded11").hide();$("#Coded12").hide();$("#Coded13").hide();
        $("#diganosisCode2").show();$("#diganosisCode3").show();$("#diganosisCode4").show();$("#diganosisCode5").show();$("#diganosisCode6").show();
        $("#diganosisCode7").show();$("#diganosisCode8").hide();$("#diganosisCode9").hide();$("#diganosisCode10").hide();$("#diganosisCode11").hide();
        $("#diganosisCode12").hide();$("#diganosisCode13").hide();
        }else if(selected == '8'){
        	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
        	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").hide();$("#ten").hide();
        	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
        $("#counterDiaghide").show();$("#counterDiagShow").show();$("#diganosisCode1").show();
        $("#Coded1").show();$("#Coded2").show();$("#Coded3").show();$("#Coded4").show();$("#Coded5").show();$("#Coded6").show();$("#Coded7").show();$("#Coded8").show();
        $("#Coded9").hide();$("#Coded10").hide();$("#Coded11").hide();$("#Coded12").hide();$("#Coded13").hide();
        $("#diganosisCode2").show();$("#diganosisCode3").show();$("#diganosisCode4").show();$("#diganosisCode5").show();$("#diganosisCode6").show();
        $("#diganosisCode7").show();$("#diganosisCode8").show();$("#diganosisCode9").hide();$("#diganosisCode10").hide();$("#diganosisCode11").hide();
        $("#diganosisCode12").hide();$("#diganosisCode13").hide();
        }else if(selected == '9'){
        	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
        	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").show();$("#ten").hide();
        	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
        $("#counterDiaghide").show();$("#counterDiagShow").show();$("#diganosisCode1").show();
        $("#Coded1").show();$("#Coded2").show();$("#Coded3").show();$("#Coded4").show();$("#Coded5").show();$("#Coded6").show();$("#Coded7").show();$("#Coded8").show();
        $("#Coded9").show();$("#Coded10").hide();$("#Coded11").hide();$("#Coded12").hide();$("#Coded13").hide();
        $("#diganosisCode2").show();$("#diganosisCode3").show();$("#diganosisCode4").show();$("#diganosisCode5").show();$("#diganosisCode6").show();
        $("#diganosisCode7").show();$("#diganosisCode8").show();$("#diganosisCode9").show();$("#diganosisCode10").hide();$("#diganosisCode11").hide();
        $("#diganosisCode12").hide();$("#diganosisCode13").hide();
        }else if(selected == '10'){
        	$("#one").show();$("#two").show();$("#three").show();$("#four").show();$("#five").show();
        	$("#six").show();$("#seven").show();$("#eight").show();$("#nine").show();$("#ten").show();
        	$("#eleven").hide();$("#twelve").hide();$("#thirteen").hide();
        $("#counterDiaghide").show();$("#counterDiagShow").show();$("#diganosisCode1").show();
        $("#Coded1").show();$("#Coded2").show();$("#Coded3").show();$("#Coded4").show();$("#Coded5").show();$("#Coded6").show();$("#Coded7").show();$("#Coded8").show();
        $("#Coded9").show();$("#Coded10").show();$("#Coded11").hide();$("#Coded12").hide();$("#Coded13").hide();
        $("#diganosisCode2").show();$("#diganosisCode3").show();$("#diganosisCode4").show();$("#diganosisCode5").show();$("#diganosisCode6").show();
        $("#diganosisCode7").show();$("#diganosisCode8").show();$("#diganosisCode9").show();$("#diganosisCode10").show();$("#diganosisCode11").hide();
        $("#diganosisCode12").hide();$("#diganosisCode13").hide();
        }
        });
});
