/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.SpntprvVO;


/**
 * @author N731694
 * Cognizant_Offshore
 */
public class SpntprvAdapter extends StoredProcedure{

	private final Log log = LogFactory.getLog(SpntprvAdapter.class);
	private static final String CNVRSTN_CD = "CNVRSTN_CD";
	private static final String VAN_ID_CD = "VAN_ID_CD";
	private static final String IN_TY_CD = "IN_TY_CD";
	
	private static final String OUT_CODE = "OUT_CODE";
	private static final String READ_CURSOR = "READ_CURSOR3";
	
	
	public SpntprvAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(CNVRSTN_CD, Types.CHAR));   
		declareParameter(new SqlParameter(VAN_ID_CD, Types.CHAR));
		declareParameter(new SqlParameter(IN_TY_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException 
					{
						SpntprvVO spntprvVO=new SpntprvVO();
						spntprvVO.setSeqNo(rs.getString("SPNTPRV_SEQUENC_NO"));
						spntprvVO.setRespInd(rs.getString("SPNTPRV_RESPNS_IND"));
						spntprvVO.setEntityIdCd(rs.getString("SPNTPRV_ENTTYID_CD"));
						spntprvVO.setEntityIdCdQual(rs.getString("SPNTPRV_ENTTYIQ_CD"));
						spntprvVO.setLastName(rs.getString("SPNTPRV_LAST_NM"));
						spntprvVO.setFirstName(rs.getString("SPNTPRV_FIRST_NM"));
						spntprvVO.setMiddleName(rs.getString("SPNTPRV_MIDDLE_NM"));
						spntprvVO.setIdCodeQual(rs.getString("SPNTPRV_IDNTFCQ_CD"));
						spntprvVO.setIdCode(rs.getString("SPNTPRV_IDNTFCT_CD"));
						spntprvVO.setAddressLine1(rs.getString("SPNTPRV_ADDRL1_TXT"));
						spntprvVO.setAddressLine2(rs.getString("SPNTPRV_ADDRL2_TXT"));
						spntprvVO.setCity(rs.getString("SPNTPRV_CITY_NM"));
						spntprvVO.setState(rs.getString("SPNTPRV_STATE_CD"));
						spntprvVO.setZipCode(rs.getString("SPNTPRV_ZIP_CD"));
						spntprvVO.setPhoneNo(rs.getString("SPNTPRV_TELEPHN_NO"));
						
						spntprvVO.setContactNo(rs.getString("SPNTPRV_CONTACT_NM"));
						spntprvVO.setEffDate(rs.getString("SPNTPRV_EFFCTV_DT"));
						spntprvVO.setExpDate(rs.getString("SPNTPRV_EXPRTN_DT"));
						spntprvVO.setVanIdCd(rs.getString("SUBMSN_VAN_ID_CD"));
						spntprvVO.setTypeCd(rs.getString("SUBMSN_TY_CD"));
						spntprvVO.setConvIdCode(rs.getString("SUBMSN_CNVRSTN_CD"));
						spntprvVO.setPorgNo(rs.getString("PRVORG_NO"));
						spntprvVO.setPorgDetailName(rs.getString("PRVORD_NM"));
						spntprvVO.setPorgEffDate(rs.getString("PRVORD_EFF_DT"));
						spntprvVO.setPorgAddLine1(rs.getString("ADDRD_STRA1LN_TXT"));
						spntprvVO.setPorgAddLine2(rs.getString("ADDRD_STRA2LN_TXT"));
						spntprvVO.setPorgCity(rs.getString("ADDRD_STRACITY_NM"));
						spntprvVO.setPorgState(rs.getString("ADDRD_STRASTSH_ABR"));
						spntprvVO.setPorgZipCode(rs.getString("SPNTPRV_PRORGZP_CD"));
						spntprvVO.setCapOfficeId(rs.getString("PCAPEXT_CAP_OFF_CD"));
						
						spntprvVO.setCapOfficeName(rs.getString("MFXWEXT_PRVNM_TXT"));
						spntprvVO.setCapOffLineText(rs.getString("MFADEXT_1LN_TXT"));
						spntprvVO.setCapOffCity(rs.getString("MFADEXT_CITY_NM"));
						spntprvVO.setCapOffState(rs.getString("MFADEXT_STSH_ABR"));
						spntprvVO.setCapOffZipcode(rs.getString("MFADEXT_ZIP_CD"));
						
						
					
						return spntprvVO;
			}

		}));

	}
	
	
	
	@SuppressWarnings("unchecked")
	public Map getSpntprvEvntTracking (String convIdCode, String vanIdCd,String typeCd,String postedDt) throws ApplicationException {
		log.debug("Entered SpntprvAdapter  - getSpntprvEvntTracking");
	
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map spntprvMap = new HashMap();
		params.put(CNVRSTN_CD, RteIntranetUtils.getTrimmedString(convIdCode));
		params.put(VAN_ID_CD, RteIntranetUtils.getTrimmedString(vanIdCd));
		params.put(IN_TY_CD, RteIntranetUtils.getTrimmedString(typeCd));
		
	
		
		log.debug(params);
		Map results = null;
		
		List<SpntprvVO> spntprvList= new LinkedList<SpntprvVO>();
		String newMessage="";
		int noOfElements;
		try {
			results = execute(params);
			log.debug("SpntprvAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(OUT_CODE));
			spntprvList = (List<SpntprvVO>) results
					.get(READ_CURSOR);	
	
			noOfElements = spntprvList.size();
			//if (null != results) {
			if (spntprvList.isEmpty()){
				
				if ("0".equals(sqlCode))
					newMessage = "No Data for Conversation ID: " + convIdCode + 
								" Van Id: " +  vanIdCd + 
								" Tran Type: " + typeCd;
					
				else
					newMessage = "Problem in DB2. sqlcode: " + sqlCode + "  Conversation ID: " + convIdCode + 
								" Van Id: " +  vanIdCd + 
								" Tran Type: " + typeCd ; 
								
			} else {
				if (noOfElements > 1) {
					newMessage = "Data found for Conversation ID: " + convIdCode +
							" Van Id: " +  vanIdCd + 
							" Tran Type: " + typeCd;;
				} else {
					newMessage = "Data found for Conversation ID: " + convIdCode +
							" Van Id: " +  vanIdCd + 
							" Tran Type: " + typeCd;;
				}
				
			}
			spntprvMap.put("newMessage", newMessage);
			spntprvMap.put("spntprvList",spntprvList);
			return spntprvMap;
		}catch (Exception exception){
			log.error("spntprvAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}

}
