/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;
import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.RtedictrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;


/**
 * @author N657186
 * Cognizant_Offshore
 */
public interface RtedictrDAO {

	Map getRtedictrLookUp(RtedictrDTO rtedictrDTO) throws ApplicationException;
	
	Map addNewRtedictr(RtedictrDTO rtedictrDTO) throws ApplicationException ;

	Map deleteRtedictr(RtedictrDTO rtedictrDTO) throws ApplicationException ;

	Map addUpdateRtedictr(RtedictrDTO existRtedictrDTO, List<RtedictrDTO> rtedictrDtoList, int index) throws ApplicationException ;

}


	
