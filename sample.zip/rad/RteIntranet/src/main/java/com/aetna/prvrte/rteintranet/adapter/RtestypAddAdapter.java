/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.RtestypDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RtestypAddAdapter extends StoredProcedure{

	private static final String UPDATE = "U";
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RtestypAddAdapter.class);
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtestypAddAdapter(DataSource datasource, String storedProc) throws SQLException{
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.IN_SVCTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_CATEGORY_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_DESCRIPTION, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_EFF_DATE, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.IN_EXP_DATE, Types.DATE));
		
		declareParameter(new SqlParameter(DBConstants.IN_POSTED_DATE, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.IN_PCPELG_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTESTYP_BENTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.RTESTYP_SRC_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.RTESTYP_ASH_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.GENDER_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.RTESTYP_PLNSVCT_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.OUT_ADD_UPDATE, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));
		
	}
	
	
	/**
	 * 
	 * @param rtestypDTO	
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	public Map addNewRtestyp(RtestypDTO rtestypDTO) throws ApplicationException {
		
		log.warn("Entered RtestypAddAdapter  - addNewRtestyp");
		
		String newMessage ="";
		Map results = null;
		Map<String, Object> params = new LinkedHashMap<String, Object>();
		Map rtestypMap = new HashMap();
		
		params = setInputParameters(rtestypDTO, params);
		log.warn(params);	
		
		try {					
			results = execute(params);
			log.warn("RtestypAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.OUT_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_CODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) {
				
				List<RtestypDTO> rtestypList = new LinkedList<RtestypDTO>();
				rtestypList.add(rtestypDTO);
				rtestypMap.put("rtestypList", rtestypList);
				if (ApplicationConstants.ADD.equalsIgnoreCase(actionCode)) {
					newMessage = "This row added to the database";
				}else {
					newMessage ="Row already exists on the database. It was updated with entered values.";					
					rtestypDTO.setUpdatedInd(ApplicationConstants.COPY);
				}				
				}
			else {
				newMessage = "Unable to add row to the database. SQLCODE = " + sqlCode;
			}
			
			rtestypMap.put("rtestypMessage", newMessage);
							
		return rtestypMap;
	}catch (Exception exception){
		log.error("RtestypAddAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}
	
	
	@SuppressWarnings("unchecked")
	public Map addUpdateRtestyp(RtestypDTO existingRtestyp,
			List<RtestypDTO> rtestypDtoList, int index, char currUpdateInd) throws ApplicationException{
		log.warn("Entered RtestypAddAdapter  - addUpdateRtestyp");
		boolean isRtestypAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, Object> params = new LinkedHashMap<String, Object>();
		Map rtestypMap = new HashMap();
		params = setInputParameters(existingRtestyp, params);
		log.warn(params);	
		
		try {					
			results = execute(params);
			log.warn("RtestypAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.OUT_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_CODE));
			if ("0".equalsIgnoreCase(sqlCode)) {
				isRtestypAddorUpdated = true;
				if (UPDATE.equalsIgnoreCase(actionCode)) {
					
					if (currUpdateInd == ApplicationConstants.COPY)						
						rtestypDtoList.set(index, existingRtestyp);						
					else
						rtestypDtoList.add(existingRtestyp);
				}
				else
					rtestypDtoList.set(index, existingRtestyp);
				
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			rtestypMap.put("rtestypMessage",newMessage);
			rtestypMap.put("rtestypDtoList",rtestypDtoList);
			rtestypMap.put("isrtestypAddorUpdated", isRtestypAddorUpdated);
			return rtestypMap;
		}catch (Exception exception){
			log.error("RtestypAddAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
	
	
	/**
	 * @param rbrcDTO
	 * @param params
	 * @return
	 */
	public Map<String, Object> setInputParameters(RtestypDTO rtestypDTO, Map<String, Object> params){
			String effDate = RteIntranetUtils.getTrimmedString(rtestypDTO.getEffDate());
			String expDate =  RteIntranetUtils.getTrimmedString(rtestypDTO.getExpDate());
		params.put(DBConstants.IN_SVCTYP_CD, RteIntranetUtils.getTrimmedString(rtestypDTO.getSvcTypeCd()));
		params.put(DBConstants.IN_CATEGORY_CD, RteIntranetUtils.getTrimmedString(rtestypDTO.getCatCd()));
		params.put(DBConstants.IN_DESCRIPTION, RteIntranetUtils.getTrimmedString(rtestypDTO.getDescription()));
		params.put(DBConstants.IN_EFF_DATE, (!"".equals(effDate)?
				Date.valueOf(effDate):effDate));
		params.put(DBConstants.IN_EXP_DATE, (!"".equals(expDate)?
				Date.valueOf(expDate):expDate));
		params.put(DBConstants.IN_POSTED_DATE, Date.valueOf(RteIntranetUtils.getTrimmedString(rtestypDTO.getPostedDate())));
		params.put(DBConstants.IN_PCPELG_IND, RteIntranetUtils.getTrimmedString(rtestypDTO.getPcpEligInd()));
		params.put(DBConstants.IN_RTESTYP_BENTYP_CD, RteIntranetUtils.getTrimmedString(rtestypDTO.getBenTypeCd()));
		params.put(DBConstants.RTESTYP_SRC_IND, RteIntranetUtils.getTrimmedString(rtestypDTO.getSrcInd()));
		params.put(DBConstants.RTESTYP_ASH_IND, RteIntranetUtils.getTrimmedString(rtestypDTO.getAshInd()));
		params.put(DBConstants.GENDER_CD, RteIntranetUtils.getTrimmedString(rtestypDTO.getGenderCd()));
		params.put(DBConstants.RTESTYP_PLNSVCT_CD, RteIntranetUtils.getTrimmedString(rtestypDTO.getPlnsvctCd()));
		
		return params;
	}
}
