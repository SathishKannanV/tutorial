/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.vo;

public class RterbacVO {
	private String accuCd = ""; 
	private String benCd = "";
	private String resInd = ""; 
	private String effDt = ""; 
	private String expDt = ""; 
	private String postedDateTimeStamp = "";
	private String userId = "";
	private String messageId=""; 
	private String messageTypeCd = ""; 
	private String shortText = ""; 
	private String fullText = "";
	private char updatedInd;
	
	/**
	 * @param accuCd
	 * @param benCd
	 * @param resInd
	 * @param effDt
	 * @param expDt
	 * @param postedDateTimeStamp
	 * @param userId
	 * @param messageId
	 * @param messageTypeCd
	 * @param shortText
	 * @param fullText
	 * @param updatedInd
	 */
	public RterbacVO(String accuCd, String benCd, String resInd, String effDt,
			String expDt, String postedDateTimeStamp, String userId,
			String messageId, String messageTypeCd, String shortText,
			String fullText, char updatedInd) {
		this.accuCd = accuCd;
		this.benCd = benCd;
		this.resInd = resInd;
		this.effDt = effDt;
		this.expDt = expDt;
		this.postedDateTimeStamp = postedDateTimeStamp;
		this.userId = userId;
		this.messageId = messageId;
		this.messageTypeCd = messageTypeCd;
		this.shortText = shortText;
		this.fullText = fullText;
		this.updatedInd = updatedInd;
	}
	/**
	 * 
	 */
	public RterbacVO() {
		super();
		
	}
	/**
	 * @return the accuCd
	 */
	public String getAccuCd() {
		return accuCd;
	}
	/**
	 * @param accuCd the accuCd to set
	 */
	public void setAccuCd(String accuCd) {
		this.accuCd = accuCd;
	}
	/**
	 * @return the benCd
	 */
	public String getBenCd() {
		return benCd;
	}
	/**
	 * @param benCd the benCd to set
	 */
	public void setBenCd(String benCd) {
		this.benCd = benCd;
	}
	/**
	 * @return the resInd
	 */
	public String getResInd() {
		return resInd;
	}
	/**
	 * @param resInd the resInd to set
	 */
	public void setResInd(String resInd) {
		this.resInd = resInd;
	}
	/**
	 * @return the effDt
	 */
	public String getEffDt() {
		return effDt;
	}
	/**
	 * @param effDt the effDt to set
	 */
	public void setEffDt(String effDt) {
		this.effDt = effDt;
	}
	/**
	 * @return the expDt
	 */
	public String getExpDt() {
		return expDt;
	}
	/**
	 * @param expDt the expDt to set
	 */
	public void setExpDt(String expDt) {
		this.expDt = expDt;
	}
	/**
	 * @return the postedDateTimeStamp
	 */
	public String getPostedDateTimeStamp() {
		return postedDateTimeStamp;
	}
	/**
	 * @param postedDateTimeStamp the postedDateTimeStamp to set
	 */
	public void setPostedDateTimeStamp(String postedDateTimeStamp) {
		this.postedDateTimeStamp = postedDateTimeStamp;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the messageTypeCd
	 */
	public String getMessageTypeCd() {
		return messageTypeCd;
	}
	/**
	 * @param messageTypeCd the messageTypeCd to set
	 */
	public void setMessageTypeCd(String messageTypeCd) {
		this.messageTypeCd = messageTypeCd;
	}
	/**
	 * @return the shortText
	 */
	public String getShortText() {
		return shortText;
	}
	/**
	 * @param shortText the shortText to set
	 */
	public void setShortText(String shortText) {
		this.shortText = shortText;
	}
	/**
	 * @return the fullText
	 */
	public String getFullText() {
		return fullText;
	}
	/**
	 * @param fullText the fullText to set
	 */
	public void setFullText(String fullText) {
		this.fullText = fullText;
	}
	/**
	 * @return the messageId
	 */
	public String getMessageId() {
		return messageId;
	}
	/**
	 * @param messageId the messageId to set
	 */
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	/**
	 * @return the updatedInd
	 */
	public char getUpdatedInd() {
		return updatedInd;
	}
	/**
	 * @param updatedInd the updatedInd to set
	 */
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}


	
	
}
