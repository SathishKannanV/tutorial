package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.StstypaDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


/**
 * @author N624926
 * Cognizant_Offshore
 */
public class StstypaAddAdapter extends StoredProcedure{
	
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(StstypaAddAdapter.class);
	
	/**
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public StstypaAddAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_STSTYPA_ID, Types.SMALLINT));
		declareParameter(new SqlParameter(DBConstants.LS_STSTYPA_ST_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_STSTYPA_COLL_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_STSTYPA_INDV_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_STSTYPA_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.LS_STSTYPA_EXP_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.LS_STSTYPA_POSTED_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.LS_STSTYPA_VERSNRLS_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.LS_OUT_SSTYPA_ID, Types.SMALLINT));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
	}
	
	/**
	 * Method to add new STSTYPA to data store.
	 * 
	 * @param ststypaDTO
	 *            ststypaDTO object.
	 * @return Map of added STSTYPA data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addNewStstypa(StstypaDTO ststypaDTO) throws ApplicationException {
		
		log.warn("Entered StstypaAddAdapter  - addNewStstypa");
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map ststypaMap = new HashMap();
		Date todaysDate = new Date(System.currentTimeMillis());
		String postedDate = todaysDate.toString();
		ststypaDTO.setPostedDate(postedDate);
		ststypaDTO.setId(ApplicationConstants.ZERO_0);
		ststypaDTO.setUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
		params.put(DBConstants.LS_STSTYPA_ID, RteIntranetUtils.getTrimmedString(ststypaDTO.getId()));
		params.put(DBConstants.LS_STSTYPA_ST_CD, RteIntranetUtils.getTrimmedString(ststypaDTO.getStateCd()));
		params.put(DBConstants.LS_STSTYPA_COLL_CD, RteIntranetUtils.getTrimmedString(ststypaDTO.getCollectionCode()));
		params.put(DBConstants.LS_STSTYPA_INDV_CD, RteIntranetUtils.getTrimmedString(ststypaDTO.getIndividualCode()));
		params.put(DBConstants.LS_STSTYPA_EFF_DT, RteIntranetUtils.getTrimmedString(ststypaDTO.getEffDate()));
		params.put(DBConstants.LS_STSTYPA_EXP_DT, RteIntranetUtils.getTrimmedString(ststypaDTO.getExpDate()));
		params.put(DBConstants.LS_STSTYPA_POSTED_DT, RteIntranetUtils.getTrimmedString(ststypaDTO.getPostedDate()));
		params.put(DBConstants.LS_STSTYPA_VERSNRLS_CD, RteIntranetUtils.getTrimmedString(ststypaDTO.getVersionReleaseCode()));
		log.warn(params);	
		
		try {
			results = execute(params);
			log.warn("StstypaAddAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results .get(DBConstants.LS_SQLCODE));
			String actionCode =  String.valueOf(results .get(DBConstants.LS_OUT_SSTYPA_ID));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				ststypaDTO.setId(actionCode);
				List<StstypaDTO> ststypaList = new LinkedList<StstypaDTO>();
				ststypaList.add(ststypaDTO);
				ststypaMap.put("ststypaList", ststypaList);
				newMessage = "This row added to the database";
				}
			else {
				newMessage = "Unable to add row to the database. SQLCODE = " + sqlCode;
			}
			
			ststypaMap.put("ststypaMessage", newMessage);
		return ststypaMap;
	}catch (Exception exception){
		log.error("StstypaAddAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}

	/**
	 * Method to add/update list of STSTYPA to data store.
	 * 
	 * @param existingStstypa
	 *            
	 * @param ststypaDtoList
	 *            list of StstypaDTO object.
	 * @param index
	 *            index to update the data
	 * @param updateInd
	 * 			  update indicator to update the data
	 * @return Map of flag to delete the data from STSTYPA list, success or
	 *         error message and list of STSTYPA.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addUpdateStstypa(StstypaDTO existingStstypa,
			List<StstypaDTO> ststypaDtoList, int index,char updateInd) throws ApplicationException{
		log.warn("Entered StstypaAddAdapter  - addUpdateStstypa");
		boolean isStstypaAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map ststypaMap = new HashMap();
		Date todaysDate = new Date(System.currentTimeMillis());
		String postedDate = todaysDate.toString();
		existingStstypa.setPostedDate(postedDate);
		params.put(DBConstants.LS_STSTYPA_ID, RteIntranetUtils.getTrimmedString(existingStstypa.getId()));
		params.put(DBConstants.LS_STSTYPA_ST_CD, RteIntranetUtils.getTrimmedString(existingStstypa.getStateCd()));
		params.put(DBConstants.LS_STSTYPA_COLL_CD, RteIntranetUtils.getTrimmedString(existingStstypa.getCollectionCode()));
		params.put(DBConstants.LS_STSTYPA_INDV_CD, RteIntranetUtils.getTrimmedString(existingStstypa.getIndividualCode()));
		params.put(DBConstants.LS_STSTYPA_EFF_DT, RteIntranetUtils.getTrimmedString(existingStstypa.getEffDate()));
		params.put(DBConstants.LS_STSTYPA_EXP_DT, RteIntranetUtils.getTrimmedString(existingStstypa.getExpDate()));
		params.put(DBConstants.LS_STSTYPA_POSTED_DT, RteIntranetUtils.getTrimmedString(existingStstypa.getPostedDate()));
		params.put(DBConstants.LS_STSTYPA_VERSNRLS_CD, RteIntranetUtils.getTrimmedString(existingStstypa.getVersionReleaseCode()));
		log.warn(params);	
		
		try {
			results = execute(params);
			log.warn("StstypaAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.LS_OUT_SSTYPA_ID));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
							isStstypaAddorUpdated = true;
							existingStstypa.setId(actionCode);
							ststypaDtoList.set(index, existingStstypa);	
				
				newMessage = "All rows that changed the database are highlighted.";
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			ststypaMap.put("ststypaMsg",newMessage);
			ststypaMap.put("ststypaDtoList",ststypaDtoList);
			ststypaMap.put("isStstypaAddorUpdated", isStstypaAddorUpdated);
			return ststypaMap;
		}catch (Exception exception){
			log.error("StstypaAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}


}