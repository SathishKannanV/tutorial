package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RterbacDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RterbacLookUpAdapter extends StoredProcedure{
	private final Log log = LogFactory.getLog(RterbacLookUpAdapter.class);
	
	public RterbacLookUpAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.RTERBAC_ACCUM_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.RTERBAC_BNFT_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR1, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = '0'; //Used by RTERBACDisplay, not on database
				RterbacDTO rterbacDTO = new RterbacDTO();
				rterbacDTO.setAccuCd(RteIntranetUtils.getTrimmedString(rs.getString("RTERBAC_ACCUM_CD")));
				rterbacDTO.setBenCd(RteIntranetUtils.getTrimmedString(rs.getString("RTERBAC_BNFT_CD")));
				rterbacDTO.setEffDt(RteIntranetUtils.getTrimmedString(rs.getString("RTERBAC_EFF_DT")));
				rterbacDTO.setExpDt(RteIntranetUtils.getTrimmedString(rs.getString("RTERBAC_EXP_DT")));
				rterbacDTO.setFullText(RteIntranetUtils.getTrimmedString(rs.getString("ERSPMSG_LONG_TXT")));
				rterbacDTO.setMessageId(RteIntranetUtils.getTrimmedString(rs.getString("ERSPMSG_ID")));
				rterbacDTO.setMessageTypeCd(RteIntranetUtils.getTrimmedString(rs.getString("ERSPMSG_MSGTYP_CD")));
				rterbacDTO.setPostedDateTimeStamp(RteIntranetUtils.getTrimmedString(rs.getString("RTERBAC_POSTED_DTS")));
				rterbacDTO.setResInd(RteIntranetUtils.getTrimmedString(rs.getString("RTERBAC_RSTRCT_IND")));
				rterbacDTO.setShortText(RteIntranetUtils.getTrimmedString(rs.getString("ERSPMSG_SHORT_TXT")));
				rterbacDTO.setUpdatedInd(updatedInd);
				rterbacDTO.setUserId(RteIntranetUtils.getTrimmedString(rs.getString("APPL_USER_ID")));
				return rterbacDTO;
			}

		}));

	}
	
	@SuppressWarnings("unchecked")
	public Map getRterbacLookUpTable (RterbacDTO rterbacDTO) throws ApplicationException {
		log.warn("Entered RterbacLookUpAdapter  - getRterbacLookUp");
		//It fetches rterbac list based on the criteria selected by user
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map rterbacMap = new HashMap();
		
		Map results = null;		
		List<RterbacDTO> rterbacList = new LinkedList<RterbacDTO>();
		String newMessage="";
		String queryAccuCd = RteIntranetUtils.getTrimmedString(rterbacDTO.getAccuCd());
		String queryBenCd = RteIntranetUtils.getTrimmedString(rterbacDTO.getBenCd());
		params.put(DBConstants.RTERBAC_ACCUM_CD, queryAccuCd);
		params.put(DBConstants.RTERBAC_BNFT_CD, queryBenCd);
		log.warn(params);		
		
		try {
			log.warn("RterbacLookUpAdapter: Executing stored procedure : " + "accu code : " + rterbacDTO.getAccuCd() 
					+ " ; benefit code : "+rterbacDTO.getBenCd());
			results = execute(params);
			log.warn("RterbacLookUpAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			rterbacList = (List<RterbacDTO>) results
					.get(DBConstants.READ_CURSOR1);	
			
			//if (null != results) {
			if (rterbacList.isEmpty()){
				
				if ("0".equals(sqlCode)) {
					newMessage = "No Data on database for Accumulator Code: " + queryAccuCd
							+ ", Benefit Code: " + queryBenCd;
					
				} else {
					newMessage = "Problem in DB2. Sqlcode: " + sqlCode +
							" Accumulator Code: " + queryAccuCd
							+ ", Benefit Code: " + queryBenCd;
					
				}			  		  		  
			} else {
				 newMessage = "Data found on database for Accumulator Code: " + queryAccuCd
						+ ", Benefit Code: " + queryBenCd;
			}
			/*}else{
				newMessage = "No Data found on the table.";
			}*/
			rterbacMap.put("rterbacMessage", newMessage);
			rterbacMap.put("rterbacList",rterbacList);
			return rterbacMap;
		}catch (Exception exception){
			log.error("RterbacLookUpAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
		
	}
}
