//To check empty
function isEmpty(strValue){
	if( strValue == "" || strValue.length <= 0 ){
		return true;
	}
	else{
		var charsFound = false;
		for( idx = 0; idx < strValue.length; idx++ ){
			if( strValue.charAt(idx) != ' ' ){
				charsFound = true;
				break;
			}
		}
		if( !charsFound ){
			return true;
		}
	}	
	return false;
}

function isLeapYear(year) {
	// A leap year occurs every 4 years except years ending in 00, unless divisible by 400.
	// 1900 should NOT be a leap year, but 2000 should.
	if ((year % 4 == 0 & !(year % 100 == 0)) || (year % 400 == 0)) {
		return true;
	}
	return false;
}

//To check whether the date is in the correct format
function isDateValid(element, format){
	var invalid = false;
	var errormsg = 'no error';
	var cmpnt = element;
	var str = cmpnt.value;
	if(isEmpty(cmpnt.value)) {
		invalid = true;
		errormsg = 'This field is required. Please enter a value.';
		return errormsg;
	}
	else if(format == 'MM/dd/yyyy'){
		try {		
			if(null == str || "" == str || str.length != 10){
				invalid = true;
				errormsg = 'This field is required. Please enter a value.';
				return errormsg;
			}
			var indxValue = str.substr(2,1);
			// month validation
			if(indxValue == "\/"){
				var mm = str.substr(0,2);
				if(mm.substr(0,1) == '0'){
					mm = parseInt(mm.substr(1,1));			
				}else{
					mm = parseInt(mm);
				}
				if(!(mm > 0 && mm < 13)){
					invalid = true;
				}
				indxValue = str.substr(5,1);
				
				if(indxValue == "\/"){
					var dd = str.substr(3,2);
					if(dd.substr(0,1) == '0'){
						dd = parseInt(dd.substr(1,1));
					}else{
						dd = parseInt(dd);
					}
					
					if(!(mm > 0 && mm < 32)){
						invalid = true;
					}					
					indxValue = str.substr(6);
					var year = parseInt(indxValue);
					if(year.toString().length!=4 || year.toString().length == 0){
						invalid = true;
					}					
					if ((mm == 2) && (isLeapYear(year)) && (dd > 29)) {
						invalid = true;
					}
					if ((mm == 2) && (!isLeapYear(year)) && (dd > 28)) {
						invalid = true;
					}
					/* Validation of other months */
					if ((dd > 31) && ((mm == 1) || (mm == 3) || (mm == 5) || (mm == 7) || (mm == 8) || (mm == 10) || (mm == 12))) {
						invalid = true;
					}
					if ((dd > 30) && ((mm == 4) || (mm == 6) || (mm == 9) || (mm == 11))) {				
						invalid = true;
					}
				}else{
					invalid = true;
				}
			}
			else {
				invalid = true;
			}
		}
		catch(err) {
			invalid = true;
			errormsg = "Please enter a valid date in the format MM/dd/yyyy."
			return errormsg;
		}		
	}
	else {
		invalid = true;		
	}
	
	if(invalid){
		errormsg =  "Please enter a valid date in the format MM/dd/yyyy."
		return errormsg;
	}
	else {
		return errormsg;
	}	
}

//To validate date against the current date
function isDateGtEqCurDate(stDateStr) {
	var currentTime = new Date();
	var month = currentTime.getMonth() + 1;
	var day = currentTime.getDate();
	var year = currentTime.getFullYear();
	var newCurrDate = new Date(month+"/"+day+"/"+year);	
	if((null!=stDateStr || ""!=stDateStr) && stDateStr.length==10){
		stDate = new Date(stDateStr);		
		if(stDate.getTime() < newCurrDate.getTime()) {
			return false;			
		}
		else 
			return true;
	}
}

//To validate date against another date 
function compareDates(effDateStr,expDateStr) {
		var effDate = new Date(effDateStr);
		var expDate = new Date(expDateStr);
		if(effDate.getTime() < expDate.getTime()) {
			return true;			
		}
		else 
			return false;	
}

