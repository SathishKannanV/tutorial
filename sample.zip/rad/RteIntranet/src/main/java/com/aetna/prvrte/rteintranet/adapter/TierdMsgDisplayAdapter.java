package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.TierdMsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


/**
 * @author N624926
 * Cognizant_Offshore
 */
public class TierdMsgDisplayAdapter extends StoredProcedure{

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(TierdMsgDisplayAdapter.class);

	private static final Pattern p = Pattern.compile("\\s");
	
	/**
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public TierdMsgDisplayAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		System.out.println(" TierdMsgDisplayAdapter ------------------> " + storedProc);
		declareParameter(new SqlParameter(DBConstants.TIERDMSG_TYPE_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.TIERDMSG_TIERST_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.SQLCODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR3, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;			//Used by TierdMsgDisplay, not on database
				TierdMsgDTO tierdmsgDTO = new TierdMsgDTO();
				tierdmsgDTO.setTierdMsgtypCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TIERDMSG_TYPE_CD)));
				tierdmsgDTO.setTierdTierstCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TIERDMSG_TIERST_CD)));
				tierdmsgDTO.setEffDt(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TIERDMSG_EFF_DT)));
				tierdmsgDTO.setExpDt(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TIERDMSG_EXPRTN_DT)));
				tierdmsgDTO.setPostedDateTimeStamp(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TIERDMSG_PSTD_DTS)));
				tierdmsgDTO.setUserId(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TIERDMSG_USER_ID)));
				tierdmsgDTO.setMessageId(rs.getInt(DBConstants.ERSPMSG_ID));
				tierdmsgDTO.setMessageTypeCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.ERSPMSG_MSGTYP_CD)));
				tierdmsgDTO.setShortText(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.ERSPMSG_SHORT_TXT)));
				tierdmsgDTO.setFullText(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.ERSPMSG_LONG_TXT)));
				tierdmsgDTO.setUpdatedInd(updatedInd);
				return tierdmsgDTO;
			}

		}));

	}
	
	/**
	 * Method to get the TIERDMSG list from data store.
	 * 
	 * @param tierdmsgDTO
	 * 			tierdmsgDTO parameter
	 * 
	 * @return Map of TIERDMSG list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map getTierdMsgLookUpTable (TierdMsgDTO tierdmsgDTO) throws ApplicationException {
		log.warn("Entered TierdMsgAdapter  - getTierdMsgLookUpTable");
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map tierdmsgMap = new HashMap();
		String queryTierdMsgtypCd = "";
		String queryTierdTierstCd = "";
		try {
			queryTierdMsgtypCd = containsUnprintableCharacters(tierdmsgDTO.getTierdMsgtypCd());
			queryTierdTierstCd = containsUnprintableCharacters(tierdmsgDTO.getTierdTierstCd());
		} catch (Exception e) {
			log.error("TierdMsgAdapter : generic error occured  "+e);
		}
		params.put(DBConstants.TIERDMSG_TYPE_CD, RteIntranetUtils.getTrimmedString(queryTierdMsgtypCd));
		params.put(DBConstants.TIERDMSG_TIERST_CD, RteIntranetUtils.getTrimmedString(queryTierdTierstCd));
		log.warn(params);
		Map results = null;
		List<TierdMsgDTO> tierdmsgList= new LinkedList<TierdMsgDTO>();
		String newMessage="";
		try {
			results = execute(params);
			log.warn("TierdMsgAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.SQLCODE));
			
			tierdmsgList = (List<TierdMsgDTO>) results
					.get(DBConstants.READ_CURSOR3);	
	
			if (tierdmsgList.isEmpty()){
					if (ApplicationConstants.ZERO_0.equals(sqlCode)) {
						newMessage = "No Data on database for TierMsgType Code: "
								+ queryTierdMsgtypCd + ", TierMsgTierst Code: "
								+ queryTierdTierstCd; 

					} else {
						newMessage = "Problem in DB2. Sqlcode: " + sqlCode
								+ " TierMsgType Code: " + queryTierdMsgtypCd
								+ ", TierMsgTierst Code: " + queryTierdTierstCd;
					}			  		  		  
				} else {
					newMessage = "Data found on database for TierMsgType Code: "
							+ queryTierdMsgtypCd
							+ ", TierMsgTierst Code: "
							+ queryTierdTierstCd;
				}
			tierdmsgMap.put("newMessage", newMessage);
			tierdmsgMap.put("tierdmsgList",tierdmsgList);
			return tierdmsgMap;
		}catch (Exception exception){
			log.error("TierdMsgAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
		
		/**
		 * This method is used replace the expression (\s) with whit space.
		 * 
		 * @param input
		 * @return
		 */
		private String replaceLinearWhiteSpace(String input) {
			return p.matcher(input).replaceAll(" ");
		}

		/**
		 * This method is used identify the unprintable characters in input string.
		 * 
		 * @param input
		 * @return
		 * @throws Exception
		 */
		private String containsUnprintableCharacters(String input) throws Exception {

			String s = input;
			int id = -1;
			char ch = 0;
			if (null != input) {
				s = replaceLinearWhiteSpace(input);

				for (int i = 0; i < s.length(); ++i) {
					ch = s.charAt(i);
					if ((ch < ' ') || (ch > '~')) {
						id = ch;
						break;
					}
				}
			}
			if (id != -1)
				throw new Exception(
						"Invalid parameter - Input parameter contains unprintable character.");
			else
				return s;
		}

}
