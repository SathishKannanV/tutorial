/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.SbmrplnVO;
import com.aetna.prvrte.rteintranet.vo.SbmsnrVO;


/**
 * @author N731694
 * Cognizant_Offshore
 */
public class SbmrplnSbmsnr2Adapter extends StoredProcedure{

	private final Log log = LogFactory.getLog(SbmrplnSbmsnr2Adapter.class);
	private static final String CNVRSTN_CD = "CNVRSTN_CD";
	private static final String VAN_ID_CD = "VAN_ID_CD";
	private static final String IN_TY_CD = "IN_TY_CD";
	private static final String SUBMSN_PSTD_DT = "SUBMSN_PSTD_DT";
	private static final String SBMSNRD_SEQ_NO = "SBMSNRD_SEQ_NO";
	private static final String SBMSNRD_IND = "SBMSNRD_IND";
	
	private static final String OUT_CODE = "OUT_CODE";
	private static final String READ_CURSOR = "READ_CURSOR3";
	
	
	public SbmrplnSbmsnr2Adapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(CNVRSTN_CD, Types.CHAR));   
		declareParameter(new SqlParameter(VAN_ID_CD, Types.CHAR));
		declareParameter(new SqlParameter(IN_TY_CD, Types.CHAR));
		declareParameter(new SqlParameter(SUBMSN_PSTD_DT, Types.CHAR));
		declareParameter(new SqlParameter(SBMSNRD_SEQ_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(SBMSNRD_IND, Types.CHAR));
		declareParameter(new SqlOutParameter(OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException 
					{
						SbmrplnVO sbmrplnVO=new SbmrplnVO();
						
						sbmrplnVO.setTableIdentifier(rs.getString("TBL_NO"));
						sbmrplnVO.setProviderMsgText(rs.getString("SBMSNRDT5_PRV_TXT"));
						sbmrplnVO.setCustSvcMsgText(rs.getString("SBMSNRDT5_SVC_TXT"));
						sbmrplnVO.setQualifierCd(rs.getString("SBMRDST_QLFR_CD"));
						sbmrplnVO.setProcedureCd(rs.getString("SBMRDST_PROC_CD"));
						
						
						sbmrplnVO.setDiagnosisCd(rs.getString("SBMRDST_DIAG_CD"));
						sbmrplnVO.setServiceTypeCd(rs.getString("SVCTYP_CD"));
						
						
					
						
						
						return sbmrplnVO;
			}

		}));

	}
	
	
	
	@SuppressWarnings("unchecked")
	public Map getSbmrplnSbmsnrEvntTracking (String convIdCode, String vanIdCd,String typeCd,String postedDt,String seqNo) throws ApplicationException {
		log.warn("Entered SbmrplnAdapter  - getSbmrplnEvntTracking");
		/*if(postedDt.equals(""))
		{
			postedDt="0001-01-01";
		}*/
	//	String seqNo="0";
		String inPostedDate = (postedDt!=null && !"".equals(postedDt))? postedDt : "0001-01-01";
		String indicator="2";
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map sbmsnrMap = new HashMap();
		params.put(CNVRSTN_CD, RteIntranetUtils.getTrimmedString(convIdCode));
		params.put(VAN_ID_CD, RteIntranetUtils.getTrimmedString(vanIdCd));
		params.put(IN_TY_CD, RteIntranetUtils.getTrimmedString(typeCd));
		params.put(SUBMSN_PSTD_DT, RteIntranetUtils.getTrimmedString(inPostedDate));
		params.put(SBMSNRD_SEQ_NO, RteIntranetUtils.getTrimmedString(seqNo));
		params.put(SBMSNRD_IND, RteIntranetUtils.getTrimmedString(indicator));
		
	
		
		log.warn(params);
		Map results = null;
		
		List<SbmrplnVO> sbmsnrsbmrplnList= new LinkedList<SbmrplnVO>();
		
		String newMessage="";
		int noOfElements;
		try {
			results = execute(params);
			log.warn("SbmrplnAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(OUT_CODE));
			sbmsnrsbmrplnList = (List<SbmrplnVO>) results
					.get(READ_CURSOR);	
		
			noOfElements = sbmsnrsbmrplnList.size();
			//if (null != results) {
			if (sbmsnrsbmrplnList.isEmpty()){
				
				if ("0".equals(sqlCode))
					newMessage = "No Data on SBMRPLN5 for Conversation ID: " + convIdCode + 
								" Van Id: " +  vanIdCd + 
								" Tran Type: " + typeCd + 
								" or Posted Date: " + postedDt;
					
				else
					newMessage = "Problem in DB2. sqlcode: " + sqlCode + "  Conversation ID: " + convIdCode + 
								" Van Id: " +  vanIdCd + 
								" Tran Type: " + typeCd + 
								" or Posted Date: " + postedDt; 
			} else {
				if (noOfElements > 1) {
			    	newMessage = noOfElements + " Rows found  ";
				} else {
			    newMessage = noOfElements + " Row found ";
				}
				
			}
			
			sbmsnrMap.put("sbmsnrsbmrplnList",sbmsnrsbmrplnList);
			sbmsnrMap.put("newMessage",newMessage);
			return sbmsnrMap;
		}catch (Exception exception){
			log.error("SbmrplnAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}

}
