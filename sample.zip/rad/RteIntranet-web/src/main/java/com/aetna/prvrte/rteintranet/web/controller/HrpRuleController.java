package com.aetna.prvrte.rteintranet.web.controller;



import java.util.HashMap;

import java.util.LinkedHashMap;

import java.util.LinkedList;

import java.util.List;

import java.util.Map;



import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;

import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.HrpRuleDTO;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;

import com.aetna.prvrte.rteintranet.facade.Facade;

import com.aetna.prvrte.rteintranet.translator.RTETranslator;

import com.aetna.prvrte.rteintranet.util.ApplicationConstants;

import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;

import com.aetna.prvrte.rteintranet.vo.HrpRuleVO;



/**

 * 

 * The HrpRule Controller is responsible for handling

 * ModelAndView the request and return a ModelAndView object which the

 * DispatcherServlet will render as view

 * 

 * @author N801539

 * Cognizant_Offshore

 */



@Controller

@RequestMapping(value = "/hrprule/*")

public class HrpRuleController {



	/*

	 * Tile name of the HrpRule Home view.

	 */

	public static final String HRPRULE_HOME = ".hrpruleHome";

	/*

	 * Tile name of the HrpRule Display view.

	 */

	public static final String HRPRULE_LOOKUP = ".hrpruleLookUpDisplay";

	/*

	 * Tile name of the Add New HrpRule Form view.

	 */

	public static final String HRPRULE_ADD = ".hrpruleAdd";

	/*

	 * Constant name used for COPY indicator.

	 */

	public static final char COPY = 'C';

	/*

	 * Log factory initialization

	 */

	private static final Log log = LogFactory.getLog(HrpRuleController.class);

	

	/**

	 * Declare a private method mav

	 */

	private ModelAndView mav;



	/**

	 * Declare a private method facade

	 */

	@Autowired(required=true)

	private Facade facade;

	

	/**

	 * Model and view of failure operation.

	 */

	private ModelAndView errormav;

	

	/**

	 * Method to getHrpRuleLookUpHome view

	 * 

	 * @param model

	 * 

	 * @return view of hrpruleLookUp, if fails return error page

	 */

	@RequestMapping(value="/hrpruleHome", method ={ RequestMethod.POST , RequestMethod.GET})

	public ModelAndView getHrpRuleLookUpHome(final HttpServletRequest request,Model model) {	

		log.warn("Entered HrpRuleController - getHrpRuleLookUpHome()");

		String securityLevel ="";

		try {

		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);

		ModelAndView mav = new ModelAndView(HRPRULE_HOME, "hrpruleVO",  new HrpRuleVO());

		mav.addObject("securityLevel", securityLevel);

		log.warn("HrpRuleController - securityLevel: "+ securityLevel);

		log.warn("Exit from HrpRuleController - getHrpRuleLookUpHome()");

		return mav;

		} catch (ApplicationException e){

			log.error("Exception occured in HrpRuleController - getHrpRuleLookUpHome() method:"+e.getErrorMessage());

			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+

					RteIntranetUtils.getTrimmedString(e.getErrorMessage());

			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			

			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			

			return errormav;

		}

	}

	

	/**

	 * Method to get the getHrpRuleLookUpTable List from data store.

	 * 

	 * @param hrpruleVO

	 *            form view object of HrpRule.

	 * @return view of hrpruleDisplay, if fails return error page

	 */

	@SuppressWarnings("unchecked")

	@RequestMapping(value = "/GatherHrpRule", method = RequestMethod.POST)

	public ModelAndView getHrpRuleLookUpTable(HttpServletRequest request,@ModelAttribute("hrpruleForm")HrpRuleVO hrpruleVO){

		log.warn("Entered HrpRuleController - getHrpRuleLookUpTable()");

		String securityLevel ="";

		ModelAndView mav ;

		Map hrpruleResultMap = new HashMap();

		List<HrpRuleVO> hrpruleList = new LinkedList<HrpRuleVO>();

		LookUpTableListVO lookUpListVO = new LookUpTableListVO();

		try{

			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);

			HrpRuleDTO hrpruleDTO = RTETranslator.toHrpRuleDTO(hrpruleVO);

			hrpruleResultMap = facade.getHrpRuleLookUpTable(hrpruleDTO);

			List<HrpRuleDTO> hrpruleDTOList = (List<HrpRuleDTO>) hrpruleResultMap.get("hrpruleList");

			hrpruleList = (List<HrpRuleVO>) RTETranslator.toHrpRuleVOList(hrpruleDTOList);

			lookUpListVO.setHrpruleVOList(hrpruleList);

			facade.getApplicationState().setHrpruleList(hrpruleList);

			mav = new ModelAndView(HRPRULE_LOOKUP, "lookUpListVO", lookUpListVO);

			mav.addObject("hrpruleMessage", hrpruleResultMap.get("newMessage"));

			mav.addObject("securityLevel", securityLevel);

			log.warn("getHrpRuleLookUpTable - hrpruleMessage: "+ hrpruleResultMap.get("newMessage"));

			log.warn("Exit from HrpRuleController - getHrpRuleLookUpTable()");

			return mav;

		}catch (ApplicationException e){

			log.error("Exception occured in HrpRuleController - getHrpRuleLookUpTable() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));

			String errorMsg ="getHrpRuleLookUpTable() :"+ApplicationConstants.ERROR_GET_LOOKUP + RteIntranetUtils.getTrimmedString(e.getErrorMessage());

			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			

			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			

			return errormav;

		}

	}

	

	

	/**

	 * Method to display get add new HrpRule form home view.

	 * 

	 * @return view of loadAddNewHrpRuleRowScreen, if fails return error page

	 */

	@RequestMapping(value="/AddNewHrpRuleRow")

	public ModelAndView loadAddNewHrpRuleRowScreen(final HttpServletRequest request,Model model) {	

		log.warn("Entered HrpRuleController - loadAddNewHrpRuleRowScreen()");

		ModelAndView mav = new ModelAndView(HRPRULE_ADD, "hrpruleVO",  new HrpRuleVO());

		try {

			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));

		} catch (ApplicationException e) {

			log.error("Exception occured in HrpRuleController - loadAddNewHrpRuleRowScreen() method:"+e.getErrorMessage());

			

			String errorMsg ="Error encountered when extracting data from the database (loadAddNewHrpRuleRowScreen). "+

					e.getErrorMessage();

			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			

			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			

			return errormav;

		}

		log.warn("Exit from HrpRuleController - loadAddNewHrpRuleRowScreen()");

		return mav;

	}

	

	

	/**

	 * Method to add the data database

	 * 

	 * @param hrpruleVO form view object of HrpRule.

	 * @param request request object for HrpRule to get username

	 * @return view of hrpruleDisplay, if fails return error page

	 * 

	 */

	@SuppressWarnings("unchecked")

	@RequestMapping(value="/AddHrpRule", method = RequestMethod.POST)

	public ModelAndView addNewHrpRule(@ModelAttribute("addHrpRuleForm")HrpRuleVO hrpruleVO,final HttpServletRequest request){

		log.warn("Entered HrpRuleController - addNewHrpRule()");

		ModelAndView mav ;

		Map hrpruleResultMap = new HashMap();

		LookUpTableListVO lookUpListVO = new LookUpTableListVO();

		List<HrpRuleDTO> hrpruleDtoList = new LinkedList<HrpRuleDTO>();

		List<HrpRuleVO> hrpruleVoList = new LinkedList<HrpRuleVO>();

		String securityLevel ="";

		try{

			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);

			hrpruleVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);

			/**
            String userId =  RteIntranetUtils.getUserId(request); //Ex: n242716 

			hrpruleVO.setUserId(userId);
			*/

			HrpRuleDTO hrpruleDTO = RTETranslator.toHrpRuleDTO(hrpruleVO);

			hrpruleResultMap = facade.addNewHrprule(hrpruleDTO);

			if(hrpruleResultMap.get("hrpruleList")!=null){

				hrpruleDtoList = (List<HrpRuleDTO>) hrpruleResultMap.get("hrpruleList");

				hrpruleVoList = RTETranslator.toHrpRuleVOList(hrpruleDtoList);

			}

			lookUpListVO.setHrpruleVOList(hrpruleVoList);

			facade.getApplicationState().setHrpruleList(hrpruleVoList);

			mav = new ModelAndView(HRPRULE_LOOKUP, "lookUpListVO", lookUpListVO);

			mav.addObject("securityLevel", securityLevel);

			mav.addObject("hrpruleMessage", hrpruleResultMap.get("hrpruleMessage"));

			log.warn("addNewHrpRule - hrpruleMessage: "+ hrpruleResultMap.get("hrpruleMessage"));

			log.warn("Exit from HrpRuleController - addNewHrpRule()");			

			return mav;	

		}catch (ApplicationException e){

			log.error("Exception occured in HrpRuleController - addNewHrpRule() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));

			String errorMsg ="addNewHrpRule() :"+ApplicationConstants.ERROR_ADD_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());

			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			

			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			

			return errormav;

		}

	}

	

	

	/**

	 * Method to delete the HrpRule List from data store.

	 * @param lookUpListVO

	 *            lookUpListVO object from view

	 * @param takeAction

	 * 			List of selected index.

	 * @return view of hrpruleDisplay, if fails return error page

	 */

	@SuppressWarnings("unchecked")

	@RequestMapping(value="/deleteHrpRule", method = RequestMethod.POST)

	public ModelAndView deleteHrpRule(final HttpServletRequest request,@ModelAttribute("hrpruleDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){

		ModelAndView mav ;

		String hrpruleMsg = "";

		boolean isHrpRuleDeleted = true;

		String securityLevel ="";

		Map hrpruleResultMap = new HashMap();

		List<HrpRuleVO> hrpruleList = new LinkedList<HrpRuleVO>();

		try{

			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);

			hrpruleList = lookUpListVO.getHrpruleVOList();

			int i;

			if ((hrpruleList != null) && (takeAction != null)) {

				for(HrpRuleVO hrpruleVO : hrpruleList){

					if(hrpruleVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){

						hrpruleVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);

					}

				}

				for (int j = takeAction.length - 1; j >= 0; j--) {

					i = Integer.parseInt(takeAction[j]);

					HrpRuleVO existingHrpRule = (HrpRuleVO) hrpruleList.get(i);

					if (existingHrpRule.getUpdatedInd() != ApplicationConstants.COPY) {

						HrpRuleDTO hrpruleDTO = RTETranslator.toHrpRuleDTO(existingHrpRule);

						hrpruleResultMap = facade.deleteHrpRule(hrpruleDTO);

						hrpruleMsg = (String) hrpruleResultMap.get("hrpruleMsg");

						isHrpRuleDeleted = (Boolean) hrpruleResultMap.get("isHrpRuleDeleted");

						

						if(isHrpRuleDeleted == true){

							hrpruleList.remove(i);

							hrpruleMsg = "Rows selected were Deleted in the database/list";

						}else{

							j = 0;

						}

					}else{

						hrpruleList.remove(i);

						hrpruleMsg = "Rows selected were Deleted in the database/list";

					}				

			}

				if(isHrpRuleDeleted == true)

					hrpruleMsg = "Rows selected were Deleted in the database/list";

		}else

			hrpruleMsg = "Take action was not selected for any of the displayed rows";

			facade.getApplicationState().setHrpruleList(hrpruleList);

			lookUpListVO.setHrpruleVOList(hrpruleList);

			mav = new ModelAndView(HRPRULE_LOOKUP, "lookUpListVO", lookUpListVO);

		    mav.addObject("hrpruleMessage",hrpruleMsg);

		    mav.addObject("securityLevel", securityLevel);

		    log.warn("deleteHrpRule - hrpruleMessage: "+ hrpruleMsg);

		    log.warn("Exit from HrpRuleController - deleteHrpRule()");

			return mav;

		}catch (ApplicationException e){

			log.error("Exception occured in HrpRuleController - deleteHrpRule() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));

			String errorMsg ="deleteHrpRule() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());

			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			

			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			

			return errormav;

		}

	}

	

	

	/**

	 * Method to copy the HrpRule List from data store.

	 * @param lookUpListVO

	 *            lookUpListVO object from view

	 * @param takeAction

	 * 			List of selected index.

	 * @return view of hrpruleDisplay, if fails return error page

	 */

	@RequestMapping(value="/copyHrpRule", method = RequestMethod.POST)

	public ModelAndView copyHrpRule(@ModelAttribute("hrpruleDisplayForm")LookUpTableListVO lookUpListVO,final HttpServletRequest request, @RequestParam(required = false) String[] takeAction){

		ModelAndView mav ;

		String hrpruleMsg = "";

		String securityLevel ="";

		int i;

		List<HrpRuleVO> hrpruleList = new LinkedList<HrpRuleVO>();

		try{

			//String postedDate =RteIntranetUtils.getPostedDate(); //Initialize Posted Date to today's date

			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			
			/**
			 * String userId =  RteIntranetUtils.getUserId(request); //Ex: n242716
			*/ 

			hrpruleList = lookUpListVO.getHrpruleVOList();

			if ((hrpruleList != null) && (takeAction != null)) {

				for(HrpRuleVO hrpruleVO : hrpruleList){

					if(hrpruleVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){

						hrpruleVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);

					}

				}

				for (int j = 0; j < takeAction.length; j++) {

					i = Integer.parseInt(takeAction[j]);

					HrpRuleVO existingHrprule = (HrpRuleVO) hrpruleList.get(i);

					HrpRuleVO copyHrpRule = new HrpRuleVO(existingHrprule.getHrprlSvcTyp() , existingHrprule.getHrprlRulecd() , existingHrprule.getHrprlEffdt() ,

							existingHrprule.getHrprlTermdt() , existingHrprule.getHrprlRuledesc() , existingHrprule.getHrprlCondspec() ,

							existingHrprule.getHrprlRulectgry() ,  existingHrprule.getHrprlCovgind() , existingHrprule.getHrprlTextsnd() ,
							
							existingHrprule.getHrprlPosTob() , existingHrprule.getHrprlTobcd() , existingHrprule.getHrprlPoscd() ,
							
							existingHrprule.getHrprlStatecd() , existingHrprule.getHrprlAmntrfmt() , existingHrprule.getHrprlBus01() ,
							
							existingHrprule.getHrprlBus02() , existingHrprule.getHrprlBus03() , existingHrprule.getHrprlBus04() ,
							
							existingHrprule.getHrprlBus05() , existingHrprule.getHrprlBus06() , existingHrprule.getHrprlBus07() ,
							
							existingHrprule.getHrprlBus08() , existingHrprule.getHrprlBus09() , existingHrprule.getHrprlBus10() ,
							
							existingHrprule.getHrprlBus11() , existingHrprule.getHrprlBus12() , existingHrprule.getHrprlBus13() , 

							existingHrprule.getHrprlBus14() , existingHrprule.getHrprlBus15() , COPY);

					hrpruleList.add(copyHrpRule);

				}

				hrpruleMsg = "Copied rows were placed at the bottom of the list and highlighted.";

			}else

				hrpruleMsg = "Take action was not selected for any of the displayed rows";

			facade.getApplicationState().setHrpruleList(hrpruleList);

			lookUpListVO.setHrpruleVOList(hrpruleList);

			mav = new ModelAndView(HRPRULE_LOOKUP, "lookUpListVO", lookUpListVO);

		    mav.addObject("hrpruleMessage",hrpruleMsg);

		    mav.addObject("securityLevel", securityLevel);

		    log.warn("copyHrpRule - hrprulegMessage: "+ hrpruleMsg);

		    log.warn("Exit from HrpRuleController - copyHrpRule()");

			return mav;		

		}catch (Exception e){

			log.error("Exception occured in HrpRuleController - copyHrpRule() method:"+e.getMessage());

			String errorMsg ="copyHrpRule() :"+ApplicationConstants.ERROR_COPY_ROW + RteIntranetUtils.getTrimmedString(e.getMessage());

			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			

			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			

			return errormav;

		}

	}

	

	

	/**

	 * Method to Add/Update the HrpRule List from data store.

	 * @param lookUpListVO

	 *            lookUpListVO object from view

	 * @param takeAction

	 * 			List of selected index.

	 * @return view of hrpruleDisplay, if fails return error page

	 */

	@SuppressWarnings("unchecked")

	@RequestMapping(value="/addUpdateHrpRule", method = RequestMethod.POST)

	public ModelAndView addUpdateHrpRule(final HttpServletRequest request,@ModelAttribute("hrpruleDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){

		log.warn("Entered from HrpRuleController - addUpdateHrpRule()");

		ModelAndView mav ;

		String hrpruleMsg = "";

		String securityLevel ="";

		List<HrpRuleVO> updatedHrpRuleList = new LinkedList<HrpRuleVO>();

		List<HrpRuleDTO> updatedHrpRuleDtoList = new LinkedList<HrpRuleDTO>();

		List<HrpRuleVO> hrpruleVoList = new LinkedList<HrpRuleVO>();

		List<HrpRuleVO> modifiedHrpRuleVoList = new LinkedList<HrpRuleVO>();

		List<HrpRuleDTO> hrpruleDtoList = new LinkedList<HrpRuleDTO>(); 

		boolean isHrpRuleAddOrUpdated = false;

		Map hrpruleResultMap = new HashMap();

		try{

			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);

			 hrpruleVoList = facade.getApplicationState().getHrpruleList();

			 modifiedHrpRuleVoList = lookUpListVO.getHrpruleVOList();

			int i;

			if (takeAction != null && takeAction.length != 0) {

				if(hrpruleVoList != null && hrpruleVoList.size() != 0 

						&& modifiedHrpRuleVoList.size() != 0 && modifiedHrpRuleVoList != null){

				for(HrpRuleVO hrpruleVO : hrpruleVoList){

					if(hrpruleVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){

						hrpruleVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);

					}

				}

				hrpruleDtoList = RTETranslator.toHrpRuleDTOList(hrpruleVoList);

				for (int j = 0; j < takeAction.length; j++) {

					char updatedInd = ApplicationConstants.UPDATE_IND_Y;

					i = Integer.parseInt(takeAction[j]);

					HrpRuleVO selectedHrpRule = (HrpRuleVO)hrpruleVoList.get(i);

					HrpRuleVO editedHrpRule = (HrpRuleVO) modifiedHrpRuleVoList.get(i);

					HrpRuleVO editedHrpRuleVO = new HrpRuleVO(editedHrpRule.getHrprlSvcTyp() , editedHrpRule.getHrprlRulecd() , editedHrpRule.getHrprlEffdt() ,

							editedHrpRule.getHrprlTermdt() , editedHrpRule.getHrprlRuledesc() , editedHrpRule.getHrprlCondspec() ,

							editedHrpRule.getHrprlRulectgry() ,  editedHrpRule.getHrprlCovgind() , editedHrpRule.getHrprlTextsnd() ,
							
							editedHrpRule.getHrprlPosTob() , editedHrpRule.getHrprlTobcd() , editedHrpRule.getHrprlPoscd() ,
							
							editedHrpRule.getHrprlStatecd() , editedHrpRule.getHrprlAmntrfmt() , editedHrpRule.getHrprlBus01() ,
							
							editedHrpRule.getHrprlBus02() , editedHrpRule.getHrprlBus03() , editedHrpRule.getHrprlBus04() ,
							
							editedHrpRule.getHrprlBus05() , editedHrpRule.getHrprlBus06() , editedHrpRule.getHrprlBus07() ,
							
							editedHrpRule.getHrprlBus08() , editedHrpRule.getHrprlBus09() , editedHrpRule.getHrprlBus10() ,
							
							editedHrpRule.getHrprlBus11() , editedHrpRule.getHrprlBus12() , editedHrpRule.getHrprlBus13() , 

							editedHrpRule.getHrprlBus14() , editedHrpRule.getHrprlBus15() , updatedInd);


					HrpRuleDTO editedHrpRuleDTO = RTETranslator.toHrpRuleDTO(editedHrpRuleVO);

					hrpruleResultMap = facade.addUpdateHrpRule(editedHrpRuleDTO, hrpruleDtoList, i , selectedHrpRule.getUpdatedInd());

					updatedHrpRuleDtoList = (List<HrpRuleDTO>) hrpruleResultMap.get("hrpruleDtoList");

					updatedHrpRuleList = RTETranslator.toHrpRuleVOList(updatedHrpRuleDtoList);

					isHrpRuleAddOrUpdated = (Boolean) hrpruleResultMap.get("isHrpRuleAddorUpdated") ;

					hrpruleMsg = (String) hrpruleResultMap.get("hrpruleMsg") ;

					if(isHrpRuleAddOrUpdated!= true){

						j = takeAction.length;

					}

				}

				lookUpListVO.setHrpruleVOList(updatedHrpRuleList);

				facade.getApplicationState().setHrpruleList(updatedHrpRuleList);

			} else {

				throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	

			}

		}else{

			hrpruleMsg = "Take action was not selected for any of the displayed rows";

			lookUpListVO.setHrpruleVOList(hrpruleVoList);

			facade.getApplicationState().setHrpruleList(hrpruleVoList);

		}

			mav = new ModelAndView(HRPRULE_LOOKUP, "lookUpListVO", lookUpListVO);

		    mav.addObject("hrpruleMessage",hrpruleMsg);

		    mav.addObject("securityLevel", securityLevel);

		    log.warn("addUpdateHrpRule - hrpruleMessage: "+ hrpruleMsg);

		    log.warn("Exit from HrpRuleController - addUpdateHrpRule()");

			return mav;

		}catch (ApplicationException e){

			log.error("Exception occured in HrpRuleController - addUpdateHrpRule() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));

			String errorMsg ="addUpdateHrpRule() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());

			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			

			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			

			return errormav;

		}

	}

	



	/**

     * Method to export HrpRule look up table to excel work book

     * 

      * @param lookUpTableListVO

     *            list of hrprule object.

     * @param response

     *            response object to return

     * @return exported file to view.

     */

     @RequestMapping(value = "/hrpruleExport", method = RequestMethod.POST)

     public ModelAndView hrpruleExport(HttpServletResponse response){

           List<HrpRuleVO> hrpruleList = new LinkedList<HrpRuleVO>();

           LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();

     String hrpruleMsg="";

           try{

                 hrpruleList = facade.getApplicationState().getHrpruleList();

                 if(hrpruleList != null && hrpruleList.size() != 0){

                 // Key map to create header

                 Map<String,String> keyMap = new LinkedHashMap<String,String>(); 

                 keyMap.put("hrprlSvcTyp", "Service Type");

                 keyMap.put("hrprlRulecd", "Rule Code");

                 keyMap.put("hrprlEffdt", "Effective Date");

                 keyMap.put("hrprlTermdt", "Termination Date");
                 
                 keyMap.put("hrprlRuledesc", "Rule Description");

                 keyMap.put("hrprlCondspec", "Condition Spec Cd");

                 keyMap.put("hrprlRulectgry", "Rule Category Cd");

                 keyMap.put("hrprlCovgind", "Coverage Code");

                 keyMap.put("hrprlTextsnd", "Text Send Ind");

                 keyMap.put("hrprlPosTob", "POS TOB Ind");

                 keyMap.put("hrprlTobcd", "Type Of Billing Cd");
                 
                 keyMap.put("hrprlPoscd", "Place Of Service Cd");

                 keyMap.put("hrprlStatecd", "State Code");

                 keyMap.put("hrprlAmntrfmt", "Amount Reformat Cd");

                 keyMap.put("hrprlBus01", "Business Rule 1");

                 keyMap.put("hrprlBus02", "Business Rule 2");

                 keyMap.put("hrprlBus03", "Business Rule 3");

                 keyMap.put("hrprlBus04", "Business Rule 4");

                 keyMap.put("hrprlBus05", "Business Rule 5");

                 keyMap.put("hrprlBus06", "Business Rule 6");

                 keyMap.put("hrprlBus07", "Business Rule 7");
                 
                 keyMap.put("hrprlBus08", "Business Rule 8");

                 keyMap.put("hrprlBus09", "Business Rule 9");

                 keyMap.put("hrprlBus10", "Business Rule 10");

                 keyMap.put("hrprlBus11", "Business Rule 11");

                 keyMap.put("hrprlBus12", "Business Rule 12");

                 keyMap.put("hrprlBus13", "Business Rule 13");

                 keyMap.put("hrprlBus14", "Business Rule 14");
                 
                 keyMap.put("hrprlBus15", "Business Rule 15");

                 RteIntranetUtils.exportToExcel(response, hrpruleList, keyMap);

                 hrpruleMsg = "LookUp table exported successfully.";

                 } else {

                       hrpruleMsg = "No data found.";

                 }

                 lookUpTableListVO.setHrpruleVOList(hrpruleList);

                 mav = new ModelAndView(HRPRULE_LOOKUP,"lookUpTableListVO", lookUpTableListVO);

                 mav.addObject("hrpruleMessage",hrpruleMsg);

                 return mav;

           }catch (ApplicationException e) {

                 log.error("Exception occured in HrpRuleController - hrpruleExport() method:" + e.getMessage());

                 String errorMsg = "Error encountered while export to excel. ";

                 errorMsg.concat(e.toString());

                 errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);

                 errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);

                 return errormav;

           }

     }



	

}

