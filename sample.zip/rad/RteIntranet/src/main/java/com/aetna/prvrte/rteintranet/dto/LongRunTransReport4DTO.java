package com.aetna.prvrte.rteintranet.dto;

import java.io.Serializable;
public class LongRunTransReport4DTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String seconds = "";
	private String dmCount = "";
	private String tradCount = "";
	private String dentalCount = "";
	private String hmoCount = "";
	private String outBoundCount = "";
	private String providerCount = "";
	private String hrpCount = "";
	private String asjCount= "";
	public LongRunTransReport4DTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LongRunTransReport4DTO(String seconds, String dmCount,
			String tradCount, String dentalCount, String hmoCount,
			String outBoundCount, String providerCount, String hrpCount,
			String asjCount) {
		super();
		this.seconds = seconds;
		this.dmCount = dmCount;
		this.tradCount = tradCount;
		this.dentalCount = dentalCount;
		this.hmoCount = hmoCount;
		this.outBoundCount = outBoundCount;
		this.providerCount = providerCount;
		this.hrpCount = hrpCount;
		this.asjCount = asjCount;
	}
	public String getSeconds() {
		return seconds;
	}
	public void setSeconds(String seconds) {
		this.seconds = seconds;
	}
	public String getDmCount() {
		return dmCount;
	}
	public void setDmCount(String dmCount) {
		this.dmCount = dmCount;
	}
	public String getTradCount() {
		return tradCount;
	}
	public void setTradCount(String tradCount) {
		this.tradCount = tradCount;
	}
	public String getDentalCount() {
		return dentalCount;
	}
	public void setDentalCount(String dentalCount) {
		this.dentalCount = dentalCount;
	}
	public String getHmoCount() {
		return hmoCount;
	}
	public void setHmoCount(String hmoCount) {
		this.hmoCount = hmoCount;
	}
	public String getOutBoundCount() {
		return outBoundCount;
	}
	public void setOutBoundCount(String outBoundCount) {
		this.outBoundCount = outBoundCount;
	}
	public String getProviderCount() {
		return providerCount;
	}
	public void setProviderCount(String providerCount) {
		this.providerCount = providerCount;
	}
	public String getHrpCount() {
		return hrpCount;
	}
	public void setHrpCount(String hrpCount) {
		this.hrpCount = hrpCount;
	}
	public String getAsjCount() {
		return asjCount;
	}
	public void setAsjCount(String asjCount) {
		this.asjCount = asjCount;
	}
	
	
	
}
