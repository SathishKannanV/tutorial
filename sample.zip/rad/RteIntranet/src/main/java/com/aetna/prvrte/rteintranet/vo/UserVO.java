/**
 * 
 */
package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.aetna.framework.security.userdetails.AefwUserDetailsImpl;

/**
 * @author N657186
 *
 */
public class UserVO extends AefwUserDetailsImpl implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -257413148564801650L;
	/**
	 * Internally generated user id. serial/PK from the DB IWS User Table
	 */
	private String aetnaId;
	
	/**
	 * Last Login Date
	 */
	private Date lastLoginDt;
	
	/**
	 * List of Network groups that the user is part of.
	 * Additional attribute retrieved from Active Directory
	 */
	private List <String> memberOf;

	private String securityLevel = "";
	private String name = "";
	
	private String dateSecLevPosted = "";
	
	public UserVO() {
		super();
		setSecurityLevel("R");
		setName("Unknown User");
		setAetnaId("z000000");
		setDateSecLevPosted("0001-01-01");
	}
	
	/**
	 * @return the aetnaId
	 */
	public String getAetnaId() {
		return aetnaId;
	}

	/**
	 * @param aetnaId the aetnaId to set
	 */
	public void setAetnaId(String aetnaId) {
		this.aetnaId = aetnaId;
	}

	public Date getLastLoginDt() {
		return lastLoginDt;
	}

	public void setLastLoginDt(Date lastLoginDt) {
		this.lastLoginDt = lastLoginDt;
	}

	public List<String> getMemberOf() {
		return memberOf;
	}

	public void setMemberOf(List<String> memberOf) {
		this.memberOf = memberOf;
	}

	
	/**
	 * Returns true if the member is part of the group sent in the input parameter.
	 * 
	 * @param groupName
	 * @return boolean
	 */
	public boolean isMemberOf(String groupName)
	{
		if(memberOf == null || memberOf.isEmpty())
				return false;
		
		for(String group : memberOf){
			if(group.equalsIgnoreCase(groupName)){
				return true;
			}
		}
	
		return false;
	}

	/**
	 * @return the securityLevel
	 */
	public String getSecurityLevel() {
		return securityLevel;
	}

	/**
	 * @param securityLevel the securityLevel to set
	 */
	public void setSecurityLevel(String securityLevel) {
		this.securityLevel = securityLevel;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the dateSecLevPosted
	 */
	public String getDateSecLevPosted() {
		return dateSecLevPosted;
	}

	/**
	 * @param dateSecLevPosted the dateSecLevPosted to set
	 */
	public void setDateSecLevPosted(String dateSecLevPosted) {
		this.dateSecLevPosted = dateSecLevPosted;
	}

	
}
