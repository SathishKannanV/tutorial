/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.SstypaAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.SstypaDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.SstypaDisplayAdapter;
import com.aetna.prvrte.rteintranet.dto.SstypaDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Repository
public class SstypaDAOImpl implements SstypaDAO {
	
	@Autowired(required=true)
	private SstypaDisplayAdapter sstypaDisplayAdapter;

	@Autowired(required=true)
	private SstypaAddAdapter sstypaAddAdapter;
	
			@Autowired(required=true)
	private SstypaDeleteAdapter sstypaDeleteAdapter;
	
	
	/**
	 * 
	 * @param sstypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map getSstypaLookUpTable(SstypaDTO sstypaDTO)
			throws ApplicationException {
		
		return sstypaDisplayAdapter.getSstypaLookUpTable(sstypaDTO);
	}

	
	/**
	 * 
	 * @param sstypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addNewSstypa(SstypaDTO sstypaDTO) throws ApplicationException {
		return sstypaAddAdapter.addNewSstypa(sstypaDTO);
	}

	/**
	 * 
	 * @param sstypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map deleteSstypa(SstypaDTO sstypaDTO) throws ApplicationException {
		return sstypaDeleteAdapter.deleteSstypa(sstypaDTO);
	}

	/**
	 * 
	 * @param editedSstypaDTO
	 * @param sstypaDtoList
	 * @param index
	 * @param  updateInd
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addUpdateSstypa(SstypaDTO editedSstypaDTO,
			List<SstypaDTO> sstypaDtoList, int index,char updateInd)
			throws ApplicationException {
		return sstypaAddAdapter.addUpdateSstypa( editedSstypaDTO, sstypaDtoList,  index, updateInd);
	}


}
