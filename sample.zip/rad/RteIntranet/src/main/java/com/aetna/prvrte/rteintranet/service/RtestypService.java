/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.RtestypDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;


/**
 * @author N657186
 * Cognizant_Offshore
 */
public interface RtestypService {
	
	Map getRtestypLookUp(RtestypDTO rtestypDTO) throws ApplicationException;;

	Map addNewRtestyp(RtestypDTO rtestypDTO)throws ApplicationException ;

	Map deleteRtestyp(String rtestypCd, String effDate) throws ApplicationException ;

	Map addUpdateRtestyp(RtestypDTO existRtestypDTO, List<RtestypDTO> rtestypDtoList, int index, char updateInd) throws ApplicationException ;
	
	
}
