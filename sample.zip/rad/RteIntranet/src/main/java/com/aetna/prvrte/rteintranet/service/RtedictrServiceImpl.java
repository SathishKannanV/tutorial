/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.RtedictrDAO;
import com.aetna.prvrte.rteintranet.dto.RtedictrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 * Cognizant_Offshore
 */
@Service
public class RtedictrServiceImpl implements RtedictrService{

	@Autowired(required=true)
	private RtedictrDAO rtedictrDAO;

	@Override
	public Map getRtedictrLookUp(RtedictrDTO rtedictrDTO) throws ApplicationException {
		return rtedictrDAO.getRtedictrLookUp(rtedictrDTO);
	}

	@Override
	public Map addNewRtedictr(RtedictrDTO rtedictrDTO) throws ApplicationException {
		return rtedictrDAO.addNewRtedictr(rtedictrDTO);
	}

	@Override
	public Map deleteRtedictr(RtedictrDTO rtedictrDTO)
			throws ApplicationException {
		return rtedictrDAO.deleteRtedictr(rtedictrDTO);
	}

	@Override
	public Map addUpdateRtedictr(RtedictrDTO modifiedRtedictrDTO, List<RtedictrDTO> rtedictrDtoList,
			int index) throws ApplicationException {
		return rtedictrDAO.addUpdateRtedictr(modifiedRtedictrDTO,rtedictrDtoList, index);
	}
}
