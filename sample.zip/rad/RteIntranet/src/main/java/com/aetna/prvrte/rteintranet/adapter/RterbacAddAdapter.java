/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RtedictrDTO;
import com.aetna.prvrte.rteintranet.dto.RterbacDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RterbacAddAdapter extends StoredProcedure{

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RterbacAddAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RterbacAddAdapter(DataSource datasource, String storedProc) throws SQLException{
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.IN_RTERBAC_ACCUM_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTERBAC_BNFT_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTERBAC_RSTRCT_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTERBAC_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.IN_RTERBAC_EXP_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.IN_ERSPMSG_ID, Types.INTEGER));
		declareParameter(new SqlParameter(DBConstants.IN_ERSPMSG_MSGTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_ERSPMSG_SHORT_TXT, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_ERSPMSG_LONG_TXT, Types.VARCHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTERBAC_POSTED_DTS, Types.TIMESTAMP));
		declareParameter(new SqlParameter(DBConstants.IN_APPL_USER_ID, Types.CHAR));
		
		
		declareParameter(new SqlOutParameter(DBConstants.LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(DBConstants.LS_ERSPMSG_ID, Types.DECIMAL));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
	}
	
	/**
	 * 
	 * @param rterbacDTO	
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	public Map addNewRterbac(RterbacDTO rterbacDTO) throws ApplicationException {
		
		log.warn("Entered RterbacAddAdapter  - addNewRterbac");
		
		String newMessage ="";
		Map results = null;
		Map<String, Object> params = new java.util.LinkedHashMap<String, Object>();
		Map rterbacMap = new HashMap();
		
		params = setInputParameters(rterbacDTO, params);
		log.warn(params);	
		
		try {
					
			results = execute(params);
			log.warn("RterbacAddAdapter: Executed stored procedure");
			String actionCode =   String.valueOf(results
					.get(DBConstants.LS_ADD_UPDATE));
			String msgId = String.valueOf(results.get(DBConstants.LS_ERSPMSG_ID));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) {
				rterbacDTO.setMessageId(msgId);
				List<RterbacDTO> rterbacList = new LinkedList<RterbacDTO>();
				rterbacList.add(rterbacDTO);
				rterbacMap.put("rterbacList", rterbacList);
						
				if ("1".equals(actionCode))
					newMessage = "Row added to ERSPMSG only";
				else 
					if ("2".equals(actionCode))
						newMessage = "Row updated on ERSPMSG only";	
					else
						if ("3".equals(actionCode))
							newMessage = "Row added to RTERBAC only";
						else
							if ("4".equals(actionCode))
								newMessage = "Row updated on RTERBAC only";
							else
								if ("5".equals(actionCode))
									newMessage = "Rows added to ERSPMSG and RTERBAC";
								else
									if ("6".equals(actionCode))
										newMessage = "Row added to ERSPMSG and updated on RTERBAC";
									else
										if ("7".equals(actionCode))
											newMessage = "Row updated on ERSPMSG and added to RTERBAC";
										else
											if ("8".equals(actionCode))
												newMessage = "Rows updated on ERSPMSG and RTERBAC";
											else 
												if("9".equals(actionCode))
													newMessage ="Row already exists on RTERBAC, no rows added or updated";
											else{
												newMessage = "No changes made to RTERBAC or ERSPMSG";
												rterbacDTO.setUpdatedInd(ApplicationConstants.COPY);
											}
				}
			else {
				newMessage = "Unable to add or update row to the database. SQLCODE = " + sqlCode;
			}
			
			rterbacMap.put("rterbacMessage", newMessage);
							
		return rterbacMap;
	}catch (Exception exception){
		log.error("RterbacAddAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}
	

	@SuppressWarnings("unchecked")
	public Map addUpdateRterbac(RterbacDTO modifiedRterbac,
			List<RterbacDTO> rterbacDtoList, int index) throws ApplicationException{
		log.warn("Entered RterbacAddAdapter  - addUpdateRterbac");
		boolean isRterbacAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, Object> params = new java.util.LinkedHashMap<String, Object>();
		Map rterbacMap = new HashMap();
		
		params = setInputParameters(modifiedRterbac, params);
		log.warn(params);	
		
		try {
					
			results = execute(params);
			log.warn("RterbacAddAdapter: Executed stored procedure");
			
			String actionCode =   String.valueOf(results
					.get(DBConstants.LS_ADD_UPDATE));
			String msgId = String.valueOf(results.get(DBConstants.LS_ERSPMSG_ID));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			if ("0".equalsIgnoreCase(sqlCode)) {
				isRterbacAddorUpdated = true;
				modifiedRterbac.setMessageId(msgId);								
				rterbacDtoList.set(index, modifiedRterbac);						
					log.warn(" sqlCode : "+sqlCode);
					log.warn(" actionCode : "+ actionCode);
					log.warn(" msgId : "+ msgId);
				
					if ("1".equals(actionCode))
						newMessage = "Row added to ERSPMSG only";
					else 
						if ("2".equals(actionCode))
							newMessage = "Row updated on ERSPMSG only";	
						else
							if ("3".equals(actionCode))
								newMessage = "Row added to RTERBAC only";
							else
								if ("4".equals(actionCode))
									newMessage = "Row updated on RTERBAC only";
								else
									if ("5".equals(actionCode))
										newMessage = "Rows added to ERSPMSG and RTERBAC";
									else
										if ("6".equals(actionCode))
											newMessage = "Row added to ERSPMSG and updated on RTERBAC";
										else
											if ("7".equals(actionCode))
												newMessage = "Row updated on ERSPMSG and added to RTERBAC";
											else
												if ("8".equals(actionCode))
													newMessage = "Rows updated on ERSPMSG and RTERBAC";
												else
													if ("9".equals(actionCode))
														newMessage ="Row already exists on RTERBAC, no rows added or updated ";
												else
													newMessage = "No changes made to RTERBAC or ERSPMSG";
				
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			rterbacMap.put("rterbacMessage",newMessage);
			rterbacMap.put("rterbacDtoList",rterbacDtoList);
			rterbacMap.put("isrterbacAddorUpdated", isRterbacAddorUpdated);
			return rterbacMap;
		}catch (Exception exception){
			log.error("RterbacAddAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
	
	private Map<String, Object> setInputParameters(RterbacDTO rterbacDTO,
			Map<String, Object> params) {
		String msgId = RteIntranetUtils.getTrimmedString(rterbacDTO.getMessageId());
		
		params.put(DBConstants.IN_RTERBAC_ACCUM_CD, RteIntranetUtils.getTrimmedString(rterbacDTO.getAccuCd()));
		params.put(DBConstants.IN_RTERBAC_BNFT_CD, RteIntranetUtils.getTrimmedString(rterbacDTO.getBenCd()));
		params.put(DBConstants.IN_RTERBAC_RSTRCT_IND, RteIntranetUtils.getTrimmedString(rterbacDTO.getResInd()));
		params.put(DBConstants.IN_RTERBAC_EFF_DT, RteIntranetUtils.getTrimmedString(rterbacDTO.getEffDt()));
		params.put(DBConstants.IN_RTERBAC_EXP_DT, RteIntranetUtils.getTrimmedString(rterbacDTO.getExpDt()));
		params.put(DBConstants.IN_ERSPMSG_ID, msgId!=""?Integer.parseInt(msgId):msgId);
		params.put(DBConstants.IN_ERSPMSG_MSGTYP_CD, RteIntranetUtils.getTrimmedString(rterbacDTO.getMessageTypeCd()));
		params.put(DBConstants.IN_ERSPMSG_SHORT_TXT, RteIntranetUtils.getTrimmedString(rterbacDTO.getShortText()));
		params.put(DBConstants.IN_ERSPMSG_LONG_TXT, RteIntranetUtils.getTrimmedString(rterbacDTO.getFullText()));
		params.put(DBConstants.IN_RTERBAC_POSTED_DTS, RteIntranetUtils.getTrimmedString(rterbacDTO.getPostedDateTimeStamp()));
		params.put(DBConstants.IN_APPL_USER_ID, RteIntranetUtils.getTrimmedString(rterbacDTO.getUserId()));
		return params;
	}	
	
		
}
