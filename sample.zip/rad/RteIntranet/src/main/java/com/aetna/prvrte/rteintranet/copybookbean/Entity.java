package com.aetna.prvrte.rteintranet.copybookbean;


public class Entity {

	String entityIndicator;
	IndividualData individualData;
	NonIndividualData nonIndividualData;
	public String getEntityIndicator() {
		return entityIndicator;
	}
	public void setEntityIndicator(String entityIndicator) {
		this.entityIndicator = entityIndicator;
	}
	public IndividualData getIndividualData() {
		return individualData;
	}
	public void setIndividualData(IndividualData individualData) {
		this.individualData = individualData;
	}
	public NonIndividualData getNonIndividualData() {
		return nonIndividualData;
	}
	public void setNonIndividualData(NonIndividualData nonIndividualData) {
		this.nonIndividualData = nonIndividualData;
	}
	public StringBuilder getEntity(){
		return new StringBuilder(getEntityIndicator())
		.append(individualData.getIndividual())
		.append(nonIndividualData.getNonIndiv());
	}
}
