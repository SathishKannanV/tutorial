package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.TOSDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class TOSDeleteAdapter extends StoredProcedure{
	
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(TOSDeleteAdapter.class);

	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public TOSDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_TOS_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_ACTION_CODE, Types.INTEGER));
		
	}
	
	
	/**
	 * Method to delete the TOS data from data store.
	 * 
	 * @param tosDTO
	 * 
	 * @return Map of flag to delete the data from TOS list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map deleteTOS(TOSDTO tosDTO) throws ApplicationException {
		
		log.warn("Entered TOSDeleteAdapter  - deleteTOS");
		boolean isTOSDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map tosMap = new HashMap();
		params.put(DBConstants.LS_TOS_CD, RteIntranetUtils.getTrimmedString(tosDTO.getDbTosCd()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("TOSDeleteAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_ACTION_CODE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) 
				isTOSDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			tosMap.put("tosMsg", newMessage);
			tosMap.put("isTOSDeleted", isTOSDeleted);
			return tosMap;
		}catch (Exception exception){
			
			log.error("TOSDeleteAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	
}
