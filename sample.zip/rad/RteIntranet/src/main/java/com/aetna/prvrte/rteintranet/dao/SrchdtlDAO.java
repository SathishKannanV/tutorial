package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.SrchcolDTO;
import com.aetna.prvrte.rteintranet.dto.SrchdtlDTO;
import com.aetna.prvrte.rteintranet.dto.SrcherrDTO;
import com.aetna.prvrte.rteintranet.dto.SrchresDTO;
import com.aetna.prvrte.rteintranet.dto.SrchscDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.vo.SrchcolVO;
import com.aetna.prvrte.rteintranet.vo.SrchdtlVO;
import com.aetna.prvrte.rteintranet.vo.SrcherrVO;
import com.aetna.prvrte.rteintranet.vo.SrchresVO;
import com.aetna.prvrte.rteintranet.vo.SrchscVO;

public interface SrchdtlDAO {
	Map getSrchdtlLookUpTable(String srchscFirstId, String srchscSecondId,String srcherrCd,String srchcolCd) throws ApplicationException ;
	Map<String, Object> deleteSrchdtl(List<SrchdtlVO> srchdtlVOList, String[] selectedIndexes)throws ApplicationException;
	public Map deleteSrchdtl(SrchdtlDTO srchdtlDTO)throws ApplicationException;

	public Map addUpdateSrchdtl(SrchdtlDTO existSrchdtlDTO,
			List<SrchdtlDTO> srchdtlDtoList, int index, char updateInd)throws ApplicationException;
	
	Map getSrchcolLookUpTable(String srchcolCd) throws ApplicationException ;
	Map getSrchscLookUpTable(String srchscId) throws ApplicationException ;
	Map getSrcherrLookUpTable(String srcherrCd) throws ApplicationException ;
	Map getSrchresLookUpTable(String srchresCd) throws ApplicationException ;

	
	public Map deleteSrchcol(SrchcolDTO srchcolDTO)throws ApplicationException;
	public Map deleteSrchsc(SrchscDTO srchscDTO)throws ApplicationException;
	public Map deleteSrcherr(SrcherrDTO srcherrDTO)throws ApplicationException;
	public Map deleteSrchres(SrchresDTO srchresDTO)throws ApplicationException;
	
	Map addUpdateSrchcol(SrchcolDTO editedSrchcolDTO, List<SrchcolDTO> srchcolDtoList, int index,char updateInd)throws ApplicationException ;
	Map addUpdateSrchsc(SrchscDTO editedSrchscDTO, List<SrchscDTO> srchscDtoList, int index,char updateInd)throws ApplicationException ;
	Map addUpdateSrcherr(SrcherrDTO editedSrcherrDTO, List<SrcherrDTO> srcherrDtoList, int index,char updateInd)throws ApplicationException ;
	Map addUpdateSrchres(SrchresDTO editedSrchresDTO, List<SrchresDTO> srchresDtoList, int index,char updateInd)throws ApplicationException ;
}
