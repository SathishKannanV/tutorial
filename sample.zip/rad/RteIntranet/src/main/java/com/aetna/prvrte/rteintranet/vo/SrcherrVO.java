package com.aetna.prvrte.rteintranet.vo;

public class SrcherrVO {
	
	private String srcherrCd = new String(); 
	private String srcherrCustInd = new String(); 
	private String srcherrDesc = new String(); 
	private String effDate = new String(); 
	private String expDate = new String();
	private String postedDate = new String();
	private char   updatedInd;

	public SrcherrVO() {
		super();
	}

	public SrcherrVO(String srcherrCd, String srcherrCustInd, String srcherrDesc,
					String effDate,	String expDate, String postedDate, char updatedInd) {
		super();
		this.srcherrCd = srcherrCd;
		this.srcherrCustInd = srcherrCustInd;
		this.srcherrDesc = srcherrDesc;
		this.effDate = effDate;
		this.expDate = expDate;
		this.postedDate = postedDate;
		this.updatedInd = updatedInd;
	}

	public String getEffDate() {
		return effDate;
	}

	public String getExpDate() {
		return expDate;
	}

	public String getPostedDate() {
		return postedDate;
	}

	public String getSrcherrDesc() {
		return srcherrDesc;
	}

	public String getSrcherrCd() {
		return srcherrCd;
	}

	public String getSrcherrCustInd() {
		return srcherrCustInd;
	}

	public char getUpdatedInd() {
		return updatedInd;
	}

	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}

	public void setSrcherrDesc(String srcherrDesc) {
		this.srcherrDesc = srcherrDesc;
	}

	public void setSrcherrCd(String srcherrCd) {
		this.srcherrCd = srcherrCd;
	}

	public void setSrcherrCustInd(String srcherrCustInd) {
		this.srcherrCustInd = srcherrCustInd;
	}

	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}


}
