package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.SstypaDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class SstypaDeleteAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(SstypaDeleteAdapter.class);
	
	/**
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public SstypaDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		declareParameter(new SqlParameter(DBConstants.IN_ID, Types.SMALLINT));// param1
		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));// param OUT
	}
	
	/**
	 * Method to delete the Sstypa data from data store.
	 * 
	 * @param sstypaDTO
	 * 
	 * @return Map of flag to delete the data from Sstypa list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map deleteSstypa(SstypaDTO sstypaDTO) throws ApplicationException {
		
		log.warn("Entered SstypaDeleteAdapter  - deleteSstypa");
		boolean isSstypaDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map sstypaMap = new HashMap();
		params.put(DBConstants.IN_ID, RteIntranetUtils.getTrimmedString(sstypaDTO.getId()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("SstypaAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_CODE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) 
				isSstypaDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			sstypaMap.put("sstypaMsg", newMessage);
			sstypaMap.put("isSstypaDeleted", isSstypaDeleted);
			return sstypaMap;
		}catch (Exception exception){
			
			log.error("SstypaAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	
}
