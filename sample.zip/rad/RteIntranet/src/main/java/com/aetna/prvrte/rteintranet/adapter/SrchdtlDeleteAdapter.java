/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.SrchdtlDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.SrchdtlVO;

/**
 * @author N731694
 * 
 */
public class SrchdtlDeleteAdapter extends StoredProcedure {
	/**
	 * 
	 */
	public SrchdtlDeleteAdapter() {
	}

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(SrchdtlDeleteAdapter.class);
	private static final String LS_SRCHDTL_ID = "LS_SRCHDTL_ID";
	private static final String LS_SQL_TYPE = "LS_SQL_TYPE";
	private static final String READ_CURSOR = "READ_CURSOR3";

	/**
	 * 
	 * @param datasource
	 * @param adasvctStoredProc
	 * @throws SQLException
	 */
	@SuppressWarnings("rawtypes")
	public SrchdtlDeleteAdapter(DataSource datasource, String storedProc)
			throws SQLException {
		super(datasource, storedProc);
		log.info(" ------------------> " +storedProc);
		declareParameter(new SqlParameter(LS_SRCHDTL_ID, Types.SMALLINT));   
	
		declareParameter(new SqlOutParameter(LS_SQL_TYPE, Types.INTEGER));
		//declareParameter(new SqlOutParameter(OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper()
		{
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;			//Used by ProcexDisplay, not on database
				SrchdtlVO srchdtlVO=new SrchdtlVO();
				srchdtlVO.setSrchdtlId(rs.getString("SRCHDTL_ID"));
				srchdtlVO.setSrchscFirstId(rs.getString("SRCHSC_FIRST_ID"));
				srchdtlVO.setSrchcolCd(rs.getString("SRCHCOL_CD"));
				srchdtlVO.setSrchresCd(rs.getString("SRCHRES_CD"));
				srchdtlVO.setSrchscSecondId(rs.getString("SRCHSC_SECOND_ID"));
				srchdtlVO.setSrchdtlStCd(rs.getString("SRCHDTL_ST_CD"));
				srchdtlVO.setSrcherrCd(rs.getString("SRCHERR_CD"));
				srchdtlVO.setEffDate(rs.getString("SRCHDTL_EFF_DT"));
				srchdtlVO.setExpDate(rs.getString("SRCHDTL_EXP_DT"));
				srchdtlVO.setPostedDate(rs.getString("SRCHDTL_POSTED_DT"));
				srchdtlVO.setCmRollCode(rs.getString("SRCHDTL_CMROLE_CD"));
				srchdtlVO.setUpdatedInd(updatedInd);
				
				return srchdtlVO;
			}
		}));
	}

	/**
	 * 
	 * @param adasvctDTO
	 * @return
	 */
	public Map<String, Object> deleteSrchdtl(List<SrchdtlVO> srchdtlVOList,	String[] selectedIndexes) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.debug("---- Entering getBplvsLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		String newMessage = "";
		int index;
		try {
			for (int j = selectedIndexes.length - 1; j >= 0; j--) {
				index = Integer.parseInt(selectedIndexes[j]);
				SrchdtlVO existingSrchdtl = (SrchdtlVO) srchdtlVOList
						.get(index);
				if (existingSrchdtl.getUpdatedInd() != 'C') {
					SrchdtlDTO srchdtlDTO = RTETranslator.toSrchdtlDTO(existingSrchdtl);
					 String srchdtlId = srchdtlDTO.getSrchdtlId();
					params.put(LS_SRCHDTL_ID, RteIntranetUtils.getTrimmedString(srchdtlId));
					log.info("Params to put new adavsct : " + params);
					Map<String, Object> results = execute(params);
					String sqlCode = String.valueOf(results.get(LS_SQL_TYPE));
					if ("0".equals(sqlCode)) {
						srchdtlVOList.remove(index);
					} else {
						newMessage = "Deleting of rows failed with a SQLCODE code of "
								+ sqlCode;
						j = 0; // end the for loop
					}
				} else { // update ind = 'C'. Change not written to DB yet, just
							// delete from local object.
					srchdtlVOList.remove(index);
				}
			}
			resultMap.put("srchdtlMessage", newMessage);
			resultMap.put("srchdtlList", srchdtlVOList);
			return resultMap;
		} catch (DataAccessException dae) {
			log.error("SrchdtlDeleteAdapter : Data access excpetion occured "
					+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS,
					dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("AdasvctADA3Adapter : generic error occured  "
					+ exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,
					exception.getMessage(), exception);
		} finally {

		}
	}
	@SuppressWarnings("unchecked")
	public Map deleteSrchdtl(SrchdtlDTO srchdtlDTO) throws ApplicationException {
		
		log.debug("Entered SrchdtlDeleteAdapter  - deleteSrchdtl");
		boolean isSrchdtlDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map srchdtlMap = new HashMap();
		params.put(LS_SRCHDTL_ID, RteIntranetUtils.getTrimmedString(srchdtlDTO.getSrchdtlId()));
	
		log.debug(params);	
		try {
			results = execute(params);
			log.debug("SrchdtlDeleteAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(LS_SQL_TYPE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) 
				isSrchdtlDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			srchdtlMap.put("srchdtlMsg", newMessage);
			srchdtlMap.put("isSrchdtlDeleted", isSrchdtlDeleted);
			return srchdtlMap;
		}catch (Exception exception){
			
			log.error("SrchdtlDeleteAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	
}
