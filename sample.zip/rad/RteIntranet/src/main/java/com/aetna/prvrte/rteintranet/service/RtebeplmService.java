/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.RtebeplmDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public interface RtebeplmService {

	Map getRtebeplmLookUpTable(RtebeplmDTO rtebeplmDTO) throws ApplicationException ;

	Map deleteRtebeplm(RtebeplmDTO rtebeplmDTO) throws ApplicationException ;

	Map addUpdateRtebeplm(RtebeplmDTO existRtebeplmDTO, List<RtebeplmDTO> rtebeplmDtoList, int index, char updateInd) throws ApplicationException ;

}
