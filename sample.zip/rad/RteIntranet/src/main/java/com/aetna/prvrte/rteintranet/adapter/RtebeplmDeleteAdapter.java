/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RtebeplmDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RtebeplmDeleteAdapter extends StoredProcedure{

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RtebeplmDeleteAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtebeplmDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_RTEBEPLM_BNFT_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_RTEBEPLM_FREQ_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_RTEBEPLM_EFF_DT, Types.DATE));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
	}
	
	@SuppressWarnings("unchecked")
	public Map deleteRtebeplm(RtebeplmDTO rtebeplmDTO) throws ApplicationException {
		
		log.warn("Entered RtebeplmDeleteAdapter  - deleteRtebeplm");
		boolean isRtebeplmDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map rtebeplmMap = new HashMap();
			
		params.put(DBConstants.LS_RTEBEPLM_BNFT_CD, RteIntranetUtils.getTrimmedString(rtebeplmDTO.getHmoBenefitCd()));
		params.put(DBConstants.LS_RTEBEPLM_FREQ_IND, RteIntranetUtils.getTrimmedString(rtebeplmDTO.getFrequencyInd()));
		params.put(DBConstants.LS_RTEBEPLM_EFF_DT, RteIntranetUtils.getTrimmedString(rtebeplmDTO.getEffDate()));
		
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("RtebeplmDeleteAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) 
				isRtebeplmDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			rtebeplmMap.put("rtebeplmMessage", newMessage);
			rtebeplmMap.put("isRtebeplmDeleted", isRtebeplmDeleted);
			return rtebeplmMap;
		}catch (Exception exception){
			
			log.error("RtebeplmDeleteAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	
}
