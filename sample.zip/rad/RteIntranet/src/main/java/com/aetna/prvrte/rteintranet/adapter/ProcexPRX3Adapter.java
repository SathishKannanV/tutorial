/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class ProcexPRX3Adapter extends StoredProcedure{
	private final Log log = LogFactory.getLog(ProcexPRX3Adapter.class);
	public ProcexPRX3Adapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.IN_PROCEX_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_SVCTYP_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
	}
	
	
	@SuppressWarnings("unchecked")
	public Map deleteProcex(String procexCd, String svcTypeCd) throws ApplicationException {
		
		log.warn("Entered ProcexPRX3Adapter  - deleteProcex");
		boolean isProcexDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map procexMap = new HashMap();
		Date todaysDate = new Date(System.currentTimeMillis());
		String postedDate = todaysDate.toString();
		params.put(DBConstants.IN_PROCEX_CD, RteIntranetUtils.getTrimmedString(procexCd));
		params.put(DBConstants.IN_SVCTYP_CD, RteIntranetUtils.getTrimmedString(svcTypeCd));
		
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("ProcexAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) 
				isProcexDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			procexMap.put("procexMsg", newMessage);
			procexMap.put("isProcxDeleted", isProcexDeleted);
			return procexMap;
		}catch (Exception exception){
			
			log.error("ProcexAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	
}
