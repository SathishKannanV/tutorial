/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.AdasvctDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.AdasvctVO;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class AdasvctAddAdapter extends StoredProcedure {

	public AdasvctAddAdapter() {}
	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(AdasvctAddAdapter.class);
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public AdasvctAddAdapter(DataSource datasource, String adasvctStoredProc)
			throws SQLException {
		super(datasource, adasvctStoredProc);
		log.info(" ------------------> " + adasvctStoredProc);
		declareParameter(new SqlParameter(DBConstants.LS_ADASVCT_ADA_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_SVCTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_ADASVCT_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.LS_ADASVCT_EXP_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.LS_ADASVCT_POSTED_DT, Types.DATE));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
	}
	/**
	 * Method to add new ADASVCT to data store.
	 * 
	 * @param adasvctDTO
	 *            adasvctDTO object.
	 * @return Map of added ADASVCT data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	public Map<String, Object> addAdasvctToDb(AdasvctDTO adasvctDTO)throws ApplicationException {
		char updatedInd = ApplicationConstants.UPDATE_IND_Y;
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<AdasvctVO> adasvctList = new LinkedList<AdasvctVO>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String newMessage = "";
		try {
			String postedDate = RteIntranetUtils.getTodaysDate();
			String adaCd = RteIntranetUtils.getTrimmedString(adasvctDTO.getAdaCd());
			String svcTypeCd = RteIntranetUtils.getTrimmedString(adasvctDTO.getSvcTypeCd());
			String effDate = RteIntranetUtils.getTrimmedString(adasvctDTO.getEffDate());
			String expDate = RteIntranetUtils.getTrimmedString(adasvctDTO.getExpDate());
			
			//query params		
			params.put(DBConstants.LS_ADASVCT_ADA_CD, adaCd);
			params.put(DBConstants.LS_SVCTYP_CD, svcTypeCd);
			params.put(DBConstants.LS_ADASVCT_EFF_DT, effDate);
			params.put(DBConstants.LS_ADASVCT_EXP_DT, expDate);
			params.put(DBConstants.LS_ADASVCT_POSTED_DT, postedDate);
			
			log.info("Params to put new adavsct : " + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			
			if ("0".equals(sqlCode)) {
				String actionCode = String.valueOf(results.get(DBConstants.LS_ADD_UPDATE));
				if ("0".equals(actionCode)) {
					newMessage = ApplicationConstants.ROW_ADDED;
				} else {
					newMessage = ApplicationConstants.ROW_ALREADY_EXISTS;
					updatedInd = ApplicationConstants.COPY;
				}
				AdasvctVO adasvctVO = new AdasvctVO(adaCd, svcTypeCd, effDate, expDate, postedDate, updatedInd);
				adasvctList.add(adasvctVO);
			} else {
				newMessage = ApplicationConstants.ADD_ROW_FAILS + sqlCode;
			}
			
			resultMap.put("adasvctMsg", newMessage);
			resultMap.put("adasvctList", adasvctList);
		} catch (DataAccessException dae) {
			log.error("AdasvctAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("AdasvctAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
		return resultMap;
	}
	
	/**
	 * Method to add/update list of ADASVCT to data store.
	 * 
	 * @param adasvctDTO
	 *            adasvctDTO object.
	 * @param adasvctDTOList
	 *            list of adasvctDTO object.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from ADASVCT list, success or
	 *         error message and list of ADASVCT.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	public Map<String, Object> addUpdateAdasvct(AdasvctDTO existingAdasvct,List<AdasvctDTO> adasvctDTOList, int index) throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String newMessage = "";
		String sqlCode ="";
		boolean isAdasvctAddorUpdated = false;
		boolean isAddUpdateCleanUp = false;
		String postedDate = RteIntranetUtils.getTodaysDate();
		
		String adaCd = RteIntranetUtils.getTrimmedString(existingAdasvct.getAdaCd());
		String svcTypeCd = RteIntranetUtils.getTrimmedString(existingAdasvct.getSvcTypeCd());
		String effDate = RteIntranetUtils.getTrimmedString(existingAdasvct.getEffDate());
		String expDate = RteIntranetUtils.getTrimmedString(existingAdasvct.getExpDate());
		
		params.put(DBConstants.LS_ADASVCT_ADA_CD, adaCd);
		params.put(DBConstants.LS_SVCTYP_CD, svcTypeCd);
		params.put(DBConstants.LS_ADASVCT_EFF_DT, effDate);
		params.put(DBConstants.LS_ADASVCT_EXP_DT, expDate);
		params.put(DBConstants.LS_ADASVCT_POSTED_DT, postedDate);

		log.info("Params to put new adavsct : " + params);
		try{
			Map<String, Object> results = execute(params);
			sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			String actionCode =  String.valueOf(results.get(DBConstants.LS_ADD_UPDATE));
			AdasvctDTO aAdasvct = new AdasvctDTO(adaCd, svcTypeCd, effDate,
								expDate, postedDate, ApplicationConstants.UPDATE_IND_Y);
			if ("0".equalsIgnoreCase(sqlCode)) {
				isAddUpdateCleanUp = true;
				if ("1".equalsIgnoreCase(actionCode)) {
					if (existingAdasvct.getUpdatedInd() == ApplicationConstants.COPY){
						adasvctDTOList.set(index, aAdasvct);	
					} else {
						adasvctDTOList.add(aAdasvct);
					}
				} else
					adasvctDTOList.set(index, aAdasvct);
			} else {
				isAdasvctAddorUpdated = true;
				newMessage = ApplicationConstants.ADD_UPDATE_ROW_FAILS + sqlCode;
			}
			resultMap.put("adasvctMsg", newMessage);
			resultMap.put("adasvctList", adasvctDTOList);
			resultMap.put("isAdasvctAddorUpdated", isAdasvctAddorUpdated);
			resultMap.put("isAddUpdateCleanUp", isAddUpdateCleanUp);
			return resultMap;
		}catch (DataAccessException dae) {
			log.error("AdasvctAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("AdasvctAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
	}
}
