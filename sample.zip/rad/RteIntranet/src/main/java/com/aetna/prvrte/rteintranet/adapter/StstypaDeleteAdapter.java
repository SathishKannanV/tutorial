package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.StstypaDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class StstypaDeleteAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(StstypaDeleteAdapter.class);

	
	/**
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public StstypaDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		declareParameter(new SqlParameter(DBConstants.IN_ID, Types.SMALLINT));// param1
		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));// param OUT
	}
	
	/**
	 * Method to delete the Ststypa data from data store.
	 * 
	 * @param ststypaDTO
	 * 
	 * @return Map of flag to delete the data from Ststypa list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map deleteStstypa(StstypaDTO ststypaDTO) throws ApplicationException {
		
		log.warn("Entered StstypaDeleteAdapter  - deleteStstypa");
		boolean isStstypaDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map ststypaMap = new HashMap();
		params.put(DBConstants.IN_ID, RteIntranetUtils.getTrimmedString(ststypaDTO.getId()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("StstypaAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_CODE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) 
				isStstypaDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			ststypaMap.put("ststypaMsg", newMessage);
			ststypaMap.put("isStstypaDeleted", isStstypaDeleted);
			return ststypaMap;
		}catch (Exception exception){
			
			log.error("StstypaAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	
}
