package com.aetna.prvrte.rteintranet.service;

import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.LongRunTransactionDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

public interface LongRunTransLookUpService {

	Map getLongRunTransLookUpList(LongRunTransactionDTO longrunTransDTO) throws ApplicationException;
}
