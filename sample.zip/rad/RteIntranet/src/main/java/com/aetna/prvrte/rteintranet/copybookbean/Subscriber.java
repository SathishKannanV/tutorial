package com.aetna.prvrte.rteintranet.copybookbean;


public class Subscriber {

	String ssn;
	Name name;
	String dob;
	String gender;
	String coverageTerminationDate;
	public String getSsn() {
		
		return ssn;
	}
	public void setSsn(String ssn) {
		
		this.ssn = ssn;
	}
	public Name getName() {
		return name;
	}
	public void setName(Name name) {
		this.name = name;
	}
	public String getDob() {
		
		return dob;
	}
	public void setDob(String dob) {
		dob=dob.replaceAll("-", "");
		
		this.dob = dob;
	}
	public String getGender() {
		
		return gender;
	}
	public void setGender(String gender) {
		
		this.gender = gender;
	}
	public String getCoverageTerminationDate() {
		
		return coverageTerminationDate;
	}
	public void setCoverageTerminationDate(String coverageTerminationDate) {
		coverageTerminationDate=coverageTerminationDate.replaceAll("-", "");
		
		this.coverageTerminationDate = coverageTerminationDate;
	}
	public StringBuilder getSubscriber(){
		return new StringBuilder(getSsn())
		.append(name.getName())
		.append(getDob())
		.append(getGender())
		.append(getCoverageTerminationDate());
	}
}
