/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RbrcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RbrcLookUpAdapter extends StoredProcedure{
	private final Log log = LogFactory.getLog(RbrcLookUpAdapter.class);
	
	public RbrcLookUpAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_SITE_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_RIDER_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_SVCTYP_CD, Types.CHAR));
		
		declareParameter(new SqlParameter(DBConstants.LS_SQL_TYPE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR1, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N; //Used by RBrCDisplay, not on database
				RbrcDTO rbrcDTO = new RbrcDTO();
				rbrcDTO.setDbSiteCd(rs.getString("SITE_CD"));
				rbrcDTO.setDbRiderCd(rs.getString("RIDER_CD"));
				rbrcDTO.setDbSvcTypeCd(rs.getString("RBRC_SVCTYP_CD"));
				rbrcDTO.setDbPostedDate(rs.getString("RBRC_SRCE_PSTD_DT"));
				rbrcDTO.setDbDescTxt(rs.getString("RBRC_DESC_TXT"));
				rbrcDTO.setDbIONtwkCd(rs.getString("RBRC_IONTWK_CD"));
				rbrcDTO.setDbTOSCd(rs.getString("TOS_CD"));
				rbrcDTO.setDbHMOSrcBnInd(rs.getString("RBRC_HMOSRCBN_IND"));
				rbrcDTO.setTextSendInd(rs.getString("RBRC_TXT_SND_CD"));
				rbrcDTO.setPrevCareInd(rs.getString("PREV_CARE_IND"));
				rbrcDTO.setGenderCd(rs.getString("GENDER_CD"));
				rbrcDTO.setDbUpdatedInd(updatedInd);
				return rbrcDTO;
			}

		}));

	}
	
	/**
	 * @param rbrcDTO
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	public Map getRbrcLookUp (RbrcDTO rbrcDTO) throws ApplicationException {
		log.warn("Entered RbrcLookUpAdapter  - getRbrcLookUp");
		//It fetches rbrc lookup based on the criteria selected by user
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map rbrcMap = new HashMap();
		int searchCd ;
		String siteCode = RteIntranetUtils.getTrimmedString(rbrcDTO.getDbSiteCd());
		String riderCode = RteIntranetUtils.getTrimmedString(rbrcDTO.getDbRiderCd());
		String svcTypeCode = RteIntranetUtils.getTrimmedString(rbrcDTO.getDbSvcTypeCd());
		
		if (!siteCode.equals("")) {
			if (!riderCode.equals("")) {
				if (!svcTypeCode.equals("")) {
					searchCd = 3;
				} else {
					searchCd = 4;
				}		
			} else {		
				if (!svcTypeCode.equals("")) {
					searchCd = 2;
				} else { 
					searchCd = 1;
					}		
				}
		} else {
				searchCd = 0;
		}
		
		params.put(DBConstants.LS_SITE_CD, siteCode);
		params.put(DBConstants.LS_RIDER_CD, riderCode);
		params.put(DBConstants.LS_SVCTYP_CD, svcTypeCode);		
		params.put(DBConstants.LS_SQL_TYPE, String.valueOf(searchCd));
		log.warn(params);
		Map results = null;
		
		List<RbrcDTO> rbrcList  = new LinkedList<RbrcDTO>();
		String newMessage="";
		int noOfElements;
		try {
			log.warn("RbrcLookUpAdapter: Executing stored procedure : " + "siteCode : " + siteCode + " ; riderCode : "+riderCode
					+"; svcTypeCode : "+ svcTypeCode +"; searchCd : "+ searchCd);
					
			results = execute(params);
			log.warn("RbrcLookUpAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			rbrcList = (List<RbrcDTO>) results
					.get(DBConstants.READ_CURSOR1);	
	
			noOfElements = rbrcList.size();
			//if (null != results) {
			if (rbrcList.isEmpty()){
				
				if ("0".equals(sqlCode)) {
					newMessage = "No Data for ";
					newMessage = getMessage(newMessage, siteCode, riderCode, svcTypeCode);
				} else {
					newMessage = "Problem in DB2. sqlcode: " + sqlCode; 
					newMessage = getMessage(newMessage, siteCode, riderCode, svcTypeCode);
				}			  		  		  
			} else {
				if (noOfElements > 1) {
			    	newMessage = noOfElements + " Rows found for ";
				} else {
			    newMessage = noOfElements + " Row found for ";
				}
				newMessage = getMessage(newMessage, siteCode, riderCode, svcTypeCode);
			}
			/*}else{
				newMessage = "You must enter a Site Code with or without combination of Rider Code and/or Service Type Code on the Look Up page.";
			}*/
			rbrcMap.put("rbrcMessage", newMessage);
			rbrcMap.put("rbrcList",rbrcList);
			return rbrcMap;
		}catch (Exception exception){
			log.error("RbrcLookUpAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
		
	}
	
	/**
	 * @param newMessage
	 * @param querySiteCd
	 * @param queryRiderCd
	 * @param querySvcTypeCd
	 * @return
	 */
	public String getMessage (String newMessage, String querySiteCd, String queryRiderCd, String querySvcTypeCd) {
		String getMessage = newMessage;
	    if (!"".equals(querySiteCd)) 
		    getMessage = getMessage + " Site  : " + querySiteCd;
		    if (!"".equals(queryRiderCd))
  		    getMessage = getMessage + " Rider  : " + queryRiderCd;
	    if (!"".equals(querySvcTypeCd))
		    getMessage = getMessage + " Service Type  : " + querySvcTypeCd;
		return getMessage;
}
	
	
	
}
