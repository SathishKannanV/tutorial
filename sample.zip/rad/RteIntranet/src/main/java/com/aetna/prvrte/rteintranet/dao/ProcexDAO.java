/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 *
 */
public interface ProcexDAO {

	Map getProcexLookUpTable(String procexCode, String svcTypeCode) throws ApplicationException ;

	Map addNewProcex(ProcexDTO procexDTO) throws ApplicationException ;

	Map deleteProcex(String procexCd, String svcTypeCd) throws ApplicationException ;

	Map addUpdateProcex(ProcexDTO existProcexDTO, List<ProcexDTO> procexDtoList, int index, char updateInd) throws ApplicationException ;

}
