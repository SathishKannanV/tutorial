/**
 * 
 */
package com.aetna.prvrte.rteintranet.dto;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RtedictrDTO {
	private String rtestypCd = "";
	private String ditemCd = "";
	private String dictCd = "";
	private String effDt = "";
	private String expDt = "";
	private String postedDateTimeStamp = "";
	private String userId = "";
	private int    messageId; 
	private String messageTypeCd = "";
	private String shortText = "";
	private String fullText = "";
	private char   updatedInd;
	/**
	 * @return the rtestypCd
	 */
	public String getRtestypCd() {
		return rtestypCd;
	}
	/**
	 * @param rtestypCd the rtestypCd to set
	 */
	public void setRtestypCd(String rtestypCd) {
		this.rtestypCd = rtestypCd;
	}
	/**
	 * @return the ditemCd
	 */
	public String getDitemCd() {
		return ditemCd;
	}
	/**
	 * @param ditemCd the ditemCd to set
	 */
	public void setDitemCd(String ditemCd) {
		this.ditemCd = ditemCd;
	}
	/**
	 * @return the dictCd
	 */
	public String getDictCd() {
		return dictCd;
	}
	/**
	 * @param dictCd the dictCd to set
	 */
	public void setDictCd(String dictCd) {
		this.dictCd = dictCd;
	}
	/**
	 * @return the effDt
	 */
	public String getEffDt() {
		return effDt;
	}
	/**
	 * @param effDt the effDt to set
	 */
	public void setEffDt(String effDt) {
		this.effDt = effDt;
	}
	/**
	 * @return the expDt
	 */
	public String getExpDt() {
		return expDt;
	}
	/**
	 * @param expDt the expDt to set
	 */
	public void setExpDt(String expDt) {
		this.expDt = expDt;
	}
	/**
	 * @return the postedDateTimeStamp
	 */
	public String getPostedDateTimeStamp() {
		return postedDateTimeStamp;
	}
	/**
	 * @param postedDateTimeStamp the postedDateTimeStamp to set
	 */
	public void setPostedDateTimeStamp(String postedDateTimeStamp) {
		this.postedDateTimeStamp = postedDateTimeStamp;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the messageId
	 */
	public int getMessageId() {
		return messageId;
	}
	/**
	 * @param messageId the messageId to set
	 */
	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}
	/**
	 * @return the messageTypeCd
	 */
	public String getMessageTypeCd() {
		return messageTypeCd;
	}
	/**
	 * @param messageTypeCd the messageTypeCd to set
	 */
	public void setMessageTypeCd(String messageTypeCd) {
		this.messageTypeCd = messageTypeCd;
	}
	/**
	 * @return the shortText
	 */
	public String getShortText() {
		return shortText;
	}
	/**
	 * @param shortText the shortText to set
	 */
	public void setShortText(String shortText) {
		this.shortText = shortText;
	}
	/**
	 * @return the fullText
	 */
	public String getFullText() {
		return fullText;
	}
	/**
	 * @param fullText the fullText to set
	 */
	public void setFullText(String fullText) {
		this.fullText = fullText;
	}
	/**
	 * @return the updatedInd
	 */
	public char getUpdatedInd() {
		return updatedInd;
	}
	/**
	 * @param updatedInd the updatedInd to set
	 */
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}


}
