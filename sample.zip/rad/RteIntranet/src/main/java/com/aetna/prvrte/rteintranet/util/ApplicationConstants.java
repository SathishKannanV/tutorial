/**
 * 
 */
package com.aetna.prvrte.rteintranet.util;

/**
 * @author N657186
 * Cognizant_Offshore
 */
/**
 * A Constants class used throughout the application
 * 
 */

public interface ApplicationConstants {

	/**
	 * Error code data access
	 */
	public static final String ERR_IR_ACCESS = "error.inq.accces";

	/**
	 * Error code for no data
	 */
	public static final String ERR_IR_NODATA = "error.inq.nodata";

	/**
	 * Error code for no data
	 */
	public static final String ERR_GENERIC = "error.generic";
	
	public static final String RTE_INTRANET_USER_ROLE = "rteIntranet_userRole_key";
	public static final String WELCOME = "Welcome ";
	public static final String MDDRteDb2 = "MDDRteDb2";
	public static final String RTEWrite = "RTEWrite";

	/** * constant for Error Page */
	public static final String ERROR_PAGE = ".errorMsgDisplay";
	public static final String EXCP_ERR_MESSAGE = "expErrorMsg";
	public static final String ZERO_0 = "0";
	public static final char COPY = 'C';
	public static final char UPDATE_IND_N = 'N';
	public static final char UPDATE_IND_Y = 'Y';
	public static final int UPDATE_IND_1 = 1;
	public static final String ADD = "A";
	public static final int ZERO = 0;
	public static final char COMMA = ',';
	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String USER = "user";
	public static final String EMPTY = " ";
	public static final String DOUBLE_QUOTES = "\"";
	/**
	 * User Security Levelconstants.
	 */
	public static final String USER_SECURITY_LEVEL_R = "R";
	public static final String USER_SECURITY_LEVEL_B = "B";
	public static final String USER_SECURITY_LEVEL_A ="RW";
	public static final String USER_SECURITY_LEVEL_W ="W";
	/**
	 * DB Message Constants.
	 */
	public static final String NO_ACTION_TAKEN = "Take action was not selected for any of the displayed rows";
	public static final String ROWS_DELETED = "Rows selected were Deleted in the database/list";
	public static final String ROWS_COPIED = "Copied rows were placed at the bottom of the list and highlighted.";
	public static final String ADD_UPDATE_ROWS = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted.";
	public static final String EXPORT_SUCCESS = "LookUp table exported successfully.";
	public static final String NO_DATA = "No data found.";
	public static final String ROW_ADDED = "This row added to the database";
	public static final String ROW_ALREADY_EXISTS = "Row already exists on the database. It was updated with entered values.";
	public static final String ADD_ROW_FAILS = "Unable to add row to the database. SQLCODE = ";
	public static final String ADD_UPDATE_ROW_FAILS = "Adding/updating of rows failed with a SQLCODE code of ";
	public static final String DELETE_ROW_FAILS = "Deleting of rows failed with a SQLCODE code of ";
	/**
	 * Controller Error Message Constants.
	 */
	public static final String ERROR_LOOKUP_VIEW = "Error encountered when loading lookup page. ";
	public static final String ERROR_GET_LOOKUP = "Error encountered when extracting data from the database ";
	public static final String ERROR_ADD_VIEW = "Error encountered when loading add form. ";
	public static final String ERROR_ADD_ROW = "Error encountered when adding a row to the database ";
	public static final String ERROR_DELETE_ROW = "Error encountered when deleting rows from database. ";
	public static final String ERROR_COPY_ROW = "Error encountered when copying data. ";
	public static final String ERROR_ADD_UPDATE_ROW = "Error encountered when Add/Updating to database. ";
	public static final String ERROR_EXPOT_TABLE  = "Error encountered when export lookup table to excel. ";
	/**
	 * 
	 */
	public static final String NO_AUTHORITY  = "You do not have sufficient authority to view or change this table.";
	public static final String SESSION_EXPIRED  = "User session time-out. Please login again to continue.";
	
	public static final String ERROR_IN_BULK_SUBMIT = "Error encountered when extracting data from the database.  java.lang.IllegalArgumentException ";
	
	/*	Begin #Resource_Type_Cognizant_Offshore #Resource_ID_N742407 updated for SR P08-P23175a */

	public static final String M1 = "M1"; // Added for RTE Dental and  tables
	public static final String M2 = "M2";
	public static final String M3 = "M3";
	public static final String M4 = "M4";

	public static final String T1 = "T1"; // Added for RTE traditional and  tables
	public static final String T2 = "T2";
	public static final String T3 = "T3";
	public static final String T4 = "T4";
	public static final String T5 = "T5";
	public static final String T6 = "T6";
	public static final String T7 = "T7";
	public static final String T8 = "T8";
/*	End #Resource_Type_Cognizant_Offshore #Resource_ID_N742407 updated for SR P08-P23175a */
}
