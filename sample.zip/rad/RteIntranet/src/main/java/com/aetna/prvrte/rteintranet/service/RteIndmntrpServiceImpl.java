/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.RteIndmntrpDAO;
import com.aetna.prvrte.rteintranet.dto.IndmntrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.service.RteIndmntrpService
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Service
public class RteIndmntrpServiceImpl implements RteIndmntrpService {
	/*
	 * Instance of RteIndmntrpDAO.
	 */
	@Autowired(required=true)
	private RteIndmntrpDAO rteIndmntrpDAO;
	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteIndmntrpService#getIndmntrpLookUpList(com.aetna.prvrte.rteintranet.dto.IndmntrpDTO)
	 */
	@Override
	public Map<String, Object> getIndmntrpLookUpList(IndmntrpDTO indmntrpDTO) throws ApplicationException {
		return rteIndmntrpDAO.getIndmntrpLookUpList(indmntrpDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteIndmntrpService#addIndmntrpToDb(com.aetna.prvrte.rteintranet.dto.IndmntrpDTO)
	 */
	@Override
	public Map<String, Object> addIndmntrpToDb(IndmntrpDTO indmntrpDTO) throws ApplicationException {
		return rteIndmntrpDAO.addIndmntrpToDb(indmntrpDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteIndmntrpService#deleteIndmntrp(com.aetna.prvrte.rteintranet.dto.IndmntrpDTO)
	 */
	@Override
	public Map<String, Object> deleteIndmntrp(IndmntrpDTO indmntrpDTO) throws ApplicationException {
		return rteIndmntrpDAO.deleteIndmntrp(indmntrpDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteIndmntrpService#addUpdateIndmntrp(com.aetna.prvrte.rteintranet.dto.IndmntrpDTO, java.util.List, int)
	 */
	@Override
	public Map<String, Object> addUpdateIndmntrp(IndmntrpDTO indmntrpDTO, List<IndmntrpDTO> indmntrpList, int index) throws ApplicationException {
		return rteIndmntrpDAO.addUpdateIndmntrp(indmntrpDTO, indmntrpList, index);
	}
	

}
