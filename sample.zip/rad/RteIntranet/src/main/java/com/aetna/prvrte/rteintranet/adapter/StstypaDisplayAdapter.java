package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.StstypaDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.StstypaVO;


/**
 * @author N624926
 * Cognizant_Offshore
 */
public class StstypaDisplayAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(StstypaDisplayAdapter.class);

	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public StstypaDisplayAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_STSTYPA_ST_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_STSTYPA_COLL_CD, Types.CHAR));

		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR3, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd =  ApplicationConstants.UPDATE_IND_N;			//Used by StstypaDisplay, not on database
				StstypaDTO ststypaDTO = new StstypaDTO();
				ststypaDTO.setId(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.STSTYPA_ID)));
				ststypaDTO.setStateCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.STSTYPA_ST_CD)));
				ststypaDTO.setCollectionCode(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.STSTYPA_COLL_CD)));
				ststypaDTO.setIndividualCode(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.STSTYPA_INDV_CD)));
				ststypaDTO.setEffDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.STSTYPA_EFF_DT)));
				ststypaDTO.setExpDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.STSTYPA_EXP_DT)));
				ststypaDTO.setPostedDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.STSTYPA_POSTED_DT)));
				ststypaDTO.setVersionReleaseCode(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.STSTYPA_VERSNRLS_CD)));					
				ststypaDTO.setUpdatedInd(updatedInd);
				return ststypaDTO;
			}

		}));

	}
	
	
	/**
	 * Method to get the STSTYPA list from data store.
	 * 
	 * @param ststypaDTO
	 * 			ststypaDTO parameter
	 * 
	 * @return Map of STSTYPA list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map getStstypaLookUpTable (StstypaDTO ststypaDTO) throws ApplicationException {
		log.warn("Entered StstypaAdapter  - getStstypaLookUpTable");
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map ststypaMap = new HashMap();
		params.put(DBConstants.LS_STSTYPA_ST_CD, RteIntranetUtils.getTrimmedString(ststypaDTO.getStateCd()));
		params.put(DBConstants.LS_STSTYPA_COLL_CD, RteIntranetUtils.getTrimmedString(ststypaDTO.getCollectionCode()));
		log.warn(params);
		Map results = null;
		
		List<StstypaVO> ststypaList= new LinkedList<StstypaVO>();
		String newMessage="";
		try {
			log.warn("StstypaAdapter: Executing stored procedure : ");
			results = execute(params);
			log.warn("StstypaAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			ststypaList = (List<StstypaVO>) results
					.get(DBConstants.READ_CURSOR3);	
	
			if (ststypaList.isEmpty()){
				
				if (ApplicationConstants.ZERO_0.equals(sqlCode)) {

					newMessage = "No Data on database for No Data on database for Collection Cd: " + ststypaDTO.getCollectionCode()+" State Cd:"+ststypaDTO.getStateCd();
				} else {
					newMessage = "Problem in DB2. sqlcode: " + sqlCode + " Collection Cd: " + ststypaDTO.getCollectionCode()+" State Cd:"+ststypaDTO.getStateCd();
				}			  		  		  
			} else {
				newMessage = "Data found on database for Collection Cd: " + ststypaDTO.getCollectionCode()+" State Cd:"+ststypaDTO.getStateCd();
				}
			ststypaMap.put("newMessage", newMessage);
			ststypaMap.put("ststypaList",ststypaList);
			return ststypaMap;
		}catch (Exception exception){
			log.error("StstypaAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
		
}
