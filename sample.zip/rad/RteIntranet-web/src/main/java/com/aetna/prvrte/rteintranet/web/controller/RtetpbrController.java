package com.aetna.prvrte.rteintranet.web.controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.aetna.prvrte.rteintranet.dto.RtetpbrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.RtetpbrVO;
import com.aetna.prvrte.rteintranet.vo.UserVO;

/**
 * The Rtetpbr Controller is responsible for handling
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * @author N624926
 * Cognizant_Offshore
 */

@Controller
@RequestMapping(value = "/rtetpbr/*")
public class RtetpbrController {

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(RtetpbrController.class);
	/*
	 * Tile name of the rtetpbr Home view.
	 */
	public static final String RTETPBR_HOME = ".rtetpbrHome";
	/*
	 * Tile name of the rtetpbr Display view.
	 */
	public static final String RTETPBR_LOOKUP = ".rtetpbrLookUpDisplay";
	/*
	 * Tile name of the Add New rtetpbr Form view.
	 */
	public static final String RTETPBR_ADD = ".rtetpbrAdd";
	/*
	 * Constant name used for COPY indicator.
	 */
	public static final char COPY = 'C';
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errormav;
	
	
	/**
	 * Method to getRtetpbrLookUpHome view
	 * 
	 * @param model
	 * 
	 * @return view of rtetpbrLookUp, if fails return error page
	 */
	@RequestMapping(value="/rtetpbrHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRtetpbrLookUpHome(final HttpServletRequest request,Model model) {	   
		
		log.warn("Entered RtetpbrController - getRtetpbrLookUpHome()");
		String securityLevel ="";
		try {
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(RTETPBR_HOME, "rtetpbrVO",  new RtetpbrVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("RtetpbrController - securityLevel: "+ securityLevel);
		log.warn("Exit from RtetpbrController - getRtetpbrLookUpHome()");
		return mav;
		} catch (ApplicationException e){
			log.error("Exception occured in RtetpbrController - getRtetpbrLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * Method to get the rtetpbrLookUp List from data store.
	 * 
	 * @param rtetpbrVO
	 *            form view object of rtetpbr.
	 * @return view of rtetpbrDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherRtetpbr", method = RequestMethod.POST)
	public ModelAndView getRtetpbrLookUpTable(HttpServletRequest request,@ModelAttribute("rtetpbrForm")RtetpbrVO rtetpbrVO){
		String idNo ="";
		String securityLevel ="";
		String effDate;
		ModelAndView mav ;
		Map rtetpbrResultMap = new HashMap();
		List<RtetpbrVO> rtetpbrList = new LinkedList<RtetpbrVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			idNo = rtetpbrVO.getIdNo();
			effDate =  rtetpbrVO.getEffDate();
			rtetpbrResultMap = facade.getRtetpbrLookUpTable(idNo,effDate);
			rtetpbrList = (List<RtetpbrVO>) rtetpbrResultMap.get("rtetpbrList");
			lookUpListVO.setRtetpbrVOList(rtetpbrList);
			facade.getApplicationState().setRtetpbrList(rtetpbrList);
			mav = new ModelAndView(RTETPBR_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("rtetpbrMessage", rtetpbrResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("getRtetpbrLookUpTable - rtetpbrMessage: "+ rtetpbrResultMap.get("newMessage"));
			log.warn("Exit from RtetpbrController - getRtetpbrLookUpTable()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtetpbrController - getRtetpbrLookUpTable() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="getRtetpbrLookUpTable() :"+ApplicationConstants.ERROR_GET_LOOKUP + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to display get add new Rtetpbr form home view.
	 * 
	 * @return view of loadAddNewRtetpbrRowScreen, if fails return error page
	 */
	@RequestMapping(value="/AddNewRtetpbrRow")
	public ModelAndView loadAddNewRtetpbrRowScreen(final HttpServletRequest request,Model model) {	   
	log.warn("Entered RtetpbrController - loadAddNewRtetpbrRowScreen()");
	ModelAndView mav = new ModelAndView(RTETPBR_ADD, "rtetpbrVO",  new RtetpbrVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in RtetpbrController - loadAddNewRtetpbrRowScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (loadAddNewRtetpbrRowScreen). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	log.warn("Exit from RtetpbrController - loadAddNewRtetpbrRowScreen()");
	return mav;
	}
	
	
	/**
	 * Method to add the data database
	 * 
	 * @param rtetpbrVO form view object of Rtetpbr.
	 * @param request request object for Rtetpbr to get userVO          
	 * @return view of rtetpbrDisplay, if fails return error page
	 * 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddRtetpbr", method = RequestMethod.POST)
	public ModelAndView addNewRtetpbr(@ModelAttribute("addRtetpbrForm")RtetpbrVO rtetpbrVO,final HttpServletRequest request){
		log.warn("Entered RtetpbrController - addNewRtetpbr()");
		ModelAndView mav ;
		Map rtetpbrResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<RtetpbrDTO> rtetpbrDtoList = new LinkedList<RtetpbrDTO>();
		List<RtetpbrVO> rtetpbrVoList = new LinkedList<RtetpbrVO>();
		String securityLevel ="";
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtetpbrVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
            String userId = RteIntranetUtils.getUserId(request); //Ex: n242716
			rtetpbrVO.setUserId(userId);
			RtetpbrDTO rtetpbrDTO = RTETranslator.toRtetpbrDTO(rtetpbrVO);
			rtetpbrResultMap = facade.addNewRtetpbr(rtetpbrDTO);
			if(rtetpbrResultMap.get("rtetpbrList")!=null){
				rtetpbrDtoList = (List<RtetpbrDTO>) rtetpbrResultMap.get("rtetpbrList");
				rtetpbrVoList = RTETranslator.toRtetpbrVOList(rtetpbrDtoList);
			}
			lookUpListVO.setRtetpbrVOList(rtetpbrVoList);
			facade.getApplicationState().setRtetpbrList(rtetpbrVoList);
			mav = new ModelAndView(RTETPBR_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("securityLevel", securityLevel);
			mav.addObject("rtetpbrMessage", rtetpbrResultMap.get("rtetpbrMessage"));
			log.warn("addNewRtetpbr() - rtetpbrMessage: "+ rtetpbrResultMap.get("rtetpbrMessage"));
			log.warn("Exit from RtetpbrController - addNewRtetpbr()");	
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtetpbrController - addNewRtetpbr() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addNewRtetpbr() :"+ApplicationConstants.ERROR_ADD_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	

	/**
	 * Method to delete the Rtetpbr List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of rtetpbrDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteRtetpbr", method = RequestMethod.POST)
	public ModelAndView deleteRtetpbr(final HttpServletRequest request,@ModelAttribute("rtetpbrDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		
		ModelAndView mav ;
		String rtetpbrMsg = "";
		boolean isRtetpbrDeleted = true;
		String securityLevel ="";
		Map rtetpbrResultMap = new HashMap();
		List<RtetpbrVO> rtetpbrList = new LinkedList<RtetpbrVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtetpbrList = lookUpListVO.getRtetpbrVOList();
			int i;
			if ((rtetpbrList != null) && (takeAction != null)) {
				for(RtetpbrVO rtetpbrVO : rtetpbrList){
					if(rtetpbrVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtetpbrVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					RtetpbrVO existingRtetpbr = (RtetpbrVO) rtetpbrList.get(i);
					if (existingRtetpbr.getUpdatedInd() != ApplicationConstants.COPY) {
						String rtetpbrIdNo = existingRtetpbr.getIdNo();
						String rtetpbrEffDate = existingRtetpbr.getEffDate();
						
						rtetpbrResultMap = facade.deleteRtetpbr(rtetpbrIdNo, rtetpbrEffDate);
						rtetpbrMsg = (String) rtetpbrResultMap.get("rtetpbrMsg");
						isRtetpbrDeleted = (Boolean) rtetpbrResultMap.get("isRtetpbrDeleted");
						
						if(isRtetpbrDeleted == true){
							rtetpbrList.remove(i);
						}else{
							j = 0;
						}
					}else{
						rtetpbrList.remove(i);
					}				
			}
				if(isRtetpbrDeleted == true)
					rtetpbrMsg = "Rows selected were Deleted in the database/list";
		}else
			rtetpbrMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setRtetpbrList(rtetpbrList);
			lookUpListVO.setRtetpbrVOList(rtetpbrList);
			mav = new ModelAndView(RTETPBR_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtetpbrMessage",rtetpbrMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteRtetpbr - rtetpbrMessage: "+ rtetpbrMsg);
		    log.warn("Exit from RtetpbrController - deleteRtetpbr()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtetpbrController - deleteRtetpbr() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteRtetpbr() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to copy the Rtetpbr List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of rtetpbrDisplay, if fails return error page
	 */
	@RequestMapping(value="/copyRtetpbr", method = RequestMethod.POST)
	public ModelAndView copyRtetpbr(final HttpServletRequest request,@ModelAttribute("rtetpbrDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered from RtetpbrController - copyUser()");
		ModelAndView mav ;
		String rtetpbrMsg = "";
		String securityLevel ="";
		int i;
		List<RtetpbrVO> rtetpbrList = new LinkedList<RtetpbrVO>();
		try{
			//String postedDate =RteIntranetUtils.getPostedDate(); //Initialize Posted Date to today's date
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtetpbrList = lookUpListVO.getRtetpbrVOList();
			if ((rtetpbrList != null) && (takeAction != null)) {
				for(RtetpbrVO rtetpbrVO : rtetpbrList){
					if(rtetpbrVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtetpbrVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					i = Integer.parseInt(takeAction[j]);
					RtetpbrVO existingRtetpbr = (RtetpbrVO) rtetpbrList.get(i);
					RtetpbrVO copyRtetpbrVO = new RtetpbrVO(existingRtetpbr.getIdNo(), existingRtetpbr.getBenrlCd(), existingRtetpbr.getSvctypCd() , existingRtetpbr.getAcastosCd(), existingRtetpbr.getAcasposCd(), existingRtetpbr.getEffDate() ,
							existingRtetpbr.getExpDate(),existingRtetpbr.getPostedDate(), existingRtetpbr.getUserId(), existingRtetpbr.getValueTxt() , COPY);
					rtetpbrList.add(copyRtetpbrVO);
				}
				rtetpbrMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				rtetpbrMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setRtetpbrList(rtetpbrList);
			lookUpListVO.setRtetpbrVOList(rtetpbrList);
			mav = new ModelAndView(RTETPBR_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtetpbrMessage",rtetpbrMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyRtetpbr - rtetpbrMessage: "+ rtetpbrMsg);
		    log.warn("Exit from RtetpbrController - copyRtetpbr()");
			return mav;		
		}catch (Exception e){
			log.error("Exception occured in RtetpbrController - copyRtetpbr() method:"+e.getMessage());
			String errorMsg ="copyRtetpbr() :"+ApplicationConstants.ERROR_COPY_ROW + RteIntranetUtils.getTrimmedString(e.getMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to Add/Update the Rtetpbr List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of rtetpbrDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateRtetpbr", method = RequestMethod.POST)
	public ModelAndView addUpdateRtetpbr(final HttpServletRequest request,@ModelAttribute("rtetpbrDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered from RtetpbrController - addUpdateRtetpbr()");
		ModelAndView mav ;
		String rtetpbrMsg = "";
		String securityLevel ="";
		List<RtetpbrVO> updatedrtetpbrList = new LinkedList<RtetpbrVO>();
		List<RtetpbrDTO> updatedRtetpbrDtoList = new LinkedList<RtetpbrDTO>();
		List<RtetpbrVO> rtetpbrVoList = new LinkedList<RtetpbrVO>();
		List<RtetpbrVO> modifiedRtetpbrVoList = new LinkedList<RtetpbrVO>();
		List<RtetpbrDTO> rtetpbrDtoList = new LinkedList<RtetpbrDTO>(); 
		boolean isRtetpbrAddOrUpdated = false;
		Map rtetpbrResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			 rtetpbrVoList = facade.getApplicationState().getRtetpbrList();
			 modifiedRtetpbrVoList = lookUpListVO.getRtetpbrVOList();
			int i;
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDate = currentTS.toString(); //Initialize Posted Date to the current timestamp
			if (takeAction != null && takeAction.length != 0) {
				if(rtetpbrVoList != null && rtetpbrVoList.size() != 0 
						&& modifiedRtetpbrVoList.size() != 0 && modifiedRtetpbrVoList != null){
				for(RtetpbrVO rtetpbrVO : rtetpbrVoList){
					if(rtetpbrVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtetpbrVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				rtetpbrDtoList = RTETranslator.toRtetpbrDTOList(rtetpbrVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					RtetpbrVO seletedRtetpbr = (RtetpbrVO) rtetpbrVoList.get(i);
					RtetpbrVO editedRtetpbr = (RtetpbrVO) modifiedRtetpbrVoList.get(i);
					RtetpbrVO editedRtetpbrVO = new RtetpbrVO(editedRtetpbr.getIdNo(), editedRtetpbr.getBenrlCd(),editedRtetpbr.getSvctypCd() , editedRtetpbr.getAcastosCd(), editedRtetpbr.getAcasposCd(), editedRtetpbr.getEffDate() ,
							editedRtetpbr.getExpDate() ,  postedDate, editedRtetpbr.getUserId() , editedRtetpbr.getValueTxt() ,  updatedInd);
					RtetpbrDTO editedRtetpbrDTO = RTETranslator.toRtetpbrDTO(editedRtetpbrVO);
					rtetpbrResultMap = facade.addUpdateRtetpbr(editedRtetpbrDTO, rtetpbrDtoList, i , seletedRtetpbr.getUpdatedInd());
					updatedRtetpbrDtoList = (List<RtetpbrDTO>) rtetpbrResultMap.get("rtetpbrDtoList");
					updatedrtetpbrList = RTETranslator.toRtetpbrVOList(updatedRtetpbrDtoList);
					isRtetpbrAddOrUpdated = (Boolean) rtetpbrResultMap.get("isRtetpbrAddorUpdated");
					rtetpbrMsg = (String) rtetpbrResultMap.get("rtetpbrMsg") ;
					if(isRtetpbrAddOrUpdated!= true){
						j = takeAction.length;
					}
				}
				if(isRtetpbrAddOrUpdated==true){
					rtetpbrMsg = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted.";
					String xRtetpbrIdNo, yRtetpbrIdNo, xEffDate, yEffDate;
					for (int x = updatedrtetpbrList.size() - 1 ; x > 0;  x--) {
						RtetpbrVO xRtetpbr = (RtetpbrVO) updatedrtetpbrList.get(x);
						xRtetpbrIdNo= xRtetpbr.getIdNo();
						xEffDate = xRtetpbr.getEffDate();
						if (xRtetpbr.getUpdatedInd() != 'C') {
							for (int y = x - 1; y > -1; y--) {
								RtetpbrVO yRtetpbr = (RtetpbrVO) updatedrtetpbrList.get(y);
								yRtetpbrIdNo= yRtetpbr.getIdNo();
								yEffDate = yRtetpbr.getEffDate();
								if (xRtetpbrIdNo.equals(yRtetpbrIdNo) && xEffDate.equals(yEffDate)) {
									updatedrtetpbrList.remove(y); 
									x--;
								}
							}
						}
					}
				}
				lookUpListVO.setRtetpbrVOList(updatedrtetpbrList);
				facade.getApplicationState().setRtetpbrList(updatedrtetpbrList);
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	
				}
		}else{
			rtetpbrMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setRtetpbrVOList(rtetpbrVoList);
			facade.getApplicationState().setRtetpbrList(rtetpbrVoList);
		}
			mav = new ModelAndView(RTETPBR_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtetpbrMessage",rtetpbrMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateRtetpbr - rtetpbrMessage: "+ rtetpbrMsg);
		    log.warn("Exit from RtetpbrController - addUpdateRtetpbr()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtetpbrController - addUpdateRtetpbr() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addUpdateRtetpbr() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}


	/**
      * Method to export Rtetpbr look up table to excel work book
      * 
      * @param lookUpTableListVO
      *            list of rtetpbr object.
      * @param response
      *            response object to return
      * @return exported file to view.
      */
	@RequestMapping(value = "/rtetpbrExport", method = RequestMethod.POST)
	public ModelAndView rtetpbrExport(HttpServletResponse response) {
		List<RtetpbrVO> rtetpbrList = new LinkedList<RtetpbrVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String rtetpbrMsg = "";
		try {
			rtetpbrList = facade.getApplicationState().getRtetpbrList();
			if (rtetpbrList != null && rtetpbrList.size() != 0) {
				// Key map to create header
				Map<String, String> keyMap = new LinkedHashMap<String, String>();
				keyMap.put("idNo", "Id NO");
				keyMap.put("benrlCd", "BEN Rule CD");
				keyMap.put("svctypCd", "Svc Typ CD");
				keyMap.put("acastosCd", "ACAS TOS CD");
				keyMap.put("acasposCd", "ACAS POS CD");
				keyMap.put("effDate", "Effective Date");
				keyMap.put("expDate", "Expiration Date");
				keyMap.put("userId", "User Id");
				keyMap.put("valueTxt", "Value Text");
				keyMap.put("postedDate", "Posted Date");
				RteIntranetUtils.exportToExcel(response, rtetpbrList, keyMap);
				rtetpbrMsg = "LookUp table exported successfully.";
			} else {
				rtetpbrMsg = ApplicationConstants.NO_DATA;
			}
			lookUpTableListVO.setRtetpbrVOList(rtetpbrList);
			mav = new ModelAndView(RTETPBR_LOOKUP, "lookUpTableListVO",
					lookUpTableListVO);
			mav.addObject("rtetpbrMessage", rtetpbrMsg);
			return mav;
		} catch (ApplicationException e) {
			log.error("Exception occured in RtetpbrController - rtetpbrExport() method:"
					+ e.getMessage());
			String errorMsg = "Error encountered while export to excel. ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);
			return errormav;
		}
	}
	
}
