/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.SbmletkAdapter;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N731694
 * Cognizant_Offshore
 */
@Repository
public class SbmletkDAOImpl implements SbmletkDAO {
	
	@Autowired(required=true)
	private SbmletkAdapter sbmletkAdapter;

	
	
	@Override
	public Map getSbmletkLookUpTable(String convIdCode, String vanIdCd,String tranType,String postedDt,String seconds)
			throws ApplicationException {
		
		return sbmletkAdapter.getSbmletkLookUpTable(convIdCode, vanIdCd,tranType,postedDt,seconds);
	}


}
