package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.RtetprlDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class RtetprlDeleteAdapter extends StoredProcedure{
	
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RtetprlDeleteAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtetprlDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_STC_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_TOS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_POS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_GROUP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_RULE_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_EFF_DT, Types.DATE));
		
		declareParameter(new SqlOutParameter(DBConstants.OUT_LS_SQLCODE, Types.INTEGER));
		
	}
	
	
	/**
	 * Method to delete the Rtetprl data from data store.
	 * 
	 * @param rtetprlDTO
	 * 
	 * @return Map of flag to delete the data from Rtetprl list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */

	@SuppressWarnings("unchecked")
	public Map deleteRtetprl(RtetprlDTO rtetprlDTO) throws ApplicationException {
		
		log.warn("Entered RtetprlDeleteAdapter  - deleteRtetprl");
		boolean isRtetprlDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map rtetprlMap = new HashMap();
		params.put(DBConstants.IN_RTETPRL_STC_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getStcCd()));
		params.put(DBConstants.IN_RTETPRL_TOS_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getTosCd()));
		params.put(DBConstants.IN_RTETPRL_POS_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getPosCd()));
		params.put(DBConstants.IN_RTETPRL_GROUP_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getGroupCd()));
		params.put(DBConstants.IN_RTETPRL_RULE_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getRuleCd()));
		params.put(DBConstants.IN_RTETPRL_EFF_DT, RteIntranetUtils.getTrimmedString(rtetprlDTO.getEffDate()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("RtetprlDeleteAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_LS_SQLCODE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) 
				isRtetprlDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			rtetprlMap.put("rtetprlMsg", newMessage);
			rtetprlMap.put("isRtetprlDeleted", isRtetprlDeleted);
			return rtetprlMap;
		}catch (Exception exception){
			
			log.error("RtetprlDeleteAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	
}
