/**
 * 
 */
package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;

/**
 * @author N731694
 * Cognizant_Offshore
 */
public class SbmletkVO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String tranType ="";
	private String loadName = "";
	private String seconds="";
	private String vanIdCd = "";
	private String typeCd = "";
	private String convIdCode ="";
	private String startTimeStamp ="";
	private String endTimeStamp ="";
	private String postedDt = "";
	public String getPostedDt() {
		return postedDt;
	}
	public void setPostedDt(String postedDt) {
		this.postedDt = postedDt;
	}
	private char updatedInd;
	public String getTranType() {
		return tranType;
	}
	public SbmletkVO() {
		super();
	
	}
	public SbmletkVO(String tranType, String loadName, String seconds,
			String vanIdCd, String typeCd, String convIdCode,
			String startTimeStamp, String endTimeStamp, char updatedInd,String postedDt) {
		super();
		this.tranType = tranType;
		this.loadName = loadName;
		this.seconds = seconds;
		this.vanIdCd = vanIdCd;
		this.typeCd = typeCd;
		this.convIdCode = convIdCode;
		this.startTimeStamp = startTimeStamp;
		this.endTimeStamp = endTimeStamp;
		this.updatedInd = updatedInd;
		this.postedDt=postedDt;
	}
	public void setTranType(String tranType) {
		this.tranType = tranType;
	}
	public String getLoadName() {
		return loadName;
	}
	public void setLoadName(String loadName) {
		this.loadName = loadName;
	}
	public String getSeconds() {
		return seconds;
	}
	public void setSeconds(String seconds) {
		this.seconds = seconds;
	}
	public String getVanIdCd() {
		return vanIdCd;
	}
	public void setVanIdCd(String vanIdCd) {
		this.vanIdCd = vanIdCd;
	}
	public String getTypeCd() {
		return typeCd;
	}
	public void setTypeCd(String typeCd) {
		this.typeCd = typeCd;
	}
	public String getConvIdCode() {
		return convIdCode;
	}
	public void setConvIdCode(String convIdCode) {
		this.convIdCode = convIdCode;
	}
	public String getStartTimeStamp() {
		return startTimeStamp;
	}
	public void setStartTimeStamp(String startTimeStamp) {
		this.startTimeStamp = startTimeStamp;
	}
	public String getEndTimeStamp() {
		return endTimeStamp;
	}
	public void setEndTimeStamp(String endTimeStamp) {
		this.endTimeStamp = endTimeStamp;
	}
	public char getUpdatedInd() {
		return updatedInd;
	}
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}
	
	
	
	
}
