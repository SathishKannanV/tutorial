/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.ProcexDAO;
import com.aetna.prvrte.rteintranet.dao.StstypaDAO;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.StstypaDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Service
public class StstypaServiceImpl implements StstypaService {
	@Autowired(required=true)
	private StstypaDAO ststypaDAO;
	
	
	/**
	 * 
	 * @param ststypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map getStstypaLookUpTable(StstypaDTO ststypaDTO)
			throws ApplicationException {
		
		return ststypaDAO.getStstypaLookUpTable(ststypaDTO);
	}

	/**
	 * 
	 * @param ststypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addNewStstypa(StstypaDTO ststypaDTO) throws ApplicationException {
		return ststypaDAO.addNewStstypa(ststypaDTO);
	}

	/**
	 * 
	 * @param ststypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map deleteStstypa(StstypaDTO ststypaDTO) throws ApplicationException {
		return ststypaDAO.deleteStstypa(ststypaDTO);
	}

	/**
	 * 
	 * @param editedStstypaDTO
	 * @param ststypaDtoList
	 * @param index
	 * @param  updateInd
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addUpdateStstypa(StstypaDTO editedStstypaDTO,
			List<StstypaDTO> ststypaDtoList, int index,char updateInd)
			throws ApplicationException {
		return ststypaDAO.addUpdateStstypa( editedStstypaDTO,ststypaDtoList, index, updateInd);
	}

}
