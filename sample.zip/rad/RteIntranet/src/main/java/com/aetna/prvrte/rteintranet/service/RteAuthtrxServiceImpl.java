/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.RteAuthTrxDAO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.service.RteAuthtrxService
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Service
public class RteAuthtrxServiceImpl implements RteAuthtrxService {
	/*
	 * Instance of RteAuthTrxDAO
	 */
	@Autowired(required=true)
	private RteAuthTrxDAO rteAuthTrxDAO;
	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteAuthTrxService#getAuthTrxLookUpList(java.lang.String)
	 */
	@Override
	public Map<String, Object> getAuthTrxLookUpList(String authTrx) throws ApplicationException {
		return rteAuthTrxDAO.getAuthTrxLookUpList(authTrx);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteAuthTrxService#addAuthTrxToDb()
	 */
	@Override
	public Map<String, Object> addAuthTrxToDb(String authTrx) throws ApplicationException {
		return rteAuthTrxDAO.addAuthTrxToDb(authTrx);
	}
	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteAuthtrxService#deleteAuthTrx(java.util.List, java.lang.String, int)
	 */
	@Override
	public Map<String, Object> deleteAuthTrx(List<String> authTrxList, String authTrx, int index) throws ApplicationException {
		return rteAuthTrxDAO.deleteAuthTrx(authTrxList, authTrx, index);
	}

	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteAuthtrxService#addUpdateAuthTrx(java.util.List, java.lang.String, int)
	 */
	@Override
	public Map<String, Object> addUpdateAuthTrx(List<String> authTrxList, String authTrx, int index) throws ApplicationException {
		return rteAuthTrxDAO.addUpdateAuthTrx(authTrxList, authTrx, index);
	}
	

}
