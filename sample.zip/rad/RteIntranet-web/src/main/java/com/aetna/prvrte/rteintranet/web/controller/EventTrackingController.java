/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.EventTrackingVO;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.SbmletkVO;
import com.aetna.prvrte.rteintranet.vo.SbmrdepVO;
import com.aetna.prvrte.rteintranet.vo.Sbmrpln5VO;
import com.aetna.prvrte.rteintranet.vo.SbmrplnVO;
import com.aetna.prvrte.rteintranet.vo.SbmsnrVO;
import com.aetna.prvrte.rteintranet.vo.SbrsrxbVO;
import com.aetna.prvrte.rteintranet.vo.SpntprvVO;
import com.aetna.prvrte.rteintranet.vo.SrapidtlVO;
import com.aetna.prvrte.rteintranet.vo.SubmsnVO;

/**
 * @author N731694
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/eventtrack/*")
public class EventTrackingController {

	public static final String EVENTTRACK_HOME = ".eventtrackHome";
	public static final String SBRSRXB_DISPLAY = ".sbrsrxbDisplay";
	public static final String SPNTPRV_DISPLAY = ".spntprvDisplay";
	public static final String SBMRDEP_DISPLAY = ".sbmrdepDisplay";
	public static final String SUBMSN_DISPLAY = ".submsnDisplay";
	public static final String SBMLETK_DISPLAY = ".sbmletkLookUpDisplay";
	public static final String SRAPIDTL_DISPLAY = ".srapidtlDisplay";
	public static final String SBMSNR_DISPLAY = ".sbmsnrDisplay";
	public static final String SBMRPLN_DISPLAY = ".sbmrplnDisplay";
	public static final String SBMRPLNDTL_DISPLAY=".sbmrplnDisplayDtl";
	private static int count=0;

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(EventTrackingController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;
	
	@RequestMapping(value="/eventtrackHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getEventtrackLookUpHome(Model model,HttpServletRequest request) {	
		
		request.setAttribute("evntValues", "evntSession");
		log.warn("Entered Eventtracking Controller - getEventtrackLookUpHome()");
		
		log.error("SR-A82-1516-WAS8.5 Welcome to WAS8 MIGRATION START*********** Eventtracking Controller");
		ModelAndView mav = new ModelAndView(EVENTTRACK_HOME, "EventTrackingVO",  new EventTrackingVO());
		log.warn("Exit from Eventtracking - getEventtrackLookUpHome()");
		return mav;
	}
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSbrsrxb", method = RequestMethod.POST)
	public ModelAndView getSbrsrxbEvntTracking(@ModelAttribute("sbrsrxbForm")SbrsrxbVO sbrsrxbVO,
			HttpServletRequest request, @RequestParam(required = false) String start){
		log.warn("Entered EventtrackingController - getSbrsrxbEvntTracking()");
		
		
		String convIdCode ="";
		String vanIdCd ="";
		String typeCd ="";
		String postedDt ="";
		
		
		ModelAndView mav ;
		Map sbrsrxbResultMap = new HashMap();
		List<SbrsrxbVO> sbrsrxbList = new LinkedList<SbrsrxbVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			convIdCode = sbrsrxbVO.getConvIdCode();
			vanIdCd =sbrsrxbVO.getVanIdCd();
			typeCd=sbrsrxbVO.getTypeCd();
			postedDt=sbrsrxbVO.getPostedDt();
		   
			sbrsrxbResultMap = facade.getSbrsrxbEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
		
			sbrsrxbList = (List<SbrsrxbVO>) sbrsrxbResultMap.get("sbrsrxbList");
		    lookUpListVO.setSbrsrxbVOList(sbrsrxbList);
		    //-------- maintain session starts Nov,2015 release----------
			maintainSession(sbrsrxbVO, request, start);
			//-------- maintain session ends Nov,2015 release----------
			facade.getApplicationState().setSbrsrxbList(sbrsrxbList);
			mav = new ModelAndView(SBRSRXB_DISPLAY, "lookUpListVO", lookUpListVO);
			mav.addObject("sbrsrxbMessage", sbrsrxbResultMap.get("newMessage"));
			log.warn("getSbrsrxbEvntTracking - sbmletkMessage: "+ sbrsrxbResultMap.get("newMessage"));
			log.warn("Exit from EventTrackingController - getSbrsrxbEvntTracking()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in EventTrackingController - getSbrsrxbEvntTracking() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSbrsrxb). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSpntprv", method = RequestMethod.POST)
	public ModelAndView getSpntprvEvntTracking(@ModelAttribute("spntprvForm")SpntprvVO spntprvVO,
			HttpServletRequest request, @RequestParam(required = false) String start){
		log.warn("Entered EventtrackingController - getSpntprvEvntTracking()");
		String convIdCode ="";
		String vanIdCd ="";
		String typeCd ="";
		String postedDt ="";
		
		
		ModelAndView mav ;
		Map spntprvResultMap = new HashMap();
		List<SpntprvVO> spntprvList = new LinkedList<SpntprvVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			convIdCode=spntprvVO.getConvIdCode();
			vanIdCd =spntprvVO.getVanIdCd();
			typeCd=spntprvVO.getTypeCd();
			postedDt=spntprvVO.getPostedDt();
		   
			spntprvResultMap = facade.getSpntprvEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
		
			spntprvList = (List<SpntprvVO>) spntprvResultMap.get("spntprvList");
		    lookUpListVO.setSpntprvVOList(spntprvList);
		  //-------- maintain session starts Nov,2015 release----------
			maintainSession(spntprvVO, request, start);
			//-------- maintain session ends Nov,2015 release----------
			facade.getApplicationState().setSpntprvList(spntprvList);
			mav = new ModelAndView(SPNTPRV_DISPLAY, "lookUpListVO", lookUpListVO);
			mav.addObject("spntprvMessage", spntprvResultMap.get("newMessage"));
			log.warn("getSbrsrxbEvntTracking - spntprvMessage: "+ spntprvResultMap.get("newMessage"));
			log.warn("Exit from EventTrackingController - getspntprvEvntTracking()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in EventTrackingController - getSbrsrxbEvntTracking() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSpntprv). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSbmrdep", method = RequestMethod.POST)
	public ModelAndView getSbmrdepEvntTracking(@ModelAttribute("sbmrdepForm")SbmrdepVO sbmrdepVO, HttpServletRequest request,
			@RequestParam(required = false) String start){
		log.warn("Entered EventtrackingController - getSbmrdepEvntTracking()");
		String convIdCode ="";
		String vanIdCd ="";
		String typeCd ="";
		String postedDt ="";
		
		
		ModelAndView mav ;
		Map sbmrdepResultMap = new HashMap();
		List<SbmrdepVO> sbmrdepList = new LinkedList<SbmrdepVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			convIdCode=sbmrdepVO.getConvIdCode();
			vanIdCd =sbmrdepVO.getVanIdCd();
			typeCd=sbmrdepVO.getTypeCd();
			postedDt=sbmrdepVO.getPostedDt();
		   
			sbmrdepResultMap = facade.getSbmrdepEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
		
			sbmrdepList = (List<SbmrdepVO>) sbmrdepResultMap.get("sbmrdepList");
		    lookUpListVO.setSbmrdepVOList(sbmrdepList);
		    //-------- maintain session starts Nov,2015 release----------
			maintainSession(sbmrdepVO, request, start);
			//-------- maintain session ends Nov,2015 release----------
			facade.getApplicationState().setSbmrdepList(sbmrdepList);
			mav = new ModelAndView(SBMRDEP_DISPLAY, "lookUpListVO", lookUpListVO);
			mav.addObject("sbmrdepMessage", sbmrdepResultMap.get("newMessage"));
			log.warn("getsbmrdepEvntTracking - sbmrdepMessage: "+ sbmrdepResultMap.get("newMessage"));
			log.warn("Exit from EventTrackingController - getsbmrdepEvntTracking()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in EventTrackingController - getSbrsrxbEvntTracking() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSbmrdep). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSubmsn", method = RequestMethod.POST)
	public ModelAndView getSubmsnEvntTracking(@ModelAttribute("submsnForm") SubmsnVO submsnVO, HttpServletRequest request,
			@RequestParam(required = false) String start) {
		log.warn("Entered EventtrackingController - getSubmsnEvntTracking()");
		String convIdCode ="";
		String vanIdCd ="";
		String typeCd ="";
		String postedDt ="";
		
		
		ModelAndView mav ;
		Map submsnResultMap = new HashMap();
		List<SubmsnVO> submsnList = new LinkedList<SubmsnVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			convIdCode=submsnVO.getConvIdCode();
			vanIdCd =submsnVO.getVanIdCd();
			typeCd=submsnVO.getTypeCd();
			postedDt=submsnVO.getPostedDt();
		   
			submsnResultMap = facade.getSubmsnEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
		
			submsnList = (List<SubmsnVO>) submsnResultMap.get("submsnList");
			if (submsnList != null && submsnList.size() != 0) {
				SubmsnVO aSubmsnVO = submsnList.get(0);
				List<SubmsnVO> asubmsnList = new LinkedList<SubmsnVO>();
				asubmsnList.add(aSubmsnVO);
				lookUpListVO.setSubmsnVOList(asubmsnList);
			} else {
				submsnList = new LinkedList<SubmsnVO>();
			}
			facade.getApplicationState().setSubmsnList(submsnList);
			mav = new ModelAndView(SUBMSN_DISPLAY, "lookUpListVO", lookUpListVO);
			mav.addObject("submsnMessage", submsnResultMap.get("newMessage"));
			mav.addObject("indexCount", "0");
			mav.addObject("totalCount", submsnList.size());
			//-------- maintain session starts Nov,2015 release----------
			maintainSession(submsnVO, request, start);
			//-------- maintain session ends Nov,2015 release----------
			log.warn("getsbmrdepEvntTracking - submsnMessage: "+ submsnResultMap.get("newMessage"));
			log.warn("Exit from EventTrackingController - getSubmsnEvntTracking()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in EventTrackingController - getSbrsrxbEvntTracking() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSubmsn). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}


	@SuppressWarnings("unchecked")
	private void maintainSession(Object obj, HttpServletRequest request,
			String start) {
		if( start!=null && !"".equals(start.trim()) &&("evntSession").equalsIgnoreCase(start)){
			ObjectMapper mapper = new ObjectMapper();
			Map<String,Object> searchFormObject = mapper.convertValue(obj, Map.class);
			String evntConIdCode = (String)searchFormObject.get("convIdCode");
			String evntVanId = (String)searchFormObject.get("vanIdCd");
			String evntTransType = (String)searchFormObject.get("typeCd");
			String evntPostdate = (String)searchFormObject.get("postedDt");
			// Event Track Changes Start
			HttpSession session = request.getSession();
			session.setAttribute("evntConIdCode", evntConIdCode);
			session.setAttribute("evntVanId", evntVanId);
			session.setAttribute("evntTransType", evntTransType);
			session.setAttribute("evntPostdate", evntPostdate);
			
			request.setAttribute("evntValues", "notValid");
		
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSrapidtl", method = RequestMethod.POST)
	public ModelAndView getSrapidtlEvntTracking(@ModelAttribute("eventtrackForm")SrapidtlVO srapidtlVO,
			@RequestParam(required = false) String nSbmrst,@RequestParam(required = false) String currentSbmrst,@RequestParam(required = false) String currentSrapidtl,
			@RequestParam(required = false) String nSrapidtl,@RequestParam(required = false) String start,
		/* Event Track Changes Start*/
			HttpServletRequest request/*,HttpServletResponse response*/ ){
		/* Event Track Changes End*/ 
		
		log.warn("Entered EventtrackingController - getSrapidtlEvntTracking()");
		
		String convIdCode ="";
		String vanIdCd ="";
		String typeCd ="";
		String postedDt ="";
		int iSrpidtl=0;
		int iSbmrst=0;
		
		
		
		// Event Track Changes Start
	//	System.out.println("KArthik  start" + request.getParameter("start"));
		
		/*String validate = request.getParameter("start");
		
	
		if( validate!=null && !"".equals(validate.trim()) &&("evntSession").equalsIgnoreCase(validate)){
			
			String evntConIdCode = srapidtlVO.getConvIdCode();
			String evntVanId = srapidtlVO.getVanIdCd();
			String evntTransType = srapidtlVO.getTypeCd();
			String evntPostdate =srapidtlVO.getPostedDt();
			// Event Track Changes Start
			HttpSession session = request.getSession();
			session.setAttribute("evntConIdCode", evntConIdCode);
			session.setAttribute("evntVanId", evntVanId);
			session.setAttribute("evntTransType", evntTransType);
			session.setAttribute("evntPostdate", evntPostdate);
			
			request.setAttribute("evntValues", "notValid");
		
		}*/
		//-------- maintain session starts Nov,2015 release----------
			maintainSession(srapidtlVO, request, start);
		//-------- maintain session ends Nov,2015 release----------
		 
		//Event Track Changes End
		
		// Event Track Changes END
		boolean isNextPrevious = false;
		if ((!("").equalsIgnoreCase(RteIntranetUtils.getTrimmedString(nSrapidtl)))
				&&("NextSrapidtl").equalsIgnoreCase(nSrapidtl) && nSrapidtl != null) { // Next
			int i = Integer.parseInt(currentSbmrst);
			iSbmrst = i+1;
			log.warn(":::::NextSrapidtl");
			log.warn(":::::Count"+iSbmrst);
			isNextPrevious = true;
			
		} else if((!("").equalsIgnoreCase(RteIntranetUtils.getTrimmedString(nSrapidtl)))
				&&("PrevSrapidtl").equalsIgnoreCase(nSrapidtl) && nSrapidtl != null){
			int i = Integer.parseInt(currentSbmrst);
			iSbmrst = i-1;
			log.warn(":::::PrevSrapidtl");
			log.warn(":::::Count"+iSbmrst);
			isNextPrevious = true;
		} else if((!("").equalsIgnoreCase(RteIntranetUtils.getTrimmedString(nSbmrst)))
				&&("PrevSbmrst").equalsIgnoreCase(nSbmrst)&& nSbmrst != null){
			int i = Integer.parseInt(currentSbmrst);
			log.warn(":::::PrevSbmrst");
			iSbmrst = i-1;
			log.warn(":::::Count"+iSbmrst);
			isNextPrevious = true;
		} else if((!("").equalsIgnoreCase(RteIntranetUtils.getTrimmedString(nSbmrst)))
				&&("NextSbmrst").equalsIgnoreCase(nSbmrst) && nSbmrst != null){
			int i = Integer.parseInt(currentSbmrst);
			iSbmrst = i+1;
			log.warn(":::::NextSbmrst");
			log.warn(":::::Count"+iSbmrst);
			isNextPrevious = true;
		}
		
		ModelAndView mav ;
		Map srapidtlResultMap = new HashMap();
		List<Sbmrpln5VO> srapidtlList = new LinkedList<Sbmrpln5VO>();
	
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			convIdCode=srapidtlVO.getConvIdCode();
			vanIdCd =srapidtlVO.getVanIdCd();
			typeCd=srapidtlVO.getTypeCd();
			postedDt=srapidtlVO.getPostedDt();
			if(!isNextPrevious){
				srapidtlResultMap = facade.getSrapidtlEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
				
				srapidtlList = (List<Sbmrpln5VO>) srapidtlResultMap.get("srapidtlList");
				if(srapidtlList != null){
					log.warn(":::::srapidtlLis1t"+srapidtlList.size());
				} 
				lookUpListVO.setSrapidtlVOList(srapidtlList);
			
				facade.getApplicationState().setSrapidtlList(srapidtlList);
				facade.getApplicationState().setSrapidtlVO(srapidtlVO);
				log.warn(":::::Fetched data");
			} else {
				srapidtlList = facade.getApplicationState().getSrapidtlList();
				lookUpListVO.setSrapidtlVOList(srapidtlList);
				srapidtlVO = facade.getApplicationState().getSrapidtlVO();
				if(srapidtlList != null){
					log.warn(":::::srapidtlList"+srapidtlList.size());
				} 
				if(srapidtlVO != null){
					log.warn(":::::data"+srapidtlVO.getVanIdCd());
					} 
				log.warn(":::::checkin data");
				if(srapidtlVO != null){
				log.warn(":::::data"+srapidtlVO.getVanIdCd());
				} else{
					log.warn(":::::Data null");
				}
			}
		/*	
			if("".equals(srapidtlVO.getCount())){
			srapidtlResultMap = facade.getSrapidtlEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
			facade.getApplicationState().setSrapidtlList(srapidtlList);
			srapidtlList = (List<SrapidtlVO>) srapidtlResultMap.get("srapidtlList");
			srapidtlVO.setCount("0");

			}else{
				srapidtlResultMap = facade.getSrapidtlEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
				facade.getApplicationState().setSrapidtlList(srapidtlList);
				srapidtlList = (List<SrapidtlVO>) srapidtlResultMap.get("srapidtlList");
			//	srapidtlVO.setCount("1");
				srapidtlList = facade.getApplicationState().getSrapidtlList();
			}
		
		
		    lookUpListVO.setSrapidtlVOList(srapidtlList);
		*/
			
			mav = new ModelAndView(SRAPIDTL_DISPLAY, "eventtrackForm", srapidtlVO);
			mav.addObject("lookUpListVO", lookUpListVO);
			mav.addObject("srapidtlMessage", srapidtlResultMap.get("newMessage"));
			mav.addObject("currentSrapidtl",iSrpidtl);
			mav.addObject("currentSbmrst",iSbmrst);
			
		//	mav.addObject("srapidtRecord",srapidtlList.get(Integer.parseInt(srapidtlVO.getCount())));
			
			log.warn("getSrapidtlEvntTracking - srapidtlMessage: "+ srapidtlResultMap.get("newMessage"));
			log.warn("Exit from EventTrackingController - getSrapidtlEvntTracking()");
			
			
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in EventTrackingController - getSbrsrxbEvntTracking() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSrapidtl). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSbmletk", method = RequestMethod.POST)
	public ModelAndView getSbmletkLookUpTable(final HttpServletRequest request,@ModelAttribute("sbmletkForm")SbmletkVO sbmletkVO,
			@RequestParam(required = false) String start){
		log.warn("Entered SbmletkController - getSbmletkLookUpTable()");
		String convIdCode ="";
		String vanIdCd ="";
		String tranType ="";
		String postedDt ="";
		String seconds ="";
		String securityLevel ="";
		
		ModelAndView mav ;
		Map sbmletkResultMap = new HashMap();
		List<SbmletkVO> sbmletkList = new LinkedList<SbmletkVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			convIdCode = sbmletkVO.getConvIdCode();
			vanIdCd =sbmletkVO.getVanIdCd();
			tranType=sbmletkVO.getTypeCd();
			postedDt=sbmletkVO.getPostedDt();
		    seconds = sbmletkVO.getSeconds();
		    sbmletkResultMap = facade.getEventTrackSbmletkLookUpTable(convIdCode, vanIdCd,tranType,postedDt,seconds);
		    //-------- maintain session starts Nov,2015 release----------
			maintainSession(sbmletkVO, request, start);
			//-------- maintain session ends Nov,2015 release----------
			sbmletkList = (List<SbmletkVO>) sbmletkResultMap.get("sbmletkList");
		    lookUpListVO.setSbmletkVOList(sbmletkList);
		
			facade.getApplicationState().setSbmletkList(sbmletkList);
			mav = new ModelAndView(SBMLETK_DISPLAY, "lookUpListVO", lookUpListVO);
			mav.addObject("sbmletkMessage", sbmletkResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			mav.addObject("typeCd", "5010");
			log.warn("getSbmletkLookUpTable - sbmletkMessage: "+ sbmletkResultMap.get("newMessage"));
			log.warn("Exit from SbmletkController - getSbmletkLookUpTable()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in SbmletkController - getSbmletkLookUpTable() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSbmletk). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSbmsnr", method = RequestMethod.POST)
	public ModelAndView getSbmsnrEvntTracking(@ModelAttribute("sbmsnrForm")SbmsnrVO sbmsnrVO,
			@RequestParam(required = false) String start, HttpServletRequest request){
		log.warn("Entered EventtrackingController - getSbmsnrEvntTracking()");
		String convIdCode ="";
		String vanIdCd ="";
		String typeCd ="";
		String postedDt ="";
		
		
		ModelAndView mav ;
		Map sbmsnrResultMap = new HashMap();
		List<SbmsnrVO> sbmsnrList = new LinkedList<SbmsnrVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			convIdCode=sbmsnrVO.getConvIdCode();
			vanIdCd =sbmsnrVO.getVanIdCd();
			typeCd=sbmsnrVO.getTypeCd();
			postedDt=sbmsnrVO.getPostedDt();
		   
			sbmsnrResultMap = facade.getSbmsnrEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
		
			sbmsnrList = (List<SbmsnrVO>) sbmsnrResultMap.get("sbmsnrList");
			if (sbmsnrList != null && sbmsnrList.size() != 0) {
				SbmsnrVO aSbmsnrVO = sbmsnrList.get(0);
				List<SbmsnrVO> asbmsnrList = new LinkedList<SbmsnrVO>();
				asbmsnrList.add(aSbmsnrVO);
				lookUpListVO.setSbmsnrVOList(asbmsnrList);
			} else {
				sbmsnrList = new LinkedList<SbmsnrVO>();
			}
		    //lookUpListVO.setSbmsnrVOList(sbmsnrList);
		
			//-------- maintain session starts Nov,2015 release----------
			maintainSession(sbmsnrVO, request, start);
			//-------- maintain session ends Nov,2015 release----------
			
			facade.getApplicationState().setSbmsnrList(sbmsnrList);
			mav = new ModelAndView(SBMSNR_DISPLAY, "lookUpListVO", lookUpListVO);
			mav.addObject("sbmsnrMessage", sbmsnrResultMap.get("newMessage"));
			mav.addObject("indexCount", "0");
			mav.addObject("totalCount", sbmsnrList.size());
			log.warn("getSbmsnrEvntTracking - sbmsnrMessage: "+ sbmsnrResultMap.get("newMessage"));
			log.warn("Exit from EventTrackingController - getSbmsnrEvntTracking()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in EventTrackingController - getSbmsnrEvntTracking() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSbmsnr). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSbmrpln", method = RequestMethod.POST)
	public ModelAndView getSbmrplnEvntTracking(@ModelAttribute("sbmsnrForm")SbmrplnVO sbmrplnVO, 
			@RequestParam(required = false) String start, HttpServletRequest request){
		log.warn("Entered EventtrackingController - getSbmrplnEvntTracking()");
		String convIdCode ="";
		String vanIdCd ="";
		String typeCd ="";
		String postedDt ="";
		String sbmrplnMessage="";
		
		ModelAndView mav ;
		Map sbmrplnResultMap = new HashMap();
		Map sbmsnrResultMap = new HashMap();
		List<SbmrplnVO> sbmrplnList = new LinkedList<SbmrplnVO>();
		List<SbmrplnVO> sbmsnrList = new LinkedList<SbmrplnVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			convIdCode=sbmrplnVO.getConvIdCode();
			vanIdCd =sbmrplnVO.getVanIdCd();
			typeCd=sbmrplnVO.getTypeCd();
			postedDt=sbmrplnVO.getPostedDt();
		   
			sbmrplnResultMap = facade.getSbmrplnEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
		
			sbmrplnList = (List<SbmrplnVO>) sbmrplnResultMap.get("sbmrplnList");
			if(sbmrplnList.size()!=0)
			{
				SbmrplnVO aSbmrplnVO = sbmrplnList.get(0);
			List<SbmrplnVO> asbmrplnList = new LinkedList<SbmrplnVO>();
			asbmrplnList.add(aSbmrplnVO);
		    lookUpListVO.setSbmrplnVOList(asbmrplnList);
			}
		   
			//lookUpListVO.setSbmrplnVOList(sbmrplnList);
		    
		    
			facade.getApplicationState().setSbmrplnList(sbmrplnList);
			
			if (sbmrplnList.isEmpty()){
				sbmrplnMessage = "No Data on SBMRPLN5 for Conversation ID: " + convIdCode +
														" Van Id: " +  convIdCode + 
														" Tran Type: " + typeCd; 
			} else {
			
				sbmsnrResultMap = facade.getSbmrplnSbmsnrEvntTracking(convIdCode, vanIdCd,typeCd,postedDt);
				if(sbmsnrResultMap != null && !sbmsnrResultMap.isEmpty()) {
					sbmsnrList = (List<SbmrplnVO>) sbmsnrResultMap.get("sbmsnrsbmrplnList");
					facade.getApplicationState().setSbmrplnListdtl(sbmsnrList);
				}
			   
			}
			//-------- maintain session starts Nov,2015 release----------
			maintainSession(sbmrplnVO, request, start);
			//-------- maintain session ends Nov,2015 release----------
			mav = new ModelAndView(SBMRPLN_DISPLAY, "lookUpListVO", lookUpListVO);
			mav.addObject("sbmrplnMessage", sbmrplnResultMap.get("newMessage"));
			mav.addObject("indexCount", "0");
			mav.addObject("totalCount", sbmrplnList.size());
			mav.addObject("sbmsnrList", sbmsnrList);
			mav.addObject("convIdCode",convIdCode);
			mav.addObject("vanIdCd",vanIdCd);
			mav.addObject("typeCd",typeCd);
			mav.addObject("postedDt",postedDt);
			log.warn("getSbmrplnEvntTracking - sbmrplnMessage: "+ sbmrplnResultMap.get("newMessage"));
			log.warn("Exit from EventTrackingController - getSbmrplnEvntTracking()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in EventTrackingController - getSbmsnrEvntTracking() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSbmrpln). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSbmrplnDtl", method = RequestMethod.POST)
	public ModelAndView getSbmrplnDtlEvntTracking(@ModelAttribute("sbmrplnDisplayForm")SbmrplnVO sbmrplnVO ,
			@RequestParam(required = false) String ThisSbmsnrd,
			@RequestParam(required = false) String start, HttpServletRequest request){
		log.warn("Entered EventtrackingController - getSbmrplnEvntTracking()");
	
		
		ModelAndView mav ;
		Map sbmrplnResultMap = new HashMap();
		Map sbmsnrResultMap = new HashMap();
		List<SbmrplnVO> sbmrplnListdtl = new LinkedList<SbmrplnVO>();
		List<SbmrplnVO> sbmsnrList2 = new LinkedList<SbmrplnVO>();
		/*List<SbmrplnVO> sbmrplnList = new LinkedList<SbmrplnVO>();
		List<SbmrplnVO> sbmsnrList = new LinkedList<SbmrplnVO>();*/
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			String convIdCode=sbmrplnVO.getConvIdCode();
			String	vanIdCd =sbmrplnVO.getVanIdCd();
			String typeCd=sbmrplnVO.getTypeCd();
			String postedDt=sbmrplnVO.getPostedDt();
			log.warn("sbmrplnVO.getPostedDt(): "+sbmrplnVO.getPostedDt());
			log.warn("tets---------------"+ThisSbmsnrd+""+convIdCode);
		int i=Integer.parseInt(ThisSbmsnrd);
		i=i-1;
		 
			sbmrplnListdtl=	facade.getApplicationState().getSbmrplnListdtl();
			 lookUpListVO.setSbmrplnVOListDtl(sbmrplnListdtl);
		
				sbmsnrResultMap = facade.getSbmrplnSbmsnrEvntTracking(convIdCode, vanIdCd,typeCd,postedDt,ThisSbmsnrd);
				sbmsnrList2 = (List<SbmrplnVO>) sbmsnrResultMap.get("sbmsnrsbmrplnList");
				//-------- maintain session starts Nov,2015 release----------
				maintainSession(sbmrplnVO, request, start);
				//-------- maintain session ends Nov,2015 release----------
			mav = new ModelAndView(SBMRPLNDTL_DISPLAY, "lookUpListVO", lookUpListVO);
			mav.addObject("sbmrplnMessage", sbmrplnResultMap.get("newMessage"));
			mav.addObject("sbmrplnListdtl", sbmrplnListdtl);
			mav.addObject("ThisSbmsnrd",i);
			mav.addObject("convIdCode",convIdCode);
			mav.addObject("vanIdCd",vanIdCd);
			mav.addObject("typeCd",typeCd);
			mav.addObject("postedDt",postedDt);
			mav.addObject("sbmsnrList2", sbmsnrList2);
			log.warn("getSbmrplnEvntTracking - sbmrplnMessage: "+ sbmrplnResultMap.get("newMessage"));
			log.warn("Exit from EventTrackingController - getSbmrplnEvntTracking()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in EventTrackingController - getSbmsnrEvntTracking() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSbmrpln). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	@RequestMapping(value = "/getRecord", method = RequestMethod.POST)
	public ModelAndView getRecord(@RequestParam(required = false) String count,@RequestParam(required = false) String moduleName,
			@RequestParam(required = false) String actionName,@RequestParam(required = false) String message,@RequestParam(required = false) String totalCount,
			@RequestParam(required = false) String convIdCode,@RequestParam(required = false) String vanIdCd,@RequestParam(required = false) String typeCd,@RequestParam(required = false) String postedDt){
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		Map resultMap =  new HashMap();
		int recordIndex=0;
		try{
			count = "".equalsIgnoreCase(RteIntranetUtils.getTrimmedString(count)) ? "0" : count;
			recordIndex = Integer.valueOf(count);
			if("next".equalsIgnoreCase(actionName)){
				recordIndex = recordIndex + 1;
			} else {
				recordIndex = recordIndex - 1;
			}
			if("submsn".equalsIgnoreCase(moduleName)){
				List<SubmsnVO> submsnList = facade.getApplicationState().getSubmsnList();
				SubmsnVO aSubmsnVO = submsnList.get(recordIndex);
				List<SubmsnVO> asubmsnList = new LinkedList<SubmsnVO>();
				asubmsnList.add(aSubmsnVO);
				lookUpListVO.setSubmsnVOList(asubmsnList);
				mav = new ModelAndView(SUBMSN_DISPLAY, "lookUpListVO", lookUpListVO);
				mav.addObject("submsnMessage", message);
				mav.addObject("totalCount", submsnList.size());
				mav.addObject("indexCount", recordIndex);
			}
			if("sbmsnr".equalsIgnoreCase(moduleName)){
				List<SbmsnrVO> sbmsnrList = facade.getApplicationState().getSbmsnrList();
				SbmsnrVO aSbmsnrVO = sbmsnrList.get(recordIndex);
				List<SbmsnrVO> asbmsnrList = new LinkedList<SbmsnrVO>();
				asbmsnrList.add(aSbmsnrVO);
				lookUpListVO.setSbmsnrVOList(asbmsnrList);
				mav = new ModelAndView(SBMSNR_DISPLAY, "lookUpListVO", lookUpListVO);
				mav.addObject("sbmsnrnMessage", message);
				mav.addObject("totalCount", sbmsnrList.size());
				mav.addObject("indexCount", recordIndex);
			}
			if("sbmrpln".equalsIgnoreCase(moduleName)){
				List<SbmrplnVO> sbmrplnList = facade.getApplicationState().getSbmrplnList();
				List<SbmrplnVO> sbmsnrList = facade.getApplicationState().getSbmrplnListdtl();
				
				SbmrplnVO aSbmrplnVO = sbmrplnList.get(recordIndex);
				List<SbmrplnVO> asbmrplnList = new LinkedList<SbmrplnVO>();
				asbmrplnList.add(aSbmrplnVO);
				lookUpListVO.setSbmrplnVOList(asbmrplnList);
				mav = new ModelAndView(SBMRPLN_DISPLAY, "lookUpListVO", lookUpListVO);
				mav.addObject("sbmrplnMessage", message);
				mav.addObject("totalCount", sbmrplnList.size());
				mav.addObject("indexCount", recordIndex);
				mav.addObject("sbmsnrList", sbmsnrList);
				mav.addObject("convIdCode", convIdCode);
				mav.addObject("vanIdCd", vanIdCd);
				mav.addObject("postedDt", postedDt);
				mav.addObject("typeCd", typeCd);
			
			}
			
			log.warn("Exit from EventTrackingController - getSbmsnrEvntTracking()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in EventTrackingController - getSbmsnrEvntTracking() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSbmsnr). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/nextSbmrpln", method = RequestMethod.POST)
	public ModelAndView getSbmrplnNextDtlEvntTracking(@ModelAttribute("sbmrplnDisplayForm")SbmrplnVO sbmrplnVO ,@RequestParam(required = false) String ThisSbmsnrd,@RequestParam(required = false) String actionName){
		log.warn("Entered EventtrackingController - getSbmrplnEvntTracking()");
	
		
		ModelAndView mav ;
		Map sbmrplnResultMap = new HashMap();
		Map sbmsnrResultMap = new HashMap();
		List<SbmrplnVO> sbmrplnListdtl = new LinkedList<SbmrplnVO>();
		List<SbmrplnVO> sbmsnrList2 = new LinkedList<SbmrplnVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			String convIdCode=sbmrplnVO.getConvIdCode();
			String	vanIdCd =sbmrplnVO.getVanIdCd();
			String typeCd=sbmrplnVO.getTypeCd();
			String postedDt=sbmrplnVO.getPostedDt();
			
			int i=Integer.parseInt(ThisSbmsnrd);
			sbmrplnListdtl=	facade.getApplicationState().getSbmrplnListdtl();
			 lookUpListVO.setSbmrplnVOListDtl(sbmrplnListdtl);
			 if("next".equalsIgnoreCase(actionName)){
					i = i + 1;
					ThisSbmsnrd=Integer.toString(i);
				} else {
					i = i - 1;
					ThisSbmsnrd=Integer.toString(i);
				}
				sbmsnrResultMap = facade.getSbmrplnSbmsnrEvntTracking(convIdCode, vanIdCd,typeCd,postedDt,ThisSbmsnrd);
				sbmsnrList2 = (List<SbmrplnVO>) sbmsnrResultMap.get("sbmsnrsbmrplnList");
			mav = new ModelAndView(SBMRPLNDTL_DISPLAY, "lookUpListVO", lookUpListVO);
			mav.addObject("sbmrplnMessage", sbmrplnResultMap.get("newMessage"));
			mav.addObject("sbmrplnListdtl", sbmrplnListdtl);
			mav.addObject("ThisSbmsnrd",ThisSbmsnrd);
			mav.addObject("sbmsnrList2", sbmsnrList2);
			mav.addObject("convIdCode",convIdCode);
			mav.addObject("vanIdCd",vanIdCd);
			mav.addObject("typeCd",typeCd);
			mav.addObject("postedDt",postedDt);
			log.warn("getSbmrplnEvntTracking - sbmrplnMessage: "+ sbmrplnResultMap.get("newMessage"));
			log.warn("Exit from EventTrackingController - getSbmrplnEvntTracking()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in EventTrackingController - getSbmsnrEvntTracking() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSbmrpln). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

}
