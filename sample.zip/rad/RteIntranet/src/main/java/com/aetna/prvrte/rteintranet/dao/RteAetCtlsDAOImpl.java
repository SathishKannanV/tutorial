/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.AetCtlsAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.AetCtlsDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.AetCtlsDisplayAdapter;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.dao.RteAetCtlsDAO
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Repository
public class RteAetCtlsDAOImpl implements RteAetCtlsDAO {
	/*
	 * Instance of AetCtlsDisplayAdapter.
	 */
	@Autowired(required = true)
	private AetCtlsDisplayAdapter aetCtlsDisplayAdapter;
	/*
	 * Instance of AetCtlsDisplayAdapter
	 */
	@Autowired(required = true)
	private AetCtlsDeleteAdapter aetCtlsDeleteAdapter;
	/*
	 * Instance of AetCtlsAddAdapter
	 */
	@Autowired(required = true)
	private AetCtlsAddAdapter aetCtlsAddAdapter;

	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteAetCtlsDAO#getAetCtlsLookUpList(java.lang.String)
	 */
	@Override
	public Map<String, Object> getAetCtlsLookUpList(String aetCtl) throws ApplicationException {
		return aetCtlsDisplayAdapter.getAetCtlsLookUpList(aetCtl);
	}

	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteAetCtlsDAO#addAetCtlsToDb(java.lang.String)
	 */
	@Override
	public Map<String, Object> addAetCtlsToDb(String aetCtl) throws ApplicationException {
		return aetCtlsAddAdapter.addAetCtlsToDb(aetCtl);
	}
	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteAetCtlsDAO#deleteAetCtls(java.util.List, java.lang.String, int)
	 */
	@Override
	public Map<String, Object> deleteAetCtls(List<String>aetCtlsList, String aetCtl, int index) throws ApplicationException {
		return aetCtlsDeleteAdapter.deleteAetCtls(aetCtlsList, aetCtl, index);
	}

	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteAetCtlsDAO#addUpdateAetCtls(java.util.List, java.lang.String, int)
	 */
	@Override
	public Map<String, Object> addUpdateAetCtls(List<String>aetCtlsList, String aetCtl, int index) throws ApplicationException {
		return aetCtlsAddAdapter.addUpdateAetCtls(aetCtlsList, aetCtl, index);
	}
	
}
