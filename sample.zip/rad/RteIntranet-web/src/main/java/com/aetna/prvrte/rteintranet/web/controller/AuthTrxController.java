/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;


/**
 * <h1>AuthTrx Controller</h1> The AuthTrx Controller is responsible for
 * handling the actual request from DispatcherServlet and returning an
 * appropriate ModelAndView the request and return a ModelAndView object which
 * the DispatcherServlet will render as view
 * 
 * @author N726899 Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/authTrx/*")
public class AuthTrxController {
	/*
	 * Instance of logger for AuthTrxController.
	 */
	private static final Log log = LogFactory.getLog(AuthTrxController.class);
	/*
	 * Tile name of the AUTHTRX home view.
	 */
	public static final String AUTHTRX_HOME = ".authTrxHome";
	/*
	 * Tile name of the AUTHTRX display view.
	 */
	public static final String AUTHTRX_DISPLAY = ".authTrxDisplay";

	/**
	 * Declare a private method facade
	 */
	@Autowired(required = true)
	private Facade facade;
	/**
	 * Declare a private method mav
	 */
	private ModelAndView modelAndView;
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errorModelAndView;

	/**
	 * Method to display authTrxLookup view.
	 * 
	 * @return view of authTrxLookUp, if fails return error page
	 */
	@RequestMapping(value = "/authTrxHome", method = {RequestMethod.GET,RequestMethod.POST })
	public ModelAndView getAuthTrxLookUp(HttpServletRequest request) {
		try {
			String userSecurityLevel ="";
			userSecurityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			
			modelAndView = new ModelAndView(AUTHTRX_HOME, "authTrx", new Object());
			modelAndView.addObject("securityLevel", userSecurityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in AuthTrxController - getAuthTrxLookUp() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_LOOKUP_VIEW + "(AuthTrxController)" + RteIntranetUtils.getTrimmedString(e.getMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the authTrxLookUp List from data store.
	 * 
	 * @param request
	 *            request object.
	 * @return view of authTrxDisplay
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/authTrxLookUp", method = RequestMethod.POST)
	public ModelAndView getAuthTrxLookUpList(@RequestParam(required = false) String authTrx,HttpServletRequest request) {
		try {
			String userSecurityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if (ApplicationConstants.USER_SECURITY_LEVEL_A.equalsIgnoreCase(userSecurityLevel)) {
				Map<String, Object> adasvclookUpMap = facade.getAuthTrxLookUpList(authTrx);
				
				List<String> authTrxList =  (List<String>) adasvclookUpMap.get("authTrxList");
				//set AuthTrxList in application state
				facade.getApplicationState().setAuthTrxList(authTrxList);
				LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
				lookUpTableListVO.setAuthTrxVOList(authTrxList);
				modelAndView = new ModelAndView(AUTHTRX_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
				modelAndView.addObject("authTrxMsg",adasvclookUpMap.get("authTrxMsg"));
				modelAndView.addObject("authTrxList", authTrxList);
				modelAndView.addObject("securityLevel", userSecurityLevel);
				return modelAndView;
			} else {
				String errorMsg = ApplicationConstants.NO_AUTHORITY;
				errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
				errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
				return errorModelAndView;
			}
			
		} catch (ApplicationException e) {
			log.error("Exception occured in AuthTrxController - getAuthTrxLookUp() method:"	+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(AuthTrxController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the authTrxLookUp List from data store.
	 * 
	 * @param request
	 *            request object.
	 * @return view of authTrxDisplay
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addAuthTrx", method = RequestMethod.POST)
	public ModelAndView addAuthTrx(@RequestParam(required = false) String authTrx,HttpServletRequest request) {
		try {
			String userSecurityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if (ApplicationConstants.USER_SECURITY_LEVEL_A.equalsIgnoreCase(userSecurityLevel)) {
				Map<String, Object> authTrxMap = facade.addAuthTrxToDb(authTrx);
				
				List<String> authTrxList =  (List<String>) authTrxMap.get("authTrxList");
				//set AuthTrxList in application state
				facade.getApplicationState().setAuthTrxList(authTrxList);
				
				LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
				lookUpTableListVO.setAuthTrxVOList(authTrxList);
				
				modelAndView = new ModelAndView(AUTHTRX_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
				modelAndView.addObject("authTrxMsg",authTrxMap.get("authTrxMsg"));
				modelAndView.addObject("authTrxList", authTrxList);
				modelAndView.addObject("securityLevel", userSecurityLevel);
				return modelAndView;
			} else {
				String errorMsg = ApplicationConstants.NO_AUTHORITY;
				errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
				errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
				return errorModelAndView;
			}
		} catch (ApplicationException e) {
			log.error("Exception occured in AuthTrxController - addAuthTrx() method:"+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_ROW + "(AuthTrxController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the authTrxLookUp List from data store.
	 * 
	 * @param request
	 *            request object.
	 * @param takeAction
	 *            List of selected indexes to delete the record(s).
	 * @return view of authTrxDisplay
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/deleteAuthTrx", method = RequestMethod.POST)
	public ModelAndView deleteAuthTrx(@RequestParam(required = false) String[] takeAction,
			@ModelAttribute("authTrxDisplayForm")LookUpTableListVO lookUpTableListVO,HttpServletRequest request) {
		Map<String, Object> authTrxMap = new HashedMap();
		String authTrxMsg = "";
		List<String> authTrxList = new LinkedList<String>();
		try {
			String userSecurityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if (ApplicationConstants.USER_SECURITY_LEVEL_A.equalsIgnoreCase(userSecurityLevel)) {
				authTrxList = lookUpTableListVO.getAuthTrxVOList();
				if (takeAction != null && takeAction.length != 0) {
					int index;
					if(authTrxList!= null){
						for (int j = takeAction.length - 1; j >= 0; j--) {
							index = Integer.parseInt(takeAction[j]);
							String aetnaControl = authTrxList.get(index);
							authTrxMap = facade.deleteAuthTrx(authTrxList, aetnaControl, index);
							authTrxList = (List<String>) authTrxMap.get("authTrxList");
							authTrxMsg = (String) authTrxMap.get("authTrxMsg");
							boolean isAuthTrxDeleted = (Boolean) authTrxMap.get("isAuthTrxDeleted");
							if (isAuthTrxDeleted) {
								j = 0; // end the for loop
							}
						}
					}
				} else {
					
					authTrxMsg = ApplicationConstants.NO_ACTION_TAKEN;
				}
				
				//update updateAuthTrxList in application state.
				facade.getApplicationState().setAuthTrxList(authTrxList);
				lookUpTableListVO.setAuthTrxVOList(authTrxList);
				modelAndView = new ModelAndView(AUTHTRX_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
				modelAndView.addObject("authTrxMsg",authTrxMsg);
				modelAndView.addObject("authTrxList",authTrxList);
				modelAndView.addObject("securityLevel", userSecurityLevel);
				return modelAndView;
			} else {
				String errorMsg = ApplicationConstants.NO_AUTHORITY;
				errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
				errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
				return errorModelAndView;
			}
		} catch (ApplicationException e){
            log.error("Exception occured in AuthTrxController - deleteAuthTrx() method:"+e.getErrorMessage());
            String errorMsg =ApplicationConstants.ERROR_GET_LOOKUP + "(AuthTrxController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
      }
	}
	/**
	 * Method to get the authTrxLookUp List from data store.
	 * 
	 * @param request
	 *            request object.
	 * @param takeAction
	 *            List of selected indexes to add/update the record(s).
	 * @return view of authTrxDisplay
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addUpdateAuthTrx", method = RequestMethod.POST)
	public ModelAndView addUpdateAuthTrx(@RequestParam(required = false) String[] takeAction,
			@ModelAttribute("authTrxDisplayForm")LookUpTableListVO lookUpTableListVO,HttpServletRequest request) {
		int index;
		String authTrxMsg ="";
		List<String> modifiedAuthTrxList = new LinkedList<String>();
		List<String> authTrxList = new LinkedList<String>();
		try {
			String userSecurityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if (ApplicationConstants.USER_SECURITY_LEVEL_A.equalsIgnoreCase(userSecurityLevel)) {
				authTrxList = facade.getApplicationState().getAuthTrxList();
				if(takeAction != null && takeAction.length != 0){			
					modifiedAuthTrxList = lookUpTableListVO.getAuthTrxVOList();
					Map<String, Object> authTrxMap = new HashedMap();
					if ((modifiedAuthTrxList != null) && (authTrxList != null) 
							&& modifiedAuthTrxList.size() !=0 && authTrxList.size() != 0 ) {
						for (int j = 0; j < takeAction.length; j++) {
							index = Integer.parseInt(takeAction[j]);
							String authTrx = modifiedAuthTrxList.get(index);
							authTrxMap = facade.addUpdateAuthTrx(authTrxList, authTrx, index);
							authTrxList = (List<String>) authTrxMap.get("authTrxList");
							boolean isAuthTrxAddorUpdated = (Boolean) authTrxMap.get("isAuthTrxAddorUpdated");
							authTrxMsg = (String) authTrxMap.get("authTrxMsg") ;
							if(isAuthTrxAddorUpdated){
								j = takeAction.length;
							}
						}
					} else {
						throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);
					}
				} else {
					authTrxMsg = ApplicationConstants.NO_ACTION_TAKEN;
				}
				//update updateAuthTrxList in application state.
				facade.getApplicationState().setAuthTrxList(authTrxList);
				lookUpTableListVO.setAuthTrxVOList(authTrxList);
				modelAndView = new ModelAndView(AUTHTRX_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
				modelAndView.addObject("authTrxMsg",authTrxMsg);
				modelAndView.addObject("authTrxList",authTrxList);
				modelAndView.addObject("securityLevel", userSecurityLevel);
				return modelAndView;
			}else {
				String errorMsg = ApplicationConstants.NO_AUTHORITY;
				errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
				errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
				return errorModelAndView;
			}
		} catch (ApplicationException e){
            log.error("Exception occured in AuthTrxController - addUpdateAuthTrx() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(AuthTrxController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
      }
	}
	/**
	 * Method to export AuthTrx look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of authTrx object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/authTrxExport", method = RequestMethod.POST)
	public ModelAndView authTrxExport(HttpServletResponse response, HttpServletRequest request){
		List<String> authTrxList = new LinkedList<String>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String authTrxMsg="";
		try{
			String userSecurityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if (ApplicationConstants.USER_SECURITY_LEVEL_A.equalsIgnoreCase(userSecurityLevel)) {
				authTrxList = facade.getApplicationState().getAuthTrxList();
				if(authTrxList != null && authTrxList.size() != 0){
					// Key map to create header
					Map<String,String> keyMap = new LinkedHashMap<String,String>();
					keyMap.put("authTrx", "Aetna Id");
					
					RteIntranetUtils.exportToExcel(response, authTrxList, keyMap);
					authTrxMsg = ApplicationConstants.EXPORT_SUCCESS;
				} else {
					authTrxMsg = ApplicationConstants.NO_DATA;
				}
				lookUpTableListVO.setAuthTrxVOList(authTrxList);
		        modelAndView = new ModelAndView(AUTHTRX_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
		        modelAndView.addObject("authTrxMsg",authTrxMsg);
		        modelAndView.addObject("securityLevel", userSecurityLevel);
			    return modelAndView;
			} else {
				String errorMsg = ApplicationConstants.NO_AUTHORITY;
				errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
				errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
				return errorModelAndView;
			}
		} catch (ApplicationException e){
            log.error("Exception occured in AuthTrxController - authTrxExport() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_EXPOT_TABLE + "(AuthTrxController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
      }
	}
}
