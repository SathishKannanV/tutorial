/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;
import com.aetna.prvrte.rteintranet.dto.TOSDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 *Cognizant_Offshore
 */
public interface TOSDAO {

	
	/**
	 * 
	 * @param tosDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map getTOSLookUpTable(TOSDTO tosDTO) throws ApplicationException ;





	/**
	 * 
	 * @param tosDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map addNewTOS(TOSDTO tosDTO)throws ApplicationException ;









	/**
	 * 
	 * @param tosDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map deleteTOS(TOSDTO tosDTO)throws ApplicationException ;

	/**
	 * 
	 * @param editedTOSDTO
	 * @param tosDtoList
	 * @param index
	 * @return
	 * @throws ApplicationException
	 */
	Map addUpdateTOS(TOSDTO editedTOSDTO, List<TOSDTO> tosDtoList, int index,char updatedInd)throws ApplicationException ;










}
