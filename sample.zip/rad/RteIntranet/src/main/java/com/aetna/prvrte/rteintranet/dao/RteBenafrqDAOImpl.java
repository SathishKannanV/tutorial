/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.BenafrqDisplayAdapter;
import com.aetna.prvrte.rteintranet.adapter.BenafrqAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.BenafrqDeleteAdapter;
import com.aetna.prvrte.rteintranet.dto.BenafrqDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.dao.RteBenafrqDAO
 * 
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Repository
public class RteBenafrqDAOImpl implements RteBenafrqDAO{
	/*
	 * Instance of BenafrqDisplayAdapter
	 */
	@Autowired(required = true)
	private BenafrqDisplayAdapter benafrqDisplayAdapter;
	/*
	 * Instance of BenafrqAddAdapter
	 */
	@Autowired(required = true)
	private BenafrqAddAdapter benafrqAddAdapter;
	/*
	 * Instance of BenafrqDeleteAdapter
	 */
	@Autowired(required = true)
	private BenafrqDeleteAdapter benafrqDeleteAdapter;
	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteBenafrqDAO#getBenafrqLookUpList(com.aetna.prvrte.rteintranet.dto.BenafrqDTO)
	 */
	@Override
	public Map<String, Object> getBenafrqLookUpList(BenafrqDTO benafrqDTO) throws ApplicationException {
		return benafrqDisplayAdapter.getBenafrqLookUpList(benafrqDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteBenafrqDAO#addBenafrqToDb(com.aetna.prvrte.rteintranet.dto.BenafrqDTO)
	 */
	@Override
	public Map<String, Object> addBenafrqToDb(BenafrqDTO benafrqDTO) throws ApplicationException {
		return benafrqAddAdapter.addBenafrqToDb(benafrqDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteBenafrqDAO#deleteBenafrq(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public Map<String, Object> deleteBenafrq(String defacumAccumCd, String benafrqAfreqCd, String hmobBenefitCd) throws ApplicationException {
		return benafrqDeleteAdapter.deleteBenafrq(defacumAccumCd, benafrqAfreqCd,hmobBenefitCd);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteBenafrqDAO#addUpdateBenafrq(com.aetna.prvrte.rteintranet.dto.BenafrqDTO, java.util.List, int)
	 */
	@Override
	public Map<String, Object> addUpdateBenafrq(BenafrqDTO benafrqDTO,List<BenafrqDTO> benafrqDTOList, int index) throws ApplicationException {
		return benafrqAddAdapter.addUpdateBenafrq(benafrqDTO, benafrqDTOList, index);
	}
}
