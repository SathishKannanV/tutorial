/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * 
 * <h1>RteAuthTrxDAO</h1> The RteAuthTrxDAO is responsible for handling the
 * storage, retrieval, and search data from/to data store.
 * 
 * @author N726899 Cognizant_Offshore
 * 
 */
public interface RteAuthTrxDAO {
	/**
	 * Method to get the AuthTrx list from data store.
	 * 
	 * @param authTrx
	 *            String of aetna id.
	 * @return Map of AetCtls list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if data not found in data store.
	 */
	Map<String, Object> getAuthTrxLookUpList(String authTrx) throws ApplicationException;
	/**
	 * Method to add new AuthTrx to data store.
	 * 
	 * @param authTrx
	 *            String of aetna id.
	 * @return Map of AetCtls list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	Map<String, Object> addAuthTrxToDb(String authTrx) throws ApplicationException;
	/**
	 * Method to delete the AuthTrx data from data store.
	 * 
	 * @param authTrxList
	 *            List of aetna ids.
	 * @param takeAction
	 *            List of selected indexes to delete aetna id.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from AuthTrx list and success or
	 *         error message.
	 * @throws ApplicationException
	 *             if deletion fails.
	 */
	Map<String, Object> deleteAuthTrx(List<String> authTrxList, String authTrx, int index) throws ApplicationException;
	
	/**
	 * Method to add/update list of AuthTrx to data store.
	 * 
	 * @param authTrxList
	 *            List of aetna ids.
	 * @param takeAction
	 *            List of selected indexes to delete aetna id.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from AuthTrx list, success or
	 *         error message and list of AuthTrx.
	 * @throws ApplicationException
	 *             if insertion or update fails.
	 */
	Map<String, Object> addUpdateAuthTrx(List<String> authTrxList, String authTrx, int index) throws ApplicationException;
}
