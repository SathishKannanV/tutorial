/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RbbcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N657186
 * Cognizant_Offshore
 */

public class RbbcRBB1Adapter extends StoredProcedure{
	private final Log log = LogFactory.getLog(RbbcRBB1Adapter.class);
	
	
	
	public RbbcRBB1Adapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		declareParameter(new SqlParameter(DBConstants.IN_BNFT_ID_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_SVCTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RBBC_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR1, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;			//Used by RBBCDisplay, not on database
				RbbcDTO rbbcDTO = new RbbcDTO();
				rbbcDTO.setDbRBBCCd(rs.getString("RBBC_CD"));
				rbbcDTO.setDbSvcTypeCd(rs.getString("RBBC_SVCTYP_CD"));
				rbbcDTO.setDbBnftIdCd(rs.getString("RBBC_BNFT_ID_CD"));
				rbbcDTO.setDbEffDate(rs.getString("RBBC_EFF_DT"));
				rbbcDTO.setDbPostedDate(rs.getString("RBBC_POSTED_DT"));
				rbbcDTO.setDbUpdatedInd(updatedInd);
				return rbbcDTO;
			}

		}));

	}
	
	@SuppressWarnings("unchecked")
	public Map getRbbcLookUp (RbbcDTO rbbcDTO) throws ApplicationException {
		log.warn("Entered RbbcRBB1Adapter  - getRbbcLookUp");
		//It fetches rbbc list based on the criteria selected by user
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map rbbcMap = new HashMap();
		String bnft_id = RteIntranetUtils.getTrimmedString(rbbcDTO.getDbBnftIdCd());
		String svcType = RteIntranetUtils.getTrimmedString(rbbcDTO.getDbSvcTypeCd());
		String rbbc_cd = RteIntranetUtils.getTrimmedString(rbbcDTO.getDbRBBCCd());
		params.put(DBConstants.IN_BNFT_ID_CD, bnft_id);
		params.put(DBConstants.IN_SVCTYP_CD, svcType);
		params.put(DBConstants.IN_RBBC_CD, rbbc_cd);		
		
		log.warn(params);
		Map results = null;
		
		List<RbbcDTO> rbbcList = new LinkedList<RbbcDTO>();
		String newMessage="";
		int noOfElements;
		try {
			log.warn("RbbcRBB1Adapter: Executing stored procedure : " + "benefit id : " + bnft_id + " ; svcTypeCode : "+svcType
					+"; rbbc code : "+ rbbc_cd);
					
			results = execute(params);
			log.warn("RbbcRBB1Adapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_CODE));
			
			rbbcList = (List<RbbcDTO>) results
					.get(DBConstants.READ_CURSOR1);	
	
			noOfElements = rbbcList.size();
			//if (null != results) {
			if (rbbcList.isEmpty()){
				
				if ("0".equals(sqlCode)) {
					newMessage = "No Data for ";
					newMessage = getMessage(newMessage, bnft_id, svcType,rbbc_cd);
				} else {
					newMessage = "Problem in DB2. sqlcode: " + sqlCode; 
					newMessage = getMessage(newMessage, bnft_id, svcType,rbbc_cd);
				}			  		  		  
			} else {
				if (noOfElements > 1) {
			    	newMessage = noOfElements + " Rows found for ";
				} else {
			    newMessage = noOfElements + " Row found for ";
				}
				newMessage = getMessage(newMessage, bnft_id, svcType,rbbc_cd);
			}
			/*}else{
				newMessage = "You must enter, at least, a Benefit Id Cd OR a Service Type Code OR a RBBC Code on the Look Up page.";
			}*/
			rbbcMap.put("rbbcMessage", newMessage);
			rbbcMap.put("rbbcList",rbbcList);
			return rbbcMap;
		}catch (Exception exception){
			log.error("RbbcRBB1Adapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
		
	}
	
	
	public String getMessage (String newMessage, String queryBnftIdCd, String querySvcTypeCd, String queryRBBCCd) {
		String getMessage = newMessage;
	    if (!"".equals(queryBnftIdCd)) 
		    getMessage = getMessage + " Benefit Id : " + queryBnftIdCd;
	    if (!"".equals(querySvcTypeCd))
		    getMessage = getMessage + " Service Type : " + querySvcTypeCd;
		    if (!"".equals(queryRBBCCd))
  		    getMessage = getMessage + " RBBC Code : " + queryRBBCCd;
		return getMessage;
}
}
