/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class AuthTrxAddAdapter extends StoredProcedure {

	public AuthTrxAddAdapter() {}
	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(AuthTrxAddAdapter.class);
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public AuthTrxAddAdapter(DataSource datasource, String authTrxStoredProc)
			throws SQLException {
		super(datasource, authTrxStoredProc);
		log.info(" ------------------> " + authTrxStoredProc);
		//SQL Params(Input)
		declareParameter(new SqlParameter(DBConstants.IN_USERID_NO, Types.CHAR));
		//Out Params
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		declareParameter(new SqlOutParameter(DBConstants.LS_ACTION_CD, Types.CHAR));

	}
	/**
	 * Method to add new AuthTrx to data store.
	 * 
	 * @param authTrx
	 *            String of aetna id.
	 * @return Map of AetCtls list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	public Map<String, Object> addAuthTrxToDb(String authTrx)throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<String> authTrxList = new LinkedList<String>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String newMessage = "";
		try {
			//query params		
			String padAetnaControl = RteIntranetUtils.getTrimmedString(authTrx);
			
			params.put(DBConstants.IN_USERID_NO, RteIntranetUtils.getTrimmedString(padAetnaControl));
			
			log.info("Params to put new adavsct : " + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			if ("0".equals(sqlCode)) {
				authTrxList.add(authTrx);
			} else {
				newMessage =  ApplicationConstants.ADD_UPDATE_ROW_FAILS + sqlCode;
			}
			
			resultMap.put("authTrxMsg", newMessage);
			resultMap.put("authTrxList", authTrxList);
		} catch (DataAccessException dae) {
			log.error("AuthTrxAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("AuthTrxAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
		return resultMap;
	}
	
	/**
	 * Method to add/update list of AuthTrx to data store.
	 * 
	 * @param authTrxList
	 *            List of aetna ids.
	 * @param takeAction
	 *            List of selected indexes to delete aetna id.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from AuthTrx list, success or
	 *         error message and list of AuthTrx.
	 * @throws ApplicationException
	 *             if insertion or update fails.
	 */
	public Map<String, Object> addUpdateAuthTrx(List<String> authTrxList, String authTrx, int index) throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String newMessage = "";
		String sqlCode ="";
		boolean isAuthTrxAddorUpdated = false;
		
		String aetnaContol = RteIntranetUtils.getTrimmedString(authTrx);
		//query params		
		params.put(DBConstants.IN_USERID_NO, aetnaContol);

		log.info("Params to put new adavsct : " + params);
		try{
			Map<String, Object> results = execute(params);
			sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			
			if ("0".equals(sqlCode)) {
				authTrxList.add(authTrx);
				newMessage = "Rows added were placed at the bottom of the list.";
			} else if ("-803".equals(sqlCode)) {
				isAuthTrxAddorUpdated = true;
				newMessage = "Unable to add Control, already exists on database. sqlcode = " + sqlCode;
			} else {
				isAuthTrxAddorUpdated = true;
				newMessage = "Adding of rows failed with a SQLCODE code of " + sqlCode;
			}
			
			resultMap.put("authTrxMsg", newMessage);
			resultMap.put("authTrxList", authTrxList);
			resultMap.put("isAuthTrxAddorUpdated", isAuthTrxAddorUpdated);
			return resultMap;
		}catch (DataAccessException dae) {
			log.error("AuthTrxAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("AuthTrxAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
	}
}
