/*
 * Created Apr 2010
 */
package com.aetna.prvrte.rteintranet.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author Kent Rancourt
 */
@Controller
public class HttpErrorController {

	@RequestMapping(value = "/errors/403")
	public String handle403() {
		return ".unauthorized";
	}
	
	@RequestMapping(value = "/errors/404")
	public String handle404() {
		return ".notFound";
	}
	
}