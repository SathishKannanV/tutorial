/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.TosctAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.TosctDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.TosctDisplayAdapter;
import com.aetna.prvrte.rteintranet.dto.TosctDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Repository
public class TosctDAOImpl implements TosctDAO {
	
	@Autowired(required=true)
	private TosctDisplayAdapter tosctDisplayAdapter;

	@Autowired(required=true)
	private TosctAddAdapter tosctAddAdapter;
	
			@Autowired(required=true)
	private TosctDeleteAdapter tosctDeleteAdapter;
	
	
	/**
	 * 
	 * @param tosctDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map getTosctLookUpTable(TosctDTO tosctDTO)
			throws ApplicationException {
		
		return tosctDisplayAdapter.getTosctLookUpTable(tosctDTO);
	}

	
	/**
	 * 
	 * @param tosctDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addNewTosct(TosctDTO tosctDTO) throws ApplicationException {
		return tosctAddAdapter.addNewTosct(tosctDTO);
	}

	/**
	 * 
	 * @param tosctDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map deleteTosct(TosctDTO tosctDTO) throws ApplicationException {
		return tosctDeleteAdapter.deleteTosct(tosctDTO);
	}

	/**
	 * 
	 * @param editedTosctDTO
	 * @param tosctDtoList
	 * @param index
	 * @param  updateInd
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addUpdateTosct(TosctDTO editedTosctDTO,
			List<TosctDTO> tosctDtoList, int index,char updateInd)
			throws ApplicationException {
		return tosctAddAdapter.addUpdateTosct( editedTosctDTO, tosctDtoList,  index, updateInd);
	}


}
