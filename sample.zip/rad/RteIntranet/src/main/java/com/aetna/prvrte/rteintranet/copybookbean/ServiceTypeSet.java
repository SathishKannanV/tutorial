package com.aetna.prvrte.rteintranet.copybookbean;

import java.util.List;

import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

public class ServiceTypeSet {

	String serviceTypeCTR;
	List<String> serviceTypeCode;
	public String getServiceTypeCTR() {
		
		return serviceTypeCTR;
	}
	public void setServiceTypeCTR(String serviceTypeCTR) {
		
		this.serviceTypeCTR = serviceTypeCTR;
	}
	public List<String> getServiceTypeCode() {
		
		return this.serviceTypeCode;
	}
	public void setServiceTypeCode(List<String> serviceTypeCode) {
		this.serviceTypeCode = serviceTypeCode;
	}
	public StringBuilder getServiceType(){

		int popCount;
		StringBuilder type = new StringBuilder();
        popCount = getServiceTypeCode().size();
       
		for(int i=0; i<popCount; i++) {
			type.append(RteIntranetUtils.spaceFiller(2, getServiceTypeCode().get(i)));
		}
		for(int i=popCount; i<99; i++) {
			type.append(RteIntranetUtils.spaceFiller(2));
	}
		
		return type;
	
	}
}
