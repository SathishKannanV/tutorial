package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.SitemsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


/**
 * @author N624926
 * Cognizant_Offshore
 */
public class SitemsgAddAdapter extends StoredProcedure{
	
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(SitemsgAddAdapter.class);

	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public SitemsgAddAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_AUTHCRT_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_BENRSP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_COMP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_CUSTSM_TXT, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_IONTWK_TXT, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_NTWK_ID_NO, Types.INTEGER));
		declareParameter(new SqlParameter(DBConstants.LS_PCP_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_PLNNTW_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_PLNTYP_DT, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_POSTED_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.LS_PRVDRM_DT, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_SEQ_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(DBConstants.LS_SITE_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_SVCTYP_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		declareParameter(new SqlOutParameter(DBConstants.LS_ACTION_CODE, Types.CHAR));
	}
	
	
	/**
	 * Method to add new SITEMSG to data store.
	 * 
	 * @param sitemsgDTO
	 *            sitemsgDTO object.
	 * @return Map of added SITEMSG data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addNewSitemsg(SitemsgDTO sitemsgDTO) throws ApplicationException {
		
		log.warn("Entered SitemsgAddAdapter  - addNewSitemsg");
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map sitemsgMap = new HashMap();
		Date todaysDate = new Date(System.currentTimeMillis());
		String postedDate = todaysDate.toString();
		sitemsgDTO.setDbPostedDate(postedDate);
		sitemsgDTO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
		params.put(DBConstants.LS_AUTHCRT_CD, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbAuthCertCd()));
		params.put(DBConstants.LS_BENRSP_CD, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbResponseCd()));
		params.put(DBConstants.LS_COMP_CD, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbCompanyCd()));
		params.put(DBConstants.LS_CUSTSM_TXT, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbCustServText()));
		params.put(DBConstants.LS_IONTWK_TXT, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbInOutNetInd()));
		params.put(DBConstants.LS_NTWK_ID_NO, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbNetworkIdNo()));
		params.put(DBConstants.LS_PCP_IND, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbPCPInd()));
		params.put(DBConstants.LS_PLNNTW_CD, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbPlanNtwkCd()));
		params.put(DBConstants.LS_PLNTYP_DT, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbPlanTypeCd()));
		params.put(DBConstants.LS_POSTED_DT, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbPostedDate()));
		params.put(DBConstants.LS_PRVDRM_DT, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbPrvdrText()));
		params.put(DBConstants.LS_SEQ_NO, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbSeqNo()));
		params.put(DBConstants.LS_SITE_CD, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbSiteCd()));
		params.put(DBConstants.LS_SVCTYP_CD, RteIntranetUtils.getTrimmedString(sitemsgDTO.getDbSvcTypeCd()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("SitemsgAddAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			String actionCode =  String.valueOf(results
					.get(DBConstants.LS_ACTION_CODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				List<SitemsgDTO> sitemsgList = new LinkedList<SitemsgDTO>();
				sitemsgList.add(sitemsgDTO);
				sitemsgMap.put("sitemsgList", sitemsgList);
				if ("A".equalsIgnoreCase(actionCode)) {
					newMessage = "This row added to the database";
				}else {
					newMessage ="Row already exists on the database. It was updated with these values.";					
					sitemsgDTO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
				}				
				}
			else {
				newMessage = "Unable to add row to the database. SQLCODE = " + sqlCode;
			}
			
			sitemsgMap.put("sitemsgMessage", newMessage);
		return sitemsgMap;
	}catch (Exception exception){
		log.error("SitemsgAddAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}

	/**
	 * Method to add/update list of SITEMSG to data store.
	 * 
	 * @param existingSitemsg
	 *            
	 * @param sitemsgDtoList
	 *            list of SitemsgDTO object.
	 * @param index
	 *            index to update the data
	 * @param updateInd
	 * 			  update indicator to update the data
	 * @return Map of flag to delete the data from SITEMSG list, success or
	 *         error message and list of SITEMSG.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addUpdateSitemsg(SitemsgDTO existingSitemsg,
			List<SitemsgDTO> sitemsgDtoList, int index,char updateInd) throws ApplicationException{
		log.warn("Entered SitemsgPRX2Adapter  - addUpdateSitemsg");
		boolean isSitemsgAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map sitemsgMap = new HashMap();
		Date todaysDate = new Date(System.currentTimeMillis());
		String postedDate = todaysDate.toString();
		existingSitemsg.setDbPostedDate(postedDate);
		params.put(DBConstants.LS_AUTHCRT_CD, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbAuthCertCd()));
		params.put(DBConstants.LS_BENRSP_CD, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbResponseCd()));
		params.put(DBConstants.LS_COMP_CD, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbCompanyCd()));
		params.put(DBConstants.LS_CUSTSM_TXT, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbCustServText()));
		params.put(DBConstants.LS_IONTWK_TXT, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbInOutNetInd()));
		params.put(DBConstants.LS_NTWK_ID_NO, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbNetworkIdNo()));
		params.put(DBConstants.LS_PCP_IND, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbPCPInd()));
		params.put(DBConstants.LS_PLNNTW_CD, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbPlanNtwkCd()));
		params.put(DBConstants.LS_PLNTYP_DT, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbPlanTypeCd()));
		params.put(DBConstants.LS_POSTED_DT, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbPostedDate()));
		params.put(DBConstants.LS_PRVDRM_DT, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbPrvdrText()));
		params.put(DBConstants.LS_SEQ_NO, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbSeqNo()));
		params.put(DBConstants.LS_SITE_CD, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbSiteCd()));
		params.put(DBConstants.LS_SVCTYP_CD, RteIntranetUtils.getTrimmedString(existingSitemsg.getDbSvcTypeCd()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("SitemsgAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.LS_ACTION_CODE));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				isSitemsgAddorUpdated = true;
				if ("A".equalsIgnoreCase(actionCode)) {
					
					if (updateInd == ApplicationConstants.COPY)						
						sitemsgDtoList.set(index, existingSitemsg);						
					else
						sitemsgDtoList.add(existingSitemsg);
				}
				else if (updateInd == ApplicationConstants.COPY)
					existingSitemsg.setDbUpdatedInd(ApplicationConstants.COPY);	
				sitemsgDtoList.set(index, existingSitemsg);
				
				newMessage = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted in RED";
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			sitemsgMap.put("sitemsgMsg",newMessage);
			sitemsgMap.put("sitemsgDtoList",sitemsgDtoList);
			sitemsgMap.put("isSitemsgAddorUpdated", isSitemsgAddorUpdated);
			return sitemsgMap;
		}catch (Exception exception){
			log.error("SitemsgAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}

}