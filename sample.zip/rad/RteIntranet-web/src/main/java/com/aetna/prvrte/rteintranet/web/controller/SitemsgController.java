package com.aetna.prvrte.rteintranet.web.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.aetna.prvrte.rteintranet.dto.SitemsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.SitemsgVO;

/**
 * The SitemsgController is responsible for handling
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * @author N624926
 * Cognizant_Offshore
 */

@Controller
@RequestMapping(value = "/sitemsg/*")
public class SitemsgController {

	/*
	 * Tile name of the sitemsg Home view.
	 */
	public static final String SITEMSG_HOME = ".sitemsgHome";
	/*
	 * Tile name of the sitemsg Display view.
	 */
	public static final String SITEMSG_LOOKUP = ".sitemsgLookUpDisplay";
	/*
	 * Tile name of the Add New sitemsg Form view.
	 */
	public static final String SITEMSG_ADD = ".sitemsgAdd";
	/*
	 * Tile name of the Help sitemsg .
	 */
	public static final String SITEMSG_HELP= ".sitemsgHelp";
	/*
	 * Constant name used for COPY indicator.
	 */
	public static final char COPY = 'C';

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(SitemsgController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errormav;
	
	
	/**
	 * Method to getSitemsgLookUpHome view
	 * 
	 * @param model
	 * 
	 * @return view of sitemsgLookUp, if fails return error page
	 */
	@RequestMapping(value="/sitemsgHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getSitemsgLookUpHome(final HttpServletRequest request,Model model) {	
		log.warn("Entered SitemsgController - getSitemsgLookUpHome()");
		String securityLevel ="";
		try {
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(SITEMSG_HOME, "sitemsgVO",  new SitemsgVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("SitemsgController - securityLevel: "+ securityLevel);
		log.warn("Exit from SitemsgController - getSitemsgLookUpHome()");
		return mav;
		} catch (ApplicationException e){
			log.error("Exception occured in SitemsgController - getSitemsgLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * Method to loadSitemsgHelp view
	 * 
	 * @return view of sitemsgHelp
	 */
	@RequestMapping(value="/sitemsgHelp")
	public String loadSitemsgHelp() {   
		return SITEMSG_HELP;
	}
	
	/**
	 * Method to get the sitemsgLookUp List from data store.
	 * 
	 * @param sitemsgVO
	 *            form view object of sitemsg.
	 * @return view of sitemsgDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSitemsg", method = RequestMethod.POST)
	public ModelAndView getSitemsgLookUpTable(HttpServletRequest request,@ModelAttribute("sitemsgForm")SitemsgVO sitemsgVO){
		String siteCd ="";
		String svcTypeCode ="";
		String securityLevel ="";
		ModelAndView mav ;
		Map sitemsgResultMap = new HashMap();
		List<SitemsgVO> sitemsgList = new LinkedList<SitemsgVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			siteCd = sitemsgVO.getDbSiteCd();
			svcTypeCode = sitemsgVO.getDbSvcTypeCd();
			sitemsgResultMap = facade.getSitemsgLookUpTable(siteCd, svcTypeCode);
			List<SitemsgDTO> sitemsgDTOList = (List<SitemsgDTO>) sitemsgResultMap.get("sitemsgList");
			sitemsgList = (List<SitemsgVO>) RTETranslator.toSitemsgVOList(sitemsgDTOList);
			lookUpListVO.setSitemsgVOList(sitemsgList);
			facade.getApplicationState().setSitemsgList(sitemsgList);
			mav = new ModelAndView(SITEMSG_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("sitemsgMessage", sitemsgResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("getSitemsgLookUpTable - sitemsgMessage: "+ sitemsgResultMap.get("newMessage"));
			log.warn("Exit from SitemsgController - getSitemsgLookUpTable()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SitemsgController - getSitemsgLookUpTable() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="getSitemsgLookUpTable() :"+ApplicationConstants.ERROR_GET_LOOKUP + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to display get add new Sitemsg form home view.
	 * 
	 * @return view of loadAddNewSitemsgRowScreen, if fails return error page
	 */
	@RequestMapping(value="/AddNewSitemsgRow")
	public ModelAndView loadAddNewSitemsgRowScreen(final HttpServletRequest request,Model model) {	
		log.warn("Entered SitemsgController - loadAddNewSitemsgRowScreen()");
		ModelAndView mav = new ModelAndView(SITEMSG_ADD, "sitemsgVO",  new SitemsgVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in SitemsgController - loadAddNewSitemsgRowScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (loadAddNewSitemsgRowScreen). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		log.warn("Exit from SitemsgController - loadAddNewSitemsgRowScreen()");
		return mav;
	}
	
	
	/**
	 * Method to add the data database
	 * 
	 * @param sitemsgVO form view object of Sitemsg.
	 * @return view of sitemsgDisplay, if fails return error page
	 * 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddSitemsg", method = RequestMethod.POST)
	public ModelAndView addNewSitemsg(final HttpServletRequest request,@ModelAttribute("addSitemsgForm")SitemsgVO sitemsgVO){
		log.warn("Entered SitemsgController - addNewSitemsg()");
		ModelAndView mav ;
		Map sitemsgResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<SitemsgDTO> sitemsgDtoList = new LinkedList<SitemsgDTO>();
		List<SitemsgVO> sitemsgVoList = new LinkedList<SitemsgVO>();
		String securityLevel ="";
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			sitemsgVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
			SitemsgDTO sitemsgDTO = RTETranslator.toSitemsgDTO(sitemsgVO);
			sitemsgResultMap = facade.addNewSitemsg(sitemsgDTO);
			if(sitemsgResultMap.get("sitemsgList")!=null){
				sitemsgDtoList = (List<SitemsgDTO>) sitemsgResultMap.get("sitemsgList");
				sitemsgVoList = RTETranslator.toSitemsgVOList(sitemsgDtoList);
			}
			lookUpListVO.setSitemsgVOList(sitemsgVoList);
			facade.getApplicationState().setSitemsgList(sitemsgVoList);
			mav = new ModelAndView(SITEMSG_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("securityLevel", securityLevel);
			mav.addObject("sitemsgMessage", sitemsgResultMap.get("sitemsgMessage"));
			log.warn("addNewSitemsg - sitemsgMessage: "+ sitemsgResultMap.get("sitemsgMessage"));
			log.warn("Exit from SitemsgController - addNewSitemsg()");			
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in SitemsgController - addNewSitemsg() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addNewSitemsg() :"+ApplicationConstants.ERROR_ADD_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to delete the Sitemsg List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of sitemsgDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteSitemsg", method = RequestMethod.POST)
	public ModelAndView deleteSitemsg(final HttpServletRequest request,@ModelAttribute("sitemsgDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String sitemsgMsg = "";
		boolean isSitemsgDeleted = true;
		String securityLevel ="";
		Map sitemsgResultMap = new HashMap();
		List<SitemsgVO> sitemsgList = new LinkedList<SitemsgVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			sitemsgList = lookUpListVO.getSitemsgVOList();
			int i;
			if ((sitemsgList != null) && (takeAction != null)) {
				for(SitemsgVO sitemsgVO : sitemsgList){
					if(sitemsgVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						sitemsgVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					SitemsgVO existingSitemsg = (SitemsgVO) sitemsgList.get(i);
					if (existingSitemsg.getDbUpdatedInd() != ApplicationConstants.COPY) {
						SitemsgDTO sitemsgDTO = RTETranslator.toSitemsgDTO(existingSitemsg);
						sitemsgResultMap = facade.deleteSitemsg(sitemsgDTO);
						sitemsgMsg = (String) sitemsgResultMap.get("sitemsgMsg");
						isSitemsgDeleted = (Boolean) sitemsgResultMap.get("isSitemsgDeleted");
						if(isSitemsgDeleted == true){
							sitemsgList.remove(i);
						}else{
							j = 0;
						}
					}else{
						sitemsgList.remove(i);
					}				
			}
				if(isSitemsgDeleted == true)
					sitemsgMsg = "Rows selected were Deleted in the database/list";
		}else
			sitemsgMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSitemsgList(sitemsgList);
			lookUpListVO.setSitemsgVOList(sitemsgList);
			mav = new ModelAndView(SITEMSG_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("sitemsgMessage",sitemsgMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteSitemsg - sitemsgMessage: "+ sitemsgMsg);
		    log.warn("Exit from SitemsgController - deleteSitemsg()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SitemsgController - deleteSitemsg() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteSitemsg() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	
	/**
	 * Method to copy the Sitemsg List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of sitemsgDisplay, if fails return error page
	 */
	@RequestMapping(value="/copySitemsg", method = RequestMethod.POST)
	public ModelAndView copySitemsg(final HttpServletRequest request,@ModelAttribute("sitemsgDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String sitemsgMsg = "";
		String securityLevel ="";
		int i;
		List<SitemsgVO> sitemsgList = new LinkedList<SitemsgVO>();
		try{
			//String postedDate =RteIntranetUtils.getPostedDate(); //Initialize Posted Date to today's date
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			sitemsgList = lookUpListVO.getSitemsgVOList();
			if ((sitemsgList != null) && (takeAction != null)) {
				for(SitemsgVO sitemsgVO : sitemsgList){
					if(sitemsgVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						sitemsgVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					i = Integer.parseInt(takeAction[j]);
					SitemsgVO existingSitemsg = (SitemsgVO) sitemsgList.get(i);
					
					SitemsgVO copySitemsg = new SitemsgVO(existingSitemsg.getDbAuthCertCd(), existingSitemsg.getDbResponseCd() , existingSitemsg.getDbCompanyCd() , existingSitemsg.getDbCustServText() ,
							existingSitemsg.getDbInOutNetInd() , existingSitemsg.getDbNetworkIdNo() , existingSitemsg.getDbPCPInd() , existingSitemsg.getDbPlanNtwkCd() ,
							existingSitemsg.getDbPlanTypeCd() ,existingSitemsg.getDbPostedDate() , existingSitemsg.getDbPrvdrText() , existingSitemsg.getDbSeqNo() ,
							existingSitemsg.getDbSiteCd() , existingSitemsg.getDbSvcTypeCd() , COPY);
					sitemsgList.add(copySitemsg);
				}
				sitemsgMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				sitemsgMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSitemsgList(sitemsgList);
			lookUpListVO.setSitemsgVOList(sitemsgList);
			mav = new ModelAndView(SITEMSG_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("sitemsgMessage",sitemsgMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copySitemsg - sitemsgMessage: "+ sitemsgMsg);
		    log.warn("Exit from SitemsgController - copySitemsg()");
			return mav;		
		}catch (Exception e){
			log.error("Exception occured in SitemsgController - copySitemsg() method:"+e.getMessage());
			String errorMsg ="copySitemsg() :"+ApplicationConstants.ERROR_COPY_ROW + RteIntranetUtils.getTrimmedString(e.getMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to Add/Update the Sitemsg List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of sitemsgDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateSitemsg", method = RequestMethod.POST)
	public ModelAndView addUpdateSitemsg(final HttpServletRequest request,@ModelAttribute("sitemsgDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered from SitemsgController - addUpdateSitemsg()");
		ModelAndView mav ;
		String sitemsgMsg = "";
		String securityLevel ="";
		List<SitemsgVO> updatedSitemsgList = new LinkedList<SitemsgVO>();
		List<SitemsgDTO> updatedSitemsgDtoList = new LinkedList<SitemsgDTO>();
		List<SitemsgVO> sitemsgVoList = new LinkedList<SitemsgVO>();
		List<SitemsgVO> modifiedSitemsgVoList = new LinkedList<SitemsgVO>();
		List<SitemsgDTO> sitemsgDtoList = new LinkedList<SitemsgDTO>(); 
		boolean isSitemsgAddOrUpdated = false;
		Map sitemsgResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			 sitemsgVoList = facade.getApplicationState().getSitemsgList();
			 modifiedSitemsgVoList = lookUpListVO.getSitemsgVOList();
			 int i;
			 Date todaysDate = new Date(System.currentTimeMillis());
			 String postedDate = todaysDate.toString();
			 if (takeAction != null && takeAction.length != 0) {
					if(sitemsgVoList != null && sitemsgVoList.size() != 0 
							&& modifiedSitemsgVoList.size() != 0 && modifiedSitemsgVoList != null){
				for(SitemsgVO sitemsgVO : sitemsgVoList){
					if(sitemsgVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						sitemsgVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				sitemsgDtoList = RTETranslator.toSitemsgDTOList(sitemsgVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char dBUpdatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					SitemsgVO selectedSitemsg = (SitemsgVO)sitemsgVoList.get(i);
					SitemsgVO editedSitemsg = (SitemsgVO) modifiedSitemsgVoList.get(i);
					SitemsgVO editedSitemsgVO = new SitemsgVO(editedSitemsg.getDbAuthCertCd(), editedSitemsg.getDbResponseCd() , editedSitemsg.getDbCompanyCd() , editedSitemsg.getDbCustServText() ,
							editedSitemsg.getDbInOutNetInd() , editedSitemsg.getDbNetworkIdNo() , editedSitemsg.getDbPCPInd() , editedSitemsg.getDbPlanNtwkCd() ,
							editedSitemsg.getDbPlanTypeCd() ,postedDate , editedSitemsg.getDbPrvdrText() , editedSitemsg.getDbSeqNo() ,
							editedSitemsg.getDbSiteCd() , editedSitemsg.getDbSvcTypeCd() , dBUpdatedInd);
					SitemsgDTO editedSitemsgDTO = RTETranslator.toSitemsgDTO(editedSitemsgVO);
					sitemsgResultMap = facade.addUpdateSitemsg(editedSitemsgDTO, sitemsgDtoList, i , selectedSitemsg.getDbUpdatedInd());
					updatedSitemsgDtoList = (List<SitemsgDTO>) sitemsgResultMap.get("sitemsgDtoList");
					updatedSitemsgList = RTETranslator.toSitemsgVOList(updatedSitemsgDtoList);
					isSitemsgAddOrUpdated = (Boolean) sitemsgResultMap.get("isSitemsgAddorUpdated") ;
					sitemsgMsg = (String) sitemsgResultMap.get("sitemsgMsg") ;
					if(isSitemsgAddOrUpdated!= true){
						j = takeAction.length;
					}
				}
				lookUpListVO.setSitemsgVOList(updatedSitemsgList);
				facade.getApplicationState().setSitemsgList(updatedSitemsgList);
					} else {
						throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	
					}
		}else{
			sitemsgMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setSitemsgVOList(sitemsgVoList);
			facade.getApplicationState().setSitemsgList(sitemsgVoList);
		}
			mav = new ModelAndView(SITEMSG_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("sitemsgMessage",sitemsgMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateSitemsg - sitemsgMessage: "+ sitemsgMsg);
		    log.warn("Exit from SitemsgController - addUpdateSitemsg()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SitemsgController - addUpdateSitemsg() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addUpdateSitemsg() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	
	/**
     * Method to export Sitemsg look up table to excel work book
     * 
      * @param lookUpTableListVO
     *            list of sitemsg object.
     * @param response
     *            response object to return
     * @return exported file to view.
     */
     @RequestMapping(value = "/sitemsgExport", method = RequestMethod.POST)
     public ModelAndView sitemsgExport(HttpServletResponse response){
           List<SitemsgVO> sitemsgList = new LinkedList<SitemsgVO>();
           LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
           String sitemsgMsg="";
           try{
                 sitemsgList = facade.getApplicationState().getSitemsgList();
                 if(sitemsgList != null && sitemsgList.size() != 0){
                 // Key map to create header
                 Map<String,String> keyMap = new LinkedHashMap<String,String>();
                 keyMap.put("dbSiteCd", "Site");
                 keyMap.put("dbSvcTypeCd", "Svc Type");
                 keyMap.put("dbNetworkIdNo", "Net Id");
                 keyMap.put("dbSeqNo", "Seq No");
                 keyMap.put("dbPCPInd", "PCP");
                 keyMap.put("dbPlanNtwkCd", "Pln Ntw");
                 keyMap.put("dbPlanTypeCd", "Pln Typ");
                 keyMap.put("dbInOutNetInd", "IO Net");
                 keyMap.put("dbResponseCd", "Resp Cd");
                 keyMap.put("dbAuthCertCd", "Auth Cert");
                 keyMap.put("dbPrvdrText", "Provider Text");
                 keyMap.put("dbCustServText", "Cust Svc Text");
                 keyMap.put("dbPostedDate", "Posted Date");
                 keyMap.put("dbCompanyCd", "Co. Code");
                 RteIntranetUtils.exportToExcel(response, sitemsgList, keyMap);
                 sitemsgMsg = "LookUp table exported successfully.";
                 } else {
                       sitemsgMsg = "No data found.";
                 }
                 lookUpTableListVO.setSitemsgVOList(sitemsgList);
                 mav = new ModelAndView(SITEMSG_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
                 mav.addObject("sitemsgMessage",sitemsgMsg);
                 return mav;
           }catch (ApplicationException e) {
                 log.error("Exception occured in SitemsgController - sitemsgExport() method:" + e.getMessage());
                 String errorMsg = "Error encountered while export to excel. ";
                 errorMsg.concat(e.toString());
                 errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
                 errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
                 return errormav;
           }
     }
	
}
