/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RtetierDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

public class RtetierDeleteAdapter extends StoredProcedure {
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RtetierDeleteAdapter.class);
	private static final String LS_ADD_UPDATE = "LS_ADD_UPDATE";
	private static final String LS_SQLCODE = "LS_SQLCODE";

	private static final String RTETIER_SAVINGS_CD = "RTETIER_SAVINGS_CD";
	private static final String RTETIER_CD = "RTETIER_CD";
	private static final String RTETIER_EFF_DT = "RTETIER_EFF_DT";
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtetierDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		declareParameter(new SqlParameter(RTETIER_SAVINGS_CD, Types.CHAR));
		declareParameter(new SqlParameter(RTETIER_CD, Types.CHAR));
		declareParameter(new SqlParameter(RTETIER_EFF_DT, Types.DATE));
		
		declareParameter(new SqlOutParameter(LS_SQLCODE, Types.INTEGER));
	}
	
	@SuppressWarnings("unchecked")
	public Map deleteRtetier(RtetierDTO rtetierDTO) throws ApplicationException {
		
		log.warn("Entered RtetierDeleteAdapter  - deleteRtetier");
		boolean isRtetierDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map rtetierMap = new HashMap();
			
		params.put(RTETIER_SAVINGS_CD, RteIntranetUtils.getTrimmedString(rtetierDTO.getRtetierSavingsCd()));
		params.put(RTETIER_CD, RteIntranetUtils.getTrimmedString(rtetierDTO.getRtetierCd()));
		params.put(RTETIER_EFF_DT, RteIntranetUtils.getTrimmedString(rtetierDTO.getEffDate()));
		
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("RtetierDeleteAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(LS_SQLCODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) 
				isRtetierDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			rtetierMap.put("rtetierMessage", newMessage);
			rtetierMap.put("isRtetierDeleted", isRtetierDeleted);
			return rtetierMap;
		}catch (Exception exception){
			
			log.error("RtetierDeleteAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
}
