package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.RbrcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class UserDeleteAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(UserDeleteAdapter.class);

	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public UserDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		declareParameter(new SqlParameter(DBConstants.LS_SITE_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_RIDER_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_SVCTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_TOS_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
	}
	
	
	/**
	 * Method to delete the Rbrc data from data store.
	 * 
	 * @param rbrcDTO
	 * 
	 * @return Map of flag to delete the data from Rbrc list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map deleteUser(RbrcDTO rbrcDTO) throws ApplicationException {
		
		log.warn("Entered UserDeleteAdapter  - deleteUser");
		boolean isRbrcDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map rbrcMap = new HashMap();
		params.put(DBConstants.LS_SITE_CD, RteIntranetUtils.getTrimmedString(rbrcDTO.getDbSiteCd()));
		params.put(DBConstants.LS_RIDER_CD, RteIntranetUtils.getTrimmedString(rbrcDTO.getDbRiderCd()));
		params.put(DBConstants.LS_SVCTYP_CD, RteIntranetUtils.getTrimmedString(rbrcDTO.getDbSvcTypeCd()));
		params.put(DBConstants.LS_TOS_CD, RteIntranetUtils.getTrimmedString(rbrcDTO.getDbTOSCd()));
		
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("UserDeleteAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) 
				isRbrcDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			rbrcMap.put("rbrcMsg", newMessage);
			rbrcMap.put("isRbrcDeleted", isRbrcDeleted);
			return rbrcMap;
		}catch (Exception exception){
			
			log.error("UserDeleteAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	
}
