package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.SrchcolDTO;
import com.aetna.prvrte.rteintranet.dto.SrcherrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


/**
 * @author N731694
 * Cognizant_Offshore
 */
public class SrcherrUpdateAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(SrcherrUpdateAdapter.class);
	
	private static final String LS_SRCHERR_CD = "LS_SRCHERR_CD";
	private static final String LS_SRCHERR_EFF_DT = "LS_SRCHCOL_EFF_DT";
	private static final String LS_SRCHERR_CUST_IND = "LS_SRCHERR_CUST_IND";
	private static final String LS_SRCHERR_DESC = "LS_SRCHERR_DESC";
	private static final String LS_SRCHERR_EXP_DT = "LS_SRCHERR_EXP_DT";
	private static final String LS_SRCHERR_POSTED_DT = "LS_SRCHERR_POSTED_DT";
	
	private static final String LS_ADD_UPDATE = "LS_ADD_UPDATE";
	private static final String LS_SQLCODE = "LS_SQLCODE";
	private static final String READ_CURSOR = "READ_CURSOR3";
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public SrcherrUpdateAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(LS_SRCHERR_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_SRCHERR_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(LS_SRCHERR_CUST_IND, Types.CHAR));
		declareParameter(new SqlParameter(LS_SRCHERR_DESC, Types.CHAR));
		declareParameter(new SqlParameter(LS_SRCHERR_EXP_DT, Types.DATE));
		declareParameter(new SqlParameter(LS_SRCHERR_POSTED_DT, Types.DATE));
	
		declareParameter(new SqlOutParameter(LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(LS_SQLCODE, Types.INTEGER));
	}
	
	
	

	
	@SuppressWarnings("unchecked")
	public Map addUpdateSrcherr(SrcherrDTO existingSrcherr,
			List<SrcherrDTO> srcherrDtoList, int index,char updateInd) throws ApplicationException{
		log.debug("Entered SrchcolupateAdapter  - addUpdateSrcherr");
		boolean isSrcherrAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map srcherrMap = new HashMap();
		Date todaysDate = new Date(System.currentTimeMillis());
		String postedDate = todaysDate.toString();
		existingSrcherr.setPostedDate(postedDate);

		params.put(LS_SRCHERR_CD, RteIntranetUtils.getTrimmedString(existingSrcherr.getSrcherrCd()));
		params.put(LS_SRCHERR_EFF_DT, RteIntranetUtils.getTrimmedString(existingSrcherr.getEffDate()));
		params.put(LS_SRCHERR_CUST_IND, RteIntranetUtils.getTrimmedString(existingSrcherr.getSrcherrCustInd()));
		params.put(LS_SRCHERR_DESC, RteIntranetUtils.getTrimmedString(existingSrcherr.getSrcherrDesc()));
		params.put(LS_SRCHERR_EXP_DT, RteIntranetUtils.getTrimmedString(existingSrcherr.getExpDate()));
		params.put(LS_SRCHERR_POSTED_DT, RteIntranetUtils.getTrimmedString(existingSrcherr.getPostedDate()));
		
		log.debug(params);	
		
		try {
					
			results = execute(params);
			log.debug("SrchcolUpdateAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(LS_SQLCODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
							isSrcherrAddorUpdated = true;
						//	existingSrchcol.setSrchcolCd((actionCode));
							srcherrDtoList.set(index, existingSrcherr);	
				
				newMessage = "All rows that changed the database are highlighted.";
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			srcherrMap.put("srcherrMsg",newMessage);
			srcherrMap.put("srcherrDtoList",srcherrDtoList);
			srcherrMap.put("isSrcherrAddorUpdated", isSrcherrAddorUpdated);
			return srcherrMap;
		}catch (Exception exception){
			log.error("Srchcol Update Adapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
}