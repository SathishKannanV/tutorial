package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.TosctDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class TosctDeleteAdapter extends StoredProcedure{
	private final Log log = LogFactory.getLog(TosctDeleteAdapter.class);
	private static final String LS_STC_CD = "LS_STC_CD";
	private static final String LS_TOS_CD = "LS_TOS_CD";
	private static final String LS_POS_CD = "LS_POS_CD";
	private static final String LS_ADA_CD = "LS_ADA_CD";
	private static final String LS_SQLCODE = "LS_SQLCODE";
	
	public TosctDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		declareParameter(new SqlParameter(LS_STC_CD, Types.CHAR));// param1
		declareParameter(new SqlParameter(LS_TOS_CD, Types.CHAR));// param2
		declareParameter(new SqlParameter(LS_POS_CD, Types.CHAR));// param3
		declareParameter(new SqlParameter(LS_ADA_CD, Types.CHAR));// param4
		declareParameter(new SqlOutParameter(LS_SQLCODE, Types.INTEGER));// param OUT
	}
	
	/**
	 * Method to delete the Tosct data from data store.
	 * 
	 * @param tosctDTO
	 * 
	 * @return Map of flag to delete the data from Tosct list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map deleteTosct(TosctDTO tosctDTO) throws ApplicationException {
		
		log.warn("Entered TosctDeleteAdapter  - deleteTosct");
		boolean isTosctDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map tosctMap = new HashMap();
		params.put(LS_STC_CD, RteIntranetUtils.getTrimmedString(tosctDTO.getDbSvcTypeCd()));
		params.put(LS_TOS_CD, RteIntranetUtils.getTrimmedString(tosctDTO.getDbTosCd()));
		params.put(LS_POS_CD, RteIntranetUtils.getTrimmedString(tosctDTO.getDbPosCd()));
		params.put(LS_ADA_CD, RteIntranetUtils.getTrimmedString(tosctDTO.getDbADACd()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("TosctAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results .get(LS_SQLCODE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
					isTosctDeleted = true;
			}
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			tosctMap.put("tosctMsg", newMessage);
			tosctMap.put("isTosctDeleted", isTosctDeleted);
			return tosctMap;
		}catch (Exception exception){
			
			log.error("TosctAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	
}
