package com.aetna.prvrte.rteintranet.copybookbean;


public class Name {

	String firstName;
	String middleName;
	String lastName;
	String titleDesc;
	public String getFirstName() {
		
		return firstName;
	}
	public void setFirstName(String firstName) {
		
		this.firstName = firstName;
	}
	public String getMiddleName() {
		
		return middleName;
	}
	public void setMiddleName(String middleName) {
		
		this.middleName = middleName;
	}
	public String getLastName() {
		
		return lastName;
	}
	public void setLastName(String lastName) {
		
		this.lastName = lastName;
	}
	public String getTitleDesc() {
		
		return titleDesc;
	}
	public void setTitleDesc(String titleDesc) {
		
		this.titleDesc = titleDesc;
	}
	public StringBuilder getName(){
		return new StringBuilder(getFirstName())
		.append(getMiddleName())
		.append(getLastName())
		.append(getTitleDesc());
	}
}
