package com.aetna.prvrte.rteintranet.dto;

public class SrchcolDTO {


	private String srchcolCd = new String(); 
	private String srchcolDesc = new String(); 
	private String effDate = new String(); 
	private String expDate = new String();
	private String postedDate = new String();
	private char   updatedInd;
	
	public SrchcolDTO() {
		super();
	}

	public SrchcolDTO(String srchcolCd, String srchcolDesc, String effDate, String expDate, String postedDate, char updatedInd) {
		super();
		this.srchcolCd = srchcolCd;
		this.srchcolDesc = srchcolDesc;
		this.effDate = effDate;
		this.expDate = expDate;
		this.postedDate = postedDate;
		this.updatedInd = updatedInd;
	}

	public String getEffDate() {
		return effDate;
	}

	public String getExpDate() {
		return expDate;
	}

	public String getPostedDate() {
		return postedDate;
	}

	public String getSrchcolCd() {
		return srchcolCd;
	}

	public String getSrchcolDesc() {
		return srchcolDesc;
	}

	public char getUpdatedInd() {
		return updatedInd;
	}

	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}

	public void setSrchcolCd(String srchcolCd) {
		this.srchcolCd = srchcolCd;
	}

	public void setSrchcolDesc(String srchcolDesc) {
		this.srchcolDesc = srchcolDesc;
	}

	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}

}
