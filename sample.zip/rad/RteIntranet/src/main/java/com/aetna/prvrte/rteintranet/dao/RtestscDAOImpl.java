/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.RtestscAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.RtestscDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.RtestscLookUpAdapter;
import com.aetna.prvrte.rteintranet.dto.RtestscDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

@Repository
public class RtestscDAOImpl implements RtestscDAO {

	@Autowired(required=true)
	private RtestscLookUpAdapter rtestscLookUpAdapter;
	
	@Autowired(required=true)
	private RtestscAddAdapter rtestscAddAdapter;
	
	@Autowired(required=true)
	private RtestscDeleteAdapter rtestscDeleteAdapter;
	
	@Override
	public Map getRtestscLookUp(RtestscDTO rtestscDTO) throws ApplicationException {
		return rtestscLookUpAdapter.getRtestscLookUpTable(rtestscDTO);
	}
	@Override
	public Map addNewRtestsc(RtestscDTO rtestscDTO) throws ApplicationException {
		return rtestscAddAdapter.addNewRtestsc(rtestscDTO);
	}
	
	@Override
	public Map deleteRtestsc(RtestscDTO rtestscDTO)
			throws ApplicationException {
		return rtestscDeleteAdapter.deleteRtestsc(rtestscDTO);
	}

	@Override
	public Map addUpdateRtestsc(RtestscDTO existRtestscDTO,
			List<RtestscDTO> rtestscDtoList, int index, char updateInd) throws ApplicationException {
		return rtestscAddAdapter.addUpdateRtestsc(existRtestscDTO, rtestscDtoList, index, updateInd);
	}
}
