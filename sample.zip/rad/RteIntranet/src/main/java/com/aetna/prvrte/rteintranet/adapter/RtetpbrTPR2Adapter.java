package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Timestamp;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.RtetpbrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


/**
 * @author N624926
 * Cognizant_Offshore
 */
public class RtetpbrTPR2Adapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RtetpbrTPR2Adapter.class);
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtetpbrTPR2Adapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.IN_RTETPBR_ID, Types.INTEGER));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPBR_BENRL_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPBR_SVC_TYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPBR_ACASTOS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPBR_ACASPOS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPBR_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPBR_EXPRTN_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPBR_PSTD_DTS, Types.TIMESTAMP));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPBR_USER_ID, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPBR_VALUE_TXT, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.OUT_LS_ADD_UPDATE, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.OUT_LS_SQLCODE, Types.INTEGER));
		
	}
	
	
	/**
	 * Method to add new RTETPBR to data store.
	 * 
	 * @param rtetpbrDTO
	 *            rtetpbrDTO object.
	 * @return Map of added RTETPBR data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addNewRtetpbr(RtetpbrDTO rtetpbrDTO) throws ApplicationException {
		
		log.warn("Entered RtetpbrTPR2Adapter  - addNewRtetpbr");
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map rtetpbrMap = new HashMap();
		Timestamp currentTS = new Timestamp(System.currentTimeMillis());
		String postedDate = currentTS.toString(); //Initialize Posted Date to the current timestamp
		rtetpbrDTO.setPostedDate(postedDate);
		rtetpbrDTO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
		params.put(DBConstants.IN_RTETPBR_ID, String.valueOf(rtetpbrDTO.getIdNo()));
		params.put(DBConstants.IN_RTETPBR_BENRL_CD, RteIntranetUtils.getTrimmedString(rtetpbrDTO.getBenrlCd()));
		params.put(DBConstants.IN_RTETPBR_SVC_TYP_CD, RteIntranetUtils.getTrimmedString(rtetpbrDTO.getSvctypCd()));
		params.put(DBConstants.IN_RTETPBR_ACASTOS_CD, RteIntranetUtils.getTrimmedString(rtetpbrDTO.getAcastosCd()));
		params.put(DBConstants.IN_RTETPBR_ACASPOS_CD, RteIntranetUtils.getTrimmedString(rtetpbrDTO.getAcasposCd()));
		params.put(DBConstants.IN_RTETPBR_EFF_DT, RteIntranetUtils.getTrimmedString(rtetpbrDTO.getEffDate()));
		params.put(DBConstants.IN_RTETPBR_EXPRTN_DT, RteIntranetUtils.getTrimmedString(rtetpbrDTO.getExpDate()));
		params.put(DBConstants.IN_RTETPBR_PSTD_DTS, RteIntranetUtils.getTrimmedString(rtetpbrDTO.getPostedDate()));
		params.put(DBConstants.IN_RTETPBR_USER_ID, RteIntranetUtils.getTrimmedString(rtetpbrDTO.getUserId()));
		params.put(DBConstants.IN_RTETPBR_VALUE_TXT, RteIntranetUtils.getTrimmedString(rtetpbrDTO.getValueTxt()));
		log.warn(params);	
		
		try {
			results = execute(params);
			log.warn("RtetpbrTPR2Adapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.OUT_LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_LS_SQLCODE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				List<RtetpbrDTO> rtetpbrList = new LinkedList<RtetpbrDTO>();
				rtetpbrList.add(rtetpbrDTO);
				rtetpbrMap.put("rtetpbrList", rtetpbrList);
				if ("A".equalsIgnoreCase(actionCode)) {
					newMessage = "This row added to the database";
				}else {
					newMessage ="Row already exists on the database. It was updated with these values.";					
					rtetpbrDTO.setUpdatedInd(ApplicationConstants.COPY);
				}				
				}
			else {
				newMessage = "Unable to add row to the database. SQLCODE = " + sqlCode;
			}
			
			rtetpbrMap.put("rtetpbrMessage", newMessage);
		return rtetpbrMap;
	}catch (Exception exception){
		log.error("RtetpbrTPR2Adapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}

	/**
	 * Method to add/update list of RTETPBR to data store.
	 * 
	 * @param modifiedRtetpbr
	 *            
	 * @param rtetpbrDtoList
	 *            list of RtetpbrDTO object.
	 * @param index
	 *            index to update the data
	 * @param updateInd
	 * 			  update indicator to update the data
	 * @return Map of flag to delete the data from RTETPBR list, success or
	 *         error message and list of RTETPBR.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addUpdateRtetpbr(RtetpbrDTO modifiedRtetpbr,
			List<RtetpbrDTO> rtetpbrDtoList, int index, char updateInd) throws ApplicationException{
		log.warn("Entered RtetpbrTPR2Adapter  - addUpdateRtetpbr");
		boolean isRtetpbrAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map rtetpbrMap = new HashMap();
		Timestamp currentTS = new Timestamp(System.currentTimeMillis());
		String postedDate = currentTS.toString(); //Initialize Posted Date to the current timestamp
		modifiedRtetpbr.setPostedDate(postedDate);
		params.put(DBConstants.IN_RTETPBR_ID, String.valueOf(modifiedRtetpbr.getIdNo()));
		params.put(DBConstants.IN_RTETPBR_BENRL_CD, RteIntranetUtils.getTrimmedString(modifiedRtetpbr.getBenrlCd()));
		params.put(DBConstants.IN_RTETPBR_SVC_TYP_CD, RteIntranetUtils.getTrimmedString(modifiedRtetpbr.getSvctypCd()));
		params.put(DBConstants.IN_RTETPBR_ACASTOS_CD, RteIntranetUtils.getTrimmedString(modifiedRtetpbr.getAcastosCd()));
		params.put(DBConstants.IN_RTETPBR_ACASPOS_CD, RteIntranetUtils.getTrimmedString(modifiedRtetpbr.getAcasposCd()));
		params.put(DBConstants.IN_RTETPBR_EFF_DT, RteIntranetUtils.getTrimmedString(modifiedRtetpbr.getEffDate()));
		params.put(DBConstants.IN_RTETPBR_EXPRTN_DT, RteIntranetUtils.getTrimmedString(modifiedRtetpbr.getExpDate()));
		params.put(DBConstants.IN_RTETPBR_PSTD_DTS, RteIntranetUtils.getTrimmedString(modifiedRtetpbr.getPostedDate()));
		params.put(DBConstants.IN_RTETPBR_USER_ID, RteIntranetUtils.getTrimmedString(modifiedRtetpbr.getUserId()));
		params.put(DBConstants.IN_RTETPBR_VALUE_TXT, RteIntranetUtils.getTrimmedString(modifiedRtetpbr.getValueTxt()));
		log.warn(params);	
		try {
					
			results = execute(params);
			log.warn("RtetpbrTPR2Adapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.OUT_LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_LS_SQLCODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				isRtetpbrAddorUpdated = true;
				if ("U".equalsIgnoreCase(actionCode)) {
					
					if (updateInd ==  ApplicationConstants.COPY)						
						rtetpbrDtoList.set(index, modifiedRtetpbr);						
					else
						rtetpbrDtoList.add(modifiedRtetpbr);
				}
				else
					rtetpbrDtoList.set(index, modifiedRtetpbr);
				
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			rtetpbrMap.put("rtetpbrMsg",newMessage);
			rtetpbrMap.put("rtetpbrDtoList",rtetpbrDtoList);
			rtetpbrMap.put("isRtetpbrAddorUpdated", isRtetpbrAddorUpdated);
			return rtetpbrMap;
		}catch (Exception exception){
			log.error("RtetpbrAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}

}