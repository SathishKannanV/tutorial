package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;



public class SpntprvVO  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 549767533222797993L;
	private String	seqNo;
	private String tranType = new String();
	private String respInd = new String();
	private String entityIdCd = new String();
	private String entityIdCdQual = new String();
	private String lastName = new String();
	private String firstName = new String();
	private String middleName = new String();
	private String idCodeQual = new String();
	private String idCode = new String();
	private String addressLine1 = new String();
	private String addressLine2 = new String();
	private String city = new String();
	private String state = new String();
	private String zipCode = new String();
	private String phoneNo = new String();
	private String contactNo = new String();
	private String effDate = new String();
	private String expDate = new String();
	private String vanIdCd = new String();
	private String typeCd = new String();
	private String convIdCode = new String();
	private String porgNo=new String();
	private String porgDetailName = new String();
	private String porgEffDate = new String();
	private String porgAddLine1 = new String();
	private String porgAddLine2 = new String();
	private String porgCity = new String();
	private String porgState = new String();
	private String porgZipCode = new String();
	private String capOfficeId = new String();
	private String capOfficeName = new String();
	private String capOffLineText = new String();
	private String capOffCity = new String();
	private String capOffState = new String();
	private String capOffZipcode = new String();
	private String postedDt = new String();
	public SpntprvVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SpntprvVO(String seqNo, String tranType, String respInd,
			String entityIdCd, String entityIdCdQual, String lastName,
			String firstName, String middleName, String idCodeQual,
			String idCode, String addressLine1, String addressLine2,
			String city, String state, String zipCode, String phoneNo,
			String contactNo, String effDate, String expDate, String vanIdCd,
			String typeCd, String convIdCode, String porgNo,
			String porgDetailName, String porgEffDate, String porgAddLine1,
			String porgAddLine2, String porgCity, String porgState,
			String porgZipCode, String capOfficeId, String capOfficeName,
			String capOffLineText, String capOffCity, String capOffState,
			String capOffZipcode ,String postedDt) {
		super();
		this.seqNo = seqNo;
		this.tranType = tranType;
		this.respInd = respInd;
		this.entityIdCd = entityIdCd;
		this.entityIdCdQual = entityIdCdQual;
		this.lastName = lastName;
		this.firstName = firstName;
		this.middleName = middleName;
		this.idCodeQual = idCodeQual;
		this.idCode = idCode;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.phoneNo = phoneNo;
		this.contactNo = contactNo;
		this.effDate = effDate;
		this.expDate = expDate;
		this.vanIdCd = vanIdCd;
		this.typeCd = typeCd;
		this.convIdCode = convIdCode;
		this.porgNo = porgNo;
		this.porgDetailName = porgDetailName;
		this.porgEffDate = porgEffDate;
		this.porgAddLine1 = porgAddLine1;
		this.porgAddLine2 = porgAddLine2;
		this.porgCity = porgCity;
		this.porgState = porgState;
		this.porgZipCode = porgZipCode;
		this.capOfficeId = capOfficeId;
		this.capOfficeName = capOfficeName;
		this.capOffLineText = capOffLineText;
		this.capOffCity = capOffCity;
		this.capOffState = capOffState;
		this.capOffZipcode = capOffZipcode;
		this.postedDt = postedDt;
	}
	public String getPostedDt() {
		return postedDt;
	}
	public void setPostedDt(String postedDt) {
		this.postedDt = postedDt;
	}
	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public String getTranType() {
		return tranType;
	}
	public void setTranType(String tranType) {
		this.tranType = tranType;
	}
	public String getRespInd() {
		return respInd;
	}
	public void setRespInd(String respInd) {
		this.respInd = respInd;
	}
	public String getEntityIdCd() {
		return entityIdCd;
	}
	public void setEntityIdCd(String entityIdCd) {
		this.entityIdCd = entityIdCd;
	}
	public String getEntityIdCdQual() {
		return entityIdCdQual;
	}
	public void setEntityIdCdQual(String entityIdCdQual) {
		this.entityIdCdQual = entityIdCdQual;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getIdCodeQual() {
		return idCodeQual;
	}
	public void setIdCodeQual(String idCodeQual) {
		this.idCodeQual = idCodeQual;
	}
	public String getIdCode() {
		return idCode;
	}
	public void setIdCode(String idCode) {
		this.idCode = idCode;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getEffDate() {
		return effDate;
	}
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	public String getExpDate() {
		return expDate;
	}
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	public String getVanIdCd() {
		return vanIdCd;
	}
	public void setVanIdCd(String vanIdCd) {
		this.vanIdCd = vanIdCd;
	}
	public String getTypeCd() {
		return typeCd;
	}
	public void setTypeCd(String typeCd) {
		this.typeCd = typeCd;
	}
	public String getConvIdCode() {
		return convIdCode;
	}
	public void setConvIdCode(String convIdCode) {
		this.convIdCode = convIdCode;
	}
	public String getPorgNo() {
		return porgNo;
	}
	public void setPorgNo(String porgNo) {
		this.porgNo = porgNo;
	}
	public String getPorgDetailName() {
		return porgDetailName;
	}
	public void setPorgDetailName(String porgDetailName) {
		this.porgDetailName = porgDetailName;
	}
	public String getPorgEffDate() {
		return porgEffDate;
	}
	public void setPorgEffDate(String porgEffDate) {
		this.porgEffDate = porgEffDate;
	}
	public String getPorgAddLine1() {
		return porgAddLine1;
	}
	public void setPorgAddLine1(String porgAddLine1) {
		this.porgAddLine1 = porgAddLine1;
	}
	public String getPorgAddLine2() {
		return porgAddLine2;
	}
	public void setPorgAddLine2(String porgAddLine2) {
		this.porgAddLine2 = porgAddLine2;
	}
	public String getPorgCity() {
		return porgCity;
	}
	public void setPorgCity(String porgCity) {
		this.porgCity = porgCity;
	}
	public String getPorgState() {
		return porgState;
	}
	public void setPorgState(String porgState) {
		this.porgState = porgState;
	}
	public String getPorgZipCode() {
		return porgZipCode;
	}
	public void setPorgZipCode(String porgZipCode) {
		this.porgZipCode = porgZipCode;
	}
	public String getCapOfficeId() {
		return capOfficeId;
	}
	public void setCapOfficeId(String capOfficeId) {
		this.capOfficeId = capOfficeId;
	}
	public String getCapOfficeName() {
		return capOfficeName;
	}
	public void setCapOfficeName(String capOfficeName) {
		this.capOfficeName = capOfficeName;
	}
	public String getCapOffLineText() {
		return capOffLineText;
	}
	public void setCapOffLineText(String capOffLineText) {
		this.capOffLineText = capOffLineText;
	}
	public String getCapOffCity() {
		return capOffCity;
	}
	public void setCapOffCity(String capOffCity) {
		this.capOffCity = capOffCity;
	}
	public String getCapOffState() {
		return capOffState;
	}
	public void setCapOffState(String capOffState) {
		this.capOffState = capOffState;
	}
	public String getCapOffZipcode() {
		return capOffZipcode;
	}
	public void setCapOffZipcode(String capOffZipcode) {
		this.capOffZipcode = capOffZipcode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
