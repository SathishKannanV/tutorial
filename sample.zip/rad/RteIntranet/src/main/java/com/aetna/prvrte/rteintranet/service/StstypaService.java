/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;
import com.aetna.prvrte.rteintranet.dto.StstypaDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public interface StstypaService {

	/**
	 * 
	 * @param ststypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map getStstypaLookUpTable(StstypaDTO ststypaDTO) throws ApplicationException ;



	/**
	 * 
	 * @param ststypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map addNewStstypa(StstypaDTO ststypaDTO)throws ApplicationException ;





	/**
	 * 
	 * @param ststypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map deleteStstypa(StstypaDTO ststypaDTO)throws ApplicationException ;

	/**
	 * 
	 * @param editedStstypaDTO
	 * @param ststypaDtoList
	 * @param index
	 * @param updateInd
	 * @return
	 * @throws ApplicationException
	 */
	Map addUpdateStstypa(StstypaDTO editedStstypaDTO,  List<StstypaDTO> ststypaDtoList, int index,char updateInd)throws ApplicationException ;







}
