/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.AuthTrxAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.AuthTrxDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.AuthTrxDisplayAdapter;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.dao.RteAdasvctDAOImpl
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Repository
public class RteAuthTrxDAOImpl implements RteAuthTrxDAO {
	/*
	 * Instance of AuthTrxDisplayAdapter.
	 */
	@Autowired(required = true)
	private AuthTrxDisplayAdapter authTrxDisplayAdapter;
	/*
	 * Instance of AuthTrxDisplayAdapter
	 */
	@Autowired(required = true)
	private AuthTrxDeleteAdapter authTrxDeleteAdapter;
	/*
	 * Instance of AuthTrxAddAdapter
	 */
	@Autowired(required = true)
	private AuthTrxAddAdapter authTrxAddAdapter;

	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteAuthTrxDAO#getAuthTrxLookUpList(java.lang.String)
	 */
	@Override
	public Map<String, Object> getAuthTrxLookUpList(String authTrx) throws ApplicationException {
		
		return authTrxDisplayAdapter.getAuthTrxLookUpList(authTrx);
	}
	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteAuthTrxDAO#addAuthTrxToDb(java.lang.String)
	 */
	@Override
	public Map<String, Object> addAuthTrxToDb(String authTrx) throws ApplicationException {
		return authTrxAddAdapter.addAuthTrxToDb(authTrx);
	}
	
	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteAuthTrxDAO#deleteAuthTrx(java.util.List, java.lang.String, int)
	 */
	@Override
	public Map<String, Object> deleteAuthTrx(List<String> authTrxList, String authTrx, int index) throws ApplicationException {
		// TODO Auto-generated method stub
		return authTrxDeleteAdapter.deleteAuthTrx(authTrxList, authTrx, index);
	}
	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteAuthTrxDAO#addUpdateAetCtls(java.util.List, java.lang.String, int)
	 */
	@Override
	public Map<String, Object> addUpdateAuthTrx(List<String> authTrxList, String authTrx, int index) throws ApplicationException {
		return authTrxAddAdapter.addUpdateAuthTrx(authTrxList, authTrx, index);
	}
}
