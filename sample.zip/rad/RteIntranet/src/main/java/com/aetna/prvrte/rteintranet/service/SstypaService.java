/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;
import com.aetna.prvrte.rteintranet.dto.SstypaDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public interface SstypaService {

	/**
	 * 
	 * @param sstypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map getSstypaLookUpTable(SstypaDTO sstypaDTO) throws ApplicationException ;


	/**
	 * 
	 * @param sstypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map addNewSstypa(SstypaDTO sstypaDTO)throws ApplicationException ;


	/**
	 * 
	 * @param sstypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map deleteSstypa(SstypaDTO sstypaDTO)throws ApplicationException ;

	/**
	 * 
	 * @param editedSstypaDTO
	 * @param sstypaDtoList
	 * @param index
	 * @param updateInd
	 * @return
	 * @throws ApplicationException
	 */
	Map addUpdateSstypa(SstypaDTO editedSstypaDTO,  List<SstypaDTO> sstypaDtoList, int index,char updateInd)throws ApplicationException ;




}
