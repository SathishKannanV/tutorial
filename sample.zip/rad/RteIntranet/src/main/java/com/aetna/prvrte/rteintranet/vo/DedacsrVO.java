package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;

/**
 * @author N726899
 *
 */
public class DedacsrVO implements Serializable {

	/**
	 * Constant serialized ID used for compatibility. 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * String of dbSvcTypeCd
	 */
	private String dbSvcTypeCd = "";
	/**
	 * String of dbDefAccumCd
	 */
	private String dbDefAccumCd = "";
	/**
	 * char of index to update the record.
	 */
	private char dbUpdatedInd;

	/**
	 * Default Constructor.
	 */
	public DedacsrVO() {
		super();
	}
	/**
	 * Creates a new DedacsrVO
	 * 
	 * @param svcTypeCd
	 *            the value for {@link svcTypeCd}
	 * @param defAccumCd
	 *            the value for {@link defAccumCd}
	 * @param updatedInd
	 *            the value for {@link updatedInd}
	 */
	public DedacsrVO(String svcTypeCd, String defAccumCd, char updatedInd) {
		super();
		setDbSvcTypeCd(svcTypeCd);
		setDbDefAccumCd(defAccumCd);
		setDbUpdatedInd(updatedInd);
	}

	/**
	 * @return the dbSvcTypeCd
	 */
	public String getDbSvcTypeCd() {
		return dbSvcTypeCd;
	}

	/**
	 * @param dbSvcTypeCd the dbSvcTypeCd to set
	 */
	public void setDbSvcTypeCd(String dbSvcTypeCd) {
		this.dbSvcTypeCd = dbSvcTypeCd;
	}

	/**
	 * @return the dbDefAccumCd
	 */
	public String getDbDefAccumCd() {
		return dbDefAccumCd;
	}

	/**
	 * @param dbDefAccumCd the dbDefAccumCd to set
	 */
	public void setDbDefAccumCd(String dbDefAccumCd) {
		this.dbDefAccumCd = dbDefAccumCd;
	}

	/**
	 * @return the dbUpdatedInd
	 */
	public char getDbUpdatedInd() {
		return dbUpdatedInd;
	}

	/**
	 * @param dbUpdatedInd the dbUpdatedInd to set
	 */
	public void setDbUpdatedInd(char dbUpdatedInd) {
		this.dbUpdatedInd = dbUpdatedInd;
	}
}
