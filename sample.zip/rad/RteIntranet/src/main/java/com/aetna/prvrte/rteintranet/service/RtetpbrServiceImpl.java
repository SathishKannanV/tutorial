/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.ProcexDAO;
import com.aetna.prvrte.rteintranet.dao.RtetpbrDAO;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.RtetpbrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Service
public class RtetpbrServiceImpl implements RtetpbrService {
	
	@Autowired(required=true)
	private RtetpbrDAO rtetpbrDAO;
	
	
	@Override
	public Map getRtetpbrLookUpTable(String idNo , String effDate)
			throws ApplicationException {
		
		return rtetpbrDAO.getRtetpbrLookUpTable(idNo , effDate);
	}


	@Override
	public Map addNewRtetpbr(RtetpbrDTO rtetpbrDTO) throws ApplicationException {
		return rtetpbrDAO.addNewRtetpbr(rtetpbrDTO);
	}


	@Override
	public Map deleteRtetpbr(String rtetpbrIdNo, String rtetpbrEffDate)
			throws ApplicationException {
		return rtetpbrDAO.deleteRtetpbr(rtetpbrIdNo,rtetpbrEffDate);
	}


	@Override
	public Map addUpdateRtetpbr(RtetpbrDTO editedProcexDTO,
			List<RtetpbrDTO> rtetpbrDtoList, int index,char updateInd)
			throws ApplicationException {
		return rtetpbrDAO.addUpdateRtetpbr(editedProcexDTO,rtetpbrDtoList, index,updateInd);
	}



}
