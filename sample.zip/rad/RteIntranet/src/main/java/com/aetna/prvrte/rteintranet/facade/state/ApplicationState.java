/*
 * Created Dec 2007
 * Updated May 2009
 */
package com.aetna.prvrte.rteintranet.facade.state;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import com.aetna.prvrte.rteintranet.vo.AdasvctVO;
import com.aetna.prvrte.rteintranet.vo.BenafrqVO;
import com.aetna.prvrte.rteintranet.vo.BplvrpVO;
import com.aetna.prvrte.rteintranet.vo.BplvsVO;
import com.aetna.prvrte.rteintranet.vo.DedacsrVO;
import com.aetna.prvrte.rteintranet.vo.ErspmsgVO;
import com.aetna.prvrte.rteintranet.vo.IndmntrpVO;
import com.aetna.prvrte.rteintranet.vo.LongRunTransReport3VO;
import com.aetna.prvrte.rteintranet.vo.LongRunTransReport4VO;
import com.aetna.prvrte.rteintranet.vo.LongRunTransactionVO;
import com.aetna.prvrte.rteintranet.vo.PlnlmEXVO;
import com.aetna.prvrte.rteintranet.vo.ProcexVO;
import com.aetna.prvrte.rteintranet.vo.RbbcVO;
import com.aetna.prvrte.rteintranet.vo.RbrcVO;
import com.aetna.prvrte.rteintranet.vo.RtetpbrVO;
import com.aetna.prvrte.rteintranet.vo.RtetprlVO;
import com.aetna.prvrte.rteintranet.vo.SbmletkVO;
import com.aetna.prvrte.rteintranet.vo.SbmrdepVO;
import com.aetna.prvrte.rteintranet.vo.Sbmrpln5VO;
import com.aetna.prvrte.rteintranet.vo.SbmrplnVO;
import com.aetna.prvrte.rteintranet.vo.SbmsnrVO;
import com.aetna.prvrte.rteintranet.vo.SbrsrxbVO;
import com.aetna.prvrte.rteintranet.vo.SitemsgVO;
import com.aetna.prvrte.rteintranet.vo.SpntprvVO;
import com.aetna.prvrte.rteintranet.vo.SrapidtlVO;
import com.aetna.prvrte.rteintranet.vo.SrchcolVO;
import com.aetna.prvrte.rteintranet.vo.SrchdtlVO;
import com.aetna.prvrte.rteintranet.vo.SrcherrVO;
import com.aetna.prvrte.rteintranet.vo.SrchresVO;
import com.aetna.prvrte.rteintranet.vo.SrchscVO;
import com.aetna.prvrte.rteintranet.vo.SstypaVO;
import com.aetna.prvrte.rteintranet.vo.StstypaVO;
import com.aetna.prvrte.rteintranet.vo.SubmsnVO;
import com.aetna.prvrte.rteintranet.vo.TOSVO;
import com.aetna.prvrte.rteintranet.vo.TierdMsgVO;
import com.aetna.prvrte.rteintranet.vo.TosctVO;
import com.aetna.prvrte.rteintranet.vo.RtebeplmVO;
import com.aetna.prvrte.rteintranet.vo.RtedictrVO;
import com.aetna.prvrte.rteintranet.vo.RterbacVO;
import com.aetna.prvrte.rteintranet.vo.RtestscVO;
import com.aetna.prvrte.rteintranet.vo.RtestypVO;
import com.aetna.prvrte.rteintranet.vo.RtetierVO;
import com.aetna.prvrte.rteintranet.vo.RtetpbrVO;
import com.aetna.prvrte.rteintranet.vo.HrpRuleVO;

/**
 * <code>ApplicationState</code> is a dependency of <code>FacadeImpl</code> and is the mechanism that
 * enables application state management via normal Java semantics (i.e. using JavaBean getters and
 * setters).  Instances of this class are intended to be plugged into and managed by any framework or
 * application's native state management interface.
 * <p>
 * Note: This class exists as an example of how to package and deploy such components and is not
 * considered reusable across the enterprise (and thus not supported), although any application is
 * free to leverage this code.
 * 
 * @author Kent Rancourt
 * @author Tony Kerz
 */
public class ApplicationState implements Serializable {

	
	private static final long serialVersionUID = -5898752773358778220L;

    // This bean is automatically managed in session scope (see beans-facade.xml) so application
    // state may be managed here simply by adding private attributes and public getter and setter
    // methods and then interacting with this state management component using normal Java
    // semantics.
    
    // It should no longer be necessary to use code like:
    
    // request.getSession().setAttribute("someKey", someObject);
    
    // or
    
    // SomeInterface myObject = (SomeInterface) request.getSession().getAttribute("someKey");
	
	private static List<ProcexVO> procexList =  new LinkedList<ProcexVO>();
	/**
	 * 
	 */
	private static List<AdasvctVO> adasvctList = new LinkedList<AdasvctVO>();
	/**
	 * 
	 */
	private static List<BenafrqVO> benafrqVOList = new LinkedList<BenafrqVO>();
	/**
	 * 
	 */
	private static List<String> aetCtlsList = new LinkedList<String>();
	/**
	 * 
	 */
	private static List<String> authTrxList = new LinkedList<String>();
	/**
	 * 
	 */
	private static List<BplvrpVO> bplvrpList = new LinkedList<BplvrpVO>();
	/**
	 * 
	 */
	private static List<DedacsrVO> dedacsrList = new LinkedList<DedacsrVO>();
	/**
	 * 
	 */
	private static List<ErspmsgVO> erspmsgList = new LinkedList<ErspmsgVO>();
	/**
	 * 
	 */
	private static List<IndmntrpVO> indmntrpList = new LinkedList<IndmntrpVO>();
	/**
	 * 
	 */
	private static List<PlnlmEXVO> plnlmEXList = new LinkedList<PlnlmEXVO>();
	private static List<RbbcVO> rbbcList =  new LinkedList<RbbcVO>();

	private static List<RtestypVO> rtestypList =  new LinkedList<RtestypVO>();
	private static List<RtebeplmVO> rtebeplmList =  new LinkedList<RtebeplmVO>();
	private static List<RtedictrVO> rtedictrList =  new LinkedList<RtedictrVO>();
	private static List<RterbacVO>  rterbacList =  new LinkedList<RterbacVO>();
	private static List<RtestscVO> rtestscList =  new LinkedList<RtestscVO>();
	private static List<RtetierVO> rtetierList =  new LinkedList<RtetierVO>();
	
	private static List<BplvsVO> bplvsList =  new LinkedList<BplvsVO>();
	private static List<SbmletkVO> sbmletkList =  new LinkedList<SbmletkVO>();
	private static List<SrchdtlVO> srchdtlList =  new LinkedList<SrchdtlVO>();
	private static List<SrchcolVO> srchcolList =  new LinkedList<SrchcolVO>();
	private static List<SrchscVO> srchscList =  new LinkedList<SrchscVO>();
	private static List<SrcherrVO> srcherrList =  new LinkedList<SrcherrVO>();
	private static List<SrchresVO> srchresList =  new LinkedList<SrchresVO>();
	private static List<SbrsrxbVO> sbrsrxbList =  new LinkedList<SbrsrxbVO>();
	private static List<SpntprvVO> spntprvList =  new LinkedList<SpntprvVO>();
	private static List<SbmrdepVO> sbmrdepList =  new LinkedList<SbmrdepVO>();
	private static List<SubmsnVO> submsnList =  new LinkedList<SubmsnVO>();
		private static List<Sbmrpln5VO> srapidtlList =  new LinkedList<Sbmrpln5VO>();
		private List<SbmsnrVO> sbmsnrList =  new LinkedList<SbmsnrVO>();
		private static List<SbmrplnVO> sbmrplnList =  new LinkedList<SbmrplnVO>();
		private static List<SbmrplnVO> sbmrplnListdtl =  new LinkedList<SbmrplnVO>();
		private static List<LongRunTransactionVO> longRunTransList =  new LinkedList<LongRunTransactionVO>();
		private static List<LongRunTransReport3VO> longRunTransList3 =  new LinkedList<LongRunTransReport3VO>();
		private static List<LongRunTransReport4VO> longRunTransList4 =  new LinkedList<LongRunTransReport4VO>();
		private static List<HrpRuleVO> hrpruleList =  new LinkedList<HrpRuleVO>();
		
		
		
		public  List<LongRunTransReport4VO> getLongRunTransList4() {
			return longRunTransList4;
		}

		public static void setLongRunTransList4(
				List<LongRunTransReport4VO> longRunTransList4) {
			ApplicationState.longRunTransList4 = longRunTransList4;
		}

		public  List<LongRunTransReport3VO> getLongRunTransList3() {
			return longRunTransList3;
		}

		public  void setLongRunTransList3(
				List<LongRunTransReport3VO> longRunTransList3) {
			ApplicationState.longRunTransList3 = longRunTransList3;
		}
		
	public  List<LongRunTransactionVO> getLongRunTransList() {
			return longRunTransList;
		}

		public  void setLongRunTransList(
				List<LongRunTransactionVO> longRunTransList) {
			ApplicationState.longRunTransList = longRunTransList;
		}

	public static List<SbmrplnVO> getSbmrplnList() {
			return sbmrplnList;
		}

		public static void setSbmrplnList(List<SbmrplnVO> sbmrplnList) {
			ApplicationState.sbmrplnList = sbmrplnList;
		}

		public static List<SbmrplnVO> getSbmrplnListdtl() {
			return sbmrplnListdtl;
		}

		public static void setSbmrplnListdtl(List<SbmrplnVO> sbmrplnListdtl) {
			ApplicationState.sbmrplnListdtl = sbmrplnListdtl;
		}

	public List<SbmsnrVO> getSbmsnrList() {
			return sbmsnrList;
		}

		public void setSbmsnrList(List<SbmsnrVO> sbmsnrList) {
			this.sbmsnrList = sbmsnrList;
		}

	/**
	 * @return the plnlmEXList
	 */
	public List<PlnlmEXVO> getPlnlmEXList() {
		return plnlmEXList;
	}

	/**
	 * @param plnlmEXList the plnlmEXList to set
	 */
	public void setPlnlmEXList(List<PlnlmEXVO> plnlmEXList) {
		this.plnlmEXList = plnlmEXList;
	}

	/**
	 * @return the indmntrpList
	 */
	public List<IndmntrpVO> getIndmntrpList() {
		return indmntrpList;
	}

	/**
	 * @param indmntrpList the indmntrpList to set
	 */
	public void setIndmntrpList(List<IndmntrpVO> indmntrpList) {
		this.indmntrpList = indmntrpList;
	}

	/**
	 * @return the erspmsgList
	 */
	public List<ErspmsgVO> getErspmsgList() {
		return erspmsgList;
	}

	/**
	 * @param erspmsgList the erspmsgList to set
	 */
	public void setErspmsgList(List<ErspmsgVO> erspmsgList) {
		this.erspmsgList = erspmsgList;
	}

	/**
	 * @return the dedacsrList
	 */
	public List<DedacsrVO> getDedacsrList() {
		return dedacsrList;
	}

	/**
	 * @param dedacsrList the dedacsrList to set
	 */
	public void setDedacsrList(List<DedacsrVO> dedacsrList) {
		this.dedacsrList = dedacsrList;
	}

	/**
	 * @return the bplvrpList
	 */
	public List<BplvrpVO> getBplvrpList() {
		return bplvrpList;
	}

	/**
	 * @param bplvrpList the bplvrpList to set
	 */
	public void setBplvrpList(List<BplvrpVO> bplvrpList) {
		this.bplvrpList = bplvrpList;
	}

	/**
	 * @return the authTrxList
	 */
	public List<String> getAuthTrxList() {
		return authTrxList;
	}

	/**
	 * @param authTrxList the authTrxList to set
	 */
	public void setAuthTrxList(List<String> authTrxList) {
		this.authTrxList = authTrxList;
	}

	/**
	 * @return the aetCtlsList
	 */
	public List<String> getAetCtlsList() {
		return aetCtlsList;
	}

	/**
	 * @param aetCtlsList2 the aetCtlsList to set
	 */
	public void setAetCtlsList(List<String> aetCtlsList2) {
		this.aetCtlsList = aetCtlsList2;
	}

	/**
	 * @return the procexList
	 */
	public List<ProcexVO> getProcexList() {
		return procexList;
	}

	/**
	 * @param procexList the procexList to set
	 */
	public void setProcexList(List<ProcexVO> procexList) {
		this.procexList = procexList;
	}

	/**
	 * @return the benafrqVOList
	 */
	public List<BenafrqVO> getBenafrqVOList() {
		return benafrqVOList;
	}

	/**
	 * @param benafrqList the benafrqVOList to set
	 */
	public void setBenafrqVOList(List<BenafrqVO> benafrqList) {
		this.benafrqVOList = benafrqList;
	}

	/**
	 * @return the adasvctList
	 */
	public List<AdasvctVO> getAdasvctList() {
		return adasvctList;
	}

	/**
	 * @param adasvctList the adasvctList to set
	 */
	public void setAdasvctList(List<AdasvctVO> adasvctList) {
		this.adasvctList = adasvctList;
	}
	
	private static List<RtetpbrVO> rtetpbrList =  new LinkedList<RtetpbrVO>();

	/**
	 * @return the rtetpbrList
	 */
	public List<RtetpbrVO> getRtetpbrList() {
		return rtetpbrList;
	}

	/**
	 * @param rtetpbrList the rtetpbrList to set
	 */
	public void setRtetpbrList(List<RtetpbrVO> rtetpbrList) {
		this.rtetpbrList = rtetpbrList;
	}
		private static List<SitemsgVO> sitemsgList =  new LinkedList<SitemsgVO>();

	/**
	 * @return the sitemsgList
	 */
	public List<SitemsgVO> getSitemsgList() {
		return sitemsgList;
	}

	/**
	 * @param sitemsgList the sitemsgList to set
	 */
	public void setSitemsgList(List<SitemsgVO> sitemsgList) {
		this.sitemsgList = sitemsgList;
	}
	
	private static List<RtetprlVO> rtetprlList =  new LinkedList<RtetprlVO>();

	/**
	 * @return the rtetprlList
	 */
	public List<RtetprlVO> getRtetprlList() {
		return rtetprlList;
	}

	/**
	 * @param rtetprlList the rtetprlList to set
	 */
	public void setRtetprlList(List<RtetprlVO> rtetprlList) {
		this.rtetprlList = rtetprlList;
	}

	private static List<TierdMsgVO> tierdmsgList =  new LinkedList<TierdMsgVO>();

	/**
	 * @return the tierdmsgList
	 */
	public List<TierdMsgVO> getTierdmsgList() {
		return tierdmsgList;
	}

	/**
	 * @param tierdmsgList the tierdmsgList to set
	 */
	public void setTierdmsgList(List<TierdMsgVO> tierdmsgList) {
		this.tierdmsgList = tierdmsgList;
	}

	private static List<SstypaVO> sstypaList =  new LinkedList<SstypaVO>();

	/**
	 * @return the sstypaList
	 */
	public List<SstypaVO> getSstypaList() {
		return sstypaList;
	}

	/**
	 * @param sstypaList the sstypaList to set
	 */
	public void setSstypaList(List<SstypaVO> sstypaList) {
		this.sstypaList = sstypaList;
	}
	
	private static List<StstypaVO> ststypaList =  new LinkedList<StstypaVO>();

	/**
	 * @return the ststypaList
	 */
	public List<StstypaVO> getStstypaList() {
		return ststypaList;
	}

	/**
	 * @param ststypaList the ststypaList to set
	 */
	public void setStstypaList(List<StstypaVO> ststypaList) {
		this.ststypaList = ststypaList;
	}

	private static List<TosctVO> tosctList =  new LinkedList<TosctVO>();

	/**
	 * @return the tosctList
	 */
	public List<TosctVO> getTosctList() {
		return tosctList;
	}

	/**
	 * @param tosctList the tosctList to set
	 */
	public void setTosctList(List<TosctVO> tosctList) {
		this.tosctList = tosctList;
	}
	
	private static List<RbrcVO> rbrcList =  new LinkedList<RbrcVO>();

	

	private static List<TOSVO> tosList =  new LinkedList<TOSVO>();

	/**
	 * @return the tosList
	 */
	public List<TOSVO> getTosList() {
		return tosList;
	}

	/**
	 * @param tosList the tosList to set
	 */
	public void setTosList(List<TOSVO> tosList) {
		this.tosList = tosList;
	}	
	
	/**
	 * @return the rbbcList
	 */
	public List<RbbcVO> getRbbcList() {
		return rbbcList;
	}

	/**
	 * @param rbbcList the rbbcList to set
	 */
	public void setRbbcList(List<RbbcVO> rbbcList) {
		this.rbbcList = rbbcList;
	}

	/**
	 * @return the rbrcList
	 */
	public List<RbrcVO> getRbrcList() {
		return rbrcList;
	}

	/**
	 * @param rbrcList the rbrcList to set
	 */
	public void setRbrcList(List<RbrcVO> rbrcList) {
		this.rbrcList = rbrcList;
	}

	/**
	 * @return the rtestypList
	 */
	public List<RtestypVO> getRtestypList() {
		return rtestypList;
	}

	/**
	 * @param rtestypList the rtestypList to set
	 */
	public void setRtestypList(List<RtestypVO> rtestypList) {
		this.rtestypList = rtestypList;
	}

	/**
	 * @return the rtedictrList
	 */
	public List<RtedictrVO> getRtedictrList() {
		return rtedictrList;
	}

	/**
	 * @param rtedictrList the rtedictrList to set
	 */
	public void setRtedictrList(List<RtedictrVO> rtedictrList) {
		this.rtedictrList = rtedictrList;
	}

	/**
	 * @return the rtebeplmList
	 */
	public List<RtebeplmVO> getRtebeplmList() {
		return rtebeplmList;
	}

	/**
	 * @param rtebeplmList the rtebeplmList to set
	 */
	public void setRtebeplmList(List<RtebeplmVO> rtebeplmList) {
		this.rtebeplmList = rtebeplmList;
	}

	/**
	 * @return the rterbacList
	 */
	public List<RterbacVO> getRterbacList() {
		return rterbacList;
	}

	/**
	 * @param rterbacList the rterbacList to set
	 */
	public void setRterbacList(List<RterbacVO> rterbacList) {
		this.rterbacList = rterbacList;
	}

	/**
	 * @return the rtestscList
	 */
	public List<RtestscVO> getRtestscList() {
		return rtestscList;
	}

	/**
	 * @param rtestscList the rtestscList to set
	 */
	public void setRtestscList(List<RtestscVO> rtestscList) {
		this.rtestscList = rtestscList;
	}

	/**
	 * @return the rtetierList
	 */
	public List<RtetierVO> getRtetierList() {
		return rtetierList;
	}

	/**
	 * @param rtetierList the rtetierList to set
	 */
	public void setRtetierList(List<RtetierVO> rtetierList) {
		this.rtetierList = rtetierList;
	}
	

	
	public List<SubmsnVO> getSubmsnList() {
		return submsnList;
	}

	public void setSubmsnList(List<SubmsnVO> submsnList) {
		this.submsnList = submsnList;
	}

	public List<SbmrdepVO> getSbmrdepList() {
		return sbmrdepList;
	}

	public void setSbmrdepList(List<SbmrdepVO> sbmrdepList) {
		this.sbmrdepList = sbmrdepList;
	}

	public List<SpntprvVO> getSpntprvList() {
		return spntprvList;
	}

	public void setSpntprvList(List<SpntprvVO> spntprvList) {
		this.spntprvList = spntprvList;
	}

	public List<SbrsrxbVO> getSbrsrxbList() {
		return sbrsrxbList;
	}

	public void setSbrsrxbList(List<SbrsrxbVO> sbrsrxbList) {
		this.sbrsrxbList = sbrsrxbList;
	}

	public List<SrchresVO> getSrchresList() {
		return srchresList;
	}

	public void setSrchresList(List<SrchresVO> srchresList) {
		this.srchresList = srchresList;
	}

	public List<SrcherrVO> getSrcherrList() {
		return srcherrList;
	}

	public void setSrcherrList(List<SrcherrVO> srcherrList) {
		this.srcherrList = srcherrList;
	}

	public List<SrchcolVO> getSrchcolList() {
		return srchcolList;
	}

	public List<SrchscVO> getSrchscList() {
		return srchscList;
	}

	public void setSrchscList(List<SrchscVO> srchscList) {
		this.srchscList = srchscList;
	}

	public void setSrchcolList(List<SrchcolVO> srchcolList) {
		this.srchcolList = srchcolList;
	}

	public List<SrchdtlVO> getSrchdtlList() {
		return srchdtlList;
	}

	public void setSrchdtlList(List<SrchdtlVO> srchdtlList) {
		this.srchdtlList = srchdtlList;
	}

	public List<SbmletkVO> getSbmletkList() {
		return sbmletkList;
	}

	public void setSbmletkList(List<SbmletkVO> sbmletkList) {
		this.sbmletkList = sbmletkList;
	}

	public List<BplvsVO> getBplvsList() {
		return bplvsList;
	}

	public void setBplvsList(List<BplvsVO> bplvsList) {
		this.bplvsList = bplvsList;
	}
		public List<Sbmrpln5VO> getSrapidtlList() {
		return srapidtlList;
	}

	public void setSrapidtlList(List<Sbmrpln5VO> srapidtlList) {
		this.srapidtlList = srapidtlList;
	}
	public SrapidtlVO getSrapidtlVO() {
		return srapidtlVO;
	}

	public void setSrapidtlVO(SrapidtlVO srapidtlVO) {
		this.srapidtlVO = srapidtlVO;
	}

	private static SrapidtlVO srapidtlVO;
	
	/**
	 * @return the hrpruleList
	 */
	public List<HrpRuleVO> getHrpruleList() {
		return hrpruleList;
	}

	/**
	 * @param hrpruleList the hrpruleList to set
	 */
	public void setHrpruleList(List<HrpRuleVO> hrpruleList) {
		this.hrpruleList = hrpruleList;
	}
}
