/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.aetna.prvrte.rteintranet.adapter.RbbcAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.RbbcDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.RbbcRBB1Adapter;
import com.aetna.prvrte.rteintranet.dto.RbbcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author n657186
 * Cognizant_Offshore
 */
@Repository
public class RbbcDAOImpl implements RbbcDAO {

	@Autowired(required=true)
	private RbbcRBB1Adapter rbbcLookUpAdapter;
	
	@Autowired(required=true)
	private RbbcAddAdapter rbbcAddAdapter;
	
	@Autowired(required=true)
	private RbbcDeleteAdapter rbbcDeleteAdapter;
	
	@Override
	public Map getRbbcLookUp(RbbcDTO rbbcDTO) throws ApplicationException {
		return rbbcLookUpAdapter.getRbbcLookUp(rbbcDTO);
	}
	@Override
	public Map addNewRbbc(RbbcDTO rbbcDTO) throws ApplicationException {
		return rbbcAddAdapter.addNewRbbc(rbbcDTO);
	}
	

	@Override
	public Map deleteRbbc(String rbbcCd, String svcTypeCd)
			throws ApplicationException {
		return rbbcDeleteAdapter.deleteRbbc(rbbcCd, svcTypeCd);
	}

	@Override
	public Map addUpdateRbbc(RbbcDTO existRbbcDTO,
			List<RbbcDTO> rbbcDtoList, int index, char updateInd) throws ApplicationException {
		return rbbcAddAdapter.addUpdateRbbc(existRbbcDTO, rbbcDtoList, index, updateInd);
	}

	
}
