/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.StstypaAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.StstypaDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.StstypaDisplayAdapter;
import com.aetna.prvrte.rteintranet.dto.StstypaDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Repository
public class StstypaDAOImpl implements StstypaDAO {
	
	@Autowired(required=true)
	private StstypaDisplayAdapter ststypaDisplayAdapter;

	@Autowired(required=true)
	private StstypaAddAdapter ststypaAddAdapter;
	
			@Autowired(required=true)
	private StstypaDeleteAdapter ststypaDeleteAdapter;
	
	
	/**
	 * 
	 * @param ststypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map getStstypaLookUpTable(StstypaDTO ststypaDTO)
			throws ApplicationException {
		
		return ststypaDisplayAdapter.getStstypaLookUpTable(ststypaDTO);
	}

	
	/**
	 * 
	 * @param ststypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addNewStstypa(StstypaDTO ststypaDTO) throws ApplicationException {
		return ststypaAddAdapter.addNewStstypa(ststypaDTO);
	}

	/**
	 * 
	 * @param ststypaDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map deleteStstypa(StstypaDTO ststypaDTO) throws ApplicationException {
		return ststypaDeleteAdapter.deleteStstypa(ststypaDTO);
	}

	/**
	 * 
	 * @param editedStstypaDTO
	 * @param ststypaDtoList
	 * @param index
	 * @param  updateInd
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addUpdateStstypa(StstypaDTO editedStstypaDTO,
			List<StstypaDTO> ststypaDtoList, int index,char updateInd)
			throws ApplicationException {
		return ststypaAddAdapter.addUpdateStstypa( editedStstypaDTO, ststypaDtoList,  index, updateInd);
	}


}
