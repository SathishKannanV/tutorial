/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.RtebeplmDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.RtebeplmVO;
import com.aetna.prvrte.rteintranet.vo.RtebeplmVO;
import com.aetna.prvrte.rteintranet.vo.RtestypVO;

/**
 * @author N657186
 * Cognizant_Offshore
 */

@Controller
@RequestMapping(value = "/rtebeplm/*")
public class RtebeplmController {

	public static final String RTEBEPLM_HOME = ".rtebeplmHome";
	public static final String RTEBEPLM_LOOKUP = ".rtebeplmLookUp";
	
	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(RtebeplmController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/rtebeplmHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRtebeplmLookUpHome(final HttpServletRequest request, Model model) {
		log.warn("Entered RtebeplmController - getRtebeplmLookUpHome()");
		String securityLevel ="";
		try{
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(RTEBEPLM_HOME, "rtebeplmVO",  new RtebeplmVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("Exit from RtebeplmController - getRtebeplmLookUpHome()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtebeplmController - getRtebeplmLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherRTEBEPLM). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rtebeplmVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherRtebeplm", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRtebeplmLookUp(final HttpServletRequest request, @ModelAttribute("rtebeplmForm")RtebeplmVO rtebeplmVO){
		log.warn("Entered RtebeplmController - getRtebeplmLookUp()");
		String securityLevel ="";
		Map rtebeplmResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<RtebeplmDTO> rtebeplmDtoList = new LinkedList<RtebeplmDTO>();
		List<RtebeplmVO> rtebeplmVoList = new LinkedList<RtebeplmVO>();
		try{
		RtebeplmDTO rtebeplmDTO = RTETranslator.toRtebeplmDTO(rtebeplmVO);
		rtebeplmResultMap = facade.getRtebeplmLookUp(rtebeplmDTO);
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		rtebeplmDtoList = (List<RtebeplmDTO>) rtebeplmResultMap.get("rtebeplmList");
		rtebeplmVoList = RTETranslator.toRtebeplmVOList(rtebeplmDtoList);
		lookUpListVO.setRtebeplmVOList(rtebeplmVoList);
		facade.getApplicationState().setRtebeplmList(rtebeplmVoList);
		log.warn("getRtebeplmLookUp - rtebeplmMessage: "+ rtebeplmResultMap.get("rbrcMessage"));
		mav = new ModelAndView(RTEBEPLM_LOOKUP, "lookUpListVO", lookUpListVO);
		mav.addObject("rtebeplmMessage", rtebeplmResultMap.get("rtebeplmMessage"));
		mav.addObject("securityLevel", securityLevel);
		log.warn("Exit from RtebeplmController - getRtebeplmLookUp()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in rtebeplmController - getrtebeplmLookUp() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (GatherRTEBEPLM). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * @param rtebeplmVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteRtebeplm", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView deleteRtebeplm(final HttpServletRequest request, @ModelAttribute("rtebeplmDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtebeplmController - deleteRtebeplm()");
		ModelAndView mav ;
		String rtebeplmMsg = "";
		String securityLevel ="";
		boolean isRtebeplmDeleted = true;
		Map rtebeplmResultMap = new HashMap();
		
		List<RtebeplmVO> rtebeplmVoList = new LinkedList<RtebeplmVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			int i;
			rtebeplmVoList= lookUpListVO.getRtebeplmVOList();
			if ((rtebeplmVoList != null) && (takeAction != null)) {
				for(RtebeplmVO rtebeplmVO : rtebeplmVoList){
					if(rtebeplmVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtebeplmVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);

					RtebeplmVO existingRtebeplm = (RtebeplmVO) rtebeplmVoList.get(i);
					if (existingRtebeplm.getUpdatedInd() != ApplicationConstants.COPY) {
						RtebeplmDTO rtebeplmDTO = RTETranslator.toRtebeplmDTO(existingRtebeplm);
						
						rtebeplmResultMap = facade.deleteRtebeplm(rtebeplmDTO);
						rtebeplmMsg = (String) rtebeplmResultMap.get("rtebeplmMessage");
						isRtebeplmDeleted = (Boolean) rtebeplmResultMap.get("isRtebeplmDeleted");
						
						if(isRtebeplmDeleted){
							rtebeplmVoList.remove(i);
						}else{
							j = 0;
						}
					}else{
						rtebeplmVoList.remove(i);
					}				
			}
				if(isRtebeplmDeleted)
					rtebeplmMsg = "Rows selected were Deleted in the database/list";
				
		}else
			rtebeplmMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRtebeplmList(rtebeplmVoList);
			lookUpListVO.setRtebeplmVOList(rtebeplmVoList);
			mav = new ModelAndView(RTEBEPLM_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtebeplmMessage",rtebeplmMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteRtebeplm - rtebeplmMessage: "+ rtebeplmMsg);
		    log.warn("Exit from RtebeplmController - deleteRtebeplm()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtebeplmController - deleteRtebeplm() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRTEBEPLM). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rtebeplmVO
	 * @param takeAction
	 * @return
	 */
	@RequestMapping(value="/copyRtebeplm", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView copyRtebeplm(final HttpServletRequest request, @ModelAttribute("rtebeplmDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtebeplmController - copyRtebeplm()");
		ModelAndView mav ;
		String rtebeplmMsg = "";
		int i;
		String securityLevel ="";
		List<RtebeplmVO> rtebeplmList = new LinkedList<RtebeplmVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtebeplmList = lookUpListVO.getRtebeplmVOList();
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDate = currentTS.toString(); //Initialize Posted Date to the current timestamp
			if ((rtebeplmList != null) && (takeAction != null)) {
				for(RtebeplmVO rtebeplmVO : rtebeplmList){
					if(rtebeplmVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtebeplmVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					RtebeplmVO existingRtebeplm = (RtebeplmVO) rtebeplmList.get(i);
					
					RtebeplmVO copyRtebeplm = new RtebeplmVO(existingRtebeplm.getHmoBenefitCd(), existingRtebeplm.getFrequencyInd(), 
							existingRtebeplm.getEligPerLimitCd(), existingRtebeplm.getEffDate(),
							existingRtebeplm.getExpDate(),postedDate, ApplicationConstants.COPY);
					rtebeplmList.add(copyRtebeplm);
				}
				rtebeplmMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				rtebeplmMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRtebeplmList(rtebeplmList);
			lookUpListVO.setRtebeplmVOList(rtebeplmList);
			mav = new ModelAndView(RTEBEPLM_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtebeplmMessage",rtebeplmMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyRtebeplm - rtebeplmMessage: "+ rtebeplmMsg);
		    log.warn("Exit from RtebeplmController - copyRtebeplm()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in RtebeplmController - copyRtebeplm() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRtebeplm). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	/**
	 * @param request
	 * @param rtebeplmVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateRtebeplm", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addUpdateRtebeplm(final HttpServletRequest request, @ModelAttribute("rtebeplmDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtebeplmController - addUpdateRtebeplm()");
		ModelAndView mav ;
		String rtebeplmMsg = "";
		List<RtebeplmVO> updatedRtebeplmList = new LinkedList<RtebeplmVO>();
		List<RtebeplmDTO> updatedRtebeplmDtoList = new LinkedList<RtebeplmDTO>();
		List<RtebeplmVO> modifiedRtebeplmList = new LinkedList<RtebeplmVO>();
		RtebeplmDTO editedRtebeplmDTO = new RtebeplmDTO();
		Map rtebeplmResultMap = new HashMap();
	    boolean isRtebeplmAddOrUpdated = false;
		List<RtebeplmVO> rtebeplmVoList = new LinkedList<RtebeplmVO>();
		List<RtebeplmDTO> rtebeplmDtoList = new LinkedList<RtebeplmDTO>();
		String securityLevel ="";
		try{
			int i;
			rtebeplmVoList = facade.getApplicationState().getRtebeplmList();
			modifiedRtebeplmList = lookUpListVO.getRtebeplmVOList();
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDate = currentTS.toString(); //Initialize Posted Date to the current timestamp
			
			if (takeAction != null && takeAction.length != 0) {
				if(rtebeplmVoList != null && rtebeplmVoList.size() != 0 
						&& modifiedRtebeplmList != null && modifiedRtebeplmList.size() != 0){
				for(RtebeplmVO rtebeplmVO : rtebeplmVoList){
					if(rtebeplmVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtebeplmVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				rtebeplmDtoList = RTETranslator.toRtebeplmDTOList(rtebeplmVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					
					i = Integer.parseInt(takeAction[j]);
					RtebeplmVO seletedRtebeplm = (RtebeplmVO) rtebeplmVoList.get(i);
					RtebeplmVO editedRtebeplm = (RtebeplmVO) modifiedRtebeplmList.get(i);
					log.warn("addUpdateRtebeplm - user selected: "+ i);
					RtebeplmVO editedRtebeplmVO = new RtebeplmVO(editedRtebeplm.getHmoBenefitCd(), 
							editedRtebeplm.getFrequencyInd(), editedRtebeplm.getEligPerLimitCd(),
							editedRtebeplm.getEffDate(), editedRtebeplm.getExpDate(),postedDate, updatedInd);
					editedRtebeplmDTO = RTETranslator.toRtebeplmDTO(editedRtebeplmVO);
					rtebeplmResultMap = facade.addUpdateRtebeplm(editedRtebeplmDTO, rtebeplmDtoList, i, seletedRtebeplm.getUpdatedInd());
					updatedRtebeplmDtoList = (List<RtebeplmDTO>) rtebeplmResultMap.get("rtebeplmDtoList");
					if(updatedRtebeplmDtoList!=null){
					updatedRtebeplmList = RTETranslator.toRtebeplmVOList(updatedRtebeplmDtoList);
					}
			
					isRtebeplmAddOrUpdated = (Boolean) rtebeplmResultMap.get("isrtebeplmAddorUpdated");
					rtebeplmMsg = (String) rtebeplmResultMap.get("rtebeplmMessage") ;
					if(!isRtebeplmAddOrUpdated){
						j = takeAction.length;
					}
				}
				
				if(isRtebeplmAddOrUpdated){
					rtebeplmMsg = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted.";
					String xHmoBenefitCd, yHmoBenefitCd, xEffDate, yEffDate;
					for (int x = rtebeplmDtoList.size() - 1 ; x > 0;  x--) {
						RtebeplmDTO xRtebeplm = (RtebeplmDTO) rtebeplmDtoList.get(x);
						xHmoBenefitCd = xRtebeplm.getHmoBenefitCd();
						xEffDate = xRtebeplm.getEffDate();
						if (xRtebeplm.getUpdatedInd() != ApplicationConstants.COPY) {
							for (int y = x - 1; y > -1; y--) {
								RtebeplmDTO aRtebeplm = (RtebeplmDTO) rtebeplmDtoList.get(y);
								yHmoBenefitCd = aRtebeplm.getHmoBenefitCd();
								yEffDate = aRtebeplm.getEffDate();
								if (xHmoBenefitCd.equals(yHmoBenefitCd) && xEffDate.equals(yEffDate)) {
									rtebeplmDtoList.remove(y); 
									x--;
								}
							}
						}
					}
				}
				lookUpListVO.setRtebeplmVOList(updatedRtebeplmList);
				facade.getApplicationState().setRtebeplmList(updatedRtebeplmList);
			} else {
				throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);				
			}
		}else{
			rtebeplmMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setRtebeplmVOList(rtebeplmVoList);
			facade.getApplicationState().setRtebeplmList(rtebeplmVoList);
		}
			mav = new ModelAndView(RTEBEPLM_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtebeplmMessage",rtebeplmMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateRtebeplm - rtebeplmMessage: "+ rtebeplmMsg);
		    log.warn("Exit from RtebeplmController - addUpdateRtebeplm()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtebeplmController - deleteRtebeplm() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRTEBEPLM). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * Method to export Rtebeplm look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of rtebeplm object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/rtebeplmExport", method = RequestMethod.POST)
	public ModelAndView rtebeplmExport(HttpServletResponse response){
		List<RtebeplmVO> rtebeplmList = new LinkedList<RtebeplmVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String rtebeplmMsg="";
		try{
			rtebeplmList = facade.getApplicationState().getRtebeplmList();
			if(rtebeplmList != null && rtebeplmList.size() != 0){
			// Key map to create header
			Map<String,String> keyMap = new LinkedHashMap<String,String>();
			keyMap.put("hmoBenefitCd", "HMO Ben CD");
			keyMap.put("frequencyInd", "Frequency Ind");
			keyMap.put("eligPerLimitCd", "EPLC Cd");
			keyMap.put("effDate", "Effective Date");
			keyMap.put("expDate", "Expiration Date");
			keyMap.put("postedDateTimestamp", "Posted Date");
			
			RteIntranetUtils.exportToExcel(response, rtebeplmList, keyMap);
			rtebeplmMsg = "LookUp table exported successfully.";
			} else {
				rtebeplmMsg = "No data found.";
			}
			lookUpTableListVO.setRtebeplmVOList(rtebeplmList);
	        mav = new ModelAndView(RTEBEPLM_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
		    mav.addObject("rtebeplmMessage",rtebeplmMsg);
			return mav;
		}catch (ApplicationException e) {
			log.error("Exception occured in RtebeplmController - rtebeplmExport() method:"
					+ e.getErrorMessage());
			String errorMsg = "Error encountered while export to excel. "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errormav;
		}
	}
	
}
