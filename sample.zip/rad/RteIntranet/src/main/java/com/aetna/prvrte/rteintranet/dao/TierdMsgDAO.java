/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.TierdMsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 *
 */
public interface TierdMsgDAO {

	
	/**
	 * 
	 * @param tierdmsgDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map getTierdMsgLookUpTable(TierdMsgDTO tierdmsgDTO) throws ApplicationException ;

	/**
	 * 
	 * @param tierdmsgDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map addNewTierdmsg(TierdMsgDTO tierdmsgDTO)throws ApplicationException ;


	/**
	 * 
	 * @param tierdmsgDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map deleteTierdMsg(TierdMsgDTO tierdmsgDTO)throws ApplicationException ;

	/**
	 * 
	 * @param editedTierdMsgDTO
	 * @param tierdmsgDtoList
	 * @param index
	 * @param updateInd
	 * @return
	 * @throws ApplicationException
	 */
	Map addUpdateTierdMsg(TierdMsgDTO editedTierdMsgDTO,
			List<TierdMsgDTO> tierdmsgDtoList, int index,char updateInd)throws ApplicationException ;


}
