/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.RbrcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public interface RbrcService {

	Map getRbrcLookUp(RbrcDTO rbrcDTO) throws ApplicationException;;

	Map addNewRbrc(RbrcDTO rbrcDTO)throws ApplicationException ;

	Map deleteRbrc(RbrcDTO rbrcDTO) throws ApplicationException ;

	Map addUpdateRbrc(RbrcDTO existRbrcDTO, List<RbrcDTO> rbrcDtoList, int index, char updateInd) throws ApplicationException ;
}
