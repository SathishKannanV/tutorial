package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.SstypaDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


/**
 * @author N624926
 * Cognizant_Offshore
 */
public class SstypaAddAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(SstypaAddAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public SstypaAddAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.IN_ID, Types.SMALLINT));
		declareParameter(new SqlParameter(DBConstants.IN_COLLECTION_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_INDIVIDUAL_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_EFF_DATE, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.IN_EXP_DATE, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.IN_POSTED_DATE, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.IN_VERSNRLS_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.OUT_ID, Types.SMALLINT));
		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));
	}
	
	
	/**
	 * Method to add new SSTYPA to data store.
	 * 
	 * @param sstypaDTO
	 *            sstypaDTO object.
	 * @return Map of added SSTYPA data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addNewSstypa(SstypaDTO sstypaDTO) throws ApplicationException {
		
		log.warn("Entered SstypaAddAdapter  - addNewSstypa");
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map sstypaMap = new HashMap();
		Date todaysDate = new Date(System.currentTimeMillis());
		String postedDate = todaysDate.toString();
		sstypaDTO.setPostedDate(postedDate);
		sstypaDTO.setId(ApplicationConstants.ZERO_0);
		sstypaDTO.setUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
		params.put(DBConstants.IN_ID, RteIntranetUtils.getTrimmedString(sstypaDTO.getId()));
		params.put(DBConstants.IN_COLLECTION_CD, RteIntranetUtils.getTrimmedString(sstypaDTO.getCollectionCode()));
		params.put(DBConstants.IN_INDIVIDUAL_CD, RteIntranetUtils.getTrimmedString(sstypaDTO.getIndividualCode()));
		params.put(DBConstants.IN_EFF_DATE, RteIntranetUtils.getTrimmedString(sstypaDTO.getEffDate()));
		params.put(DBConstants.IN_EXP_DATE, RteIntranetUtils.getTrimmedString(sstypaDTO.getExpDate()));
		params.put(DBConstants.IN_POSTED_DATE, RteIntranetUtils.getTrimmedString(sstypaDTO.getPostedDate()));
		params.put(DBConstants.IN_VERSNRLS_CD, RteIntranetUtils.getTrimmedString(sstypaDTO.getVersionReleaseCode()));
		log.warn(params);	
		
		try {
			results = execute(params);
			log.warn("SstypaAddAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results .get(DBConstants.OUT_CODE));
			String actionCode =  String.valueOf(results .get(DBConstants.OUT_ID));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				sstypaDTO.setId(actionCode);
				List<SstypaDTO> sstypaList = new LinkedList<SstypaDTO>();
				sstypaList.add(sstypaDTO);
				sstypaMap.put("sstypaList", sstypaList);
				newMessage = "This row added to the database";
				}
			else {
				newMessage = "Unable to add row to the database. SQLCODE = " + sqlCode;
			}
			
			sstypaMap.put("sstypaMessage", newMessage);
		return sstypaMap;
	}catch (Exception exception){
		log.error("SstypaAddAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}


	/**
	 * Method to add/update list of SSTYPA to data store.
	 * 
	 * @param existingSstypa
	 *            
	 * @param sstypaDtoList
	 *            list of SstypaDTO object.
	 * @param index
	 *            index to update the data
	 * @param updateInd
	 * 			  update indicator to update the data
	 * @return Map of flag to delete the data from SSTYPA list, success or
	 *         error message and list of SSTYPA.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addUpdateSstypa(SstypaDTO existingSstypa,
			List<SstypaDTO> sstypaDtoList, int index,char updateInd) throws ApplicationException{
		log.warn("Entered SstypaAddAdapter  - addUpdateSstypa");
		boolean isSstypaAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map sstypaMap = new HashMap();
		Date todaysDate = new Date(System.currentTimeMillis());
		String postedDate = todaysDate.toString();
		existingSstypa.setPostedDate(postedDate);
		params.put(DBConstants.IN_ID, RteIntranetUtils.getTrimmedString(existingSstypa.getId()));
		params.put(DBConstants.IN_COLLECTION_CD, RteIntranetUtils.getTrimmedString(existingSstypa.getCollectionCode()));
		params.put(DBConstants.IN_INDIVIDUAL_CD, RteIntranetUtils.getTrimmedString(existingSstypa.getIndividualCode()));
		params.put(DBConstants.IN_EFF_DATE, RteIntranetUtils.getTrimmedString(existingSstypa.getEffDate()));
		params.put(DBConstants.IN_EXP_DATE, RteIntranetUtils.getTrimmedString(existingSstypa.getExpDate()));
		params.put(DBConstants.IN_POSTED_DATE, RteIntranetUtils.getTrimmedString(existingSstypa.getPostedDate()));
		params.put(DBConstants.IN_VERSNRLS_CD, RteIntranetUtils.getTrimmedString(existingSstypa.getVersionReleaseCode()));
		log.warn(params);	
		
		try {
					
			results = execute(params);
			log.warn("SstypaAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.OUT_ID));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_CODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
							isSstypaAddorUpdated = true;
							existingSstypa.setId(actionCode);
							sstypaDtoList.set(index, existingSstypa);	
				
				newMessage = "All rows that changed the database are highlighted.";
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			sstypaMap.put("sstypaMsg",newMessage);
			sstypaMap.put("sstypaDtoList",sstypaDtoList);
			sstypaMap.put("isSstypaAddorUpdated", isSstypaAddorUpdated);
			return sstypaMap;
		}catch (Exception exception){
			log.error("SstypaAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
}