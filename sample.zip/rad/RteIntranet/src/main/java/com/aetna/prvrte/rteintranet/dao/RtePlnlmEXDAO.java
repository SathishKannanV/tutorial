/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.ErspmsgDTO;
import com.aetna.prvrte.rteintranet.dto.PlnlmEXDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * 
 * <h1>RteErspmsgService</h1> The RteErspmsgService is responsible for handling
 * the business logic of ERSPMSG Look up.
 * 
 * @author N726899 Cognizant_Offshore
 * 
 */
public interface RtePlnlmEXDAO {
	/**
	 * Method to get the PLNLMEX list from data store.
	 * 
	 * @param plnlmEXDTO
	 * 			plnlmEXDTO object.
	 * @return Map of PLNLMEX list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	Map<String, Object> getPlnlmEXLookUpList(PlnlmEXDTO plnlmEXDTO) throws ApplicationException;
	/**
	 * Method to add new PLNLMEX to data store.
	 * 
	 * @param plnlmEXDTO
	 *            plnlmEXDTO object.
	 * @return Map of added PLNLMEX data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	Map<String, Object> addPlnlmEXToDb(PlnlmEXDTO plnlmEXDTO) throws ApplicationException;
	/**
	 * Method to delete the PLNLMEX data from data store.
	 * 
	 * @param explntCd
	 *            String of explntCd.
	 * @return Map of flag to delete the data from PLNLMEX list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	Map<String, Object> deletePlnlmEX(String  explntCd) throws ApplicationException;
	
	/**
	 * Method to add/update list of PLNLMEX to data store.
	 * 
	 * @param plnlmEXDTO
	 *            plnlmEXDTO object.
	 * @param plnlmEXDTOList
	 *            list of plnlmEXDTO object.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from PLNLMEX list, success or
	 *         error message and list of PLNLMEX.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	Map<String, Object> addUpdatePlnlmEX(PlnlmEXDTO plnlmEXDTO,	List<PlnlmEXDTO> plnlmEXList, int index)throws ApplicationException;
}
