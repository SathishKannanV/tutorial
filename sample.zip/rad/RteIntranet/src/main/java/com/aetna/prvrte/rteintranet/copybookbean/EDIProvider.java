package com.aetna.prvrte.rteintranet.copybookbean;


public class EDIProvider {

	String providerID;
	String qualifier;
	Entity entity;
	public String getProviderID() {
		
		return providerID;
	}
	public void setProviderID(String providerID) {
		
		this.providerID = providerID;
	}
	public String getQualifier() {
		
		return qualifier;
	}
	public void setQualifier(String qualifier) {
		
		this.qualifier = qualifier;
	}
	public Entity getEntity() {
		return entity;
	}
	public void setEntity(Entity entity) {
		this.entity = entity;
	}
	public StringBuilder getProvider(){
		return new StringBuilder(getProviderID())
		.append(getQualifier())
		.append(entity.getEntity());
	}
	
}
