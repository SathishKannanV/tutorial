/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.Map;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 *
 */
public interface RteSecurityDAO {

	Map getUserSecurityLevel(String userId)throws ApplicationException;

}
