/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * 
 * <h1>RteAetCtlsDAO</h1> The RteAetCtlsDAO is responsible for handling the
 * storage, retrieval, and search data from/to data store.
 * 
 * @author N726899 Cognizant_Offshore
 * 
 */
public interface RteAetCtlsDAO {
	/**
	 * Method to get the AetCtls list from data store.
	 * 
	 * @param aetCtl
	 *            String of aetna id.
	 * @return Map of AetCtls list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if data not found in data store.
	 */
	Map<String, Object> getAetCtlsLookUpList(String aetCtl) throws ApplicationException;
	/**
	 * Method to add new AetCtls to data store.
	 * 
	 * @param aetCtl
	 *            String of aetna id.
	 * @return Map of AetCtls list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	Map<String, Object> addAetCtlsToDb(String aetCtl) throws ApplicationException;
	/**
	 * Method to delete the AetCtls data from data store.
	 * 
	 * @param aetCtlsList
	 *            List of aetna ids.
	 * @param takeAction
	 *            List of selected indexes to delete aetna id.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from AetCtls list and success or
	 *         error message.
	 * @throws ApplicationException
	 *             if deletion fails.
	 */
	Map<String, Object> deleteAetCtls(List<String>aetCtlsList, String aetCtl, int index) throws ApplicationException;
	
	/**
	 * Method to add/update list of AetCtls to data store.
	 * 
	 * @param aetCtlsList
	 *            List of aetna ids.
	 * @param takeAction
	 *            List of selected indexes to delete aetna id.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from AetCtls list, success or
	 *         error message and list of AetCtls.
	 * @throws ApplicationException
	 *             if insertion or update fails.
	 */
	Map<String, Object> addUpdateAetCtls(List<String>aetCtlsList, String aetCtl, int index) throws ApplicationException;
}
