/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.RteErspmsgDAO;
import com.aetna.prvrte.rteintranet.dto.ErspmsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.service.RteErspmsgService
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Service
public class RteErspmsgServiceImpl implements RteErspmsgService {
	/*
	 * Instance of RteErspmsgDAO.
	 */
	@Autowired(required=true)
	private RteErspmsgDAO rteErspmsgDAO;
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteErspmsgService#getErspmsgLookUpList(com.aetna.prvrte.rteintranet.dto.ErspmsgDTO)
	 */
	@Override
	public Map<String, Object> getErspmsgLookUpList(ErspmsgDTO erspmsgDTO) throws ApplicationException {
		return rteErspmsgDAO.getErspmsgLookUpList(erspmsgDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteErspmsgService#addErspmsgToDb(com.aetna.prvrte.rteintranet.dto.ErspmsgDTO)
	 */
	@Override
	public Map<String, Object> addErspmsgToDb(ErspmsgDTO erspmsgDTO) throws ApplicationException {
		return rteErspmsgDAO.addErspmsgToDb(erspmsgDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteErspmsgService#deleteErspmsg(java.lang.String)
	 */
	@Override
	public Map<String, Object> deleteErspmsg(int messageId) throws ApplicationException {
		return rteErspmsgDAO.deleteErspmsg(messageId);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteErspmsgService#addUpdateErspmsg(com.aetna.prvrte.rteintranet.dto.ErspmsgDTO, java.util.List, int)
	 */
	@Override
	public Map<String, Object> addUpdateErspmsg(ErspmsgDTO erspmsgDTO, List<ErspmsgDTO> erspmsgList, int index) throws ApplicationException {
		return rteErspmsgDAO.addUpdateErspmsg(erspmsgDTO, erspmsgList, index);
	}
	

}
