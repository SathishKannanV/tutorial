/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.ProcexDAO;
import com.aetna.prvrte.rteintranet.dao.RtetprlDAO;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.RtetprlDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Service
public class RtetprlServiceImpl implements RtetprlService {
	@Autowired(required=true)
	private RtetprlDAO rtetprlDAO;
	
	
	/**
	 * 
	 * @param rtetprlDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map getRtetprlLookUpTable(RtetprlDTO rtetprlDTO)
			throws ApplicationException {
		
		return rtetprlDAO.getRtetprlLookUpTable(rtetprlDTO);
	}

	/**
	 * 
	 * @param rtetprlDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addNewRtetprl(RtetprlDTO rtetprlDTO) throws ApplicationException {
		return rtetprlDAO.addNewRtetprl(rtetprlDTO);
	}

	/**
	 * 
	 * @param rtetprlDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map deleteRtetprl(RtetprlDTO rtetprlDTO) throws ApplicationException {
		return rtetprlDAO.deleteRtetprl(rtetprlDTO);
	}

	/**
	 * 
	 * @param editedRtetprlDTO
	 * @param rtetprlDtoList
	 * @param index
	 * @param  updateInd
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addUpdateRtetprl(RtetprlDTO editedRtetprlDTO,
			List<RtetprlDTO> rtetprlDtoList, int index,char updateInd)
			throws ApplicationException {
		return rtetprlDAO.addUpdateRtetprl( editedRtetprlDTO,rtetprlDtoList, index, updateInd);
	}


	/*@Override
	public Map addNewProcex(ProcexDTO procexDTO) throws ApplicationException {
		
		return procexDAO.addNewProcex(procexDTO);
	}


	@Override
	public Map deleteProcex(String procexCd, String svcTypeCd)
			throws ApplicationException {
		
		return procexDAO.deleteProcex(procexCd,svcTypeCd);
	}


	@Override
	public Map addUpdateProcex(ProcexDTO existProcexDTO,
			List<ProcexDTO> procexDtoList, int index) throws ApplicationException {
		return procexDAO.addUpdateProcex(existProcexDTO,procexDtoList, index);
	}*/

}
