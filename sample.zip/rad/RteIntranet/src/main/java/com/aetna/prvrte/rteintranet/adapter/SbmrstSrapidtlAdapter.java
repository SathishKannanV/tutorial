/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.SbmrdepVO;
import com.aetna.prvrte.rteintranet.vo.SbmrstSrapidtlVO;
import com.aetna.prvrte.rteintranet.vo.SbmrstVO;

/** 
 *
 * @author N726899
 *
 */
public class SbmrstSrapidtlAdapter extends StoredProcedure{
	private final Log log = LogFactory.getLog(SbmrdepAdapter.class);
	private static final String CNVRSTN_CD = "CNVRSTN_CD";
	private static final String VAN_ID_CD = "VAN_ID_CD";
	private static final String IN_TY_CD = "IN_TY_CD";
	
	private static final String OUT_CODE = "OUT_CODE";
	private static final String READ_CURSOR = "READ_CURSOR3";
	private static final String TRANS_TYPE_5010 = "5010";
	private static final int seqNo = 0;
	private static final ArrayList<String> mapoutBenDtls = new ArrayList<String>();
	public SbmrstSrapidtlAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(CNVRSTN_CD, Types.CHAR));   
		declareParameter(new SqlParameter(VAN_ID_CD, Types.CHAR));
		declareParameter(new SqlParameter(IN_TY_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1) throws SQLException {
				SbmrstVO sbmrstVO = new SbmrstVO();
				ArrayList srapidtlCollection = new ArrayList();
				ArrayList<String> mappedEbsBenDtls = new ArrayList<String>();
				int tempInt = rs.getInt("SBMRPLN_SEQ_NO");
				sbmrstVO.setDbConvCode(rs.getString(RteIntranetUtils.getTrimmedString("SUBMSN_CNVRSTN_CD")));
				sbmrstVO.setDbDiagnosisCd(rs.getString(RteIntranetUtils.getTrimmedString("PBNF_SEQ_NO")));
				sbmrstVO.setDbProcedureCd(rs.getString(RteIntranetUtils.getTrimmedString("BNFT_ID_CD")));
				sbmrstVO.setDbQualifierCd(rs.getString(RteIntranetUtils.getTrimmedString("SBMRPLN_CTL_NO")));
				sbmrstVO.setDbSeqNo(tempInt);
				sbmrstVO.setDbServiceTypeCd(rs.getString(RteIntranetUtils.getTrimmedString("SBMRPLN_PLAN_NO")));
				sbmrstVO.setDbTranType(RteIntranetUtils.getTrimmedString(TRANS_TYPE_5010));
				sbmrstVO.setDbTypeCd(rs.getString(RteIntranetUtils.getTrimmedString("SUBMSN_TY_CD")));
				sbmrstVO.setDbVanIdCd(rs.getString(RteIntranetUtils.getTrimmedString("SUBMSN_VAN_ID_CD")));
				
				String coverageTypeCd = rs.getString(RteIntranetUtils.getTrimmedString("SBMRPLN_PLSMRY_CD"));
				String programName = rs.getString(RteIntranetUtils.getTrimmedString("SBMRPLN_PLAN_NM"));
				String ebsBenefitData = rs.getString(RteIntranetUtils.getTrimmedString("SRAPIDTL_CVRGTP_CD"));
				try {
					mappedEbsBenDtls = mapBenDetails(coverageTypeCd, ebsBenefitData);
				} catch (Exception e) {
					log.error("SbmrstSrapidtlAdapter : generic error occured  " + e);
				}
				SbmrstSrapidtlVO srapidtl  = new SbmrstSrapidtlVO(coverageTypeCd,programName,mappedEbsBenDtls);
				srapidtlCollection.add(srapidtl);
				sbmrstVO.setDbBenefitCollection(srapidtlCollection);
				return sbmrstVO;
			}

		}));

	}
	@SuppressWarnings("unchecked")
	public Map getSbmrstSrapidtlEvntTracking (String convIdCode, String vanIdCd,String typeCd) throws ApplicationException {
		log.debug("Entered sbmrdepAdapter  - getSbmrdepEvntTracking");
	
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		@SuppressWarnings("rawtypes")
		Map sbmrdepMap = new LinkedHashMap();
		params.put(CNVRSTN_CD, RteIntranetUtils.getTrimmedString(convIdCode));
		params.put(VAN_ID_CD, RteIntranetUtils.getTrimmedString(vanIdCd));
		params.put(IN_TY_CD, RteIntranetUtils.getTrimmedString(typeCd));
		log.debug(params);
		Map results = null;
		
		List<SbmrstVO> srapidtlList= new LinkedList<SbmrstVO>();
		String newMessage="";
		int noOfElements;
		try {
			results = execute(params);
			log.debug("sbmrdepAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(OUT_CODE));
			srapidtlList = (List<SbmrstVO>) results
					.get(READ_CURSOR);	
	
			noOfElements = srapidtlList.size();
			if (srapidtlList.isEmpty()) {
				newMessage = "No Data for Conversation ID: "
						+ convIdCode + " Van Id: " + vanIdCd
						+ " Tran Type: " + typeCd;
			} else {
				newMessage = "Data found for Conversation ID: "
						+ convIdCode + " Van Id: " + vanIdCd
						+ " Tran Type: " + typeCd;
			}
			sbmrdepMap.put("newMessage", newMessage);
			sbmrdepMap.put("srapidtlList",srapidtlList);
			return sbmrdepMap;
		}catch (Exception exception){
			log.error("sbmrdepAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	public ArrayList<String> mapBenDetails(String cvgTypeCd, String ebsBenDtls)
			throws Exception {
		String recordType = cvgTypeCd.substring(1, 3);
		String apiType = cvgTypeCd.substring(1, 2);
		// ArrayList<String> mapoutBenDtls = new ArrayList<String>();
	
		String tempText,planCopayInd,providerNameInd,inputCriteriaInd,inputproviderInd,nameCriteriaInd,planIdentifierInd;
		if (recordType.equals("A1") || recordType.equals("A4")) { // Trad Accum
																	// Part 1
																	// first (1)
																	// and
			int j = 0; // second (4) call to the service
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 6));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			mapoutBenDtls.add(convertMFSignedNumbers(ebsBenDtls.substring(j,
					j += 5)));
			mapoutBenDtls.add(convertMFSignedNumbers(ebsBenDtls.substring(j,
					j += 5)));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 4));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 4));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
			for (int i = 0; i < 10; i++) {
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 5));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 65));
				tempText = ebsBenDtls.substring(j, j += 5) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				tempText = ebsBenDtls.substring(j, j += 5) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				tempText = ebsBenDtls.substring(j, j += 5) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				tempText = ebsBenDtls.substring(j, j += 5) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				tempText = ebsBenDtls.substring(j, j += 5) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				tempText = ebsBenDtls.substring(j, j += 5) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 4));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2)); // 8262d Feb // 2012
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));	//P8551b-Nov Release-Added a new field												
			}
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
			for (int i = 0; i < 3; i++) {
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 5));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 65));
				tempText = ebsBenDtls.substring(j, j += 7) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				tempText = ebsBenDtls.substring(j, j += 7) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				tempText = ebsBenDtls.substring(j, j += 7) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				for (int k = 0; k < 25; k++) {
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
				}
				for (int k = 0; k < 25; k++) {
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
				}
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				tempText = ebsBenDtls.substring(j, j += 7) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2)); // 8262d Feb 2012
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));	//P8551b-Nov Release-Added a new field										
			}
			tempText = ebsBenDtls.substring(j, j += 7) + "."
					+ ebsBenDtls.substring(j, j += 2);
			mapoutBenDtls.add(convertMFSignedNumbers(tempText));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
			mapoutBenDtls.add(convertMFSignedNumbers(ebsBenDtls.substring(j,
					j += 5)));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			for (int i = 0; i < 10; i++) {
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
			}
			//if (cvgTypeCd.equals("DA1")) { // Trad Dental specific elements -
											// Trad Accum Part 1 only
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3) + "."
						+ ebsBenDtls.substring(j, j += 2));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				for (int i = 0; i < 12; i++) {
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 8));
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
				}
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				for (int i = 0; i < 3; i++) {
					mapoutBenDtls	.add(ebsBenDtls.substring(j, j += 5));
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
					for (int k = 0; k < 3; k++) {
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
						for (int l = 0; l < 4; l++) {
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
						} // l
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 7));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 17));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
						tempText = ebsBenDtls.substring(j, j += 5) + "."
								+ ebsBenDtls.substring(j, j += 2);
						mapoutBenDtls.add(convertMFSignedNumbers(tempText));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 19));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 32));
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
					} // k
				} // i
			//} // end cvgTypeCd "DA1"
	
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1)); // feb 2012
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2)); // 8262d Feb
																// 2012
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2)); // 8262d Feb
																// 2012
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2)); // 7140w Feb
																// 2012
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10)); // 7140w Feb
																	// 2012
			// venkat August 2012
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1)); // P8357D August
																// 2012
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1)); // P8357D August
																// 2012
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1)); // P8357D August 2012
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1)); //P8551b-Start-Nov Release-Added below new fields
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3)); //P8551b-Nov Release-Added a new field						
			// venkat August 2012
	
			mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1)); // FICOMPARE-IND
																// and end of
																// 'A1' & 'A4'
		} else if (recordType.equals("A2") || recordType.equals("A3")
				|| recordType.equals("A5") || recordType.equals("A6")) { // Trad
																			// Accum
																			// Parts
																			// 2
																			// and
																			// 3
			int j = 0; // first (2-3) and second (5-6)call
	
			if (recordType.equals("A2")) { // 8262e Feb 2012 (scheduled
											// benefits)
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2)); // 8262e Feb
																	// 2012
																	// (scheduled
																	// benefits)
				for (int l = 0; l < 20; l++) { // 8262e Feb 2012 (scheduled
												// benefits)
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 11)); // 8262e
																			// Feb
																			// 2012
																			// (scheduled
																			// Benefits)
				} // 8262e Feb 2012
			} // 8262e Feb 2012
	
			for (int i = 0; i < 11; i++) {
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 5));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 65));
				tempText = ebsBenDtls.substring(j, j += 7) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				tempText = ebsBenDtls.substring(j, j += 7) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				tempText = ebsBenDtls.substring(j, j += 7) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				for (int k = 0; k < 25; k++) {
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
				}
				for (int k = 0; k < 25; k++) {
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
				}
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				tempText = ebsBenDtls.substring(j, j += 7) + "."
						+ ebsBenDtls.substring(j, j += 2);
				mapoutBenDtls.add(convertMFSignedNumbers(tempText));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2)); // Feb 12 8262d
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));	//P8551b-Nov Release-Added a new field											
			}
			if (recordType.equals("A3") || recordType.equals("A6")) {
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 6));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			}
		} else if (apiType.equals("S")) { // Trad SE Parts 1-4 first (MS1-4) and
											// second (VS1-4) call
			int j = 0;
			if (recordType.equals("S1")) {  //P8262-Aug Release-start-Modified the structure of copybook
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 6));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			}
			int k = 13; // pcr 8825 changed from 16 to 13
			if (recordType.equals("S4"))
				k = 11; // pcr 8825 new 'S4' only 11 occurenced
			for (int i = 0; i < k; i++) {
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3)); //P8551b-Nov Release-Added a new field		
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1)); 
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
		        mapoutBenDtls.add(ebsBenDtls.substring(j, j += 8));
		        mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
		        for (int k1 = 0; k1 < 2; k1++) {
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 5));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
		        mapoutBenDtls.add(ebsBenDtls.substring(j, j += 8));
		        mapoutBenDtls.add(ebsBenDtls.substring(j, j += 5));
		        }
			    mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
		        for (int k2 = 0; k2 < 4; k2++) {
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 5));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 7));
		        mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
		        mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
		        planCopayInd = ebsBenDtls.substring(j, j += 1);
		        mapoutBenDtls.add(planCopayInd);
		        if ((planCopayInd.equals("1")) || (planCopayInd.equals("2"))){
		        	mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
		        	mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			        mapoutBenDtls.add(ebsBenDtls.substring(j, j += 8));
		        }
		        else {
		        	mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));
		        }
		         }
		        /*P8551c - August 2014: BASIC-DEDUCTIBLE-LINE-NO-B,BASIC-COVERED-RATE-CALC-IND-B*/
		        mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
		        mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));
			}
			//P8262-Aug Release-end-Modified the structure of copybook 
			
			//19134a - RTE Feb 2014 release - New condition added
			
		} else if (apiType.equals("P")) { 
											
			int j = 0;
			if (recordType.equals("P1")){
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));     		//AS-OF-DATE
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));				//ENTITY-TYPE-CODE 
				inputproviderInd = ebsBenDtls.substring(j, j += 1);
				mapoutBenDtls.add(inputproviderInd);												//INPUT-PROVIDER-IND
				if ((inputproviderInd.equals("1")) ){
		        	mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));   //TAX-ID-FORMAT-CODE 
		        	mapoutBenDtls.add(ebsBenDtls.substring(j, j += 9));   //TAX-IDENTIFIER-NUMBER
		        }
				else if((inputproviderInd.equals("2")) || (inputproviderInd.equals("3"))){
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));   		//PROVIDER-ID-NUMBER and  NATIONAL-PROVIDER-IDENTIFIER
				}
				else {
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10));    	//INPUT-PROVIDER-IDENTIFIER-DATA
		        }
				inputCriteriaInd = ebsBenDtls.substring(j, j += 1);
				mapoutBenDtls.add(inputCriteriaInd);												//INPUT-CRITERIA-IND can take 1,2,3 values
				if ((inputCriteriaInd.equals("1")) ){
						nameCriteriaInd = ebsBenDtls.substring(j, j += 1);  
						mapoutBenDtls.add(nameCriteriaInd); 										//NAME-CRITERIA-IND can take 1 and 2 as values
						if( nameCriteriaInd.equals("1")) {
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 50)); 	//LAST-NAME
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 25)); 	// FIRST-NAME
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 25));  //MIDDLE-NAME
						}else if((nameCriteriaInd.equals("2")) ){
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 50));  //NON-INDIVIDUAL-NAME
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 50));  //FILLER
						}else{
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 100)); //NAME-CRITERIA-DATA
						}
						
					    mapoutBenDtls.add(ebsBenDtls.substring(j, j += 7)); 	//CONTROL-NUMBER 
						planIdentifierInd = ebsBenDtls.substring(j, j += 1);  
						mapoutBenDtls.add(planIdentifierInd); 									//PLAN-IDENTIFIER-IND can take 1 and 2 as values
						if ( planIdentifierInd.equals("1")) {
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));  	//PLAN-NUMBER
						}else if ( planIdentifierInd.equals("2") ){
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));   //PLAN-SUMMARY
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));   //FILLER
						}else{
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));   //PLAN-IDENTIFIER-DATA
						}
				}else if ( inputCriteriaInd.equals("2") ){  								//TIER-CRITERIA-DATA
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 7)); 		//CONTROL-NUMBER
						planIdentifierInd = ebsBenDtls.substring(j, j += 1);
						mapoutBenDtls.add(planIdentifierInd); 									//PLAN-IDENTIFIER-IND can take 1 and 2 as values
						if (planIdentifierInd.equals("1")) {
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3)); 	//PLAN-NUMBER 
						}else if ( planIdentifierInd.equals("2")){
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));  	//PLAN-SUMMARY
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));  	//FILLER
						}else{
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));  	//PLAN-IDENTIFIER-DATA
						}
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 101)); 	//FILLER
				}else if ((inputCriteriaInd.equals("3")) ){  								//NAME-CRITERIA-DATA
						nameCriteriaInd = ebsBenDtls.substring(j, j += 1); 
						mapoutBenDtls.add(nameCriteriaInd);											//NAME-CRITERIA-IND can take 1 and 2 as values
						if ( nameCriteriaInd.equals("1")) {
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 50)); 	//LAST-NAME
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 25)); 	//FIRST-NAME
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 25)); 	//MIDDLE-NAME
						}else if((nameCriteriaInd.equals("2")) ){             	//NON-IND-NAME-CRITERIA-DATA
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 50));  //NON-INDIVIDUAL-NAME
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 50));  // FILLER
						}else{
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 100)); //NAME-CRITERIA-DATA
						}
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 11)); 		//FILLER
				}else{							
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 112)); 		//INPUT-CRITERIA-DATA 
				}
				//PROVIDER-TIERS-BY-ID
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1)); 				//WARNING-INDICATOR
				//PROVIDER-DETAILS
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 10)); 				//PROVIDER-ID
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));  				//PROVIDER-INFO-TYPE can take only 1,2,3,4 values
				//PROVIDER-TYPE
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));  				//TYPE-CODE
				mapoutBenDtls.add(ebsBenDtls.substring(j, j += 60));  			//DESCRIPTION
				providerNameInd = ebsBenDtls.substring(j, j += 1);    			//PROVIDER-NAME-IND
				mapoutBenDtls.add(providerNameInd); 												//PROVIDER-NAME-IND can take 1 and 2 as values
					if( (providerNameInd.equals("1")) ){  										//INDIVIDUAL-NAME-DATA
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 50));  	//LAST-NAME
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 25));  	//FIRST-NAME
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 25)); 		//MIDDLE-NAME
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 4));  		//RANK
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 4));  		//SALUTATION
					}else if( (providerNameInd.equals("2")) ) {  							//NON-INDIVIDUAL-NAME-DATA
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 50));  	//MARKETING-NAME
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 58));  	//FILLER
					}else{
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 108)); 	//PROVIDER-NAME-DATA
					}
					
					//PROVIDER-TIER-SET
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));   		//PROVIDER-TIER-CTR
					for(int i=1; i<6; i++){
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));  		//PROVIDER-TIER
					}
					//CATEGORY-DETAIL-SET-SET
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));   		//CATEGORY-DETAIL-SET-CTR
					for (int i=1; i<11; i++){
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 8));  		//CATEGORY-CODE
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 50)); 		//CATEGORY-CODE-DESCRIPTION
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 8));   	//MASTER-CATEGORY-CODE
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 50));  	//MASTER-CATEGORY-DESCRIPTION
						
						//CLASSIFICATION-SET
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2));  		//CLASSIFICATION-CTR 
						for (int a=1; a<16; a++){
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 3));  	//CLASSIFICATION-CODE
												}
						//PRVDR-TIER-SET
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));    	//PRVDR-TIER-CTR
						for (int b=1; b<6; b++){
							mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1));		//PRVDR-TIER
						}
					}
					
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1)); 			//EYEMED-PROVIDER-INDICATOR
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 2)); 		//PROVIDER-FLAG-CTR
					
					for (int i=1; i<11; i++){
						mapoutBenDtls.add(ebsBenDtls.substring(j, j += 8));  //FLAG-CODE 
					}
					mapoutBenDtls.add(ebsBenDtls.substring(j, j += 1)); /*P20941a August 2014:PROVIDER-MATCH-INDICATOR*/ 
			}
		}
		//19134a - RTE Feb 2014 release ends here
		
		else if (apiType.equals("B") || apiType.equals("H")) { // HMO Accum
			// Summary
			// SRAPIDTL
			// mapping
			// D107HMB1
				LinkedHashMap<String, Object> fieldList = null;
				if (apiType.equals("B")) {
					HMB1CopyBookList copyBookList = new HMB1CopyBookList();
					fieldList = copyBookList.getCopyBookFields();
				} else if (apiType.equals("H")) {
					// HMB1CopyBookList copyBookList = new HMB1CopyBookList();
					HMP1CopyBookList copyBookList = new HMP1CopyBookList();
					fieldList = copyBookList.getCopyBookFields();
				}
				int curentPosition = 0;
				String accumInd = "";
				for (String keyField : fieldList.keySet()) {
					Object fieldVal = fieldList.get(keyField);
					if (fieldVal instanceof HashMap) {
						int repeatTimes = 1;
						if (keyField.indexOf("REPEAT") != -1) {
							repeatTimes = Integer.parseInt(keyField
									.substring(keyField.length() - 1));
						}
						// process the Hash & Loop
						int updatedPosition = processHMOMap(ebsBenDtls,
								(LinkedHashMap<String, Object>) fieldVal,
								curentPosition, repeatTimes, apiType);
						curentPosition = updatedPosition;
					} else {
						String fieldValue = (String) fieldList.get(keyField);
						String[] stVals = fieldValue.split("\\|");
						int fieldLen = Integer.parseInt(stVals[0]);
						String fieldType = stVals[1];
						String fieldLabel = stVals[2];
	
						String val = ebsBenDtls.substring(curentPosition, curentPosition += fieldLen);
						mapoutBenDtls.add(fieldLabel + "|" + val);
					}
	
				}
		}
	
		return mapoutBenDtls;
	}

	public String convertMFSignedNumbers(String numberToConvert) {
		char singleChar = numberToConvert
				.charAt((numberToConvert.length() - 1));
		String displayNumber = "";
		switch (singleChar) {
		case '{':
			displayNumber = "+" + numberToConvert;
			displayNumber = displayNumber.replace('{', '0');
			break;
		case 'A':
			displayNumber = "+" + numberToConvert;
			displayNumber = displayNumber.replace('A', '1');
			break;
		case 'B':
			displayNumber = "+" + numberToConvert;
			displayNumber = displayNumber.replace('B', '2');
			break;
		case 'C':
			displayNumber = "+" + numberToConvert;
			displayNumber = displayNumber.replace('C', '3');
			break;
		case 'D':
			displayNumber = "+" + numberToConvert;
			displayNumber = displayNumber.replace('D', '4');
			break;
		case 'E':
			displayNumber = "+" + numberToConvert;
			displayNumber = displayNumber.replace('E', '5');
			break;
		case 'F':
			displayNumber = "+" + numberToConvert;
			displayNumber = displayNumber.replace('F', '6');
			break;
		case 'G':
			displayNumber = "+" + numberToConvert;
			displayNumber = displayNumber.replace('G', '7');
			break;
		case 'H':
			displayNumber = "+" + numberToConvert;
			displayNumber = displayNumber.replace('H', '8');
			break;
		case 'I':
			displayNumber = "+" + numberToConvert;
			displayNumber = displayNumber.replace('I', '9');
			break;
		case '}':
			displayNumber = "-" + numberToConvert;
			displayNumber = displayNumber.replace('}', '0');
			break;
		case 'J':
			displayNumber = "-" + numberToConvert;
			displayNumber = displayNumber.replace('J', '1');
			break;
		case 'K':
			displayNumber = "-" + numberToConvert;
			displayNumber = displayNumber.replace('K', '2');
			break;
		case 'L':
			displayNumber = "-" + numberToConvert;
			displayNumber = displayNumber.replace('L', '3');
			break;
		case 'M':
			displayNumber = "-" + numberToConvert;
			displayNumber = displayNumber.replace('M', '4');
			break;
		case 'N':
			displayNumber = "-" + numberToConvert;
			displayNumber = displayNumber.replace('N', '5');
			break;
		case 'O':
			displayNumber = "-" + numberToConvert;
			displayNumber = displayNumber.replace('O', '6');
			break;
		case 'P':
			displayNumber = "-" + numberToConvert;
			displayNumber = displayNumber.replace('P', '7');
			break;
		case 'Q':
			displayNumber = "-" + numberToConvert;
			displayNumber = displayNumber.replace('Q', '8');
			break;
		case 'R':
			displayNumber = "-" + numberToConvert;
			displayNumber = displayNumber.replace('R', '9');
			break;
		}
		return displayNumber;
	}

	private int processHMOMap(String bnftDetailStr,
			LinkedHashMap<String, Object> currentMap, int currentPosition,
			int repeatTimes, String apiType) {
		int updatedPosition = currentPosition;
		int repeatId = 1;
		String accumInd = "";
		try {
			for (int i = 0; i < repeatTimes; i++) {
				for (String keyField : currentMap.keySet()) {
					Object fieldVal = currentMap.get(keyField);
					if (fieldVal instanceof HashMap) {
						int repeatNum = 1;
						if (keyField.indexOf("REPEAT") != -1) {
							repeatNum = Integer.parseInt(keyField
									.substring(keyField.length() - 1));
						}
						// process the Hash & Loop
						int newPosition = processHMOMap(bnftDetailStr,
								(LinkedHashMap<String, Object>) fieldVal,
								updatedPosition, repeatNum, apiType);
						updatedPosition = newPosition;
					} else {
						String fieldValue = (String) currentMap.get(keyField);
						String[] stVals = fieldValue.split("\\|");
						int fieldLen = Integer.parseInt(stVals[0]);
						String fieldType = stVals[1];
						String fieldLbl = stVals[2];
						String fieldLabel = fieldLbl + " " + repeatId;

						String val = bnftDetailStr.substring(updatedPosition,
								updatedPosition += fieldLen);
						mapoutBenDtls.add(fieldLabel + "|" + val.trim());
						if (fieldLbl.equals("COPAY-MAXIMUM-IND")) {
							updatedPosition = addRedefineBenData(apiType, bnftDetailStr, updatedPosition,repeatId, "COPAY", val);
						}
						if (fieldLbl.equals("ACCUMULATOR-USAGE-IND")) {
							accumInd = val;
						}
						if (fieldLbl.equals("LIFETIME-LIMIT")) {
							updatedPosition = addRedefineBenData(apiType, bnftDetailStr, updatedPosition,repeatId, "ACCUM", accumInd);
						}

					}
				}
				repeatId++;
			}
		} catch (Exception e) {
			log.warn(e.getMessage());
		}
		return updatedPosition;
	}
	
	private int addRedefineBenData(String apiType, String ebsBenDtls, int currentPosition,int repeatId, String type, String val){
		LinkedHashMap<String, Object> fieldList = null;
		int finalPosition = currentPosition;
		if (type.equals("COPAY")){
			if(apiType.equals("B")){
				HMB1CopyBookList copyBookList = new HMB1CopyBookList();
				fieldList = copyBookList.getCopayMaxData(val);
			}
		}else{
			if(apiType.equals("B")){
				HMB1CopyBookList copyBookList = new HMB1CopyBookList();
				fieldList = copyBookList.getAccumlatorData(val);
			}
		}
		
		for (String keyField : fieldList.keySet()) {
			Object fieldVal = fieldList.get(keyField);

			String fieldValue = (String) fieldList.get(keyField);
			String[] stVals = fieldValue.split("\\|");
			int fieldLen = Integer.parseInt(stVals[0]);
			String fieldType = stVals[1];
			String fieldLabel = stVals[2]+" "+repeatId;

			String value = ebsBenDtls.substring(finalPosition, finalPosition += fieldLen);
			mapoutBenDtls.add(fieldLabel + "|" + value.trim());
			//finalPosition = finalPosition+fieldLen;
		}
		return finalPosition;
	}
}
