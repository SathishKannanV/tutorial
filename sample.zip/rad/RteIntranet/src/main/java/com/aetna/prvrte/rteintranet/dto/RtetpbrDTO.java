/**
 * 
 */
package com.aetna.prvrte.rteintranet.dto;

import java.io.Serializable;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class RtetpbrDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1256286342259748256L;
	private String idNo = "";
	private String benrlCd = "";
	private String svctypCd = "";
	private String acastosCd = "";
	private String acasposCd = "";
	private String effDate = "";
	private String expDate = "";
	private String postedDate = "";
	private String userId = "";
	private String valueTxt = "";
	private char   updatedInd;
	
	
	
	public RtetpbrDTO(String idNo, String benrlCd, String svctypCd, String acastosCd, String acasposCd, String effDate,
			String expDate,	String postedDate, String userId, String valueTxt, char updatedInd) {
		super();
		this.idNo = idNo;
		this.benrlCd = benrlCd;
		this.svctypCd = svctypCd;
		this.acastosCd = acastosCd;
		this.acasposCd = acasposCd;
		this.effDate = effDate;
		this.expDate = expDate;
		this.postedDate = postedDate;
		this.userId = userId;
		this.valueTxt = valueTxt;
		this.updatedInd = updatedInd;
	}
	
	public RtetpbrDTO() {
		super();
	}
	
	/**
	 * @return the idNo
	 */
	public String getIdNo() {
		return idNo;
	}
	/**
	 * @param idNo the idNo to set
	 */
	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}
	/**
	 * @return the benrlCd
	 */
	public String getBenrlCd() {
		return benrlCd;
	}
	/**
	 * @param benrlCd the benrlCd to set
	 */
	public void setBenrlCd(String benrlCd) {
		this.benrlCd = benrlCd;
	}
	/**
	 * @return the svctypCd
	 */
	public String getSvctypCd() {
		return svctypCd;
	}
	/**
	 * @param svctypCd the svctypCd to set
	 */
	public void setSvctypCd(String svctypCd) {
		this.svctypCd = svctypCd;
	}
	/**
	 * @return the acastosCd
	 */
	public String getAcastosCd() {
		return acastosCd;
	}
	/**
	 * @param acastosCd the acastosCd to set
	 */
	public void setAcastosCd(String acastosCd) {
		this.acastosCd = acastosCd;
	}
	/**
	 * @return the acasposCd
	 */
	public String getAcasposCd() {
		return acasposCd;
	}
	/**
	 * @param acasposCd the acasposCd to set
	 */
	public void setAcasposCd(String acasposCd) {
		this.acasposCd = acasposCd;
	}
	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}
	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	/**
	 * @return the expDate
	 */
	public String getExpDate() {
		return expDate;
	}
	/**
	 * @param expDate the expDate to set
	 */
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	/**
	 * @return the postedDate
	 */
	public String getPostedDate() {
		return postedDate;
	}
	/**
	 * @param postedDate the postedDate to set
	 */
	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the valueTxt
	 */
	public String getValueTxt() {
		return valueTxt;
	}
	/**
	 * @param valueTxt the valueTxt to set
	 */
	public void setValueTxt(String valueTxt) {
		this.valueTxt = valueTxt;
	}
	/**
	 * @return the updatedInd
	 */
	public char getUpdatedInd() {
		return updatedInd;
	}
	/**
	 * @param updatedInd the updatedInd to set
	 */
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}
	
	
	
}
