/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.AdasvctDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * 
 * <h1>RteAdasvctDAO</h1> The RteAdasvctDAO is responsible for handling the
 * storage, retrieval, and search data from/to data store.
 * 
 * @author N726899 Cognizant_Offshore
 * 
 */
public interface RteAdasvctDAO {
	/**
	 * Method to get the ADASVCT list from data store.
	 * 
	 * @param adasvctDTO
	 * 			adasvctDTO object.
	 * @return Map of ADASVCT list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	Map<String, Object> getAdasvctLookUpList(AdasvctDTO adasvctDTO) throws ApplicationException;
	/**
	 * Method to add new ADASVCT to data store.
	 * 
	 * @param adasvctDTO
	 *            adasvctDTO object.
	 * @return Map of added ADASVCT data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	Map<String, Object> addAdasvctToDb(AdasvctDTO adasvctDTO) throws ApplicationException;
	/**
	 * Method to delete the ADASVCT data from data store.
	 * 
	 * @param adaCd
	 *            String of adaCd.
	 * @param expDate
	 *            String of expiration data of adaCd.
	 * @return Map of flag to delete the data from ADASVCT list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	Map<String, Object> deleteAdasvct(String adaCd, String expDate)throws ApplicationException;
	
	/**
	 * Method to add/update list of ADASVCT to data store.
	 * 
	 * @param adasvctDTO
	 *            adasvctDTO object.
	 * @param adasvctDTOList
	 *            list of adasvctDTO object.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from ADASVCT list, success or
	 *         error message and list of ADASVCT.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	Map<String, Object> addUpdateAdasvct(AdasvctDTO adasvctDTO,	List<AdasvctDTO> adasvctDTOList, int index)throws ApplicationException;
	Map<String, Object> getVanList()throws ApplicationException;
	
}
