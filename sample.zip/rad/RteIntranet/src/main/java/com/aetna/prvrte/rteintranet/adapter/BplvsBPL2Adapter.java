/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.BplvsDTO;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;



/**
 * @author N657186
 * Cognizant_Offshore
 */
public class BplvsBPL2Adapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(BplvsBPL2Adapter.class);
	private static final String LS_RQSTDBNFT_CD = "LS_RQSTDBNFT_CD";
	private static final String LS_D_SEQ_NO = "LS_D_SEQ_NO";
	private static final String LS_SRCE_PSTD_DT = "LS_SRCE_PSTD_DT";
	private static final String LS_D_NO_QLFR_CD = "LS_D_NO_QLFR_CD";
	private static final String LS_D_NO = "LS_D_NO";
	private static final String LS_D_DSCRPTN_TXT = "LS_D_DSCRPTN_TXT";
	private static final String LS_D_ELPDLMT_CD = "LS_D_ELPDLMT_CD";
	private static final String LS_D_TYPE_CD = "LS_D_TYPE_CD";
	private static final String LS_BNFT_ID_CD = "LS_BNFT_ID_CD";
	private static final String LS_BPRO_NO = "LS_BPRO_NO";
	private static final String IN_BPLV_NO = "IN_BPLV_NO";
	private static final String LS_AUTHCERT_CD = "LS_AUTHCERT_CD";
	private static final String LS_IONTWK_CD = "LS_IONTWK_CD";
	private static final String LS_SVCTYP_CD = "LS_SVCTYP_CD";
	private static final String LS_D_USER_TXT = "LS_D_USER_TXT";
	private static final String LS_ADD_UPDATE = "LS_ADD_UPDATE";
	private static final String LS_SQL_TYPE = "LS_SQL_TYPE";
	
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public BplvsBPL2Adapter(DataSource datasource, String storedProc) throws SQLException{
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(LS_RQSTDBNFT_CD, Types.CHAR));   
		declareParameter(new SqlParameter(LS_D_SEQ_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(LS_SRCE_PSTD_DT, Types.DATE));
		declareParameter(new SqlParameter(LS_D_NO_QLFR_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_D_NO, Types.CHAR));
		declareParameter(new SqlParameter(LS_D_DSCRPTN_TXT, Types.CHAR));
		declareParameter(new SqlParameter(LS_D_ELPDLMT_CD, Types.CHAR));   
		declareParameter(new SqlParameter(LS_D_TYPE_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_BNFT_ID_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_BPRO_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(IN_BPLV_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(LS_AUTHCERT_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_IONTWK_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_SVCTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_D_USER_TXT, Types.CHAR));
		declareParameter(new SqlOutParameter(LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(LS_SQL_TYPE, Types.INTEGER));
		
	}
	
	
	@SuppressWarnings("unchecked")
	public Map addNewBplvs(BplvsDTO bplvsDTO) throws ApplicationException {
		
		log.debug("Entered BplvsBpl2Adapter  - addNewBplvs");
		//boolean isProcexAdded = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map bplvsMap = new HashMap();
		Date todaysDate = new Date(System.currentTimeMillis());
		String postedDate = todaysDate.toString();
		bplvsDTO.setPostedDt(postedDate);
		bplvsDTO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
		String reqBenCd = bplvsDTO.getReqBenCd();
		 String dSeqNo = bplvsDTO.getdSeqNo();
		 String postedDt =bplvsDTO.getPostedDt();
		 String dNoQlfrCd = bplvsDTO.getdNoQlfrCd();
		 String dNo =bplvsDTO.getdNo();
		 String dDiscTxt = bplvsDTO.getdDiscTxt();
		 String dElpDlmtCd= bplvsDTO.getdElpDlmtCd();
		 String dTypeCd = bplvsDTO.getdTypeCd();
		 String bic = bplvsDTO.getBic().trim();
		 String prov = bplvsDTO.getProv();
		 String lineVal = bplvsDTO.getLineVal();
		 String authCertCd = bplvsDTO.getAuthCertCd();
		 String ioNtwkCd = bplvsDTO.getIoNtwkCd();
		 String svcType= bplvsDTO.getSvcType();
		 String userTxt = bplvsDTO.getUserTxt();
		
		 	params.put(LS_RQSTDBNFT_CD, RteIntranetUtils.getTrimmedString(reqBenCd));
		 	params.put(LS_D_SEQ_NO, RteIntranetUtils.getTrimmedString(dSeqNo));
			params.put(LS_SRCE_PSTD_DT, RteIntranetUtils.getTrimmedString(postedDt));
			params.put(LS_D_NO_QLFR_CD, RteIntranetUtils.getTrimmedString(dNoQlfrCd));
			params.put(LS_D_NO, RteIntranetUtils.getTrimmedString(dNo));
			params.put(LS_D_DSCRPTN_TXT, RteIntranetUtils.getTrimmedString(dDiscTxt));
			params.put(LS_D_ELPDLMT_CD, RteIntranetUtils.getTrimmedString(dElpDlmtCd));
			params.put(LS_D_TYPE_CD, RteIntranetUtils.getTrimmedString(dTypeCd));
		 	params.put(LS_BNFT_ID_CD, RteIntranetUtils.getTrimmedString(bic));
		 	params.put(LS_BPRO_NO, RteIntranetUtils.getTrimmedString(prov));
		 	params.put(IN_BPLV_NO, RteIntranetUtils.getTrimmedString(lineVal));
		 	params.put(LS_AUTHCERT_CD,  RteIntranetUtils.getTrimmedString(authCertCd));
		 	params.put(LS_IONTWK_CD,  RteIntranetUtils.getTrimmedString(ioNtwkCd));
			params.put(LS_SVCTYP_CD, RteIntranetUtils.getTrimmedString(svcType));
			params.put(LS_D_USER_TXT, RteIntranetUtils.getTrimmedString(userTxt));
		
		log.debug(params);	
		
		try {
			
					
			results = execute(params);
			log.debug("BplvsBPL2Adapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(LS_SQL_TYPE));
			
			if ("0".equalsIgnoreCase(sqlCode)) {
				//isProcexAdded = true;
				List<BplvsDTO> bplvsList = new LinkedList<BplvsDTO>();
				bplvsList.add(bplvsDTO);
				bplvsMap.put("BplvsList", bplvsList);
				if ("0".equalsIgnoreCase(actionCode)) {
					newMessage = "This row added to the database";
				}else {
					newMessage ="Row already exists on the database. It was updated with these values.";					
					bplvsDTO.setUpdatedInd(ApplicationConstants.UPDATE_IND_Y); 
				}				
				}
			else {
				newMessage = "Unable to add row to the database. SQLCODE = " + sqlCode;
			}
			
			bplvsMap.put("bplvsMessage", newMessage);
			//procexMap.put("isProcexAdded", isProcexAdded);				
		return bplvsMap;
	}catch (Exception exception){
		log.error("bplvsAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}


	@SuppressWarnings("unchecked")
	public Map addUpdateBplvs(BplvsDTO modifiedBplvs,
			List<BplvsDTO> bplvsDtoList, int index, char updateInd) throws ApplicationException{
		log.debug("Entered BplvsBPL2Adapter  - addUpdateBplvs");
		boolean isBplvsAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map bplvsMap = new HashMap();
		String reqBenCd = modifiedBplvs.getReqBenCd();
		 String dSeqNo = modifiedBplvs.getdSeqNo();
		 String postedDt =modifiedBplvs.getPostedDt();
		 String dNoQlfrCd = modifiedBplvs.getdNoQlfrCd();
		 String dNo =modifiedBplvs.getdNo();
		 String dDiscTxt = modifiedBplvs.getdDiscTxt();
		 String dElpDlmtCd= modifiedBplvs.getdElpDlmtCd();
		 String dTypeCd = modifiedBplvs.getdTypeCd();
		 String bic = modifiedBplvs.getBic().trim();
		 String prov = modifiedBplvs.getProv();
		 String lineVal = modifiedBplvs.getLineVal();
		 String authCertCd = modifiedBplvs.getAuthCertCd();
		 String ioNtwkCd = modifiedBplvs.getIoNtwkCd();
		 String svcType= modifiedBplvs.getSvcType();
		 String userTxt = modifiedBplvs.getUserTxt();
		
		 	params.put(LS_RQSTDBNFT_CD, RteIntranetUtils.getTrimmedString(reqBenCd));
		 	params.put(LS_D_SEQ_NO, RteIntranetUtils.getTrimmedString(dSeqNo));
			params.put(LS_SRCE_PSTD_DT, RteIntranetUtils.getTrimmedString(postedDt));
			params.put(LS_D_NO_QLFR_CD, RteIntranetUtils.getTrimmedString(dNoQlfrCd));
			params.put(LS_D_NO, RteIntranetUtils.getTrimmedString(dNo));
			params.put(LS_D_DSCRPTN_TXT, RteIntranetUtils.getTrimmedString(dDiscTxt));
			params.put(LS_D_ELPDLMT_CD, RteIntranetUtils.getTrimmedString(dElpDlmtCd));
			params.put(LS_D_TYPE_CD, RteIntranetUtils.getTrimmedString(dTypeCd));
		 	params.put(LS_BNFT_ID_CD, RteIntranetUtils.getTrimmedString(bic));
		 	params.put(LS_BPRO_NO, RteIntranetUtils.getTrimmedString(prov));
		 	params.put(IN_BPLV_NO, RteIntranetUtils.getTrimmedString(lineVal));
		 	params.put(LS_AUTHCERT_CD,  RteIntranetUtils.getTrimmedString(authCertCd));
		 	params.put(LS_IONTWK_CD,  RteIntranetUtils.getTrimmedString(ioNtwkCd));
			params.put(LS_SVCTYP_CD, RteIntranetUtils.getTrimmedString(svcType));
			params.put(LS_D_USER_TXT, RteIntranetUtils.getTrimmedString(userTxt));
		
		log.debug(params);	
		
		try {
					
			results = execute(params);
			log.debug("BplvsBPL2Adapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(LS_SQL_TYPE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				isBplvsAddorUpdated = true;
			//	existingSrchcol.setSrchcolCd((actionCode));
				bplvsDtoList.set(index, modifiedBplvs);	
	
				newMessage = "All rows that changed the database are highlighted.";
					}
			else {
			newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
		
			bplvsMap.put("bplvsMsg",newMessage);
			bplvsMap.put("bplvsDtoList",bplvsDtoList);
			bplvsMap.put("isBplvsAddorUpdated", isBplvsAddorUpdated);
			return bplvsMap;
		}catch (Exception exception){
			log.error("BplvsAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
}