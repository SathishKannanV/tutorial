package com.aetna.prvrte.rteintranet.web.controller;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.aetna.prvrte.rteintranet.dto.TierdMsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.TierdMsgVO;

/**
 * 
 * The TierdMsg Controller is responsible for handling
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * @author N624926
 * Cognizant_Offshore
 */

@Controller
@RequestMapping(value = "/tierdmsg/*")
public class TierdMsgController {

	/*
	 * Tile name of the tierdmsg Home view.
	 */
	public static final String TIERDMSG_HOME = ".tierdmsgHome";
	/*
	 * Tile name of the tierdmsg Display view.
	 */
	public static final String TIERDMSG_LOOKUP = ".tierdmsgLookUpDisplay";
	/*
	 * Tile name of the Add New tierdmsg Form view.
	 */
	public static final String TIERDMSG_ADD = ".tierdmsgAdd";
	/*
	 * Constant name used for COPY indicator.
	 */
	public static final char COPY = 'C';
	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(TierdMsgController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	/**
	 * Model and view of failure operation.
	 */
	private ModelAndView errormav;
	
	/**
	 * Method to getTierdMsgLookUpHome view
	 * 
	 * @param model
	 * 
	 * @return view of tierdmsgLookUp, if fails return error page
	 */
	@RequestMapping(value="/tierdmsgHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getTierdMsgLookUpHome(final HttpServletRequest request,Model model) {	
		log.warn("Entered TierdMsgController - getTierdMsgLookUpHome()");
		String securityLevel ="";
		try {
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(TIERDMSG_HOME, "tierdmsgVO",  new TierdMsgVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("TierdMsgController - securityLevel: "+ securityLevel);
		log.warn("Exit from TierdMsgController - getTierdMsgLookUpHome()");
		return mav;
		} catch (ApplicationException e){
			log.error("Exception occured in TierdMsgController - getTierdMsgLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * Method to get the getTierdMsgLookUpTable List from data store.
	 * 
	 * @param tierdmsgVO
	 *            form view object of tierdmsg.
	 * @return view of tierdmsgDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherTierdMsg", method = RequestMethod.POST)
	public ModelAndView getTierdMsgLookUpTable(HttpServletRequest request,@ModelAttribute("tierdmsgForm")TierdMsgVO tierdmsgVO){
		log.warn("Entered TierdMsgController - getTierdMsgLookUpTable()");
		String securityLevel ="";
		ModelAndView mav ;
		Map tierdmsgResultMap = new HashMap();
		List<TierdMsgVO> tierdmsgList = new LinkedList<TierdMsgVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			TierdMsgDTO tierdmsgDTO = RTETranslator.toTierdMsgDTO(tierdmsgVO);
			tierdmsgResultMap = facade.getTierdMsgLookUpTable(tierdmsgDTO);
			List<TierdMsgDTO> tierdmsgDTOList = (List<TierdMsgDTO>) tierdmsgResultMap.get("tierdmsgList");
			tierdmsgList = (List<TierdMsgVO>) RTETranslator.toTierdMsgVOList(tierdmsgDTOList);
			lookUpListVO.setTierdmsgVOList(tierdmsgList);
			facade.getApplicationState().setTierdmsgList(tierdmsgList);
			mav = new ModelAndView(TIERDMSG_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("tierdmsgMessage", tierdmsgResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("getTierdMsgLookUpTable - tierdmsgMessage: "+ tierdmsgResultMap.get("newMessage"));
			log.warn("Exit from TierdMsgController - getTierdMsgLookUpTable()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in TierdMsgController - getTierdMsgLookUpTable() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="getTierdMsgLookUpTable() :"+ApplicationConstants.ERROR_GET_LOOKUP + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to display get add new TierdMsg form home view.
	 * 
	 * @return view of loadAddNewTierdMsgRowScreen, if fails return error page
	 */
	@RequestMapping(value="/AddNewTierdMsgRow")
	public ModelAndView loadAddNewTierdMsgRowScreen(final HttpServletRequest request,Model model) {	
		log.warn("Entered TierdMsgController - loadAddNewTierdMsgRowScreen()");
		ModelAndView mav = new ModelAndView(TIERDMSG_ADD, "tierdmsgVO",  new TierdMsgVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in TierdMsgController - loadAddNewTierdMsgRowScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (loadAddNewTierdMsgRowScreen). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		log.warn("Exit from TierdMsgController - loadAddNewTierdMsgRowScreen()");
		return mav;
	}
	
	
	/**
	 * Method to add the data database
	 * 
	 * @param tierdmsgVO form view object of TierdMsg.
	 * @param request request object for TierdMsg to get username
	 * @return view of tierdmsgDisplay, if fails return error page
	 * 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddTierdMsg", method = RequestMethod.POST)
	public ModelAndView addNewTierdMsg(@ModelAttribute("addTierdMsgForm")TierdMsgVO tierdmsgVO,final HttpServletRequest request){
		log.warn("Entered TierdMsgController - addNewTierdMsg()");
		ModelAndView mav ;
		Map tierdmsgResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<TierdMsgDTO> tierdmsgDtoList = new LinkedList<TierdMsgDTO>();
		List<TierdMsgVO> tierdmsgVoList = new LinkedList<TierdMsgVO>();
		String securityLevel ="";
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			tierdmsgVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
            String userId =  RteIntranetUtils.getUserId(request); //Ex: n242716 
			tierdmsgVO.setUserId(userId);
			TierdMsgDTO tierdmsgDTO = RTETranslator.toTierdMsgDTO(tierdmsgVO);
			tierdmsgResultMap = facade.addNewTierdmsg(tierdmsgDTO);
			if(tierdmsgResultMap.get("tierdmsgList")!=null){
				tierdmsgDtoList = (List<TierdMsgDTO>) tierdmsgResultMap.get("tierdmsgList");
				tierdmsgVoList = RTETranslator.toTierdMsgVOList(tierdmsgDtoList);
			}
			lookUpListVO.setTierdmsgVOList(tierdmsgVoList);
			facade.getApplicationState().setTierdmsgList(tierdmsgVoList);
			mav = new ModelAndView(TIERDMSG_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("securityLevel", securityLevel);
			mav.addObject("tierdmsgMessage", tierdmsgResultMap.get("tierdmsgMessage"));
			log.warn("addNewTierdMsg - tierdmsgMessage: "+ tierdmsgResultMap.get("tierdmsgMessage"));
			log.warn("Exit from TierdMsgController - addNewTierdMsg()");			
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in TierdMsgController - addNewTierdMsg() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addNewTierdMsg() :"+ApplicationConstants.ERROR_ADD_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to delete the TierdMsg List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of tierdmsgDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteTierdMsg", method = RequestMethod.POST)
	public ModelAndView deleteTierdMsg(final HttpServletRequest request,@ModelAttribute("tierdmsgDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String tierdmsgMsg = "";
		boolean isTierdMsgDeleted = true;
		String securityLevel ="";
		Map tierdmsgResultMap = new HashMap();
		List<TierdMsgVO> tierdmsgList = new LinkedList<TierdMsgVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			tierdmsgList = lookUpListVO.getTierdmsgVOList();
			int i;
			if ((tierdmsgList != null) && (takeAction != null)) {
				for(TierdMsgVO tierdmsgVO : tierdmsgList){
					if(tierdmsgVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						tierdmsgVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					TierdMsgVO existingTierdMsg = (TierdMsgVO) tierdmsgList.get(i);
					if (existingTierdMsg.getUpdatedInd() != ApplicationConstants.COPY) {
						TierdMsgDTO tierdmsgDTO = RTETranslator.toTierdMsgDTO(existingTierdMsg);
						tierdmsgResultMap = facade.deleteTierdMsg(tierdmsgDTO);
						tierdmsgMsg = (String) tierdmsgResultMap.get("tierdmsgMsg");
						isTierdMsgDeleted = (Boolean) tierdmsgResultMap.get("isTierdMsgDeleted");
						
						if(isTierdMsgDeleted == true){
							tierdmsgList.remove(i);
							tierdmsgMsg = "Rows selected were Deleted in the database/list";
						}else{
							j = 0;
						}
					}else{
						tierdmsgList.remove(i);
						tierdmsgMsg = "Rows selected were Deleted in the database/list";
					}				
			}
				if(isTierdMsgDeleted == true)
					tierdmsgMsg = "Rows selected were Deleted in the database/list";
		}else
			tierdmsgMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setTierdmsgList(tierdmsgList);
			lookUpListVO.setTierdmsgVOList(tierdmsgList);
			mav = new ModelAndView(TIERDMSG_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("tierdmsgMessage",tierdmsgMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteTierdMsg - tierdmsgMessage: "+ tierdmsgMsg);
		    log.warn("Exit from TierdMsgController - deleteTierdMsg()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in TierdMsgController - deleteTierdMsg() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteTierdMsg() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to copy the TierdMsg List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of tierdmsgDisplay, if fails return error page
	 */
	@RequestMapping(value="/copyTierdMsg", method = RequestMethod.POST)
	public ModelAndView copyTierdMsg(@ModelAttribute("tierdmsgDisplayForm")LookUpTableListVO lookUpListVO,final HttpServletRequest request, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String tierdmsgMsg = "";
		String securityLevel ="";
		int i;
		List<TierdMsgVO> tierdmsgList = new LinkedList<TierdMsgVO>();
		try{
			//String postedDate =RteIntranetUtils.getPostedDate(); //Initialize Posted Date to today's date
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			String userId =  RteIntranetUtils.getUserId(request); //Ex: n242716 
			tierdmsgList = lookUpListVO.getTierdmsgVOList();
			if ((tierdmsgList != null) && (takeAction != null)) {
				for(TierdMsgVO tierdmsgVO : tierdmsgList){
					if(tierdmsgVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						tierdmsgVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					i = Integer.parseInt(takeAction[j]);
					TierdMsgVO existingTierdmsg = (TierdMsgVO) tierdmsgList.get(i);
					TierdMsgVO copyTierdMsg = new TierdMsgVO(existingTierdmsg.getTierdMsgtypCd() , existingTierdmsg.getTierdTierstCd() , existingTierdmsg.getEffDt() ,
							existingTierdmsg.getExpDt() , existingTierdmsg.getPostedDateTimeStamp() , userId ,
							0,  existingTierdmsg.getMessageTypeCd() , existingTierdmsg.getShortText() ,
							 existingTierdmsg.getFullText(), COPY);
					tierdmsgList.add(copyTierdMsg);
				}
				tierdmsgMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				tierdmsgMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setTierdmsgList(tierdmsgList);
			lookUpListVO.setTierdmsgVOList(tierdmsgList);
			mav = new ModelAndView(TIERDMSG_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("tierdmsgMessage",tierdmsgMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyTierdMsg - tierdmsgMessage: "+ tierdmsgMsg);
		    log.warn("Exit from TierdMsgController - copyTierdMsg()");
			return mav;		
		}catch (Exception e){
			log.error("Exception occured in TierdMsgController - copyTierdMsg() method:"+e.getMessage());
			String errorMsg ="copyTierdMsg() :"+ApplicationConstants.ERROR_COPY_ROW + RteIntranetUtils.getTrimmedString(e.getMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to Add/Update the TierdMsg List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of tierdmsgDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateTierdMsg", method = RequestMethod.POST)
	public ModelAndView addUpdateTierdMsg(final HttpServletRequest request,@ModelAttribute("tierdmsgDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered from TierdMsgController - addUpdateTierdMsg()");
		ModelAndView mav ;
		String tierdmsgMsg = "";
		String securityLevel ="";
		List<TierdMsgVO> updatedTierdMsgList = new LinkedList<TierdMsgVO>();
		List<TierdMsgDTO> updatedTierdMsgDtoList = new LinkedList<TierdMsgDTO>();
		List<TierdMsgVO> tierdmsgVoList = new LinkedList<TierdMsgVO>();
		List<TierdMsgVO> modifiedTierdMsgVoList = new LinkedList<TierdMsgVO>();
		List<TierdMsgDTO> tierdmsgDtoList = new LinkedList<TierdMsgDTO>(); 
		boolean isTierdMsgAddOrUpdated = false;
		Map tierdmsgResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			 tierdmsgVoList = facade.getApplicationState().getTierdmsgList();
			 modifiedTierdMsgVoList = lookUpListVO.getTierdmsgVOList();
			int i;
			if (takeAction != null && takeAction.length != 0) {
				if(tierdmsgVoList != null && tierdmsgVoList.size() != 0 
						&& modifiedTierdMsgVoList.size() != 0 && modifiedTierdMsgVoList != null){
				for(TierdMsgVO tierdmsgVO : tierdmsgVoList){
					if(tierdmsgVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						tierdmsgVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				tierdmsgDtoList = RTETranslator.toTierdMsgDTOList(tierdmsgVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					TierdMsgVO selectedTierdMsg = (TierdMsgVO)tierdmsgVoList.get(i);
					TierdMsgVO editedTierdMsg = (TierdMsgVO) modifiedTierdMsgVoList.get(i);
					TierdMsgVO editedTierdMsgVO = new TierdMsgVO(editedTierdMsg.getTierdMsgtypCd() , editedTierdMsg.getTierdTierstCd() , editedTierdMsg.getEffDt() ,
							editedTierdMsg.getExpDt() , editedTierdMsg.getPostedDateTimeStamp() , editedTierdMsg.getUserId() ,
							editedTierdMsg.getMessageId(),  editedTierdMsg.getMessageTypeCd() , editedTierdMsg.getShortText() ,
							 editedTierdMsg.getFullText(), updatedInd);
					TierdMsgDTO editedTierdMsgDTO = RTETranslator.toTierdMsgDTO(editedTierdMsgVO);
					tierdmsgResultMap = facade.addUpdateTierdMsg(editedTierdMsgDTO, tierdmsgDtoList, i , selectedTierdMsg.getUpdatedInd());
					updatedTierdMsgDtoList = (List<TierdMsgDTO>) tierdmsgResultMap.get("tierdmsgDtoList");
					updatedTierdMsgList = RTETranslator.toTierdMsgVOList(updatedTierdMsgDtoList);
					isTierdMsgAddOrUpdated = (Boolean) tierdmsgResultMap.get("isTierdMsgAddorUpdated") ;
					tierdmsgMsg = (String) tierdmsgResultMap.get("tierdmsgMsg") ;
					if(isTierdMsgAddOrUpdated!= true){
						j = takeAction.length;
					}
				}
				lookUpListVO.setTierdmsgVOList(updatedTierdMsgList);
				facade.getApplicationState().setTierdmsgList(updatedTierdMsgList);
			} else {
				throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	
			}
		}else{
			tierdmsgMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setTierdmsgVOList(tierdmsgVoList);
			facade.getApplicationState().setTierdmsgList(tierdmsgVoList);
		}
			mav = new ModelAndView(TIERDMSG_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("tierdmsgMessage",tierdmsgMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateTierdMsg - tierdmsgMessage: "+ tierdmsgMsg);
		    log.warn("Exit from TierdMsgController - addUpdateTierdMsg()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in TierdMsgController - addUpdateTierdMsg() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addUpdateTierdMsg() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	

	/**
     * Method to export TierdMsg look up table to excel work book
     * 
      * @param lookUpTableListVO
     *            list of tierdmsg object.
     * @param response
     *            response object to return
     * @return exported file to view.
     */
     @RequestMapping(value = "/tierdmsgExport", method = RequestMethod.POST)
     public ModelAndView tierdmsgExport(HttpServletResponse response){
           List<TierdMsgVO> tierdmsgList = new LinkedList<TierdMsgVO>();
           LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
     String tierdmsgMsg="";
           try{
                 tierdmsgList = facade.getApplicationState().getTierdmsgList();
                 if(tierdmsgList != null && tierdmsgList.size() != 0){
                 // Key map to create header
                 Map<String,String> keyMap = new LinkedHashMap<String,String>();
                 keyMap.put("tierdMsgtypCd", "TierMsgType Cd");
                 keyMap.put("tierdTierstCd", "TierMsgTierst Cd");
                 keyMap.put("effDt", "Eff Dt");
                 keyMap.put("expDt", "Exp Dt");
                 keyMap.put("postedDateTimeStamp", "Posted Timestamp");
                 keyMap.put("userId", "User Id");
                 keyMap.put("messageId", "Message Id");
                 keyMap.put("messageTypeCd", "Message Type Cd");
                 keyMap.put("shortText", "Short Provider Text");
                 keyMap.put("fullText", "Long Provider Text");
                 RteIntranetUtils.exportToExcel(response, tierdmsgList, keyMap);
                 tierdmsgMsg = "LookUp table exported successfully.";
                 } else {
                       tierdmsgMsg = "No data found.";
                 }
                 lookUpTableListVO.setTierdmsgVOList(tierdmsgList);
                 mav = new ModelAndView(TIERDMSG_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
                 mav.addObject("tierdmsgMessage",tierdmsgMsg);
                 return mav;
           }catch (ApplicationException e) {
                 log.error("Exception occured in TierdMsgController - tierdmsgExport() method:" + e.getMessage());
                 String errorMsg = "Error encountered while export to excel. ";
                 errorMsg.concat(e.toString());
                 errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
                 errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
                 return errormav;
           }
     }

	
}
