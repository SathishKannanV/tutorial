/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.TierdMsgAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.TierdMsgDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.TierdMsgDisplayAdapter;
import com.aetna.prvrte.rteintranet.dto.TierdMsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Repository
public class TierdMsgDAOImpl implements TierdMsgDAO {
	
	@Autowired(required=true)
	private TierdMsgDisplayAdapter tierdmsgDisplayAdapter;
	
	@Autowired(required=true)
	private TierdMsgAddAdapter tierdmsgAddAdapter;
	
	@Autowired(required=true)
	private TierdMsgDeleteAdapter tierdmsgDeleteAdapter;
	
	@Override
	public Map getTierdMsgLookUpTable(TierdMsgDTO tierdmsgDTO)
			throws ApplicationException {
		
		return tierdmsgDisplayAdapter.getTierdMsgLookUpTable(tierdmsgDTO);
	}

	@Override
	public Map addNewTierdmsg(TierdMsgDTO tierdmsgDTO) throws ApplicationException {
		return tierdmsgAddAdapter.addNewTierdMsg(tierdmsgDTO);
	}

	@Override
	public Map deleteTierdMsg(TierdMsgDTO tierdmsgDTO) throws ApplicationException {
		return tierdmsgDeleteAdapter.deleteTierdMsg(tierdmsgDTO);
	}

	@Override
	public Map addUpdateTierdMsg(TierdMsgDTO editedTierdMsgDTO,
			List<TierdMsgDTO> tierdmsgDtoList, int index,char updateInd)
			throws ApplicationException {
		return tierdmsgAddAdapter.addUpdateTierdMsg( editedTierdMsgDTO, tierdmsgDtoList,  index, updateInd);
	}


}
