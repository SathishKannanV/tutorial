/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class ErspmsgDeleteAdapter extends StoredProcedure {

	public ErspmsgDeleteAdapter() {}

	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(ErspmsgDeleteAdapter.class);
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public ErspmsgDeleteAdapter(DataSource datasource, String storedProc)
			throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of ErspmsgAdapter : " + storedProc);
		//Input parameter declaration
		declareParameter(new SqlParameter(DBConstants.LS_ERSPMSG_ID, Types.INTEGER));
		
		//Output parameter declaration
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
	}
	
	/**
	 * Method to delete the Erspmsg data from data store.
	 * 
	 * @param messageId
	 *           Integer of messageId.
	 * @return Map of flag to delete the data from Erspmsg list and success or
	 *         error message.
	 * @throws ApplicationException
	 *             if deletion fails.
	 */
	public Map<String, Object> deleteErspmsg(int messageId) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering getErspmsgLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, Integer> params = new LinkedHashMap<String, Integer>();
		String erspmsgMsg = "";
		boolean isErspmsgDeleted = false;
		try {
			int id = Integer.valueOf(messageId);
			params.put(DBConstants.LS_ERSPMSG_ID, id);
			
			log.info("Params for getting Erspmsg LookUp List : " + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			if ("0".equals(sqlCode)){
				isErspmsgDeleted = true;
				erspmsgMsg = ApplicationConstants.ROWS_DELETED;
				
			} else {
				erspmsgMsg = ApplicationConstants.DELETE_ROW_FAILS + sqlCode;
				
			}
			resultMap.put("erspmsgsMsg", erspmsgMsg);
			resultMap.put("isErspmsgDeleted", isErspmsgDeleted);
			return resultMap;
			
		} catch (DataAccessException dae) {
			log.error("ErspmsgDisplayAdapter : Data access excpetion occured " + dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("ErspmsgDisplayAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} finally {

		}
	}
}
