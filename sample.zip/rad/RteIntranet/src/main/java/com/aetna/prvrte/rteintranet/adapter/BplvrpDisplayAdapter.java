/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.BplvrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.BplvrpVO;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class BplvrpDisplayAdapter extends StoredProcedure {

	public BplvrpDisplayAdapter() {}

	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(BplvrpDisplayAdapter.class);
	
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	@SuppressWarnings("rawtypes")
	public BplvrpDisplayAdapter(DataSource datasource, String storedProc)
			throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of BplvrpDisplayAdapter : " + storedProc);
		declareParameter(new SqlParameter(DBConstants.LS_BNFT_ID_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));

		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR4, new RowMapper() {
			/*
			 * (non-Javadoc)
			 * 
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet , int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				BplvrpVO bplvrpVO = new BplvrpVO();
				bplvrpVO.setDbBnftIdCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.BNFT_ID_CD)));
				bplvrpVO.setDbPRCRTInd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.BPLVRP_PRCRT_IND)));
				bplvrpVO.setDbProvLinVal(rs.getShort(DBConstants.BPLV_NO));
				bplvrpVO.setDbProvNo(rs.getShort(DBConstants.BPRO_NO));
				bplvrpVO.setDbPRXSTNGInd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.BPLVRP_PRXSTNG_IND)));
				bplvrpVO.setDbRFRLInd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.BPLVRP_RFRL_IND)));
				bplvrpVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
				return bplvrpVO;
			}
		}));
	}
	
	/**
	 * Method to get the Bplvrp list from data store.
	 * 
	 * @param bplvrp
	 *            String of aetna id.
	 * @return Map of Bplvrp list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getBplvrpLookUpList(BplvrpDTO bplvrpDTO) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering getBplvrpLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, String> params = new LinkedHashMap<String, String>();
		List<BplvrpDTO> bplvrpList = new LinkedList<BplvrpDTO>();
		String bplvrpMsg = "";
		try {
			String bnftIdCd = bplvrpDTO.getDbBnftIdCd();
			
			params.put(DBConstants.LS_BNFT_ID_CD, bnftIdCd);
			log.info("Params for getting Bplvrp LookUp List : " + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			if ("0".equals(sqlCode)){
				bplvrpList =  (ArrayList<BplvrpDTO>) results.get(DBConstants.READ_CURSOR4);
				if(bplvrpList.isEmpty()){
					bplvrpMsg = "No Data on database for BPLVRP Code: " + bnftIdCd;
				} else {
					bplvrpMsg = "Data found on database for BPLVRP Code: " + bnftIdCd;
				}
			} else {
				bplvrpMsg = "Problem in DB2. sqlcode: " + sqlCode + " BPLVRP Code: " + bnftIdCd;
			}
			resultMap.put("bplvrpMsg", bplvrpMsg);
			resultMap.put("bplvrpList", bplvrpList);
			return resultMap;
			
		} catch (DataAccessException dae) {
			log.error("BplvrpDisplayAdapter : Data access excpetion occured " + dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("BplvrpDisplayAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} finally {

		}
	}
}
