/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class BenafrqDeleteAdapter extends StoredProcedure {
	
	public BenafrqDeleteAdapter() {}

	/*
	 * Instance of Looger
	 */
	private final Log log = LogFactory.getLog(BenafrqDeleteAdapter.class);
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public BenafrqDeleteAdapter(DataSource datasource, String benafrqStoredProc)
			throws SQLException {
		super(datasource, benafrqStoredProc);
		log.info(" ------------------> " + benafrqStoredProc);
		//InPut Parameters
		declareParameter(new SqlParameter(DBConstants.DEFACUM_ACCUM_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.BENAFRQ_AFREQ_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.RTEBEPLM_BNFT_CD, Types.CHAR));
		
		//Out Parameters
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
	}

	/**
	 * Method to delete the BENAFRQ data from data store.
	 * 
	 * @param defacumAccumCd
	 *            String of default accum data.
	 * @param benafrqAfreqCd
	 *            String of frequency data.
	 * @param hmobBenefitCd
	 *            String of benefit data.
	 * @return Map of flag to delete the data from BENAFRQ list and success or
	 *         error message.
	 * @exception ApplicationException
	 *                if deletion fails.
	 */
	public Map<String, Object> deleteBenafrq(String defacumAccumCd,String  benafrqAfreqCd,String hmobBenefitCd) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering getBenafrqLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		String newMessage = "";
		boolean isBenafrqDeleted = false;
		String sqlCode = "0";
		try {
				params.put(DBConstants.DEFACUM_ACCUM_CD, RteIntranetUtils.getTrimmedString(defacumAccumCd));
				params.put(DBConstants.BENAFRQ_AFREQ_CD, RteIntranetUtils.getTrimmedString(benafrqAfreqCd));
				params.put(DBConstants.RTEBEPLM_BNFT_CD, RteIntranetUtils.getTrimmedString(hmobBenefitCd));
				log.info("Params to put new adavsct : " + params);
				Map<String, Object> results = execute(params);
				sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
				
				if ("0".equals(sqlCode)){
					isBenafrqDeleted = true;
				} else {
					newMessage = ApplicationConstants.DELETE_ROW_FAILS + sqlCode;
				}
					
				resultMap.put("benafrqMsg", newMessage);
				resultMap.put("isBenafrqDeleted", isBenafrqDeleted);
				return resultMap;
		} catch (DataAccessException dae) {
			log.error("BenafrqDeleteAdapter : Data access excpetion occured "
					+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS,
					dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("BenafrqDeleteAdapter : generic error occured  "
					+ exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,
					exception.getMessage(), exception);
		} 
	}
}
