/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.ProcexDAO;
import com.aetna.prvrte.rteintranet.dao.UserDAO;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.RbrcDTO;
import com.aetna.prvrte.rteintranet.dto.RbrcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Service
public class UserServiceImpl implements UserService {
	@Autowired(required=true)
	private UserDAO userDAO;
	
	
	/**
	 * 
	 * @param rbrcDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map getUserLookUpTable(RbrcDTO rbrcDTO)
			throws ApplicationException {
		
		return userDAO.getUserLookUpTable(rbrcDTO);
	}

	/**
	 * 
	 * @param rbrcDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addNewUser(RbrcDTO rbrcDTO) throws ApplicationException {
		return userDAO.addNewUser(rbrcDTO);
	}

	/**
	 * 
	 * @param rbrcDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map deleteUser(RbrcDTO rbrcDTO) throws ApplicationException {
		return userDAO.deleteUser(rbrcDTO);
	}


	/**
	 * @param editedRbrcDTO
	 * @param rbrcDtoList
	 * @param index
	 * @param dbUpdatedInd
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addUpdateUser(RbrcDTO editedRbrcDTO, List<RbrcDTO> rbrcDtoList, int index,char dbUpdatedInd)
			throws ApplicationException {
		return userDAO.addUpdateUser( editedRbrcDTO, rbrcDtoList,  index, dbUpdatedInd);
	}

}
