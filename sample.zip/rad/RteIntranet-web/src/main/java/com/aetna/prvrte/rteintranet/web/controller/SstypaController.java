package com.aetna.prvrte.rteintranet.web.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.aetna.prvrte.rteintranet.dto.SstypaDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.SstypaVO;

/**
 * 
 * The SstypaController is responsible for handling
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * @author N624926
 * Cognizant_Offshore
 */

@Controller
@RequestMapping(value = "/sstypa/*")
public class SstypaController {

	/*
	 * Tile name of the sstypa Home view.
	 */
	public static final String SSTYPA_HOME = ".sstypaHome";
	/*
	 * Tile name of the sstypa Display view.
	 */
	public static final String SSTYPA_LOOKUP = ".sstypaLookUpDisplay";
	/*
	 * Tile name of the Add New sstypa Form view.
	 */
	public static final String SSTYPA_ADD = ".sstypaAdd";
	/*
	 * Constant name used for COPY indicator.
	 */
	public static final char COPY = 'C';

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(SstypaController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errormav;
	
	
	/**
	 * Method to getSstypaLookUpHome view
	 * 
	 * @param model
	 * 
	 * @return view of sstypaLookUp, if fails return error page
	 */
	@RequestMapping(value="/sstypaHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getSstypaLookUpHome(final HttpServletRequest request,Model model) {	   
		log.warn("Entered SstypaController - getSstypaLookUpHome()");
		String securityLevel ="";
		try {
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(SSTYPA_HOME, "sstypaVO",  new SstypaVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("SstypaController - securityLevel: "+ securityLevel);
		log.warn("Exit from SstypaController - getSstypaLookUpHome()");
		return mav;
		} catch (ApplicationException e){
			log.error("Exception occured in SstypaController - getSstypaLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	

	/**
	 * Method to get the sstypaLookUp List from data store.
	 * 
	 * @param sstypaVO
	 *            form view object of sstypa.
	 * @return view of sstypaDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSstypa", method = RequestMethod.POST)
	public ModelAndView getSstypaLookUpTable(HttpServletRequest request,@ModelAttribute("sstypaForm")SstypaVO sstypaVO){
		String securityLevel ="";
		ModelAndView mav ;
		Map sstypaResultMap = new HashMap();
		List<SstypaVO> sstypaList = new LinkedList<SstypaVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			SstypaDTO sstypaDTO = RTETranslator.toSstypaDTO(sstypaVO);
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			sstypaResultMap = facade.getSstypaLookUpTable(sstypaDTO);
			List<SstypaDTO> sstypaDTOList = (List<SstypaDTO>) sstypaResultMap.get("sstypaList");
			sstypaList = (List<SstypaVO>) RTETranslator.toSstypaVOList(sstypaDTOList);
			lookUpListVO.setSstypaVOList(sstypaList);
			facade.getApplicationState().setSstypaList(sstypaList);
			mav = new ModelAndView(SSTYPA_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("sstypaMessage", sstypaResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("getSstypaLookUpTable - sstypaMessage: "+ sstypaResultMap.get("newMessage"));
			log.warn("Exit from SstypaController - getSstypaLookUpTable()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SstypaController - getSstypaLookUpTable() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="getSstypaLookUpTable() :"+ApplicationConstants.ERROR_GET_LOOKUP + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	
	/**
	 * Method to display get add new Sstypa form home view.
	 * 
	 * @return view of loadAddNewSstypaRowScreen, if fails return error page
	 */
	@RequestMapping(value="/AddNewSstypaRow")
	public ModelAndView loadAddNewSstypaRowScreen(final HttpServletRequest request,Model model) {	
		log.warn("Entered SstypaController - loadAddNewSstypaRowScreen()");
		ModelAndView mav = new ModelAndView(SSTYPA_ADD, "sstypaVO",  new SstypaVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in SstypaController - loadAddNewSstypaRowScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		log.warn("Exit from SstypaController - loadAddNewSstypaRowScreen()");
		return mav;
	}
	
	
	/**
	 * Method to add the data database
	 * 
	 * @param sstypaVO form view object of Sstypa.
	 * @return view of sstypaDisplay, if fails return error page
	 * 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddSstypa", method = RequestMethod.POST)
	public ModelAndView addNewSstypa(@ModelAttribute("addSstypaForm")SstypaVO sstypaVO,final HttpServletRequest request){
		log.warn("Entered SstypaController - addNewSstypa()");
		ModelAndView mav ;
		Map sstypaResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<SstypaDTO> sstypaDtoList = new LinkedList<SstypaDTO>();
		List<SstypaVO> sstypaVoList = new LinkedList<SstypaVO>();
		String securityLevel ="";
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			sstypaVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
			SstypaDTO sstypaDTO = RTETranslator.toSstypaDTO(sstypaVO);
			sstypaResultMap = facade.addNewSstypa(sstypaDTO);
			if(sstypaResultMap.get("sstypaList")!=null){
				sstypaDtoList = (List<SstypaDTO>) sstypaResultMap.get("sstypaList");
				sstypaVoList = RTETranslator.toSstypaVOList(sstypaDtoList);
			}
			lookUpListVO.setSstypaVOList(sstypaVoList);
			facade.getApplicationState().setSstypaList(sstypaVoList);
			mav = new ModelAndView(SSTYPA_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("securityLevel", securityLevel);
			mav.addObject("sstypaMessage", sstypaResultMap.get("sstypaMessage"));
			log.warn("addNewSstypa - sstypaMessage: "+ sstypaResultMap.get("sstypaMessage"));
			log.warn("Exit from SstypaController - addNewSstypa()");			
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in SstypaController - addNewSstypa() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addNewSstypa() :"+ApplicationConstants.ERROR_ADD_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to delete the Sstypa List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of sstypaDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteSstypa", method = RequestMethod.POST)
	public ModelAndView deleteSstypa(final HttpServletRequest request,@ModelAttribute("sstypaDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String sstypaMsg = "";
		boolean isSstypaDeleted = true;
		String securityLevel ="";
		Map sstypaResultMap = new HashMap();
		List<SstypaVO> sstypaList = new LinkedList<SstypaVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			sstypaList = lookUpListVO.getSstypaVOList();
			int i;
			if ((sstypaList != null) && (takeAction != null)) {
				for(SstypaVO sstypaVO : sstypaList){
					if(sstypaVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						sstypaVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					SstypaVO editedSstypa = (SstypaVO) sstypaList.get(i);
					if (editedSstypa.getUpdatedInd() != ApplicationConstants.COPY) {
						SstypaDTO sstypaDTO = RTETranslator.toSstypaDTO(editedSstypa);
						sstypaResultMap = facade.deleteSstypa(sstypaDTO);
						sstypaMsg = (String) sstypaResultMap.get("sstypaMsg");
						isSstypaDeleted = (Boolean) sstypaResultMap.get("isSstypaDeleted");
						
						if(isSstypaDeleted == true){
							sstypaList.remove(i);
						}else{
							j = 0;
						}
					}else{
						sstypaList.remove(i);
					}				
			}
				if(isSstypaDeleted == true)
					sstypaMsg = "Rows selected were Deleted in the database/list";
		}else
			sstypaMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSstypaList(sstypaList);
			lookUpListVO.setSstypaVOList(sstypaList);
			mav = new ModelAndView(SSTYPA_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("sstypaMessage",sstypaMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteSstypa - sstypaMessage: "+ sstypaMsg);
		    log.warn("Exit from SstypaController - deleteSstypa()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SstypaController - deleteSstypa() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteSstypa() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	
	/**
	 * Method to copy the Sstypa List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of sstypaDisplay, if fails return error page
	 */
	@RequestMapping(value="/copySstypa", method = RequestMethod.POST)
	public ModelAndView copySstypa(final HttpServletRequest request,@ModelAttribute("sstypaDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String sstypaMsg = "";
		String securityLevel ="";
		int i;
		List<SstypaVO> sstypaList = new LinkedList<SstypaVO>();
		try{
			//String postedDate =RteIntranetUtils.getPostedDate(); //Initialize Posted Date to today's date
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			sstypaList = lookUpListVO.getSstypaVOList();
			if ((sstypaList != null) && (takeAction != null)) {
				for(SstypaVO sstypaVO : sstypaList){
					if(sstypaVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						sstypaVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					i = Integer.parseInt(takeAction[j]);
					SstypaVO existingSstypa = (SstypaVO) sstypaList.get(i);
					SstypaVO copySstypa = new SstypaVO( "0" ,existingSstypa.getCollectionCode() , existingSstypa.getIndividualCode() , existingSstypa.getEffDate() ,
							existingSstypa.getExpDate() , existingSstypa.getPostedDate() , existingSstypa.getVersionReleaseCode() , COPY);
					sstypaList.add(copySstypa);
				}
				sstypaMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				sstypaMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setSstypaList(sstypaList);
			lookUpListVO.setSstypaVOList(sstypaList);
			mav = new ModelAndView(SSTYPA_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("sstypaMessage",sstypaMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copySstypa - sstypaMessage: "+ sstypaMsg);
		    log.warn("Exit from SstypaController - copySstypa()");
			return mav;		
		}catch (Exception e){
			log.error("Exception occured in SstypaController - copySstypa() method:"+e.getMessage());
			String errorMsg ="copySstypa() :"+ApplicationConstants.ERROR_COPY_ROW + RteIntranetUtils.getTrimmedString(e.getMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to Add/Update the Sstypa List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of sstypaDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateSstypa", method = RequestMethod.POST)
	public ModelAndView addUpdateSstypa(final HttpServletRequest request,@ModelAttribute("sstypaDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered from SstypaController - addUpdateSstypa()");
		ModelAndView mav ;
		String sstypaMsg = "";
		String securityLevel ="";
		List<SstypaVO> updatedSstypaList = facade.getApplicationState().getSstypaList();
		List<SstypaDTO> updatedSstypaDtoList = new LinkedList<SstypaDTO>();
		List<SstypaVO> sstypaVoList = new LinkedList<SstypaVO>();
		List<SstypaVO> modifiedSstypaVoList = new LinkedList<SstypaVO>();
		List<SstypaDTO> sstypaDtoList = new LinkedList<SstypaDTO>(); 
		boolean isSstypaAddOrUpdated = false;
		Map sstypaResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			sstypaVoList = facade.getApplicationState().getSstypaList();
			modifiedSstypaVoList = lookUpListVO.getSstypaVOList();
			int i;
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString();
			if (takeAction != null && takeAction.length != 0) {
				if(sstypaVoList != null && sstypaVoList.size() != 0 
						&& modifiedSstypaVoList.size() != 0 && modifiedSstypaVoList != null){
				for(SstypaVO sstypaVO : sstypaVoList){
					if(sstypaVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						sstypaVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				sstypaDtoList = RTETranslator.toSstypaDTOList(sstypaVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					SstypaVO selectedSstypa = (SstypaVO)sstypaVoList.get(i);
					SstypaVO editedSstypa = (SstypaVO) modifiedSstypaVoList.get(i);
					SstypaVO editedSstypaVO = new SstypaVO(  editedSstypa.getId() ,editedSstypa.getCollectionCode() , editedSstypa.getIndividualCode() , editedSstypa.getEffDate() ,
							editedSstypa.getExpDate() ,postedDate , editedSstypa.getVersionReleaseCode() , updatedInd);
					SstypaDTO editedSstypaDTO = RTETranslator.toSstypaDTO(editedSstypaVO);
					sstypaResultMap = facade.addUpdateSstypa(editedSstypaDTO, sstypaDtoList, i , selectedSstypa.getUpdatedInd());
					updatedSstypaDtoList = (List<SstypaDTO>) sstypaResultMap.get("sstypaDtoList");
					updatedSstypaList = RTETranslator.toSstypaVOList(updatedSstypaDtoList);
					isSstypaAddOrUpdated = (Boolean) sstypaResultMap.get("isSstypaAddorUpdated")  ;
					sstypaMsg = (String) sstypaResultMap.get("sstypaMsg") ;
					if(isSstypaAddOrUpdated!= true){
						j = takeAction.length;
					}
				}
				lookUpListVO.setSstypaVOList(updatedSstypaList);
				facade.getApplicationState().setSstypaList(updatedSstypaList);
			} else {
				throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	
			}
		}else{
			sstypaMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setSstypaVOList(sstypaVoList);
			facade.getApplicationState().setSstypaList(sstypaVoList);
		}
			mav = new ModelAndView(SSTYPA_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("sstypaMessage",sstypaMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateSstypa - sstypaMessage: "+ sstypaMsg);
		    log.warn("Exit from SstypaController - addUpdateSstypa()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in SstypaController - addUpdateSstypa() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addUpdateSstypa() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	

	/**
      * Method to export Sstypa look up table to excel work book
      * 
       * @param lookUpTableListVO
      *            list of sstypa object.
      * @param response
      *            response object to return
      * @return exported file to view.
      */
      @RequestMapping(value = "/sstypaExport", method = RequestMethod.POST)
      public ModelAndView sstypaExport(HttpServletResponse response){
            List<SstypaVO> sstypaList = new LinkedList<SstypaVO>();
            LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
            String sstypaMsg="";
            try{
                  sstypaList = facade.getApplicationState().getSstypaList();
                  if(sstypaList != null && sstypaList.size() != 0){
                  // Key map to create header
                  Map<String,String> keyMap = new LinkedHashMap<String,String>();
                  keyMap.put("collectionCode", "Collection Code");
                  keyMap.put("individualCode", "Individual CD");
                  keyMap.put("versionReleaseCode", "Version Release Code");
                  keyMap.put("effDate", "Effective Date");
                  keyMap.put("expDate", "Expiration Date");
                  keyMap.put("postedDate", "Posted Date");
                  keyMap.put("id", "Id");
                  RteIntranetUtils.exportToExcel(response, sstypaList, keyMap);
                  sstypaMsg = "LookUp table exported successfully.";
                  } else {
                        sstypaMsg = "No data found.";
                  }
                  lookUpTableListVO.setSstypaVOList(sstypaList);
                  mav = new ModelAndView(SSTYPA_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
                  mav.addObject("sstypaMessage",sstypaMsg);
                  return mav;
            }catch (ApplicationException e) {
                  log.error("Exception occured in SstypaController - sstypaExport() method:" + e.getMessage());
                  String errorMsg = "Error encountered while export to excel. ";
                  errorMsg.concat(e.toString());
                  errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
                  errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
                  return errormav;
            }
      }


}
