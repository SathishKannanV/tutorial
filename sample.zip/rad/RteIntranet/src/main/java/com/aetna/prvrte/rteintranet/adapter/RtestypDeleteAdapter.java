/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RtestypDeleteAdapter extends StoredProcedure{

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RtestypDeleteAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtestypDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		declareParameter(new SqlParameter(DBConstants.LS_SVCTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_EFF_DATE, Types.DATE));
		
		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));
		
	}
	
	@SuppressWarnings("unchecked")
	public Map deleteRtestyp(String svcTypeCd, String effDate) throws ApplicationException {
		
		log.warn("Entered RtestypDeleteAdapter  - deleteRtestyp");
		boolean isRtestypDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map rtestypMap = new HashMap();
			
		params.put(DBConstants.LS_SVCTYP_CD, RteIntranetUtils.getTrimmedString(svcTypeCd));
		params.put(DBConstants.IN_EFF_DATE, RteIntranetUtils.getTrimmedString(effDate));
		
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("RtestypDeleteAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_CODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) 
				isRtestypDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			rtestypMap.put("rtestypMessage", newMessage);
			rtestypMap.put("isRtestypDeleted", isRtestypDeleted);
			return rtestypMap;
		}catch (Exception exception){
			
			log.error("RtestypDeleteAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
}
