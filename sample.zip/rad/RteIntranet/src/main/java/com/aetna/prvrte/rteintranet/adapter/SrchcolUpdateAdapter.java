package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.SrchcolDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


/**
 * @author N731694
 * Cognizant_Offshore
 */
public class SrchcolUpdateAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(SrchcolUpdateAdapter.class);
	
	private static final String LS_SRCHCOL_CD = "LS_SRCHCOL_CD";
	private static final String LS_SRCHCOL_EFF_DT = "LS_SRCHCOL_EFF_DT";
	private static final String LS_SRCHCOL_DESC = "LS_SRCHCOL_DESC";
	private static final String LS_SRCHCOL_EXP_DT = "LS_SRCHCOL_EXP_DT";
	private static final String LS_SRCHCOL_POSTED_DT = "LS_SRCHCOL_POSTED_DT";
	
	private static final String LS_ADD_UPDATE = "LS_ADD_UPDATE";
	private static final String LS_SQLCODE = "LS_SQLCODE";
	private static final String READ_CURSOR = "READ_CURSOR3";
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public SrchcolUpdateAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(LS_SRCHCOL_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_SRCHCOL_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(LS_SRCHCOL_DESC, Types.CHAR));
		declareParameter(new SqlParameter(LS_SRCHCOL_EXP_DT, Types.DATE));
		declareParameter(new SqlParameter(LS_SRCHCOL_POSTED_DT, Types.DATE));
	
		declareParameter(new SqlOutParameter(LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(LS_SQLCODE, Types.INTEGER));
	}
	
	
	

	
	@SuppressWarnings("unchecked")
	public Map addUpdateSrchcol(SrchcolDTO existingSrchcol,
			List<SrchcolDTO> srchcolDtoList, int index,char updateInd) throws ApplicationException{
		log.debug("Entered SrchcolupateAdapter  - addUpdateSrchcol");
		boolean isSrchcolAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map srchcolMap = new HashMap();
		Date todaysDate = new Date(System.currentTimeMillis());
		String postedDate = todaysDate.toString();
		existingSrchcol.setPostedDate(postedDate);

		params.put(LS_SRCHCOL_CD, RteIntranetUtils.getTrimmedString(existingSrchcol.getSrchcolCd()));
		params.put(LS_SRCHCOL_EFF_DT, RteIntranetUtils.getTrimmedString(existingSrchcol.getEffDate()));
		params.put(LS_SRCHCOL_DESC, RteIntranetUtils.getTrimmedString(existingSrchcol.getSrchcolDesc()));
		params.put(LS_SRCHCOL_EXP_DT, RteIntranetUtils.getTrimmedString(existingSrchcol.getExpDate()));
		params.put(LS_SRCHCOL_POSTED_DT, RteIntranetUtils.getTrimmedString(existingSrchcol.getPostedDate()));
		
		log.debug(params);	
		
		try {
					
			results = execute(params);
			log.debug("SrchcolUpdateAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(LS_SQLCODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
							isSrchcolAddorUpdated = true;
						//	existingSrchcol.setSrchcolCd((actionCode));
							srchcolDtoList.set(index, existingSrchcol);	
				
				newMessage = "All rows that changed the database are highlighted.";
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			srchcolMap.put("srchcolMsg",newMessage);
			srchcolMap.put("srchcolDtoList",srchcolDtoList);
			srchcolMap.put("isSrchcolAddorUpdated", isSrchcolAddorUpdated);
			return srchcolMap;
		}catch (Exception exception){
			log.error("Srchcol Update Adapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
}