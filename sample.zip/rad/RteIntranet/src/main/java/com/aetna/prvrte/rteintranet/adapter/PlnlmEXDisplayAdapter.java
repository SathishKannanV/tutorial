/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.PlnlmEXDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.PlnlmEXVO;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class PlnlmEXDisplayAdapter extends StoredProcedure {

	public PlnlmEXDisplayAdapter() {}

	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(PlnlmEXDisplayAdapter.class);
	
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	@SuppressWarnings("rawtypes")
	public PlnlmEXDisplayAdapter(DataSource datasource, String storedProc) throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of PlnlmEXAdapter : " + storedProc);
		//Input Params declaration
		declareParameter(new SqlParameter(DBConstants.PLNLMEX_EXPLNT_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.PLNLMEX_QLFR_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.PLNLMEX_RSPNSTP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.PLNLMEX_EPLC_CD, Types.CHAR));
		
		
		//Output Params declaration
		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));

		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR4, new RowMapper() {
			/*
			 * (non-Javadoc)
			 * 
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet , int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1) throws SQLException {
			PlnlmEXVO plnlmEXVO = new PlnlmEXVO();
			plnlmEXVO.setDbEligPerLmtCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.PLNLMEX_EPLC_CD)));
			plnlmEXVO.setDbExplntCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.PLNLMEX_EXPLNT_CD)));
			plnlmEXVO.setDbFdbInd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.PLNLMEX_FDB_IND)));
			plnlmEXVO.setDbPlnLvlInd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.PLNLMEX_PLNLVL_IND)));
			plnlmEXVO.setDbQlfrCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.PLNLMEX_QLFR_CD)));
			plnlmEXVO.setDbRspnstpCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.PLNLMEX_RSPNSTP_CD)));
			plnlmEXVO.setDbRspnstpTxt(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.PLNLMEX_RSPNS_TXT)));
			plnlmEXVO.setDbTxtSndCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.PLNLMEX_TXT_SND_CD)));
			plnlmEXVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);//Used by PlnlmEXDisplay, not on database
			return plnlmEXVO;
			}
		}));
	}
	
	/**
	 * Method to get the PlnlmEX list from data store.
	 * 
	 * @param plnlmEX
	 *            String of aetna id.
	 * @return Map of PlnlmEX list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getPlnlmEXLookUpList(PlnlmEXDTO plnlmEXDTO) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering getPlnlmEXLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<PlnlmEXDTO> plnlmEXList = new LinkedList<PlnlmEXDTO>();
		String plnlmEXMsg = "";
		try {
			
			String dbExplntCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbExplntCd());
			String dbQlfrCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbQlfrCd());
			String dbRspnstpCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbRspnstpCd());
			String dbEligPerLmtCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbEligPerLmtCd());
			
			//Query Param
			params.put(DBConstants.PLNLMEX_EXPLNT_CD, dbExplntCd);
			params.put(DBConstants.PLNLMEX_QLFR_CD, dbQlfrCd);
			params.put(DBConstants.PLNLMEX_RSPNSTP_CD, dbRspnstpCd);
			params.put(DBConstants.PLNLMEX_EPLC_CD, dbEligPerLmtCd);
			
			log.info("Params for getting PlnlmEX LookUp List : " + params);
			
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.OUT_CODE));
			if ("0".equals(sqlCode)){
				plnlmEXList =  (ArrayList<PlnlmEXDTO>) results.get(DBConstants.READ_CURSOR4);
				int noOfElements = plnlmEXList.size(); 
				if (plnlmEXList.isEmpty()){
					plnlmEXMsg = "No Data for ";
					plnlmEXMsg = getMessage(plnlmEXMsg, dbExplntCd, dbQlfrCd, dbRspnstpCd, dbEligPerLmtCd);
				}else {
					if (noOfElements > 1) { 
				    	plnlmEXMsg = noOfElements + " Rows found for ";
					} else {
				    plnlmEXMsg = noOfElements + " Row found for ";
					}
					plnlmEXMsg = getMessage(plnlmEXMsg, dbExplntCd, dbQlfrCd, dbRspnstpCd, dbEligPerLmtCd);
				}
			} else {
				plnlmEXMsg = "Problem in DB2. sqlcode: " + sqlCode; 
				plnlmEXMsg = getMessage(plnlmEXMsg, dbExplntCd, dbQlfrCd, dbRspnstpCd, dbEligPerLmtCd);
			}	
			
			resultMap.put("plnlmEXMsg", plnlmEXMsg);
			resultMap.put("plnlmEXList", plnlmEXList);
			return resultMap;
			
		} catch (DataAccessException dae) {
			log.error("PlnlmEXDisplayAdapter : Data access excpetion occured " + dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("PlnlmEXDisplayAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
	}

	public String getMessage(String newMessage, String queryBnftIdCd,
			String querySvcTypeCd, String queryExplntCd,
			String queryEligPerLmtCd) {
		String getMessage = newMessage;
		if (!queryBnftIdCd.equals(""))
			getMessage = getMessage + " Benefit Id : " + queryBnftIdCd;
		if (!querySvcTypeCd.equals(""))
			getMessage = getMessage + " Service Type : " + querySvcTypeCd;
		if (!queryExplntCd.equals(""))
			getMessage = getMessage + " PlnlmEX Code : " + queryExplntCd;
		if (!queryEligPerLmtCd.equals(""))
			getMessage = getMessage + " Elig Per Limit CD: "
					+ queryEligPerLmtCd;
		return getMessage;
}	
}
