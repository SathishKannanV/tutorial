/**

 * 

 */

package com.aetna.prvrte.rteintranet.dao;



import java.util.List;

import java.util.Map;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;



import com.aetna.prvrte.rteintranet.adapter.HrpRuleAddAdapter;

import com.aetna.prvrte.rteintranet.adapter.HrpRuleDeleteAdapter;

import com.aetna.prvrte.rteintranet.adapter.HrpRuleDisplayAdapter;

import com.aetna.prvrte.rteintranet.dto.HrpRuleDTO;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;



/**

 * @author N624926

 * Cognizant_Offshore

 */

@Repository

public class HrpRuleDAOImpl implements HrpRuleDAO {

	

	@Autowired(required=true)

	private HrpRuleDisplayAdapter hrpruleDisplayAdapter;

	

	@Autowired(required=true)

	private HrpRuleAddAdapter hrpruleAddAdapter;

	

	@Autowired(required=true)

	private HrpRuleDeleteAdapter hrpruleDeleteAdapter;

	

	@Override

	public Map getHrpRuleLookUpTable(HrpRuleDTO hrpruleDTO)

			throws ApplicationException {

		

		return hrpruleDisplayAdapter.getHrpRuleLookUpTable(hrpruleDTO);

	}



	@Override

	public Map addNewHrprule(HrpRuleDTO hrpruleDTO) throws ApplicationException {

		return hrpruleAddAdapter.addNewHrpRule(hrpruleDTO);

	}



	@Override

	public Map deleteHrpRule(HrpRuleDTO hrpruleDTO) throws ApplicationException {

		return hrpruleDeleteAdapter.deleteHrpRule(hrpruleDTO);

	}



	@Override

	public Map addUpdateHrpRule(HrpRuleDTO editedHrpRuleDTO,

			List<HrpRuleDTO> hrpruleDtoList, int index,char updateInd)

			throws ApplicationException {

		return hrpruleAddAdapter.addUpdateHrpRule( editedHrpRuleDTO, hrpruleDtoList,  index, updateInd);

	}





}

