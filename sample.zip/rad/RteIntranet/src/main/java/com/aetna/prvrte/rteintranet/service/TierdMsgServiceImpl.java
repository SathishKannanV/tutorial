/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.TierdMsgDAO;
import com.aetna.prvrte.rteintranet.dto.TierdMsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Service
public class TierdMsgServiceImpl implements TierdMsgService {
	@Autowired(required=true)
	private TierdMsgDAO tierdmsgDAO;
	
	
	/**
	 * 
	 * @param tierdmsgDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map getTierdMsgLookUpTable(TierdMsgDTO tierdmsgDTO)
			throws ApplicationException {
		
		return tierdmsgDAO.getTierdMsgLookUpTable(tierdmsgDTO);
	}

	/**
	 * 
	 * @param tierdmsgDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addNewTierdmsg(TierdMsgDTO tierdmsgDTO) throws ApplicationException {
		return tierdmsgDAO.addNewTierdmsg(tierdmsgDTO);
	}

	/**
	 * 
	 * @param tierdmsgDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map deleteTierdMsg(TierdMsgDTO tierdmsgDTO) throws ApplicationException {
		return tierdmsgDAO.deleteTierdMsg(tierdmsgDTO);
	}

	/**
	 * 
	 * @param editedTierdMsgDTO
	 * @param tierdmsgDtoList
	 * @param index
	 * @param  updateInd
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addUpdateTierdMsg(TierdMsgDTO editedTierdMsgDTO,
			List<TierdMsgDTO> tierdmsgDtoList, int index,char updateInd)
			throws ApplicationException {
		return tierdmsgDAO.addUpdateTierdMsg( editedTierdMsgDTO,tierdmsgDtoList, index, updateInd);
	}

}
