/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.SbmletkVO;

/**
 * @author N731694
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/sbmletk/*")
public class SbmletkController {

	public static final String SBMLETK_HOME = ".sbmletkHome";
	public static final String SBMLETK_LOOKUP = ".sbmletkLookUpDisplay";
	

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(SbmletkController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;
	
	@RequestMapping(value="/sbmletkHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getSbmletkLookUpHome(final HttpServletRequest request,Model model) {	
		log.debug("Entered SbmletkController - getSbmletkLookUpHome()");
		String securityLevel ="";
		try {
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		
		ModelAndView mav = new ModelAndView(SBMLETK_HOME, "SbmletkVO",  new SbmletkVO());
		mav.addObject("securityLevel", securityLevel);
		log.debug("Exit from BplvsController - getBplvsLookUpHome( )");
		return mav;
		}
		catch (ApplicationException e){
			log.error("Exception occured in SbmletkController - getSbmletkLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (sbmletkHome). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherSbmletk", method = RequestMethod.POST)
	public ModelAndView getSbmletkLookUpTable(final HttpServletRequest request,@ModelAttribute("sbmletkForm")SbmletkVO sbmletkVO){
		log.debug("Entered SbmletkController - getSbmletkLookUpTable()");
		String convIdCode ="";
		String vanIdCd ="";
		String tranType ="";
		String postedDt ="";
		String seconds ="";
		String securityLevel ="";
		
		ModelAndView mav ;
		Map sbmletkResultMap = new HashMap();
		List<SbmletkVO> sbmletkList = new LinkedList<SbmletkVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			convIdCode = sbmletkVO.getConvIdCode();
			vanIdCd =sbmletkVO.getVanIdCd();
			tranType=sbmletkVO.getTranType();
			postedDt=sbmletkVO.getPostedDt();
		    seconds = sbmletkVO.getSeconds();
		    sbmletkResultMap = facade.getSbmletkLookUpTable(convIdCode, vanIdCd,tranType,postedDt,seconds);
		
			sbmletkList = (List<SbmletkVO>) sbmletkResultMap.get("sbmletkList");
		    lookUpListVO.setSbmletkVOList(sbmletkList);
		
			facade.getApplicationState().setSbmletkList(sbmletkList);
			mav = new ModelAndView(SBMLETK_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("sbmletkMessage", sbmletkResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.debug("getSbmletkLookUpTable - sbmletkMessage: "+ sbmletkResultMap.get("newMessage"));
			log.debug("Exit from SbmletkController - getSbmletkLookUpTable()");
			return mav;
		  }
		catch (Exception e)
		{
			log.error("Exception occured in SbmletkController - getSbmletkLookUpTable() method:"+e.getMessage());			
			String errorMsg ="Error encountered when extracting data from the database (GatherSbmletk). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	
}
