package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;
import java.util.ArrayList;

public class SrapidtlVO implements  Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String coverageTypeCd = new String();
	private String programName = new String();
	private String ebsBenefitData = new String();
	private String convIdCode ="";
	private String vanIdCd = "";
	private String typeCd = "";
	private String postedDt = "";
	private String tranType ="";
	private String seqNo;
	private String controlNo;
	private String benefitIdCd = new String();
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	private String pbnfSeqNo;
	private String planNo;
	private String planSummaryCd = new String();
	private String planName = new String();
	private String apisrtName = new String();
	private String count = "";
	
	private ArrayList dbEbsBenefitData = new ArrayList();
	public ArrayList getDbEbsBenefitData() {
		return dbEbsBenefitData;
	}
	public void setDbEbsBenefitData(ArrayList dbEbsBenefitData) {
		this.dbEbsBenefitData = dbEbsBenefitData;
	}
	public SrapidtlVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SrapidtlVO(String coverageTypeCd, String programName,
			String ebsBenefitData, String convIdCode, String vanIdCd,
			String typeCd, String postedDt, String tranType, String seqNo,
			String controlNo, String benefitIdCd, String pbnfSeqNo, String planNo,
			String planSummaryCd, String planName, String apisrtName) {
		super();
		this.coverageTypeCd = coverageTypeCd;
		this.programName = programName;
		this.ebsBenefitData = ebsBenefitData;
		this.convIdCode = convIdCode;
		this.vanIdCd = vanIdCd;
		this.typeCd = typeCd;
		this.postedDt = postedDt;
		this.tranType = tranType;
		this.seqNo = seqNo;
		this.controlNo = controlNo;
		this.benefitIdCd = benefitIdCd;
		this.pbnfSeqNo = pbnfSeqNo;
		this.planNo = planNo;
		this.planSummaryCd = planSummaryCd;
		this.planName = planName;
		this.apisrtName = apisrtName;
	}
	public String getCoverageTypeCd() {
		return coverageTypeCd;
	}
	public void setCoverageTypeCd(String coverageTypeCd) {
		this.coverageTypeCd = coverageTypeCd;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getEbsBenefitData() {
		return ebsBenefitData;
	}
	public void setEbsBenefitData(String ebsBenefitData) {
		this.ebsBenefitData = ebsBenefitData;
	}
	public String getConvIdCode() {
		return convIdCode;
	}
	public void setConvIdCode(String convIdCode) {
		this.convIdCode = convIdCode;
	}
	public String getVanIdCd() {
		return vanIdCd;
	}
	public void setVanIdCd(String vanIdCd) {
		this.vanIdCd = vanIdCd;
	}
	public String getTypeCd() {
		return typeCd;
	}
	public void setTypeCd(String typeCd) {
		this.typeCd = typeCd;
	}
	public String getPostedDt() {
		return postedDt;
	}
	public void setPostedDt(String postedDt) {
		this.postedDt = postedDt;
	}
	public String getTranType() {
		return tranType;
	}
	public void setTranType(String tranType) {
		this.tranType = tranType;
	}
	
	public String getPlanSummaryCd() {
		return planSummaryCd;
	}
	public void setPlanSummaryCd(String planSummaryCd) {
		this.planSummaryCd = planSummaryCd;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getApisrtName() {
		return apisrtName;
	}
	public void setApisrtName(String apisrtName) {
		this.apisrtName = apisrtName;
	}
	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public String getControlNo() {
		return controlNo;
	}
	public void setControlNo(String controlNo) {
		this.controlNo = controlNo;
	}
	public String getBenefitIdCd() {
		return benefitIdCd;
	}
	public void setBenefitIdCd(String benefitIdCd) {
		this.benefitIdCd = benefitIdCd;
	}
	public String getPbnfSeqNo() {
		return pbnfSeqNo;
	}
	public void setPbnfSeqNo(String pbnfSeqNo) {
		this.pbnfSeqNo = pbnfSeqNo;
	}
	public String getPlanNo() {
		return planNo;
	}
	public void setPlanNo(String planNo) {
		this.planNo = planNo;
	}
	

}
