package com.aetna.prvrte.rteintranet.web.controller;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.aetna.prvrte.rteintranet.dto.TOSDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.TOSVO;
import com.aetna.prvrte.rteintranet.vo.UserVO;

/**
 * 
 * The TOS Controller is responsible for handling
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * @author N624926
 * Cognizant_Offshore
 */

@Controller
@RequestMapping(value = "/tostext/*")
public class TOSController {


	/*
	 * Tile name of the tos Home view.
	 */
	public static final String TOS_HOME = ".tosHome";
	/*
	 * Tile name of the tos Display view.
	 */
	public static final String TOS_LOOKUP = ".tosLookUpDisplay";
	/*
	 * Tile name of the Add New tos Form view.
	 */
	public static final String TOS_ADD = ".tosAdd";
	/*
	 * Constant name used for COPY indicator.
	 */
	public static final char COPY = 'C';

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(TOSController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errormav;
	
	/**
	 * Method to getTOSLookUpHome view
	 * 
	 * @param model
	 * 
	 * @return view of tosLookUp, if fails return error page
	 */
	@RequestMapping(value="/tosHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getTOSLookUpHome(final HttpServletRequest request,Model model) {	
		log.warn("Entered TOSController - getTOSLookUpHome()");
		String securityLevel ="";
		try {
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(TOS_HOME, "tosVO",  new TOSVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("TOSController - securityLevel: "+ securityLevel);
		log.warn("Exit from TOSController - getTOSLookUpHome()");
		return mav;
		} catch (ApplicationException e){
			log.error("Exception occured in TOSController - getTOSLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	/**
	 * Method to get the tosLookUp List from data store.
	 * 
	 * @param tosVO
	 *            form view object of tos.
	 * @return view of tosDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherTOS", method = RequestMethod.POST)
	public ModelAndView getTOSLookUpTable(HttpServletRequest request,@ModelAttribute("tosForm")TOSVO tosVO){
		log.warn("Entered TOSController - getTOSLookUpTable()");
		String securityLevel ="";
		ModelAndView mav ;
		Map tosResultMap = new HashMap();
		List<TOSVO> tosList = new LinkedList<TOSVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			TOSDTO tosDTO = RTETranslator.toTOSDTO(tosVO);
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			tosResultMap = facade.getTOSLookUpTable(tosDTO);
			tosList = (List<TOSVO>) tosResultMap.get("tosList");
			lookUpListVO.setTosVOList(tosList);
			facade.getApplicationState().setTosList(tosList);
			mav = new ModelAndView(TOS_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("tosMessage", tosResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("getTOSLookUpTable - tosMessage: "+ tosResultMap.get("newMessage"));
			log.warn("Exit from TOSController - getTOSLookUpTable()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in TOSController - getTOSLookUpTable() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="getTOSLookUpTable() :"+ApplicationConstants.ERROR_GET_LOOKUP + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to display get add new TOS form home view.
	 * 
	 * @return view of loadAddNewTOSRowScreen, if fails return error page
	 */
	@RequestMapping(value="/AddNewTOSRow")
	public ModelAndView loadAddNewTOSRowScreen(final HttpServletRequest request,Model model) {	
		log.warn("Entered TOSController - loadAddNewTOSRowScreen()");
		ModelAndView mav = new ModelAndView(TOS_ADD, "tosVO",  new TOSVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in TOSController - loadAddNewTOSRowScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (loadAddNewTOSRowScreen). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		log.warn("Exit from TOSController - loadAddNewTOSRowScreen()");
		return mav;
	}
	
	
	/**
	 * Method to add the data database
	 * 
	 * @param tosVO form view object of TOS.
	 * @param request request object for TOS to get userVO
	 * @return view of tosDisplay, if fails return error page
	 * 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddTOS", method = RequestMethod.POST)
	public ModelAndView addNewTOS(@ModelAttribute("addTOSForm")TOSVO tosVO,final  HttpServletRequest request){
		log.warn("Entered TOSController - addNewTOS()");
		ModelAndView mav ;
		Map tosResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<TOSDTO> tosDtoList = new LinkedList<TOSDTO>();
		List<TOSVO> tosVoList = new LinkedList<TOSVO>();
		String securityLevel ="";
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			tosVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
            String userId = RteIntranetUtils.getUserId(request); //Ex: n242716 
			tosVO.setDbUserId(userId);
			TOSDTO tosDTO = RTETranslator.toTOSDTO(tosVO);
			tosResultMap = facade.addNewTOS(tosDTO);
			if(tosResultMap.get("tosList")!=null){
				tosDtoList = (List<TOSDTO>) tosResultMap.get("tosList");
				tosVoList = RTETranslator.toTOSVOList(tosDtoList);
			}
			lookUpListVO.setTosVOList(tosVoList);
			facade.getApplicationState().setTosList(tosVoList);
			mav = new ModelAndView(TOS_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("securityLevel", securityLevel);
			mav.addObject("tosMessage", tosResultMap.get("tosMessage"));
			log.warn("addNewTOS - tosMessage: "+ tosResultMap.get("tosMessage"));
			log.warn("Exit from TOSController - addNewTOS()");			
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in TOSController - addNewTOS() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addNewTOS() :"+ApplicationConstants.ERROR_ADD_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	
	/**
	 * Method to delete the TOS List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of tosDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteTOS", method = RequestMethod.POST)
	public ModelAndView deleteTOS(final HttpServletRequest request,@ModelAttribute("tosDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered TOSController - deleteTOS()");
		ModelAndView mav ;
		String tosMsg = "";
		boolean isTOSDeleted = true;
		String securityLevel ="";
		Map tosResultMap = new HashMap();
		List<TOSVO> tosList = new LinkedList<TOSVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			tosList = lookUpListVO.getTosVOList();
			int i;
			if ((tosList != null) && (takeAction != null)) {
				for(TOSVO tosVO : tosList){
					if(tosVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						tosVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					TOSVO existingTOS = (TOSVO) tosList.get(i);
					if (existingTOS.getDbUpdatedInd() != ApplicationConstants.COPY) {
						TOSDTO tosDTO = RTETranslator.toTOSDTO(existingTOS);
						tosResultMap = facade.deleteTOS(tosDTO);
						tosMsg = (String) tosResultMap.get("tosMsg");
						isTOSDeleted = (Boolean) tosResultMap.get("isTOSDeleted");
						if(isTOSDeleted == true){
							tosList.remove(i);
						}else{
							j = 0;
						}
					}else{
						tosList.remove(i);
					}				
			}
				if(isTOSDeleted == true)
					tosMsg = "Rows selected were Deleted in the database/list";
		}else
			tosMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setTosList(tosList);
			lookUpListVO.setTosVOList(tosList);
			mav = new ModelAndView(TOS_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("tosMessage",tosMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteTOS - tosMessage: "+ tosMsg);
		    log.warn("Exit from TOSController - deleteTOS()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in TOSController - deleteTOS() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteTOS() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	
	/**
	 * Method to copy the TOS List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of tosDisplay, if fails return error page
	 */
	@RequestMapping(value="/copyTOS", method = RequestMethod.POST)
	public ModelAndView copyTOS(final HttpServletRequest request,@ModelAttribute("tosDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered from TOSController - copyTOS()");
		ModelAndView mav ;
		String tosMsg = "";
		String securityLevel ="";
		int i;
		List<TOSVO> tosList = new LinkedList<TOSVO>();
		try{
			//String postedDate =RteIntranetUtils.getPostedDate(); //Initialize Posted Date to today's date
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			tosList = lookUpListVO.getTosVOList();
			if ((tosList != null) && (takeAction != null)) {
				for(TOSVO tosVO : tosList){
					if(tosVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						tosVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					i = Integer.parseInt(takeAction[j]);
					TOSVO existingTOS = (TOSVO) tosList.get(i);
					
					TOSVO copyTOS = new TOSVO(existingTOS.getDbTosCd(), existingTOS.getDbEffDate() , existingTOS.getDbExpDate() , existingTOS.getDbStatusCd() ,
							existingTOS.getDbApprovalCd() , existingTOS.getDbDisplayName() , existingTOS.getDbShortName() , existingTOS.getDbTosName() ,
							existingTOS.getDbPostedDate(), existingTOS.getDbLastUpdtDate(), existingTOS.getDbUserId() , existingTOS.getDbTosComments() ,
							 existingTOS.getDbUpdateReason() , ApplicationConstants.COPY);
					tosList.add(copyTOS);
				}
				tosMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				tosMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setTosList(tosList);
			lookUpListVO.setTosVOList(tosList);
			mav = new ModelAndView(TOS_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("tosMessage",tosMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyTOS - tosMessage: "+ tosMsg);
		    log.warn("Exit from TOSController - copyTOS()");
			return mav;		
		}catch (Exception e){
			log.error("Exception occured in TOSController - copyTOS() method:"+e.getMessage());
			String errorMsg ="copyTOS() :"+ApplicationConstants.ERROR_COPY_ROW + RteIntranetUtils.getTrimmedString(e.getMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to Add/Update the TOS List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of tosDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateTOS", method = RequestMethod.POST)
	public ModelAndView addUpdateTOS(final HttpServletRequest request,@ModelAttribute("tosDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered from TOSController - addUpdateTOS()");
		ModelAndView mav ;
		String tosMsg = "";
		String securityLevel ="";
		List<TOSVO> updatedtosList = new LinkedList<TOSVO>();
		List<TOSDTO> updatedTOSDtoList = new LinkedList<TOSDTO>();
		List<TOSVO> tosVoList = new LinkedList<TOSVO>();
		List<TOSVO> modifiedTOSVoList = new LinkedList<TOSVO>();
		List<TOSDTO> tosDtoList = new LinkedList<TOSDTO>(); 
		boolean isTOSAddOrUpdated = false;
		Map tosResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			 tosVoList = facade.getApplicationState().getTosList();
			 modifiedTOSVoList = lookUpListVO.getTosVOList();
			int i;
			if (takeAction != null && takeAction.length != 0) {
				if(tosVoList != null && tosVoList.size() != 0 
						&& modifiedTOSVoList.size() != 0 && modifiedTOSVoList != null){
				for(TOSVO tosVO : tosVoList){
					if(tosVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						tosVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				tosDtoList = RTETranslator.toTOSDTOList(tosVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					TOSVO seletedTOS = (TOSVO) tosVoList.get(i);
					TOSVO editedTOS = (TOSVO) modifiedTOSVoList.get(i);
					TOSVO editedTOSVO = new TOSVO(editedTOS.getDbTosCd(), editedTOS.getDbEffDate() , editedTOS.getDbExpDate() , editedTOS.getDbStatusCd() ,
							editedTOS.getDbApprovalCd() , editedTOS.getDbDisplayName() , editedTOS.getDbShortName() , editedTOS.getDbTosName() ,
							editedTOS.getDbPostedDate(), editedTOS.getDbLastUpdtDate(), editedTOS.getDbUserId() , editedTOS.getDbTosComments() ,
							 editedTOS.getDbUpdateReason() ,  updatedInd);
					TOSDTO editedTOSDTO = RTETranslator.toTOSDTO(editedTOSVO);
					tosResultMap = facade.addUpdateTOS(editedTOSDTO, tosDtoList, i , seletedTOS.getDbUpdatedInd());
					updatedTOSDtoList = (List<TOSDTO>) tosResultMap.get("tosDtoList");
					updatedtosList = RTETranslator.toTOSVOList(updatedTOSDtoList);
					isTOSAddOrUpdated = (Boolean) tosResultMap.get("isTOSAddorUpdated")  ;
					tosMsg = (String) tosResultMap.get("tosMsg") ;
					if(isTOSAddOrUpdated!= true){
						j = takeAction.length;
					}
				}
				if(isTOSAddOrUpdated==true){
					tosMsg = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted.";
				}
				lookUpListVO.setTosVOList(updatedtosList);
				facade.getApplicationState().setTosList(updatedtosList);
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	
				}
		}else{
			tosMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setTosVOList(tosVoList);
			facade.getApplicationState().setTosList(tosVoList);
		}
			mav = new ModelAndView(TOS_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("tosMessage",tosMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateTOS - tosMessage: "+ tosMsg);
		    log.warn("Exit from TOSController - addUpdateTOS()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in TOSController - addUpdateTOS() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addUpdateTOS() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	
	/**
     * Method to export TOS look up table to excel work book
     * 
      * @param lookUpTableListVO
     *            list of tos object.
     * @param response
     *            response object to return
     * @return exported file to view.
     */
     @RequestMapping(value = "/tosExport", method = RequestMethod.POST)
     public ModelAndView tosExport(HttpServletResponse response){
           List<TOSVO> tosList = new LinkedList<TOSVO>();
           LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
     String tosMsg="";
           try{
                 tosList = facade.getApplicationState().getTosList();
                 if(tosList != null && tosList.size() != 0){
                 // Key map to create header
                 Map<String,String> keyMap = new LinkedHashMap<String,String>();
                 keyMap.put("dbTosCd", "TOS Code");
                 keyMap.put("dbDisplayName", "Display Name");
                 keyMap.put("dbUserId", "User Id");
                 keyMap.put("dbPostedDate", "Post Date");
                 keyMap.put("dbLastUpdtDate", "Upd Date");
                 keyMap.put("dbShortName", "Short Name");
                 keyMap.put("dbTosName", "Full Name");
                 keyMap.put("dbStatusCd", "Status");
                 keyMap.put("dbApprovalCd", "Approval");
                 keyMap.put("dbEffDate", "Eff Date");
                 keyMap.put("dbExpDate", "Exp Date");
                 keyMap.put("dbTosComments", "Comments");
                 keyMap.put("dbUpdateReason", "Update Reason");
                 RteIntranetUtils.exportToExcel(response, tosList, keyMap);
                 tosMsg = "LookUp table exported successfully.";
                 } else {
                       tosMsg = "No data found.";
                 }
                 lookUpTableListVO.setTosVOList(tosList);
               mav = new ModelAndView(TOS_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
               mav.addObject("tosMessage",tosMsg);
               return mav;
           }catch (ApplicationException e) {
                 log.error("Exception occured in TOSController - tosExport() method:"
                             + e.getMessage());
                 String errorMsg = "Error encountered while export to excel. ";
                 errorMsg.concat(e.toString());
                 errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
                 errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
                 return errormav;
           }
     }

}