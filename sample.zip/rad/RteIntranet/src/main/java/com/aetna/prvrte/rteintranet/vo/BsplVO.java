package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;
import java.util.Vector;


public class BsplVO implements Serializable {
	private String dbBnftIdCd = "";
	private String dbSvcTypCd = "";
	private short dbProvision;
	private String dbProvType = "";
	private String dbProvPosition = "";
	private short dbNextProv;
	private String dbFmtGeneric = "";
	private String dbCSMsgText = "";
	private String dbPvdrMsgText = "";
	private short dbNP1LineVal;
	private short dbNP2LineVal;
	private short dbCSLineVal;
	private short dbNCLineVal;
	private short dbPCLineVal;
	private short dbBALineVal;
	private short dbCXLineVal;
	private String dbReadBPLV = "";
	private String dbCondLogCd = "";
	private char   dbUpdatedInd;
	private Vector dbBspprGroup = new Vector();

	/**
	 * Constructor for Bspl
	 */

	public BsplVO() {
		super();
	}
	
	public BsplVO(String bnftIdCd, String svcTypeCd, short provision, String provType,
				 String provPosition, short nextProv, String fmtGeneric, String cSMsgText,
				 String pvdrMsgText, short nP1LineVal, short nP2LineVal, short cSLineVal,
				 short nCLineVal, short pCLineVal, short bALineVal, short cXLineVal,
				 String readBPLV, String condLogCd, char updatedInd, Vector bspprGroup) {
		super();
		
		setBnftIdCd(bnftIdCd);
		setSvcTypCd(svcTypeCd);
		setProvision(provision);
		setProvType(provType);
		setProvPosition(provPosition);
		setNextProv(nextProv);
		setFmtGeneric(fmtGeneric);
		setCSMsgText(cSMsgText);
		setPvdrMsgText(pvdrMsgText);
		setNP1LineVal(nP1LineVal);
		setNP2LineVal(nP2LineVal);
		setCSLineVal(cSLineVal);
		setNCLineVal(nCLineVal);
		setPCLineVal(pCLineVal);
		setBALineVal(bALineVal);
		setCXLineVal(cXLineVal);
		setReadBPLV(readBPLV);
		setCondLogCd(condLogCd);
		setUpdatedInd(updatedInd);
		setBspprGroup(bspprGroup);
	}
	
	public void updateBsplColumns(String bnftIdCd, String svcTypeCd, short provision,
									String provType, String provPosition, short nextProv,
									String fmtGeneric, String cSMsgText, String pvdrMsgText,
									short nP1LineVal, short nP2LineVal, short cSLineVal,
									short nCLineVal, short pCLineVal, short bALineVal,
									short cXLineVal, String readBPLV, String condLogCd) {
		setBnftIdCd(bnftIdCd);
		setSvcTypCd(svcTypeCd);
		setProvision(provision);
		setProvType(provType);
		setProvPosition(provPosition);
		setNextProv(nextProv);
		setFmtGeneric(fmtGeneric);
		setCSMsgText(cSMsgText);
		setPvdrMsgText(pvdrMsgText);
		setNP1LineVal(nP1LineVal);
		setNP2LineVal(nP2LineVal);
		setCSLineVal(cSLineVal);
		setNCLineVal(nCLineVal);
		setPCLineVal(pCLineVal);
		setBALineVal(bALineVal);
		setCXLineVal(cXLineVal);
		setReadBPLV(readBPLV);
		setCondLogCd(condLogCd);
	}
									
	
	public String getBnftIdCd(){
		return dbBnftIdCd;
	}

	public String getSvcTypCd(){
		return dbSvcTypCd;
	}
	
	public short getProvision(){
		return dbProvision;
	}

	public String getProvType(){
		return dbProvType;
	}
	
	public String getProvPosition(){
		return dbProvPosition;
	}

	public short getNextProv(){
		return dbNextProv;
	}
	
	public String getFmtGeneric(){
		return dbFmtGeneric;
	}
	
	public String getCSMsgText(){
		return dbCSMsgText;
	}

	public String getPvdrMsgText(){
		return dbPvdrMsgText;
	}

	public short getNP1LineVal(){
		return dbNP1LineVal;
	}
	
	public short getNP2LineVal(){
		return dbNP2LineVal;
	}

	public short getCSLineVal(){
		return dbCSLineVal;
	}
	
	public short getNCLineVal(){
		return dbNCLineVal;
	}

	public short getPCLineVal(){
		return dbPCLineVal;
	}
	
	public short getBALineVal(){
		return dbBALineVal;
	}

	public short getCXLineVal(){
		return dbCXLineVal;
	}

	public String getReadBPLV(){
		return dbReadBPLV;
	}
	
	public String getCondLogCd(){
		return dbCondLogCd;
	}

	public char getUpdatedInd(){
		return dbUpdatedInd;
	}
	
	public Vector getBspprGroup(){
		return dbBspprGroup;
	}

	public void setBnftIdCd(String bnftIdCd){
		dbBnftIdCd = bnftIdCd;
	}
	
	public void setSvcTypCd(String svcTypCd){
		dbSvcTypCd = svcTypCd;
	}
	
	public void setProvision(short provision){
		dbProvision = provision;
	}
	
	public void setProvType(String provType){
		dbProvType = provType;
	}
	
	public void setProvPosition(String provPosition){
		dbProvPosition = provPosition;
	}

	public void setNextProv(short nextProv){
		dbNextProv = nextProv;
	}
	
	public void setFmtGeneric(String fmtGeneric){
		dbFmtGeneric = fmtGeneric;
	}
	
	public void setCSMsgText(String cSMsgText){
		dbCSMsgText = cSMsgText;
	}
	
	public void setPvdrMsgText(String pvdrMsgText){
		dbPvdrMsgText = pvdrMsgText;
	}
	
	public void setNP1LineVal(short nP1LineVal){
		dbNP1LineVal = nP1LineVal;
	}
	
	public void setNP2LineVal(short nP2LineVal){
		dbNP2LineVal = nP2LineVal;
	}
	
	public void setCSLineVal(short cSLineVal){
		dbCSLineVal = cSLineVal;
	}
	
	public void setNCLineVal(short nCLineVal){
		dbNCLineVal = nCLineVal;
	}
	
	public void setPCLineVal(short pCLineVal){
		dbPCLineVal = pCLineVal;
	}
	
	public void setBALineVal(short bALineVal){
		dbBALineVal = bALineVal;
	}
	
	public void setCXLineVal(short cXLineVal){
		dbCXLineVal = cXLineVal;
	}
	
	public void setReadBPLV(String readBPLV){
		dbReadBPLV = readBPLV;
	}
	
	public void setCondLogCd(String condLogCd){
		dbCondLogCd = condLogCd;
	}
	
	public void setUpdatedInd(char updateInd){
		dbUpdatedInd = updateInd;
	}
	
	public void setBspprGroup(Vector bspprGroup){
		dbBspprGroup = bspprGroup;
	}
	
}

