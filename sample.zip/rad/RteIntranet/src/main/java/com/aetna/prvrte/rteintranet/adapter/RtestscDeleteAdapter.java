/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RtestscDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


public class RtestscDeleteAdapter extends StoredProcedure {

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RtestscDeleteAdapter.class);
	private static final String SVC_TYP_CD = "SVC_TYP_CD";
	private static final String SCSR_SVC_TYP_CD = "SCSR_SVC_TYP_CD";
	private static final String SCSR_SERVICE_CD = "SCSR_SERVICE_CD";
	private static final String RTE_STSC_EFF_DT = "RTE_STSC_EFF_DT";
	private static final String LS_SQLCODE = "LS_SQLCODE";
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtestscDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		declareParameter(new SqlParameter(SVC_TYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(SCSR_SVC_TYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(SCSR_SERVICE_CD, Types.CHAR));
		declareParameter(new SqlParameter(RTE_STSC_EFF_DT, Types.DATE));
		declareParameter(new SqlOutParameter(LS_SQLCODE, Types.INTEGER));
	}
	
	@SuppressWarnings("unchecked")
	public Map deleteRtestsc(RtestscDTO rtestscDTO) throws ApplicationException {
		
		log.warn("Entered RtestscDeleteAdapter  - deleteRtestsc");
		boolean isRtestscDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map rtestscMap = new HashMap();
			
		params.put(SVC_TYP_CD, RteIntranetUtils.getTrimmedString(rtestscDTO.getSvcTypeCd()));
		params.put(SCSR_SVC_TYP_CD, RteIntranetUtils.getTrimmedString(rtestscDTO.getScsrSvcTypeCd()));
		params.put(SCSR_SERVICE_CD, RteIntranetUtils.getTrimmedString(rtestscDTO.getScsrServiceCd()));
		params.put(RTE_STSC_EFF_DT, RteIntranetUtils.getTrimmedString(rtestscDTO.getEffDate()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("RtestscDeleteAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(LS_SQLCODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) 
				isRtestscDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			rtestscMap.put("rtestscMessage", newMessage);
			rtestscMap.put("isRtestscDeleted", isRtestscDeleted);
			return rtestscMap;
		}catch (Exception exception){
			
			log.error("RtestscDeleteAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
}
