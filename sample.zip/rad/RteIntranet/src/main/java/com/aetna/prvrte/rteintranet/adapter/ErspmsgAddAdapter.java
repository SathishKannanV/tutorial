/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.ErspmsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.ErspmsgVO;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class ErspmsgAddAdapter extends StoredProcedure {

	public ErspmsgAddAdapter() {}
	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(ErspmsgAddAdapter.class);
	
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public ErspmsgAddAdapter(DataSource datasource, String storedProc) throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of ErspmsgAdapter : " + storedProc);
		//Input Params declaration
		declareParameter(new SqlParameter(DBConstants.LS_ERSPMSG_ID, Types.INTEGER));
		declareParameter(new SqlParameter(DBConstants.LS_ERSPMSG_MSGTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_ERSPMSG_SHORT_TXT, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_ERSPMSG_LONG_TXT, Types.VARCHAR));
		declareParameter(new SqlParameter(DBConstants.LS_ERSPMSG_POSTED_DTS, Types.TIMESTAMP));
		declareParameter(new SqlParameter(DBConstants.LS_ERSPMSG_USER_ID, Types.CHAR));
		
		//Output Params declaration
		declareParameter(new SqlOutParameter(DBConstants.LS_OUT_ERSPMSG_ID, Types.INTEGER));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
	}
	/**
	 * Method to add new Erspmsg to data store.
	 * 
	 * @param erspmsg
	 *            String of aetna id.
	 * @return Map of Erspmsg list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	public Map<String, Object> addErspmsgToDb(ErspmsgDTO erspmsgDTO)throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<ErspmsgVO> erspmsgList = new LinkedList<ErspmsgVO>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String erspmsgMsg = "";
		try {
			int messageId = erspmsgDTO.getMessageId();
			String messageTypeCd = RteIntranetUtils.getTrimmedString(erspmsgDTO.getMessageTypeCd());
			String shortText = RteIntranetUtils.getTrimmedString(erspmsgDTO.getShortText());
			String fullText = RteIntranetUtils.getTrimmedString(erspmsgDTO.getFullText());
			String userId = RteIntranetUtils.getTrimmedString(erspmsgDTO.getUserId());
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDateTimeStamp = currentTS.toString();
			
			//Query params
			params.put(DBConstants.LS_ERSPMSG_ID, messageId);
			params.put(DBConstants.LS_ERSPMSG_MSGTYP_CD, messageTypeCd);
			params.put(DBConstants.LS_ERSPMSG_SHORT_TXT, shortText);
			params.put(DBConstants.LS_ERSPMSG_LONG_TXT, fullText);
			params.put(DBConstants.LS_ERSPMSG_POSTED_DTS, postedDateTimeStamp);
			params.put(DBConstants.LS_ERSPMSG_USER_ID, userId);
			log.info("Params for getting Erspmsg LookUp List : " + params);
			
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			if ("0".equals(sqlCode)) {
				String returnID = String.valueOf(results.get(DBConstants.LS_OUT_ERSPMSG_ID));
				erspmsgMsg = ApplicationConstants.ROW_ADDED;
				int returnMsgId  = Integer.valueOf(returnID);
				ErspmsgVO erspmsgObj = new ErspmsgVO(returnMsgId, messageTypeCd,
						shortText, fullText, userId, postedDateTimeStamp, ApplicationConstants.UPDATE_IND_Y);
				erspmsgList.add(erspmsgObj);
			} else {
				erspmsgMsg = ApplicationConstants.ADD_ROW_FAILS + sqlCode;
				
			}
			resultMap.put("erspmsgMsg", erspmsgMsg);
			resultMap.put("erspmsgList", erspmsgList);
		} catch (DataAccessException dae) {
			log.error("ErspmsgAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("ErspmsgAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
		return resultMap;
	}
	
	/**
	 * Method to add/update list of Erspmsg to data store.
	 * 
	 * @param erspmsgList
	 *            List of aetna ids.
	 * @param takeAction
	 *            List of selected indexes to delete aetna id.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from Erspmsg list, success or
	 *         error message and list of Erspmsg.
	 * @throws ApplicationException
	 *             if insertion or update fails.
	 */
	public Map<String, Object> addUpdateErspmsg(ErspmsgDTO erspmsgDTO, List<ErspmsgDTO> erspmsgList, int index) throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String erspmsgMsg = "";
		boolean isErspmsgAddorUpdated = false;
		try{
			int messageId = erspmsgDTO.getMessageId();
			String messageTypeCd = RteIntranetUtils.getTrimmedString(erspmsgDTO.getMessageTypeCd());
			String shortText = RteIntranetUtils.getTrimmedString(erspmsgDTO.getShortText());
			String fullText = RteIntranetUtils.getTrimmedString(erspmsgDTO.getFullText());
			String userId = RteIntranetUtils.getTrimmedString(erspmsgDTO.getUserId());
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDateTimeStamp = currentTS.toString();
			
			//Query params
			params.put(DBConstants.LS_ERSPMSG_ID, messageId);
			params.put(DBConstants.LS_ERSPMSG_MSGTYP_CD, messageTypeCd);
			params.put(DBConstants.LS_ERSPMSG_SHORT_TXT, shortText);
			params.put(DBConstants.LS_ERSPMSG_LONG_TXT, fullText);
			params.put(DBConstants.LS_ERSPMSG_POSTED_DTS, postedDateTimeStamp);
			params.put(DBConstants.LS_ERSPMSG_USER_ID, userId);
			
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			String id =  String.valueOf(results.get(DBConstants.LS_OUT_ERSPMSG_ID));
			if ("0".equalsIgnoreCase(sqlCode)) {
				erspmsgMsg = ApplicationConstants.ADD_UPDATE_ROWS;
				int returnMsgId  = Integer.valueOf(id);
				ErspmsgDTO erspmsgObj = new ErspmsgDTO(returnMsgId, messageTypeCd,
						shortText, fullText, userId, postedDateTimeStamp, ApplicationConstants.UPDATE_IND_Y);
				
				erspmsgList.set(index, erspmsgObj);
			} else {
				isErspmsgAddorUpdated = true;
				erspmsgMsg = ApplicationConstants.ADD_UPDATE_ROW_FAILS + sqlCode;
			}
			resultMap.put("erspmsgMsg", erspmsgMsg);
			resultMap.put("erspmsgList", erspmsgList);
			resultMap.put("isErspmsgAddorUpdated", isErspmsgAddorUpdated);
			return resultMap;
		}catch (DataAccessException dae) {
			log.error("ErspmsgAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("ErspmsgAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		}
	}
}
