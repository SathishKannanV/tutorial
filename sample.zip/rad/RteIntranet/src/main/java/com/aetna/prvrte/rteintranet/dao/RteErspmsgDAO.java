/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.ErspmsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * 
 * <h1>RteErspmsgService</h1> The RteErspmsgService is responsible for handling
 * the business logic of ERSPMSG Look up.
 * 
 * @author N726899 Cognizant_Offshore
 * 
 */
public interface RteErspmsgDAO {
	/**
	 * Method to get the ERSPMSG list from data store.
	 * 
	 * @param erspmsgDTO
	 * 			erspmsgDTO object.
	 * @return Map of ERSPMSG list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	Map<String, Object> getErspmsgLookUpList(ErspmsgDTO erspmsgDTO) throws ApplicationException;
	/**
	 * Method to add new ERSPMSG to data store.
	 * 
	 * @param erspmsgDTO
	 *            erspmsgDTO object.
	 * @return Map of added ERSPMSG data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	Map<String, Object> addErspmsgToDb(ErspmsgDTO erspmsgDTO) throws ApplicationException;
	/**
	 * Method to delete the ERSPMSG data from data store.
	 * 
	 * @param messageId
	 *            Integer of messageId.
	 * @return Map of flag to delete the data from ERSPMSG list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	Map<String, Object> deleteErspmsg(int messageId) throws ApplicationException;
	
	/**
	 * Method to add/update list of ERSPMSG to data store.
	 * 
	 * @param erspmsgDTO
	 *            erspmsgDTO object.
	 * @param erspmsgDTOList
	 *            list of erspmsgDTO object.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from ERSPMSG list, success or
	 *         error message and list of ERSPMSG.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	Map<String, Object> addUpdateErspmsg(ErspmsgDTO erspmsgDTO,	List<ErspmsgDTO> erspmsgDTOList, int index)throws ApplicationException;
}
