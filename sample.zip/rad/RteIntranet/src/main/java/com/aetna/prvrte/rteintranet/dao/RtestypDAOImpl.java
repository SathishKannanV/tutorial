package com.aetna.prvrte.rteintranet.dao;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.RtestypAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.RtestypDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.RtestypLookUpAdapter;
import com.aetna.prvrte.rteintranet.dto.RtestypDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;


/**
 * @author N657186
 * Cognizant_Offshore
 */
@Repository
public class RtestypDAOImpl implements RtestypDAO {
	
	@Autowired(required=true)
	private RtestypLookUpAdapter rtestypLookUpAdapter;
	
	@Autowired(required=true)
	private RtestypAddAdapter rtestypAddAdapter;
	
	@Autowired(required=true)
	private RtestypDeleteAdapter rtestypDeleteAdapter;
	
	@Override
	public Map getRtestypLookUp(RtestypDTO rtestypDTO) throws ApplicationException {
		return rtestypLookUpAdapter.getRtestypLookUp(rtestypDTO);
	}
	@Override
	public Map addNewRtestyp(RtestypDTO rtestypDTO) throws ApplicationException {
		return rtestypAddAdapter.addNewRtestyp(rtestypDTO);
	}
	

	@Override
	public Map deleteRtestyp(String rtestypCd, String svcTypeCd)
			throws ApplicationException {
		return rtestypDeleteAdapter.deleteRtestyp(rtestypCd, svcTypeCd);
	}

	@Override
	public Map addUpdateRtestyp(RtestypDTO existRtestypDTO,
			List<RtestypDTO> rtestypDtoList, int index, char updateInd) throws ApplicationException {
		return rtestypAddAdapter.addUpdateRtestyp(existRtestypDTO, rtestypDtoList, index, updateInd);
	}

}
