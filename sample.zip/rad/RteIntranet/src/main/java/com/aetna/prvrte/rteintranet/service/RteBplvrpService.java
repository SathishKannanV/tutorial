/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.BplvrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * 
 * <h1>RteBplvrpService</h1> The RteBplvrpService is responsible for handling
 * the business logic of BPLVRP Look up.
 * 
 * @author N726899 Cognizant_Offshore
 * 
 */
public interface RteBplvrpService {
	/**
	 * Method to get the BPLVRP list from data store.
	 * 
	 * @param bplvrpDTO
	 * 			bplvrpDTO object.
	 * @return Map of BPLVRP list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	Map<String, Object> getBplvrpLookUpList(BplvrpDTO bplvrpDTO) throws ApplicationException;
	/**
	 * Method to add new BPLVRP to data store.
	 * 
	 * @param bplvrpDTO
	 *            bplvrpDTO object.
	 * @return Map of added BPLVRP data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	Map<String, Object> addBplvrpToDb(BplvrpDTO bplvrpDTO) throws ApplicationException;
	/**
	 * Method to delete the BPLVRP data from data store.
	 * 
	 * @param bplvrpDTO
	 *            bplvrpDTO object.
	 * @return Map of flag to delete the data from BPLVRP list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	Map<String, Object> deleteBplvrp(BplvrpDTO bplvrpDTO) throws ApplicationException;
	
	/**
	 * Method to add/update list of BPLVRP to data store.
	 * 
	 * @param bplvrpDTO
	 *            bplvrpDTO object.
	 * @param bplvrpDTOList
	 *            list of bplvrpDTO object.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from BPLVRP list, success or
	 *         error message and list of BPLVRP.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	Map<String, Object> addUpdateBplvrp(BplvrpDTO bplvrpDTO,	List<BplvrpDTO> bplvrpDTOList, int index)throws ApplicationException;
}
