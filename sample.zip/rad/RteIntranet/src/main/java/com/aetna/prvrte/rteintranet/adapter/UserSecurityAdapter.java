package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.vo.UserVO;

public class UserSecurityAdapter extends StoredProcedure{

	private final Log log = LogFactory.getLog(UserSecurityAdapter.class);
	private static final String LS_SITE_CD = "LS_SITE_CD";
	private static final String LS_RIDER_CD = "LS_RIDER_CD";
	private static final String LS_SVCTYP_CD = "LS_SVCTYP_CD";
	private static final String LS_SQL_TYPE = "LS_SQL_TYPE";
	private static final String LS_SQLCODE = "LS_SQLCODE";
	//Defaulting to the Stored Procedure's search with site, rider and service code option.
	private static final String siteCd = "ZZZZ";
	private static final String svcTypeCd = "99999";
	private static final int searchCd = 3;    
	private static final String READ_CURSOR3 = "READ_CURSOR3";

	
	
	public UserSecurityAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		System.out.println("-------------------->"+storedProc);
		declareParameter(new SqlParameter(LS_SITE_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_RIDER_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_SVCTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_SQL_TYPE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(LS_SQLCODE, Types.CHAR));
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR3, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				
				UserVO currentUser =new UserVO();
				currentUser.setAetnaId(rs.getString("RIDER_CD"));
				currentUser.setDateSecLevPosted(rs.getString("RBRC_SRCE_PSTD_DT"));
				currentUser.setName(rs.getString("RBRC_DESC_TXT"));
				currentUser.setSecurityLevel(rs.getString("RBRC_IONTWK_CD"));
				return currentUser;
			}

		}));

	}
	
	@SuppressWarnings("unchecked")
	public Map getUserSecurityLevel (String userId) throws ApplicationException {
		log.debug("Entered UserSecurityAdapter  - getUserSecurityLevel");
		Map<String, String> params = new java.util.HashMap<String, String>();
		params.put(LS_SITE_CD, siteCd);
		params.put(LS_RIDER_CD, userId.toLowerCase());
		params.put(LS_SVCTYP_CD, svcTypeCd);
		params.put(LS_SQL_TYPE, String.valueOf(searchCd));
		log.debug(params);
		Map results = null;
		List<UserVO> userList = new LinkedList<UserVO>();
		Map userDetailsMap = new HashMap();
		UserVO currUser = new UserVO();
		String newMessage="";
		try {
			log.warn("UserSecurityAdapter: Executing stored procedure : " + "user id : " + userId);
					
			results = execute(params);
			log.warn("UserSecurityAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(LS_SQLCODE));
			
			if(results != null){
				if ("0".equals(sqlCode)){					
				
				userList = (ArrayList<UserVO>) results
						.get(READ_CURSOR3);	
				if(userList!=null){
				currUser = userList.get(0);
				
				if ("Unknown User".equalsIgnoreCase(currUser.getName())){
					newMessage = "Unable to find ---> " + currUser.getAetnaId() +
									 " <--- on the RTE Security table. Contact RTE P&E to fix. Read Only rights granted.";
				} else {
					newMessage = "Welcome " + currUser.getName();
				}
				}else{
					log.info("result set is empty");
					newMessage = "Unable to find ---> " + currUser.getAetnaId() +
							 " <--- on the RTE Security table. Contact RTE P&E to fix. Read Only rights granted.";
				}
			}else{
				
				
				 newMessage = "Problem in DB2. Sqlcode: " + sqlCode;
			}
			}
			userDetailsMap.put("userMessage", newMessage);
			userDetailsMap.put("user", currUser);
			log.warn("End: UserSecurityAdapter  - getUserSecurityLevel");
			return userDetailsMap;
			
		}catch (DataAccessException dae) {
			log.error("UserSecurityAdapter : Data access excpetion occured "+dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS,dae.getMessage(),dae);
		}catch (Exception exception){
			log.error("UserSecurityAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
		
	}
	
}
