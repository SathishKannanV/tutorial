/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.RtedictrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.RtedictrVO;
import com.aetna.prvrte.rteintranet.vo.RtedictrVO;
import com.aetna.prvrte.rteintranet.vo.UserVO;

/**
 * @author N657186
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/rtedictr/*")
public class RtedictrController {

	
	
	public static final String RTEDICTR_HOME = ".rtedictrHome";
	public static final String RTEDICTR_LOOKUP = ".rtedictrLookUp";
	public static final String RTEDICTR_ADD = ".rtedictrAdd";
	
	
	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(RtedictrController.class);
	
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/rtedictrHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRtedictrLookUpHome(final HttpServletRequest request, Model model) {
		log.warn("Entered RtedictrController - getRtedictrLookUpHome()");
		String securityLevel ="";
		try{
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(RTEDICTR_HOME, "rtedictrVO",  new RtedictrVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("RtedictrController - securityLevel: "+ securityLevel);
		log.warn("Exit from RtedictrController - getRtedictrLookUpHome()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtedictrController - getRtedictrLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (RtedictrList). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rtedictrVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherRtedictr", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRtedictrLookUp(final HttpServletRequest request, @ModelAttribute("rtedictrForm")RtedictrVO rtedictrVO){
		log.warn("Entered RtedictrController - getRtedictrLookUp()");
		ModelAndView mav ;
		String securityLevel ="";
		Map rtedictrResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<RtedictrDTO> rtedictrDtoList = new LinkedList<RtedictrDTO>();
		List<RtedictrVO> rtedictrVoList = new LinkedList<RtedictrVO>();
		try{
		RtedictrDTO rtedictrDTO = RTETranslator.toRtedictrDTO(rtedictrVO);
		rtedictrResultMap = facade.getRtedictrLookUp(rtedictrDTO);
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		rtedictrDtoList = (List<RtedictrDTO>) rtedictrResultMap.get("rtedictrList");
		rtedictrVoList = RTETranslator.toRtedictrVOList(rtedictrDtoList);
		lookUpListVO.setRtedictrVOList(rtedictrVoList);
		facade.getApplicationState().setRtedictrList(rtedictrVoList);
		log.warn("getRtedictrLookUp - rtedictrMessage: "+ rtedictrResultMap.get("rbrcMessage"));
		mav = new ModelAndView(RTEDICTR_LOOKUP, "lookUpListVO", lookUpListVO);
		mav.addObject("rtedictrMessage", rtedictrResultMap.get("rtedictrMessage"));
		mav.addObject("securityLevel", securityLevel);
		log.warn("Exit from RtedictrController - getRtedictrLookUp()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in rtedictrController - getrtedictrLookUp() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (RtedictrList)."+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	@RequestMapping(value="/AddNewRtedictrRow")
	public ModelAndView loadAddNewRtedictrRowScreen(final HttpServletRequest request,Model model) {	
		log.warn("Entered RtedictrController - loadAddNewRtedictrRowScreen()");
		ModelAndView mav = new ModelAndView(RTEDICTR_ADD, "rtedictrVO",  new RtedictrVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in RtedictrController - loadAddNewRtedictrRowScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (loadAddNewRtedictrRowScreen). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		log.warn("Exit from RtedictrController - loadAddNewRtedictrRowScreen()");
		return mav;
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddRtedictr", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addNewRtedictr(final HttpServletRequest request,@ModelAttribute("addRtedictrForm")RtedictrVO rtedictrVO){
		log.warn("Entered RtedictrController - addNewRtedictr()");
		String securityLevel ="";
		Map rtedictrResultMap = new HashMap();
		List<RtedictrDTO> rtedictrDtoList = new LinkedList<RtedictrDTO>();
		List<RtedictrVO> rtedictrVoList = new LinkedList<RtedictrVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			String userId ="";
			userId = RteIntranetUtils.getUserId(request);
			rtedictrVO.setUserId(userId);
			rtedictrVO.setUpdatedInd(ApplicationConstants.COPY);
			rtedictrVO.setMessageId(ApplicationConstants.ZERO);
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDateTimeStamp = currentTS.toString(); //Initialize Posted Date to the current timestamp
			rtedictrVO.setPostedDateTimeStamp(postedDateTimeStamp);
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			RtedictrDTO rtedictrDTO = RTETranslator.toRtedictrDTO(rtedictrVO);
			rtedictrResultMap = facade.addNewRtedictr(rtedictrDTO);
			
			if(rtedictrResultMap.get("rtedictrList")!=null){
				rtedictrDtoList = (List<RtedictrDTO>) rtedictrResultMap.get("rtedictrList");
				rtedictrVoList = RTETranslator.toRtedictrVOList(rtedictrDtoList);
			}
			lookUpListVO.setRtedictrVOList(rtedictrVoList);
			facade.getApplicationState().setRtedictrList(rtedictrVoList);
			
			mav = new ModelAndView(RTEDICTR_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("rtedictrMessage", rtedictrResultMap.get("rtedictrMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("addNewRtedictr - rtedictrMessage: "+ rtedictrResultMap.get("rtedictrMessage"));
			log.warn("Exit from RtedictrController - addNewRtedictr()");
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in RtedictrController - addNewRtedictr() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when adding a row to the database (AddRTEDICTR). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * @param rtedictrVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteRtedictr", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView deleteRtedictr(final HttpServletRequest request, @ModelAttribute("rtedictrDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtedictrController - deleteRtedictr()");
		ModelAndView mav ;
		String rtedictrMsg = "";
		boolean isRtedictrDeleted = true;
		Map rtedictrResultMap = new HashMap();
		String securityLevel ="";
		List<RtedictrVO> rtedictrVoList = new LinkedList<RtedictrVO>();
		try{
			int i;
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtedictrVoList= lookUpListVO.getRtedictrVOList();
			if ((rtedictrVoList != null) && (takeAction != null)) {
				for(RtedictrVO rtedictrVO : rtedictrVoList){
					if(rtedictrVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtedictrVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);

					RtedictrVO existingRtedictr = (RtedictrVO) rtedictrVoList.get(i);
					if (existingRtedictr.getUpdatedInd() != ApplicationConstants.COPY) {
						RtedictrDTO rtedictrDTO = RTETranslator.toRtedictrDTO(existingRtedictr);
						
						rtedictrResultMap = facade.deleteRtedictr(rtedictrDTO);
						rtedictrMsg = (String) rtedictrResultMap.get("rtedictrMessage");
						isRtedictrDeleted = (Boolean) rtedictrResultMap.get("isRtedictrDeleted");
						
						if(isRtedictrDeleted){
							rtedictrVoList.remove(i);
						}else{
							j = 0;
						}
					}else{
						rtedictrVoList.remove(i);
					}				
			}
				
				if(isRtedictrDeleted){
					rtedictrMsg = "Rows selected were Deleted in the database/list";
				}
		}else
			rtedictrMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRtedictrList(rtedictrVoList);
			lookUpListVO.setRtedictrVOList(rtedictrVoList);
			
			mav = new ModelAndView(RTEDICTR_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtedictrMessage",rtedictrMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteRtedictr - rtedictrMessage: "+ rtedictrMsg);
		    log.warn("Exit from RtedictrController - deleteRtedictr()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtedictrController - deleteRtedictr() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (RtedictrListChange). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rtedictrVO
	 * @param takeAction
	 * @return
	 */
	@RequestMapping(value="/copyRtedictr", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView copyRtedictr(final HttpServletRequest request,@ModelAttribute("rtedictrDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtedictrController - copyRtedictr()");
		ModelAndView mav ;
		String rtedictrMsg = "";
		int i;
		String securityLevel ="";
		String userId ="";
		List<RtedictrVO> rtedictrList = new LinkedList<RtedictrVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			userId = RteIntranetUtils.getUserId(request);
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDateTimeStamp = currentTS.toString(); 
			rtedictrList = lookUpListVO.getRtedictrVOList();
			
			if ((rtedictrList != null) && (takeAction != null)) {
				for(RtedictrVO rtedictrVO : rtedictrList){
					if(rtedictrVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtedictrVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					RtedictrVO existingRtedictr = (RtedictrVO) rtedictrList.get(i);
					RtedictrVO copyRtedictr = new RtedictrVO(existingRtedictr.getRtestypCd(), existingRtedictr.getDitemCd(), 
							existingRtedictr.getDictCd(), existingRtedictr.getEffDt(),
							existingRtedictr.getExpDt(),postedDateTimeStamp,userId, existingRtedictr.getMessageId(), 
							existingRtedictr.getMessageTypeCd(), existingRtedictr.getShortText(),
							existingRtedictr.getFullText(),ApplicationConstants.COPY);
					rtedictrList.add(copyRtedictr);
				}
				rtedictrMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				rtedictrMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRtedictrList(rtedictrList);
			lookUpListVO.setRtedictrVOList(rtedictrList);
			
			mav = new ModelAndView(RTEDICTR_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtedictrMessage",rtedictrMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyRtedictr - rtedictrMessage: "+ rtedictrMsg);
		    log.warn("Exit from RtedictrController - copyRtedictr()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in RtedictrController - copyRtedictr() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRtedictr). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	/**
	 * @param request
	 * @param rtedictrVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateRtedictr", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addUpdateRtedictr(final HttpServletRequest request, @ModelAttribute("rtedictrDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtedictrController - addUpdateRtedictr()");
		ModelAndView mav ;
		String rtedictrMsg = "";
		String securityLevel ="";
		String userId="";
		List<RtedictrVO> updatedRtedictrList = new LinkedList<RtedictrVO>();
		List<RtedictrDTO> updatedRtedictrDtoList = new LinkedList<RtedictrDTO>();
		List<RtedictrVO> rtedictrVoList = new LinkedList<RtedictrVO>();
		List<RtedictrVO> modifiedRtedictrVoList = new LinkedList<RtedictrVO>();
		List<RtedictrDTO> rtedictrDtoList = new LinkedList<RtedictrDTO>(); 
		boolean isRtedictrAddOrUpdated = false;
		Map rtedictrResultMap = new HashMap();		
		try{
		Timestamp currentTS = new Timestamp(System.currentTimeMillis());
		String postedDateTimeStamp = currentTS.toString(); 
			rtedictrVoList = facade.getApplicationState().getRtedictrList();
			modifiedRtedictrVoList = lookUpListVO.getRtedictrVOList();
			userId = RteIntranetUtils.getUserId(request);
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			int i;
			if (takeAction != null && takeAction.length != 0) {
				if(rtedictrVoList != null && rtedictrVoList.size() != 0 
						&& modifiedRtedictrVoList.size() != 0 && modifiedRtedictrVoList != null){
				for(RtedictrVO rtedictrVO : rtedictrVoList){
					if(rtedictrVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){//have to fix this
						rtedictrVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				
				rtedictrDtoList = RTETranslator.toRtedictrDTOList(rtedictrVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					RtedictrVO seletedRtedictr = (RtedictrVO) rtedictrVoList.get(i);
					RtedictrVO editedRtedictr = (RtedictrVO) modifiedRtedictrVoList.get(i);
					RtedictrVO editedRtedictrVO = new RtedictrVO(editedRtedictr.getRtestypCd(),editedRtedictr.getDitemCd(),editedRtedictr.getDictCd(),
							editedRtedictr.getEffDt(),editedRtedictr.getExpDt(),postedDateTimeStamp,editedRtedictr.getUserId(),
							editedRtedictr.getMessageId(),editedRtedictr.getMessageTypeCd(),editedRtedictr.getShortText(),editedRtedictr.getFullText(),updatedInd);
					
					RtedictrDTO editedRtedictrDTO = RTETranslator.toRtedictrDTO(editedRtedictrVO);
					rtedictrResultMap = facade.addUpdateRtedictr(editedRtedictrDTO, rtedictrDtoList, i);
					updatedRtedictrDtoList = (List<RtedictrDTO>) rtedictrResultMap.get("rtedictrDtoList");
					updatedRtedictrList = RTETranslator.toRtedictrVOList(updatedRtedictrDtoList);
					isRtedictrAddOrUpdated = (Boolean) rtedictrResultMap.get("isrtedictrAddorUpdated");
					rtedictrMsg = (String) rtedictrResultMap.get("rtedictrMessage") ;
					if(!isRtedictrAddOrUpdated){
						j = takeAction.length;
					}
				}
			} else {
				throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);				
			}
		}else
			rtedictrMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRtedictrList(updatedRtedictrList);
			lookUpListVO.setRtedictrVOList(updatedRtedictrList);
			
			mav = new ModelAndView(RTEDICTR_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtedictrMessage",rtedictrMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateRtedictr - rtedictrMessage: "+ rtedictrMsg);
		    log.warn("Exit from RtedictrController - addUpdateRtedictr()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtedictrController - addUpdateRtedictr() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRTEDICTR). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * Method to export Rtedictr look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of rtedictr object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/rtedictrExport", method = RequestMethod.POST)
	public ModelAndView rtedictrExport(HttpServletResponse response){
		List<RtedictrVO> rtedictrList = new LinkedList<RtedictrVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String rtedictrMsg="";
		try{
			rtedictrList = facade.getApplicationState().getRtedictrList();
			if(rtedictrList != null && rtedictrList.size() != 0){
			// Key map to create header
			Map<String,String> keyMap = new LinkedHashMap<String,String>();
			keyMap.put("rtestypCd", "Rtestyp Cd");
			keyMap.put("ditemCd", "Ditem Cd");
			keyMap.put("dictCd", "Dict Cd");
			keyMap.put("effDt", "Eff Dt");
			keyMap.put("expDt", "Exp Dt");
			keyMap.put("postedDateTimeStamp", "Posted Timestamp");
			keyMap.put("userId", "User Id");
			keyMap.put("messageId", "Message Id");
			keyMap.put("messageTypeCd", "Message Type Cd");
			keyMap.put("shortText", "Short Provider Text");
			keyMap.put("fullText", "Long Provider Text");
			
			RteIntranetUtils.exportToExcel(response, rtedictrList, keyMap);
			rtedictrMsg = "LookUp table exported successfully.";
			} else {
				rtedictrMsg = "No data found.";
			}
			lookUpTableListVO.setRtedictrVOList(rtedictrList);
	        mav = new ModelAndView(RTEDICTR_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
		    mav.addObject("rtedictrMessage",rtedictrMsg);
			return mav;
		}catch (ApplicationException e) {
			log.error("Exception occured in RtedictrController - rtedictrExport() method:"
					+ e.getErrorMessage());
			String errorMsg = "Error encountered while export to excel. "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errormav;
		}
	}
	
}
