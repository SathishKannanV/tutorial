package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.LongRunTransactionDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;

public class LongRunTransLookUpAdapter extends StoredProcedure {

private final Log log = LogFactory.getLog(LongRunTransLookUpAdapter.class);
	
	private static final String START_TIMESTAMP = "START_TIMESTAMP";
	private static final String END_TIMESTAMP = "END_TIMESTAMP";
	private static final String LOAD_MODULE = "LOAD_MODULE";
	private static final String SECONDS_RANGE = "SECONDS_RANGE";
	private static final String MINUTES_SPLIT = "MINUTES_SPLIT";
	private static final String LS_SQLCODE = "LS_SQLCODE";
	private static final String READ_CURSOR = "READ_CURSOR1";
	private static final String IN_RPT_IND = "IN_RPT_IND";
	
	public LongRunTransLookUpAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(START_TIMESTAMP, Types.TIMESTAMP));
		declareParameter(new SqlParameter(END_TIMESTAMP, Types.TIMESTAMP));
		declareParameter(new SqlParameter(LOAD_MODULE, Types.CHAR));
		
		declareParameter(new SqlParameter(SECONDS_RANGE, Types.DECIMAL));
		declareParameter(new SqlParameter(MINUTES_SPLIT, Types.DECIMAL));
		declareParameter(new SqlParameter(IN_RPT_IND, Types.CHAR));
		declareParameter(new SqlOutParameter(LS_SQLCODE, Types.INTEGER));
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				
				LongRunTransactionDTO longRunTransDTO =  new LongRunTransactionDTO();
				longRunTransDTO.setConvrsnCDResult(rs.getString("SUBMSN_CNVRSTN_CD"));
				longRunTransDTO.setVanIDCDResult(rs.getString("SUBMSN_VAN_ID_CD"));
				longRunTransDTO.setTypCDResult(rs.getString("SUBMSN_TY_CD"));
				longRunTransDTO.setResultSecondsResult(rs.getString("TIME_SECONDS"));
				longRunTransDTO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
				return longRunTransDTO;
			}

		}));

	}
	
	@SuppressWarnings("unchecked")
	public Map getLongrunTransLookUpTable (LongRunTransactionDTO longrunTransDTO) throws ApplicationException {
		log.warn("Entered LongRunTransLookUpAdapter  - getLongrunTransLookUpTable");
		
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map longRunTransMap = new HashMap();
		params.put(START_TIMESTAMP, longrunTransDTO.getStartTimestamp().replaceAll("/", "-"));
		params.put(END_TIMESTAMP, longrunTransDTO.getEndTimestamp());
		params.put(LOAD_MODULE, longrunTransDTO.getModule());
		params.put(SECONDS_RANGE, longrunTransDTO.getSecondsCalc());
		params.put(MINUTES_SPLIT, longrunTransDTO.getMinutesCalc());
		params.put(IN_RPT_IND, "1");
		log.warn(params);
		Map results = null;
		
		List<LongRunTransactionDTO> longRunTransList = new LinkedList<LongRunTransactionDTO>();
		String newMessage="";
		
		try {
			
			results = execute(params);
			log.warn("LongRunTransLookUpAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(LS_SQLCODE));
			
			longRunTransList = (List<LongRunTransactionDTO>) results
					.get(READ_CURSOR);
			if (longRunTransList.isEmpty()){
				
				if ("0".equals(sqlCode)) {
					newMessage = "No Data on database ";
				}else if ("-905".equals(sqlCode)){
					newMessage = "Try to minimize the start time and end time for results" + sqlCode;
				} 
				else {
					newMessage = "Problem in DB2. sqlcode: " + sqlCode ;
				}			  		  		  
			} else {
				newMessage = "";
			}
			longRunTransMap.put("longRunTransMessage", newMessage);
			longRunTransMap.put("longRunTransList",longRunTransList);
			return longRunTransMap;
		}catch (Exception exception){
			log.error("LongRunTransLookUpAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
		
	}
}
