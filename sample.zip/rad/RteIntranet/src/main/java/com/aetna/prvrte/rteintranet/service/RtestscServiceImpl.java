/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.aetna.prvrte.rteintranet.dao.RtestscDAO;
import com.aetna.prvrte.rteintranet.dto.RtestscDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

@Service
public class RtestscServiceImpl implements RtestscService{
	@Autowired(required=true)
	private RtestscDAO rtestscDAO;

	@Override
	public Map getRtestscLookUp(RtestscDTO rtestscDTO) throws ApplicationException {
		return rtestscDAO.getRtestscLookUp(rtestscDTO);
	}

	@Override
	public Map addNewRtestsc(RtestscDTO rtestscDTO) throws ApplicationException {
		return rtestscDAO.addNewRtestsc(rtestscDTO);
	}

	@Override
	public Map deleteRtestsc(RtestscDTO rtestscDTO)
			throws ApplicationException {
		return rtestscDAO.deleteRtestsc(rtestscDTO);
	}

	@Override
	public Map addUpdateRtestsc(RtestscDTO modifiedRtestscDTO, List<RtestscDTO> rtestscDtoList,
			int index, char updateInd) throws ApplicationException {
		return rtestscDAO.addUpdateRtestsc(modifiedRtestscDTO,rtestscDtoList, index, updateInd);
	}

}
