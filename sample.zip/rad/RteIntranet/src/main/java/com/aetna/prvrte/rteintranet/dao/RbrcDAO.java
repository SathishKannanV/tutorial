/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.dto.RbrcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 * Cognizant_Offshore
 */

public interface RbrcDAO {

Map getRbrcLookUp(RbrcDTO rbrcDTO) throws ApplicationException;
	
	Map addNewRbrc(RbrcDTO RbrcDTO) throws ApplicationException ;

	Map deleteRbrc(RbrcDTO rbrcDTO) throws ApplicationException ;

	Map addUpdateRbrc(RbrcDTO existRbrcDTO, List<RbrcDTO> rbrcDtoList, int index, char updateInd) throws ApplicationException ;
}
