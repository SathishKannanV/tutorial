/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.ProcexVO;


/**
 * @author N657186
 * Cognizant_Offshore
 */
public class ProcexAdapter extends StoredProcedure{

	private final Log log = LogFactory.getLog(ProcexAdapter.class);
	
	
	
	public ProcexAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.IN_PROCEX_CD, Types.CHAR));   
		declareParameter(new SqlParameter(DBConstants.IN_SVCTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_SEARCH_CD, Types.DECIMAL));
		
		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR3, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;			//Used by ProcexDisplay, not on database
				ProcexVO procexVO = new ProcexVO();
				procexVO.setDbProcexCd(rs.getString("PROCEX_CD"));
				procexVO.setDbSvcTypeCd(rs.getString("PROCEX_SVCTYP_CD"));
				procexVO.setDbDescTxt(rs.getString("PROCEX_DESC_TXT"));
				procexVO.setDbPostedDate(rs.getString("PROCEX_PSTD_DT"));
				procexVO.setDbUpdatedInd(updatedInd);
				return procexVO;
			}

		}));

	}
	
	
	
	@SuppressWarnings("unchecked")
	public Map getProcexLookUpTable (String procexCode, String svcTypeCode) throws ApplicationException {
		log.warn("Entered ProcexAdapter  - getProcexLookUpTable");
		int searchCd ;
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map procexMap = new HashMap();
		params.put(DBConstants.IN_PROCEX_CD, RteIntranetUtils.getTrimmedString(procexCode));
		params.put(DBConstants.IN_SVCTYP_CD, RteIntranetUtils.getTrimmedString(svcTypeCode));
		
		if (!procexCode.equals("")) {
			if (!svcTypeCode.equals("")) {
				searchCd = 1;
			} else {
				searchCd = 2;
				}		
		} else {		
			if (!svcTypeCode.equals("")) {
					searchCd = 3;
			} else { 
					searchCd = 0;
					}		
				}
		
		params.put(DBConstants.IN_SEARCH_CD, String.valueOf(searchCd));
		
		log.warn(params);
		Map results = null;
		
		List<ProcexVO> procexList= new LinkedList<ProcexVO>();
		String newMessage="";
		int noOfElements;
		try {
			log.warn("ProcexAdapter: Executing stored procedure : " + "procexCode : " + procexCode + " ; svcTypeCode : "+svcTypeCode
					+"; searchCd : "+ searchCd);
					
			results = execute(params);
			log.warn("ProcexAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_CODE));
			
			procexList = (List<ProcexVO>) results
					.get(DBConstants.READ_CURSOR3);	
	
			noOfElements = procexList.size();
			//if (null != results) {
			if (procexList.isEmpty()){
				
				if ("0".equals(sqlCode)) {
					newMessage = "No Data for ";
					newMessage = getMessage(newMessage, procexCode, svcTypeCode);
				} else {
					newMessage = "Problem in DB2. sqlcode: " + sqlCode; 
					newMessage = getMessage(newMessage, procexCode, svcTypeCode);
				}			  		  		  
			} else {
				if (noOfElements > 1) {
			    	newMessage = noOfElements + " Rows found for ";
				} else {
			    newMessage = noOfElements + " Row found for ";
				}
				newMessage = getMessage(newMessage, procexCode, svcTypeCode);
			}
			/*}else{
				newMessage = "You must enter a Procex Code with or without combination of Rider Code and/or Service Type Code on the Look Up page.";
			}*/
			procexMap.put("newMessage", newMessage);
			procexMap.put("procexList",procexList);
			return procexMap;
		}catch (Exception exception){
			log.error("ProcexAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
		
		
		public String getMessage (String newMessage, String queryProcexCd, String querySvcTypeCd) {
			String getMessage = newMessage;
		    if (!"".equals(queryProcexCd)) 
			    getMessage = getMessage + " Procex  : " + queryProcexCd;
		    if (!"".equals(querySvcTypeCd))
			    getMessage = getMessage + " Service Type  : " + querySvcTypeCd;
			return getMessage;
}	

}
