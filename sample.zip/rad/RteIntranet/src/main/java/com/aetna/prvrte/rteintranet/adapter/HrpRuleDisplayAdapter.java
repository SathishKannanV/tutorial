package com.aetna.prvrte.rteintranet.adapter;



import java.sql.ResultSet;

import java.sql.SQLException;

import java.sql.Types;

import java.util.HashMap;

import java.util.LinkedList;

import java.util.List;

import java.util.Map;

import java.util.regex.Pattern;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;

import org.apache.commons.logging.LogFactory;

import org.springframework.jdbc.core.RowMapper;

import org.springframework.jdbc.core.SqlOutParameter;

import org.springframework.jdbc.core.SqlParameter;

import org.springframework.jdbc.core.SqlReturnResultSet;

import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.HrpRuleDTO;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;

import com.aetna.prvrte.rteintranet.util.ApplicationConstants;

import com.aetna.prvrte.rteintranet.util.DBConstants;

import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;





/**

 * @author N801539

 * Cognizant_Offshore

 */

public class HrpRuleDisplayAdapter extends StoredProcedure{



	/**

	 * Instance of Log Factory.

	 */

	private final Log log = LogFactory.getLog(HrpRuleDisplayAdapter.class);



	private static final Pattern p = Pattern.compile("\\s");

	

	/**

	 * @param datasource

	 * @param storedProc

	 * @throws SQLException

	 */

	public HrpRuleDisplayAdapter(DataSource datasource, String storedProc) {

		super(datasource, storedProc);

		System.out.println(" HrpRuleDisplayAdapter ------------------> " + storedProc);

		declareParameter(new SqlParameter(DBConstants.HRPRL_SVTYP_CD, Types.CHAR));

		declareParameter(new SqlParameter(DBConstants.HRPRL_RL_CD, Types.CHAR));

		

		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));

		

		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR3, new RowMapper(){

			

			/* (non-Javadoc)

			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)

			 */

			public Object mapRow(final ResultSet rs, final int arg1)

					throws SQLException {

				char updatedInd = ApplicationConstants.UPDATE_IND_N;			//Used by HrpRuleDisplay, not on database

				HrpRuleDTO hrpruleDTO = new HrpRuleDTO();
				
				hrpruleDTO.setHrprlSvcTyp(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_SVTYP_CD)));
				
				hrpruleDTO.setHrprlRulecd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_RL_CD)));
				
				hrpruleDTO.setHrprlEffdt(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_EFF_DT)));
				
				hrpruleDTO.setHrprlTermdt(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_TERM_DT)));
				
				hrpruleDTO.setHrprlRuledesc(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_RLE_DESC)));
				
				hrpruleDTO.setHrprlCondspec(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_CNSPF_IND)));
				
				hrpruleDTO.setHrprlRulectgry(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_RLCTG_IND)));
				
				hrpruleDTO.setHrprlCovgind(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_CVG_IND)));
				
				hrpruleDTO.setHrprlTextsnd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_TXSD_IND)));
				
				hrpruleDTO.setHrprlPosTob(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_PSTS_IND)));
				
				hrpruleDTO.setHrprlTobcd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_TYP_CD)));
				
				hrpruleDTO.setHrprlPoscd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_PLSVC_CD)));
				
				hrpruleDTO.setHrprlStatecd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_ST_CD)));
				
				hrpruleDTO.setHrprlAmntrfmt(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_AMTRFT_IND)));
				
				hrpruleDTO.setHrprlBus01(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL01_CD)));
				
				hrpruleDTO.setHrprlBus02(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL02_CD)));
				
				hrpruleDTO.setHrprlBus03(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL03_CD)));
				
				hrpruleDTO.setHrprlBus04(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL04_CD)));
				
				hrpruleDTO.setHrprlBus05(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL05_CD)));
				
				hrpruleDTO.setHrprlBus06(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL06_CD)));
				
				hrpruleDTO.setHrprlBus07(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL07_CD)));
				
				hrpruleDTO.setHrprlBus08(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL08_CD)));
				
				hrpruleDTO.setHrprlBus09(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL09_CD)));
				
				hrpruleDTO.setHrprlBus10(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL10_CD)));
				
				hrpruleDTO.setHrprlBus11(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL11_CD)));
				
				hrpruleDTO.setHrprlBus12(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL12_CD)));
				
				hrpruleDTO.setHrprlBus13(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL13_CD)));
				
				hrpruleDTO.setHrprlBus14(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL14_CD)));
				
				hrpruleDTO.setHrprlBus15(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.HRPRL_BUSRL15_CD)));

				hrpruleDTO.setUpdatedInd(updatedInd);

				return hrpruleDTO;

			}



		}));



	}

	

	/**

	 * Method to get the HRPRULE list from data store.

	 * 

	 * @param hrpruleDTO

	 * 			hrpruleDTO parameter

	 * 

	 * @return Map of HRPRULE list and success or error message.

	 * 

	 * @exception ApplicationException if data not found in data store.

	 */

	@SuppressWarnings("unchecked")

	public Map getHrpRuleLookUpTable (HrpRuleDTO hrpruleDTO) throws ApplicationException {

		log.warn("Entered HrpRuleAdapter  - getHrpRuleLookUpTable");

		Map<String, String> params = new java.util.LinkedHashMap<String, String>();

		Map hrpruleMap = new HashMap();

		String queryHrprlSvcTyp = "";

		String queryHrprlRulecd = "";

		try {

			queryHrprlSvcTyp = containsUnprintableCharacters(hrpruleDTO.getHrprlSvcTyp());

			queryHrprlRulecd = containsUnprintableCharacters(hrpruleDTO.getHrprlRulecd());

		} catch (Exception e) {

			log.error("HrpRuleAdapter : generic error occured  "+e);

		}

		params.put(DBConstants.HRPRL_SVTYP_CD, RteIntranetUtils.getTrimmedString(queryHrprlSvcTyp));

		params.put(DBConstants.HRPRL_RL_CD, RteIntranetUtils.getTrimmedString(queryHrprlRulecd));

		log.warn(params);

		Map results = null;

		List<HrpRuleDTO> hrpruleList= new LinkedList<HrpRuleDTO>();

		String newMessage="";
		
		int noOfElements;

		try {

			log.warn("HrpRuleAdapter: Starting stored procedure");
			
			results = execute(params);

			log.warn("HrpRuleAdapter: Executed stored procedure");

			String sqlCode =  String.valueOf(results.get(DBConstants.LS_SQLCODE));

			hrpruleList = (List<HrpRuleDTO>) results.get(DBConstants.READ_CURSOR3);	

			noOfElements = hrpruleList.size();

			if (hrpruleList.isEmpty()){

					if (ApplicationConstants.ZERO_0.equals(sqlCode)) {

						newMessage = "No Data on database for Service Type Code: "

								+ queryHrprlSvcTyp + ", Rule Code: "

								+ queryHrprlRulecd; 



					} else {

						newMessage = "Problem in DB2. Sqlcode: " + sqlCode

								+ " Service Type Code: " + queryHrprlSvcTyp

								+ ", Rule Code: " + queryHrprlRulecd;

					}			  		  		  

				} else {

					newMessage = "'" + noOfElements + "' data rows found on database for Service Type Code: "

							+ queryHrprlSvcTyp

							+ ", Rule Code: "

							+ queryHrprlRulecd;

				}

			hrpruleMap.put("newMessage", newMessage);

			hrpruleMap.put("hrpruleList",hrpruleList);

			return hrpruleMap;

		}catch (Exception exception){

			log.error("HrpRuleAdapter : generic error occured  "+exception);

			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);

		}

	}

		

		/**

		 * This method is used replace the expression (\s) with whit space.

		 * 

		 * @param input

		 * @return

		 */

		private String replaceLinearWhiteSpace(String input) {

			return p.matcher(input).replaceAll(" ");

		}



		/**

		 * This method is used identify the unprintable characters in input string.

		 * 

		 * @param input

		 * @return

		 * @throws Exception

		 */

		private String containsUnprintableCharacters(String input) throws Exception {



			String s = input;

			int id = -1;

			char ch = 0;

			if (null != input) {

				s = replaceLinearWhiteSpace(input);



				for (int i = 0; i < s.length(); ++i) {

					ch = s.charAt(i);

					if ((ch < ' ') || (ch > '~')) {

						id = ch;

						break;

					}

				}

			}

			if (id != -1)

				throw new Exception(

						"Invalid parameter - Input parameter contains unprintable character.");

			else

				return s;

		}



}

