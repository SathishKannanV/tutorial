/**
 * 
 */
package com.aetna.prvrte.rteintranet.dto;

import java.io.Serializable;

/**
 * @author N624926
 * Cognizant_Offshore
 */

public class StstypaDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7689716387189006364L;
	private String id = "";
	private String stateCd = "";
	private String collectionCode = "";    
	private String individualCode = "";    
	private String effDate = "";     
	private String expDate = "";
	private String postedDate = "";
	private String versionReleaseCode = "";
	private char   updatedInd;
	
	public StstypaDTO() {
	super();
	}


public StstypaDTO(String id, String stateCd, String collectionCode, String individualCode, String effDate,
				String expDate, String postedDate, String versionReleaseCode, char updatedInd) {
	super();
	this.id = id;
	this.stateCd = stateCd;
	this.collectionCode = collectionCode;
	this.individualCode = individualCode;
	this.effDate = effDate;
	this.expDate = expDate;
	this.postedDate = postedDate;
	this.versionReleaseCode = versionReleaseCode;
	this.updatedInd = updatedInd;
}
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the stateCd
	 */
	public String getStateCd() {
		return stateCd;
	}
	/**
	 * @param stateCd the stateCd to set
	 */
	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}
	/**
	 * @return the collectionCode
	 */
	public String getCollectionCode() {
		return collectionCode;
	}
	/**
	 * @param collectionCode the collectionCode to set
	 */
	public void setCollectionCode(String collectionCode) {
		this.collectionCode = collectionCode;
	}
	/**
	 * @return the individualCode
	 */
	public String getIndividualCode() {
		return individualCode;
	}
	/**
	 * @param individualCode the individualCode to set
	 */
	public void setIndividualCode(String individualCode) {
		this.individualCode = individualCode;
	}
	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}
	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	/**
	 * @return the expDate
	 */
	public String getExpDate() {
		return expDate;
	}
	/**
	 * @param expDate the expDate to set
	 */
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	/**
	 * @return the postedDate
	 */
	public String getPostedDate() {
		return postedDate;
	}
	/**
	 * @param postedDate the postedDate to set
	 */
	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}
	/**
	 * @return the versionReleaseCode
	 */
	public String getVersionReleaseCode() {
		return versionReleaseCode;
	}
	/**
	 * @param versionReleaseCode the versionReleaseCode to set
	 */
	public void setVersionReleaseCode(String versionReleaseCode) {
		this.versionReleaseCode = versionReleaseCode;
	}
	/**
	 * @return the updatedInd
	 */
	public char getUpdatedInd() {
		return updatedInd;
	}
	/**
	 * @param updatedInd the updatedInd to set
	 */
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}
	}
