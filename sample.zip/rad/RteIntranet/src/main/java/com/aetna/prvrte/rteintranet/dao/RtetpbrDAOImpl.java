/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.ProcexAdapter;
import com.aetna.prvrte.rteintranet.adapter.ProcexPRX2Adapter;
import com.aetna.prvrte.rteintranet.adapter.RtetpbrAdapter;
import com.aetna.prvrte.rteintranet.adapter.RtetpbrTPR2Adapter;
import com.aetna.prvrte.rteintranet.adapter.RtetpbrTPR3Adapter;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.RtetpbrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Repository
public class RtetpbrDAOImpl implements RtetpbrDAO {
	
	@Autowired(required=true)
	private RtetpbrAdapter rtetpbrAdapter;
	
	@Autowired(required=true)
	private RtetpbrTPR2Adapter rtetpbrTPR2Adapter;
	
	@Autowired(required=true)
	private RtetpbrTPR3Adapter rtetpbrTPR3Adapter;
	
	@Override
	public Map getRtetpbrLookUpTable(String idNo , String effDate)
			throws ApplicationException {
		
		return rtetpbrAdapter.getRtetpbrLookUpTable(idNo,effDate);
	}

	@Override
	public Map addNewRtetpbr(RtetpbrDTO rtetpbrDTO) throws ApplicationException {
		return rtetpbrTPR2Adapter.addNewRtetpbr(rtetpbrDTO);
	}

	@Override
	public Map deleteRtetpbr(String rtetpbrIdNo, String rtetpbrEffDate)
			throws ApplicationException {
		return rtetpbrTPR3Adapter.deleteRtetpbr(rtetpbrIdNo, rtetpbrEffDate);
	}

	@Override
	public Map addUpdateRtetpbr(RtetpbrDTO editedProcexDTO,
			List<RtetpbrDTO> rtetpbrDtoList, int index,char updateInd)
			throws ApplicationException {
		return rtetpbrTPR2Adapter.addUpdateRtetpbr(editedProcexDTO, rtetpbrDtoList, index,updateInd);
	}

}
