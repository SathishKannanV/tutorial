package com.aetna.prvrte.rteintranet.dto;

import java.io.Serializable;

/**
 * @author N726899
 * Cognizant_Offshore
 */
public class BplvrpDTO implements Serializable {
	/**
	 * Constant serialized ID used for compatibility. 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * String of dbBnftIdCd
	 */
	private String dbBnftIdCd = "";
	/**
	 * short of dbProvNo
	 */
	private short dbProvNo;
	/**
	 * short of dbProvLinVal
	 */
	private short dbProvLinVal;
	/**
	 * String of dbRFRLInd
	 */
	private String dbRFRLInd = "";
	/**
	 * String of dbPRCRTInd
	 */
	private String dbPRCRTInd = "";
	/**
	 * String of dbPRXSTNGInd
	 */
	private String dbPRXSTNGInd = "";
	/**
	 * char of index to update the record(Eg:'Y','N','C').
	 */
	private char dbUpdatedInd;

	/**
	 * Default Constructor.
	 */
	public BplvrpDTO() {
		super();
	}
	
	/**
	 * Creates a new BplvrpDTO
	 * 
	 * @param bnftIdCd
	 *            the value for {@link bnftIdCd}
	 * @param provNo
	 *            the value for {@link provNo}
	 * @param provLineVal
	 *            the value for {@link provLineVal}
	 * @param rfrlInd
	 *            the value for {@link rfrlInd}
	 * @param prcrtInd
	 *            the value for {@link prcrtInd}
	 * @param prxstngInd
	 *            the value for {@link prxstngInd}
	 * @param updatedInd
	 *            the value for {@link updatedInd}
	 */
	public BplvrpDTO(String bnftIdCd, short provNo, short provLineVal,
			String rfrlInd, String prcrtInd, String prxstngInd, char updatedInd) {
		super();
		setDbBnftIdCd(bnftIdCd);
		setDbProvNo(provNo);
		setDbProvLinVal(provLineVal);
		setDbRFRLInd(rfrlInd);
		setDbPRCRTInd(prcrtInd);
		setDbPRXSTNGInd(prxstngInd);
		setDbUpdatedInd(updatedInd);
	}

	/**
	 * @return the dbBnftIdCd
	 */
	public String getDbBnftIdCd() {
		return dbBnftIdCd;
	}

	/**
	 * @param dbBnftIdCd the dbBnftIdCd to set
	 */
	public void setDbBnftIdCd(String dbBnftIdCd) {
		this.dbBnftIdCd = dbBnftIdCd;
	}

	/**
	 * @return the dbProvNo
	 */
	public short getDbProvNo() {
		return dbProvNo;
	}

	/**
	 * @param dbProvNo the dbProvNo to set
	 */
	public void setDbProvNo(short dbProvNo) {
		this.dbProvNo = dbProvNo;
	}

	/**
	 * @return the dbProvLinVal
	 */
	public short getDbProvLinVal() {
		return dbProvLinVal;
	}

	/**
	 * @param dbProvLinVal the dbProvLinVal to set
	 */
	public void setDbProvLinVal(short dbProvLinVal) {
		this.dbProvLinVal = dbProvLinVal;
	}

	/**
	 * @return the dbRFRLInd
	 */
	public String getDbRFRLInd() {
		return dbRFRLInd;
	}

	/**
	 * @param dbRFRLInd the dbRFRLInd to set
	 */
	public void setDbRFRLInd(String dbRFRLInd) {
		this.dbRFRLInd = dbRFRLInd;
	}

	/**
	 * @return the dbPRCRTInd
	 */
	public String getDbPRCRTInd() {
		return dbPRCRTInd;
	}

	/**
	 * @param dbPRCRTInd the dbPRCRTInd to set
	 */
	public void setDbPRCRTInd(String dbPRCRTInd) {
		this.dbPRCRTInd = dbPRCRTInd;
	}

	/**
	 * @return the dbPRXSTNGInd
	 */
	public String getDbPRXSTNGInd() {
		return dbPRXSTNGInd;
	}

	/**
	 * @param dbPRXSTNGInd the dbPRXSTNGInd to set
	 */
	public void setDbPRXSTNGInd(String dbPRXSTNGInd) {
		this.dbPRXSTNGInd = dbPRXSTNGInd;
	}

	/**
	 * @return the dbUpdatedInd
	 */
	public char getDbUpdatedInd() {
		return dbUpdatedInd;
	}

	/**
	 * @param dbUpdatedInd the dbUpdatedInd to set
	 */
	public void setDbUpdatedInd(char dbUpdatedInd) {
		this.dbUpdatedInd = dbUpdatedInd;
	}

}