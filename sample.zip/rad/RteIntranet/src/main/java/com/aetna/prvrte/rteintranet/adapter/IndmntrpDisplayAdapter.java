/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.IndmntrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.IndmntrpVO;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class IndmntrpDisplayAdapter extends StoredProcedure {

	public IndmntrpDisplayAdapter() {}

	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(IndmntrpDisplayAdapter.class);
	
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	@SuppressWarnings("rawtypes")
	public IndmntrpDisplayAdapter(DataSource datasource, String storedProc) throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of IndmntrpAdapter : " + storedProc);
		//Input Params declaration
		declareParameter(new SqlParameter(DBConstants.LS_INDMNTY_CD, Types.CHAR));
		
		//Output Params declaration
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));

		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR4, new RowMapper() {
			/*
			 * (non-Javadoc)
			 * 
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet , int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1) throws SQLException {
			IndmntrpVO indmntrpVO = new IndmntrpVO();
			indmntrpVO.setDbIndmntyCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.INDMNTY_CD)));
			indmntrpVO.setDbIndmntyNm(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.INDMNTY_NM)));
			indmntrpVO.setDbIndmntyPRCRTInd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.INDMNTRP_PRCRT_IND)));
			indmntrpVO.setDbIndmntyRFRLInd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.INDMNTRP_RFRL_IND)));
			indmntrpVO.setDbIndmntyShrtNm(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.INDMNTY_SHRT_NM)));
			indmntrpVO.setDbPcpSelReqInd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.INDMNTRP_SELRQ_IND)));
			indmntrpVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
			return indmntrpVO;
			}
		}));
	}
	
	/**
	 * Method to get the Indmntrp list from data store.
	 * 
	 * @param indmntrp
	 *            String of aetna id.
	 * @return Map of Indmntrp list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getIndmntrpLookUpList(IndmntrpDTO indmntrpDTO) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering getIndmntrpLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<IndmntrpDTO> indmntrpList = new LinkedList<IndmntrpDTO>();
		String indmntrpMsg = "";
		try {
			
			String dbIndmntyCd = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyCd());
			//Query Param
			params.put(DBConstants.LS_INDMNTY_CD, dbIndmntyCd);
			log.info("Params for getting Indmntrp LookUp List : " + params);
			
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			if ("0".equals(sqlCode)){
				indmntrpList =  (ArrayList<IndmntrpDTO>) results.get(DBConstants.READ_CURSOR4);
				if (indmntrpList.isEmpty()){
					indmntrpMsg = "No Data on database for INDMNTRP Code: " + dbIndmntyCd;
				} else {
					indmntrpMsg = "Data found on database for INDMNTRP Code: " + dbIndmntyCd;
				}
			} else {
				indmntrpMsg = "Problem in DB2. sqlcode: " + sqlCode + " INDMNTRP Code: " + dbIndmntyCd ;
			}
			resultMap.put("indmntrpMsg", indmntrpMsg);
			resultMap.put("indmntrpList", indmntrpList);
			return resultMap;
			
		} catch (DataAccessException dae) {
			log.error("IndmntrpDisplayAdapter : Data access excpetion occured " + dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("IndmntrpDisplayAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
	}
}
