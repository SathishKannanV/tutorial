/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.SrchcolVO;
import com.aetna.prvrte.rteintranet.vo.SrchdtlVO;


/**
 * @author N731694
 * Cognizant_Offshore
 */
public class SrchcolAdapter extends StoredProcedure{

	private final Log log = LogFactory.getLog(SrchcolAdapter.class);
	
	private static final String LS_SRCHCOL_CD = "LS_SRCHCOL_CD";
	private static final String OUT_CODE = "OUT_CODE";
	private static final String LS_SQL_TYPE = "LS_SQL_TYPE";
	private static final String READ_CURSOR = "READ_CURSOR3";
	
	
	public SrchcolAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(LS_SRCHCOL_CD, Types.CHAR));  
		declareParameter(new SqlOutParameter(LS_SQL_TYPE, Types.INTEGER));
		
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;			
				SrchcolVO srchcolVO=new SrchcolVO();
				srchcolVO.setSrchcolCd(rs.getString("SRCHCOL_CD"));
				srchcolVO.setSrchcolDesc(rs.getString("SRCHCOL_DESC"));
				srchcolVO.setEffDate(rs.getString("SRCHCOL_EFF_DT"));
				srchcolVO.setExpDate(rs.getString("SRCHCOL_EXP_DT"));
				srchcolVO.setPostedDate(rs.getString("SRCHCOL_POSTED_DT"));
				srchcolVO.setUpdatedInd(updatedInd);
				
				return srchcolVO;
			}

		}));

	}
	
	
	
	@SuppressWarnings("unchecked")
	public Map getSrchcolLookUpTable (String srchcolCd) throws ApplicationException {
		log.debug("Entered SrchcolAdapter  - getSrchcolLookUpTable");
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map srchcolMap = new HashMap();
	
		params.put(LS_SRCHCOL_CD,RteIntranetUtils.getTrimmedString(srchcolCd));
		
		log.debug(params);
		Map results = null;
		
		List<SrchcolVO> srchcolList= new LinkedList<SrchcolVO>();
		String newMessage="";
		int noOfElements;
		try {
			log.debug("Srchdtl Adapter: Executing stored procedure :srchcolCd"+srchcolCd);
					
		 results = execute(params);
			
			log.debug("SrchcolAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(OUT_CODE));
			
			srchcolList = (List<SrchcolVO>) results
					.get(READ_CURSOR);	
	
			noOfElements = srchcolList.size();
			//if (null != results) {
			if (srchcolList.isEmpty()){
				
				if ("0".equals(sqlCode))
					newMessage = "No Data on database for srchcolCd " ;
			//		" || Second Search Id: " + srchscSecondId + " || Triple A Error Cd: " + srcherrCd + " || Member Search Column Cd " + srchcolCd;
				else
					newMessage = "Problem in DB2. sqlcode: " + sqlCode; 
			} else {
				if (noOfElements > 1) {
			    	newMessage = noOfElements + " Rows found for  srchcolCd " ;
				} else {
			    newMessage = noOfElements + " Row found for srchcolCd";
				}
				//newMessage = getMessage(newMessage, bicId, prov);
			}
			/*}else{
				newMessage = "You must enter a Procex Code with or without combination of Rider Code and/or Service Type Code on the Look Up page.";
			}*/
			srchcolMap.put("newMessage", newMessage);
			srchcolMap.put("srchcolList",srchcolList);
			return srchcolMap;
		}catch (Exception exception){
			log.error("SrchdtlAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	

}
