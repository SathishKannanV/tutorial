/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.RtePlnlmEXDAO;
import com.aetna.prvrte.rteintranet.dto.PlnlmEXDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.service.RtePlnlmEXService
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Service
public class RtePlnlmEXServiceImpl implements RtePlnlmEXService {
	/*
	 * Instance of RtePlnlmEXDAO.
	 */
	@Autowired(required=true)
	private RtePlnlmEXDAO rtePlnlmEXDAO;
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RtePlnlmEXService#getPlnlmEXLookUpList(com.aetna.prvrte.rteintranet.dto.PlnlmEXDTO)
	 */
	@Override
	public Map<String, Object> getPlnlmEXLookUpList(PlnlmEXDTO plnlmEXDTO) throws ApplicationException {
		return rtePlnlmEXDAO.getPlnlmEXLookUpList(plnlmEXDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RtePlnlmEXService#addPlnlmEXToDb(com.aetna.prvrte.rteintranet.dto.PlnlmEXDTO)
	 */
	@Override
	public Map<String, Object> addPlnlmEXToDb(PlnlmEXDTO plnlmEXDTO) throws ApplicationException {
		return rtePlnlmEXDAO.addPlnlmEXToDb(plnlmEXDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RtePlnlmEXService#deletePlnlmEX(java.lang.String)
	 */
	@Override
	public Map<String, Object> deletePlnlmEX(String  explntCd) throws ApplicationException {
		return rtePlnlmEXDAO.deletePlnlmEX(explntCd);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RtePlnlmEXService#addUpdatePlnlmEX(com.aetna.prvrte.rteintranet.dto.PlnlmEXDTO, java.util.List, int)
	 */
	@Override
	public Map<String, Object> addUpdatePlnlmEX(PlnlmEXDTO plnlmEXDTO, List<PlnlmEXDTO> plnlmEXList, int index) throws ApplicationException {
		return rtePlnlmEXDAO.addUpdatePlnlmEX(plnlmEXDTO, plnlmEXList, index);
	}
	

}
