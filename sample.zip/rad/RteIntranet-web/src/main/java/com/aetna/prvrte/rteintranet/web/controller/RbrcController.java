package com.aetna.prvrte.rteintranet.web.controller;

import java.sql.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.aetna.prvrte.rteintranet.dto.RbrcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.RbrcVO;
import com.aetna.prvrte.rteintranet.vo.RbrcVO;

/**
 * @author N657186
 * Cognizant_Offshore
 */

/**
 * @author N657186
 *
 */
@Controller
@RequestMapping(value = "/rbrc/*")
public class RbrcController {

	public static final String RBRC_HOME = ".rbrcHome";
	public static final String RBRC_LOOKUP = ".rbrcLookUp";
	public static final String RBRC_ADD = ".rbrcAdd";
	public static final String RBRC_HELP= ".rbrcHelp";
	private static final String STC_LIST = ".stcList";
	
	
	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(RbrcController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;
	
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/rbrcHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRbrcLookUpHome(final HttpServletRequest request,Model model) {
		log.warn("Entered RbrcController - getRbrcLookUpHome()");
		String securityLevel ="";
		try{
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(RBRC_HOME, "rbrcVO",  new RbrcVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("RbrcController - securityLevel: "+ securityLevel);
		log.warn("Exit from RbrcController - getRbrcLookUpHome()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RbrcController - getRbrcLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherRBRC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rbrcVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherRbrc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRbrcLookUp(final HttpServletRequest request, @ModelAttribute("rbrcForm")RbrcVO rbrcVO){
		log.warn("Entered RbrcController - getRbrcLookUp()");
		ModelAndView mav ;
		String securityLevel ="";
		Map rbrcResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<RbrcDTO> rbrcDtoList = new LinkedList<RbrcDTO>();
		List<RbrcVO> rbrcVoList = new LinkedList<RbrcVO>();
		try{
		RbrcDTO rbrcDTO = RTETranslator.toRbrcDTO(rbrcVO);
		rbrcResultMap = facade.getRbrcLookUp(rbrcDTO);
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		rbrcDtoList = (List<RbrcDTO>) rbrcResultMap.get("rbrcList");
		rbrcVoList = RTETranslator.toRbrcVOList(rbrcDtoList);
		lookUpListVO.setRbrcVOList(rbrcVoList);
		facade.getApplicationState().setRbrcList(rbrcVoList);
		
		log.warn("getRbrcLookUp - rbrcMessage: "+ rbrcResultMap.get("rbrcMessage"));
		mav = new ModelAndView(RBRC_LOOKUP, "lookUpListVO", lookUpListVO);
		mav.addObject("rbrcMessage", rbrcResultMap.get("rbrcMessage"));
		mav.addObject("securityLevel", securityLevel);
		log.warn("Exit from RbrcController - getRbrcLookUp()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in rbrcController - getrbrcLookUp() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (GatherRBRC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/AddNewRbrcRow", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView loadAddNewRbrcRowScreen(Model model, HttpServletRequest request) {	
		log.warn("Entered RbrcController - loadAddNewRbrcRowScreen()");
		try{
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			ModelAndView mav = new ModelAndView(RBRC_ADD, "rbrcVO",  new RbrcVO());
			mav.addObject("securityLevel", securityLevel);
			log.warn("Exit from RbrcController - loadAddNewRbrcRowScreen()");
			return mav;
		} catch (Exception e){
			log.error("Exception occured in RbrcController - loadAddNewRbrcRowScreen() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when loading AddNewRbrc. "+
					RteIntranetUtils.getTrimmedString(e.getMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rbrcVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddRbrc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addNewRbrc(final HttpServletRequest request, @ModelAttribute("addRbrcForm")RbrcVO rbrcVO){
		log.warn("Entered RbrcController - addNewRbrc()");
		String securityLevel ="";
		Map rbrcResultMap = new HashMap();
		List<RbrcDTO> rbrcDtoList = new LinkedList<RbrcDTO>();
		List<RbrcVO> rbrcVoList = new LinkedList<RbrcVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString();
			
			rbrcVO.setDbPostedDate(postedDate);
			rbrcVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
			RbrcDTO rbrcDTO = RTETranslator.toRbrcDTO(rbrcVO);
			rbrcResultMap = facade.addNewRbrc(rbrcDTO);
			
			if(rbrcResultMap.get("rbrcList")!=null){
				rbrcDtoList = (List<RbrcDTO>) rbrcResultMap.get("rbrcList");
				rbrcVoList = RTETranslator.toRbrcVOList(rbrcDtoList);
			}
			lookUpListVO.setRbrcVOList(rbrcVoList);
			facade.getApplicationState().setRbrcList(rbrcVoList);
			mav = new ModelAndView(RBRC_LOOKUP, "lookUpListVO", lookUpListVO);	
			mav.addObject("rbrcMessage", rbrcResultMap.get("rbrcMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("addNewRbrc - rbrcMessage: "+ rbrcResultMap.get("rbrcMessage"));
			log.warn("Exit from RbrcController - addNewRbrc()");
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in RbrcController - addNewRbrc() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when adding a row to the database (AddRBRC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	@RequestMapping(value="/rbrcHelp")
	public String loadRbrcHelp() {   
		return RBRC_HELP;
	}
	
	@RequestMapping(value="/stcList")
	public String loadStcList() {	   
		return STC_LIST;
	}
	
	
	/**
	 * @param rbrcVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteRbrc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView deleteRbrc(final HttpServletRequest request, @ModelAttribute("rbrcDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RbrcController - deleteRbrc()");
		ModelAndView mav ;
		String rbrcMsg = "";
		String securityLevel ="";
		boolean isRbrcDeleted = true;
		Map rbrcResultMap = new HashMap();
		RbrcDTO rbrcDTO = new RbrcDTO();
		List<RbrcVO> rbrcList = new LinkedList<RbrcVO>();
		
		try{
			 rbrcList = lookUpListVO.getRbrcVOList();
			int i;
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if ((rbrcList != null) && (takeAction != null)) {
				for(RbrcVO rbrcVO : rbrcList){
					if(rbrcVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rbrcVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
			
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);

					RbrcVO existingRbrc = (RbrcVO) rbrcList.get(i);
					if(existingRbrc!=null){
					if (existingRbrc.getDbUpdatedInd() != ApplicationConstants.COPY) {
						
						rbrcDTO = RTETranslator.toRbrcDTO(existingRbrc);
						
						rbrcResultMap = facade.deleteRbrc(rbrcDTO);
						
						rbrcMsg = (String) rbrcResultMap.get("rbrcMessage");
						isRbrcDeleted = (Boolean) rbrcResultMap.get("isRbrcDeleted");
						
						if(isRbrcDeleted){
							rbrcList.remove(i);
						}else{
							j = 0;
						}
					}else{
						rbrcList.remove(i);
					}	
					}
			}
				if(isRbrcDeleted)
					rbrcMsg = "Rows selected were Deleted in the database/list";
				
		}else
			rbrcMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRbrcList(rbrcList);
			lookUpListVO.setRbrcVOList(rbrcList);
			
			mav = new ModelAndView(RBRC_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rbrcMessage",rbrcMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteRbrc - rbrcMessage: "+ rbrcMsg);
		    log.warn("Exit from RbrcController - deleteRbrc()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RbrcController - deleteRbrc() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRBRC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rbrcVO
	 * @param takeAction
	 * @return
	 */
	@RequestMapping(value="/copyRbrc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView copyRbrc(final HttpServletRequest request,@ModelAttribute("rbrcDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RbrcController - copyRbrc()");
		ModelAndView mav ;
		String rbrcMsg = "";
		String securityLevel ="";
		int i;
		List<RbrcVO> rbrcList = new LinkedList<RbrcVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rbrcList = lookUpListVO.getRbrcVOList();
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString(); //Initialize Posted Date to today's date
			if ((rbrcList != null) && (takeAction != null)) {
				for(RbrcVO rbrcVO : rbrcList){
					if(rbrcVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rbrcVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					RbrcVO existingRbrc = (RbrcVO) rbrcList.get(i);
					
					RbrcVO copyRbrc = new RbrcVO(existingRbrc.getDbSiteCd(), existingRbrc.getDbRiderCd(), 
							existingRbrc.getDbSvcTypeCd(), postedDate,
							existingRbrc.getDbDescTxt(),existingRbrc.getDbIONtwkCd(), existingRbrc.getDbTOSCd(), 
							existingRbrc.getDbHMOSrcBnInd(), existingRbrc.getTextSendInd(),
							existingRbrc.getPrevCareInd(),existingRbrc.getGenderCd(), ApplicationConstants.COPY);
					rbrcList.add(copyRbrc);
				}
				rbrcMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				rbrcMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRbrcList(rbrcList);
			lookUpListVO.setRbrcVOList(rbrcList);
			mav = new ModelAndView(RBRC_LOOKUP, "lookUpListVO", lookUpListVO);

		    mav.addObject("rbrcMessage",rbrcMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyRbrc - rbrcMessage: "+ rbrcMsg);
		    log.warn("Exit from RbrcController - copyRbrc()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in RbrcController - copyRbrc() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRbrc). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	/**
	 * @param request
	 * @param rbrcVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateRbrc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addUpdateRbrc(final HttpServletRequest request, @ModelAttribute("rbrcDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RbrcController - addUpdateRbrc()");
		ModelAndView mav ;
		String rbrcMsg = "";
		List<RbrcVO> updatedRbrcList = new LinkedList<RbrcVO>();

	
		List<RbrcDTO> updatedRbrcDtoList = new LinkedList<RbrcDTO>();
		List<RbrcVO> rbrcVoList = new LinkedList<RbrcVO>();
		List<RbrcVO> modifiedRbrcVoList = new LinkedList<RbrcVO>();
		List<RbrcDTO> rbrcDtoList = new LinkedList<RbrcDTO>();
		RbrcDTO editedRbrcDTO = new RbrcDTO();
		Map rbrcResultMap = new HashMap();
		boolean isRbrcAddOrUpdated = false;
		String securityLevel ="";
		int i;
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rbrcVoList = facade.getApplicationState().getRbrcList();
			modifiedRbrcVoList = lookUpListVO.getRbrcVOList();
			
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString();
			if (takeAction != null && takeAction.length != 0) {
				if(rbrcVoList != null && rbrcVoList.size() != 0 
						&& modifiedRbrcVoList != null && modifiedRbrcVoList.size() != 0){
				for(RbrcVO rbrcVO : rbrcVoList){
					if(rbrcVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rbrcVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				rbrcDtoList = RTETranslator.toRbrcDTOList(rbrcVoList);
			
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					
					i = Integer.parseInt(takeAction[j]);
					RbrcVO seletedRbrc = (RbrcVO) rbrcVoList.get(i);
					RbrcVO editedRbrc = (RbrcVO) modifiedRbrcVoList.get(i);
					log.warn("addUpdateRbrc - user selected: "+ i);
					
										
					
					RbrcVO editedRbrcVO = new RbrcVO(editedRbrc.getDbSiteCd(), editedRbrc.getDbRiderCd(), 
							editedRbrc.getDbSvcTypeCd(), postedDate,
							editedRbrc.getDbDescTxt(),editedRbrc.getDbIONtwkCd(), editedRbrc.getDbTOSCd(), 
							editedRbrc.getDbHMOSrcBnInd(),editedRbrc.getTextSendInd(),
							editedRbrc.getPrevCareInd() ,editedRbrc.getGenderCd(), updatedInd);
					if(editedRbrcVO!=null){
					editedRbrcDTO = RTETranslator.toRbrcDTO(editedRbrcVO);
					}
					rbrcResultMap = facade.addUpdateRbrc(editedRbrcDTO, rbrcDtoList, i, seletedRbrc.getDbUpdatedInd());
					updatedRbrcDtoList = (List<RbrcDTO>) rbrcResultMap.get("rbrcDtoList");
					if(updatedRbrcDtoList!=null){
					updatedRbrcList = RTETranslator.toRbrcVOList(updatedRbrcDtoList);
					}
					isRbrcAddOrUpdated = (Boolean) rbrcResultMap.get("isrbrcAddorUpdated");
					rbrcMsg = (String) rbrcResultMap.get("rbrcMessage") ;
					if(!isRbrcAddOrUpdated){
						j = takeAction.length;
					}
				}
				
				if(isRbrcAddOrUpdated){
				rbrcMsg = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted.";
				String xSiteCd, ySiteCd, xRiderCd, yRiderCd, xSTC, ySTC;
				for (int x = updatedRbrcList.size() - 1 ; x > 0;  x--) {
					RbrcVO xRBRC = (RbrcVO) updatedRbrcList.get(x);
					xSiteCd= xRBRC.getDbSiteCd();
					xRiderCd= xRBRC.getDbRiderCd();
					xSTC = xRBRC.getDbSvcTypeCd();
					if (xRBRC.getDbUpdatedInd() != ApplicationConstants.COPY) {
						for (int y = x - 1; y > -1; y--) {
							RbrcVO yRBRC = (RbrcVO) updatedRbrcList.get(y);
							ySiteCd= yRBRC.getDbSiteCd();
							yRiderCd= yRBRC.getDbRiderCd();
							ySTC = yRBRC.getDbSvcTypeCd();
							if (xSiteCd.equals(ySiteCd) && xRiderCd.equals(yRiderCd) && xSTC.equals(ySTC)) {
								updatedRbrcList.remove(y); 
								x--;
							}
						}
					}
				}
				}
				lookUpListVO.setRbrcVOList(updatedRbrcList);
				facade.getApplicationState().setRbrcList(updatedRbrcList);
			} else {
				throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);
			}
		}else{
			rbrcMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setRbrcVOList(rbrcVoList);	
			facade.getApplicationState().setRbrcList(rbrcVoList);
		}
			mav = new ModelAndView(RBRC_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rbrcMessage",rbrcMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateRbrc - rbrcMessage: "+ rbrcMsg);
		    log.warn("Exit from RbrcController - addUpdateRbrc()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RbrcController - deleteRbrc() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRBRC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * Method to export Rbrc look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of rbrc object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/rbrcExport", method = RequestMethod.POST)
	public ModelAndView rbrcExport(HttpServletResponse response){
		List<RbrcVO> rbrcList = new LinkedList<RbrcVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String rbrcMsg="";
		try{
			rbrcList = facade.getApplicationState().getRbrcList();
			if(rbrcList != null && rbrcList.size() != 0){
			// Key map to create header
			Map<String,String> keyMap = new LinkedHashMap<String,String>();
			keyMap.put("dbSiteCd", "Site Code");
			keyMap.put("dbRiderCd", "Rider Code");
			keyMap.put("dbSvcTypeCd", "Svc Type");
			keyMap.put("dbDescTxt", "Description");
			keyMap.put("dbIONtwkCd", "IO Network Code");
			keyMap.put("dbTOSCd", "TOS Code");
			keyMap.put("dbHMOSrcBnInd", "True Ben Code Ind");
			keyMap.put("textSendInd", "Text Send Ind");
			keyMap.put("prevCareInd", "Prev Care Ind");
			keyMap.put("genderCd", "Gender Code");
			keyMap.put("dbPostedDate", "Posted Date");
			
			RteIntranetUtils.exportToExcel(response, rbrcList, keyMap);
			rbrcMsg = "LookUp table exported successfully.";
			} else {
				rbrcMsg = "No data found.";
			}
			lookUpTableListVO.setRbrcVOList(rbrcList);
	        mav = new ModelAndView(RBRC_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
		    mav.addObject("rbrcMessage",rbrcMsg);
			return mav;
		}catch (ApplicationException e) {
			log.error("Exception occured in RbrcController - rbrcExport() method:"
					+ e.getErrorMessage());
			String errorMsg = "Error encountered while export to excel. "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errormav;
		}
	}
}
