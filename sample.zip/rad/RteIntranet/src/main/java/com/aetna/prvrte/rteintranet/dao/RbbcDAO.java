/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.RbbcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author n657186
 * Cognizant_Offshore
 */
public interface RbbcDAO {

	Map getRbbcLookUp(RbbcDTO rbbcDTO) throws ApplicationException;
	
	Map addNewRbbc(RbbcDTO RbbcDTO) throws ApplicationException ;

	Map deleteRbbc(String RbbcCd, String svcTypeCd) throws ApplicationException ;

	Map addUpdateRbbc(RbbcDTO existRbbcDTO, List<RbbcDTO> rbbcDtoList, int index, char updateInd) throws ApplicationException ;

}
