/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;
import com.aetna.prvrte.rteintranet.dto.TosctDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public interface TosctService {

	/**
	 * 
	 * @param tosctDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map getTosctLookUpTable(TosctDTO tosctDTO) throws ApplicationException ;




	/**
	 * 
	 * @param tosctDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map addNewTosct(TosctDTO tosctDTO)throws ApplicationException ;



	/**
	 * 
	 * @param tosctDTO
	 * @return
	 * @throws ApplicationException
	 */
	Map deleteTosct(TosctDTO tosctDTO)throws ApplicationException ;

	/**
	 * 
	 * @param editedTosctDTO
	 * @param tosctDtoList
	 * @param index
	 * @param updateInd
	 * @return
	 * @throws ApplicationException
	 */
	Map addUpdateTosct(TosctDTO editedTosctDTO,  List<TosctDTO> tosctDtoList, int index,char updateInd)throws ApplicationException ;











}
