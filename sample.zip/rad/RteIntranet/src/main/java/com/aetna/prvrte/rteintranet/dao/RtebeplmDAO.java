/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.RtebeplmDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 *
 */
public interface RtebeplmDAO {
	Map getRtebeplmLookUpTable(RtebeplmDTO rtebeplmDTO) throws ApplicationException ;

	Map deleteRtebeplm(RtebeplmDTO rtebeplmDTO) throws ApplicationException ;

	Map addUpdateRtebeplm(RtebeplmDTO existRtebeplmDTO, List<RtebeplmDTO> rtebeplmDtoList, int index, char updateInd) throws ApplicationException ;

}
