package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.TierdMsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class TierdMsgAddAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(TierdMsgAddAdapter.class);
	private static final Pattern p = Pattern.compile("\\s");	
	private static final String EXPDT = "9999-12-31";
	private static final int MESSAGE_ID = 0;	
	
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public TierdMsgAddAdapter(DataSource datasource, String storedProc) throws SQLException{
		super(datasource, storedProc);
		declareParameter(new SqlParameter(DBConstants.TIERDMSG_TYPE_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.TIERDMSG_TIERST_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.TIERDMSG_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.TIERDMSG_EXP_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.ERSPMSG_ID, Types.INTEGER));
		declareParameter(new SqlParameter(DBConstants.ERSPMSG_MSGTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.ERSPMSG_SHORT_TXT, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.ERSPMSG_LONG_TXT, Types.VARCHAR));
		declareParameter(new SqlParameter(DBConstants.TIERDMSG_PSTD_DTS, Types.TIMESTAMP));
		declareParameter(new SqlParameter(DBConstants.TIERDMSG_USER_ID, Types.CHAR));

		declareParameter(new SqlOutParameter(DBConstants.ADD_UPD_IND, Types.DECIMAL));
		declareParameter(new SqlOutParameter(DBConstants.OUT_ERSPMSG_ID, Types.DECIMAL));
		declareParameter(new SqlOutParameter(DBConstants.SQLCODE, Types.INTEGER));
	}
	
	/**
	 * Method to add new TIERDMSG to data store.
	 * 
	 * @param tierdmsgDTO
	 *            tierdmsgDTO object.
	 * @return Map of added TIERDMSG data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addNewTierdMsg(TierdMsgDTO tierdmsgDTO) throws ApplicationException {
		
		log.warn("Entered TierdMsgAddAdapter  - addNewTierdMsg");
		String newMessage ="";
		String effDt=getCurrentDate();
		String expDt = EXPDT;
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map tierdmsgMap = new HashMap();
		Timestamp currentTS = new Timestamp(System.currentTimeMillis());
		String postedDate = currentTS.toString(); 
		tierdmsgDTO.setPostedDateTimeStamp(postedDate);
		tierdmsgDTO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
		tierdmsgDTO.setMessageId(MESSAGE_ID);
		tierdmsgDTO.setEffDt(effDt);
		tierdmsgDTO.setExpDt(expDt);
		params.put(DBConstants.TIERDMSG_TYPE_CD, RteIntranetUtils.getTrimmedString(tierdmsgDTO.getTierdMsgtypCd()));
		params.put(DBConstants.TIERDMSG_TIERST_CD, RteIntranetUtils.getTrimmedString(tierdmsgDTO.getTierdTierstCd()));
		params.put(DBConstants.TIERDMSG_EFF_DT, RteIntranetUtils.getTrimmedString(tierdmsgDTO.getEffDt()));
		params.put(DBConstants.TIERDMSG_EXP_DT, RteIntranetUtils.getTrimmedString(tierdmsgDTO.getExpDt()));
		params.put(DBConstants.ERSPMSG_ID, String.valueOf(tierdmsgDTO.getMessageId()));
		params.put(DBConstants.ERSPMSG_MSGTYP_CD, String.valueOf(tierdmsgDTO.getMessageTypeCd()));
		params.put(DBConstants.ERSPMSG_SHORT_TXT, RteIntranetUtils.getTrimmedString(tierdmsgDTO.getShortText()));
		params.put(DBConstants.ERSPMSG_LONG_TXT, RteIntranetUtils.getTrimmedString(tierdmsgDTO.getFullText()));
		params.put(DBConstants.TIERDMSG_PSTD_DTS, RteIntranetUtils.getTrimmedString(tierdmsgDTO.getPostedDateTimeStamp()));
		params.put(DBConstants.TIERDMSG_USER_ID, RteIntranetUtils.getTrimmedString(tierdmsgDTO.getUserId()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("TierdMsgAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.ADD_UPD_IND));
			
			String returnId =  String.valueOf(results
					.get(DBConstants.OUT_ERSPMSG_ID));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.SQLCODE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				tierdmsgDTO.setMessageId(Integer.parseInt(returnId));
				List<TierdMsgDTO> tierdmsgList = new LinkedList<TierdMsgDTO>();
				tierdmsgList.add(tierdmsgDTO);
				tierdmsgMap.put("tierdmsgList", tierdmsgList);
				if ("1".equalsIgnoreCase(actionCode))
					newMessage ="Row added to ERSPMSG only";
				else 
					if ("2".equalsIgnoreCase(actionCode))
						newMessage ="Row updated on ERSPMSG only";	
					else
						if ("3".equalsIgnoreCase(actionCode))
							newMessage ="Row added to TIERDMSG only";
						else
							if ("4".equalsIgnoreCase(actionCode))
								newMessage ="Row updated on TIERDMSG only";
							else
								if ("5".equalsIgnoreCase(actionCode))
									newMessage ="Rows added to ERSPMSG and TIERDMSG";
								else
									if ("6".equalsIgnoreCase(actionCode))
										newMessage ="Row added to ERSPMSG and updated on TIERDMSG";
									else
										if ("7".equalsIgnoreCase(actionCode))
											newMessage ="Row updated on ERSPMSG and added to TIERDMSG";
										else
											if ("8".equalsIgnoreCase(actionCode))
												newMessage ="Rows updated on ERSPMSG and TIERDMSG";
											else
												newMessage ="No changes made to TIERDMSG or ERSPMSG";
				}
			else {
				newMessage = "Unable to add or update row to the database. SQLCODE = " + sqlCode;
			}
			tierdmsgMap.put("tierdmsgMessage", newMessage);
		return tierdmsgMap;
	}catch (Exception exception){
		log.error("TierdMsgAddAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}
	
	/**
	 * Method to add/update list of TIERDMSG to data store.
	 * 
	 * @param existingTierdMsg
	 *            
	 * @param sstypaDtoList
	 *            list of TierdMsgDTO object.
	 * @param index
	 *            index to update the data
	 * @param updateInd
	 * 			  update indicator to update the data
	 * @return Map of flag to delete the data from TIERDMSG list, success or
	 *         error message and list of TIERDMSG.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addUpdateTierdMsg(TierdMsgDTO existingTierdMsg,
			List<TierdMsgDTO> tierdmsgDtoList, int index,char updateInd) throws ApplicationException{
		log.warn("Entered TierdMsgAddAdapter  - addUpdateTierdMsg");
		boolean isTierdMsgAddorUpdated = false;
		String newMessage ="";
		String msg = "All rows that changed the database are highlighted.";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map tierdmsgMap = new HashMap();
		Timestamp currentTS = new Timestamp(System .currentTimeMillis());
		String postedDate  = currentTS.toString();
		existingTierdMsg.setPostedDateTimeStamp(postedDate);
	try {
			params.put(DBConstants.TIERDMSG_TYPE_CD, containsUnprintableCharacters(existingTierdMsg.getTierdMsgtypCd()));
			params.put(DBConstants.TIERDMSG_TIERST_CD, containsUnprintableCharacters(existingTierdMsg.getTierdTierstCd()));
			params.put(DBConstants.TIERDMSG_EFF_DT, containsUnprintableCharacters(existingTierdMsg.getEffDt()));
			params.put(DBConstants.TIERDMSG_EXP_DT, containsUnprintableCharacters(existingTierdMsg.getExpDt()));
			params.put(DBConstants.ERSPMSG_ID, String.valueOf(existingTierdMsg.getMessageId()));
			params.put(DBConstants.ERSPMSG_MSGTYP_CD, containsUnprintableCharacters(existingTierdMsg.getMessageTypeCd()));
			params.put(DBConstants.ERSPMSG_SHORT_TXT, containsUnprintableCharacters(existingTierdMsg.getShortText()));
			params.put(DBConstants.ERSPMSG_LONG_TXT, containsUnprintableCharacters(existingTierdMsg.getFullText()));
			params.put(DBConstants.TIERDMSG_PSTD_DTS, RteIntranetUtils.getTrimmedString(existingTierdMsg.getPostedDateTimeStamp()));
			params.put(DBConstants.TIERDMSG_USER_ID, RteIntranetUtils.getTrimmedString(existingTierdMsg.getUserId()));
			log.warn(params);	
			results = execute(params);
			log.warn("TierdMsgAddAdapter: Executed stored procedure");
			String updatedInd =  String.valueOf(results
					.get(DBConstants.ADD_UPD_IND));
			String returnId =  String.valueOf(results
					.get(DBConstants.OUT_ERSPMSG_ID));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.SQLCODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				isTierdMsgAddorUpdated = true;
					existingTierdMsg.setMessageId(Integer.parseInt(returnId));
					if (!updatedInd.equalsIgnoreCase(ApplicationConstants.ZERO_0))
						tierdmsgDtoList.set(index, existingTierdMsg);
					if ("1".equalsIgnoreCase(updatedInd))
						newMessage ="Row added to ERSPMSG only." + msg;
					else if ("2".equalsIgnoreCase(updatedInd))
						newMessage ="Row updated on ERSPMSG only."+ msg;
					else if ("3".equalsIgnoreCase(updatedInd))         
						newMessage ="Row added to TIERDMSG only."+ msg;
					else if ("4".equalsIgnoreCase(updatedInd))
						newMessage ="Row updated on TIERDMSG only." + msg;
					else if ("5".equalsIgnoreCase(updatedInd))
						newMessage ="Rows added to ERSPMSG and TIERDMSG." + msg;
					else if ("6".equalsIgnoreCase(updatedInd))
						newMessage ="Row added to ERSPMSG and updated on TIERDMSG." + msg;
					else if ("7".equalsIgnoreCase(updatedInd))
						newMessage ="Row updated on ERSPMSG and added to TIERDMSG." + msg;
					else if ("8".equalsIgnoreCase(updatedInd))
						newMessage ="Rows updated on ERSPMSG and TIERDMSG." + msg;
					else
						newMessage ="No changes made to TIERDMSG or ERSPMSG";
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			tierdmsgMap.put("tierdmsgMsg",newMessage);
			tierdmsgMap.put("tierdmsgDtoList",tierdmsgDtoList);
			tierdmsgMap.put("isTierdMsgAddorUpdated", isTierdMsgAddorUpdated);
			return tierdmsgMap;
		}catch (Exception exception){
			log.error("TierdMsgAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
	
		private String getCurrentDate(){
			Calendar calendar = Calendar.getInstance() ;
			String curDate=null;
			int year =calendar.get(Calendar.YEAR);
			int month =calendar.get(Calendar.MONTH)+1;
			int day =calendar.get(Calendar.DAY_OF_MONTH);
			curDate=""+year+"-"+formatDate(month)+"-"+formatDate(day);
			return curDate;
		}
		private  String formatDate(int value){
			String fdate;
			if (value <10){
				fdate ="0"+value;
			}else{
				fdate =""+value;
			}
			return fdate;
		}


		/**
		 * This method is used replace the expression (\s) with whit space.
		 * 
		 * @param input
		 * @return
		 */
		private String replaceLinearWhiteSpace(String input) {
			return p.matcher(input).replaceAll(" ");
		}

		/**
		 * This method is used identify the unprintable characters in input string.
		 * 
		 * @param input
		 * @return
		 * @throws Exception
		 */
		private String containsUnprintableCharacters(String input) throws Exception {

			String s = input;
			int id = -1;
			char ch = 0;
			if (null != input) {
				s = replaceLinearWhiteSpace(input);

				for (int i = 0; i < s.length(); ++i) {
					ch = s.charAt(i);
					if ((ch < ' ') || (ch > '~')) {
						id = ch;
						break;
					}
				}
			}
			if (id != -1)
				throw new Exception(
						"Invalid parameter - Input parameter contains unprintable character.");
			else
				return s;
		}

		private String[] containsUnprintableCharacters(String[] input)
				throws Exception {
			int id = -1;
			char ch = 0;
			for (int j = 0; j < input.length; j++) {
				String s = replaceLinearWhiteSpace(input[j]);
				input[j] = s;

				for (int i = 0; i < s.length(); ++i) {
					ch = s.charAt(i);
					if ((ch < ' ') || (ch > '~')) {
						id = ch;
						break;
					}
				}
				if (id != -1)
					break;

			}

			if (id != -1)
				throw new Exception(
						"Invalid parameter - Input parameter contains unprintable character.");
			else
				return input;
		}


}