/**
 * 
 */
package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class RtetprlVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2939609083024455629L;
	private String stcCd = "";
	private String tosCd = "";
	private String posCd = "";
	private String groupCd = "";
	private String ruleCd = "";
	private String orderNo = "";
	private String effDate = "";
	private String expDate = "";
	private String postedDate = "";
	private String userId = "";
	private char   updatedInd;
	
	
	public RtetprlVO(String stcCd, String tosCd, String posCd, String groupCd, String ruleCd, String orderNo, String effDate,
			String expDate,	String postedDate, String userId, char updatedInd) {
		super();
		this.stcCd = stcCd;
		this.tosCd = tosCd;
		this.posCd = posCd;
		this.groupCd = groupCd;
		this.ruleCd = ruleCd;
		this.orderNo = orderNo;
		this.effDate = effDate;
		this.expDate = expDate;
		this.postedDate = postedDate;
		this.userId = userId;
		this.updatedInd = updatedInd;
	}
	
	public RtetprlVO() {
		super();
	}
	
	
	/**
	 * @return the stcCd
	 */
	public String getStcCd() {
		return stcCd;
	}
	/**
	 * @param stcCd the stcCd to set
	 */
	public void setStcCd(String stcCd) {
		this.stcCd = stcCd;
	}
	/**
	 * @return the tosCd
	 */
	public String getTosCd() {
		return tosCd;
	}
	/**
	 * @param tosCd the tosCd to set
	 */
	public void setTosCd(String tosCd) {
		this.tosCd = tosCd;
	}
	/**
	 * @return the posCd
	 */
	public String getPosCd() {
		return posCd;
	}
	/**
	 * @param posCd the posCd to set
	 */
	public void setPosCd(String posCd) {
		this.posCd = posCd;
	}
	/**
	 * @return the groupCd
	 */
	public String getGroupCd() {
		return groupCd;
	}
	/**
	 * @param groupCd the groupCd to set
	 */
	public void setGroupCd(String groupCd) {
		this.groupCd = groupCd;
	}
	/**
	 * @return the ruleCd
	 */
	public String getRuleCd() {
		return ruleCd;
	}
	/**
	 * @param ruleCd the ruleCd to set
	 */
	public void setRuleCd(String ruleCd) {
		this.ruleCd = ruleCd;
	}
	/**
	 * @return the orderNo
	 */
	public String getOrderNo() {
		return orderNo;
	}
	/**
	 * @param orderNo the orderNo to set
	 */
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}
	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	/**
	 * @return the expDate
	 */
	public String getExpDate() {
		return expDate;
	}
	/**
	 * @param expDate the expDate to set
	 */
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	/**
	 * @return the postedDate
	 */
	public String getPostedDate() {
		return postedDate;
	}
	/**
	 * @param postedDate the postedDate to set
	 */
	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the updatedInd
	 */
	public char getUpdatedInd() {
		return updatedInd;
	}
	/**
	 * @param updatedInd the updatedInd to set
	 */
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}
	
	
}
