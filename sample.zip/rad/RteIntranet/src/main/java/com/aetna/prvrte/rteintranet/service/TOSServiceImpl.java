/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.ProcexDAO;
import com.aetna.prvrte.rteintranet.dao.TOSDAO;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.TOSDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Service
public class TOSServiceImpl implements TOSService {
	@Autowired(required=true)
	private TOSDAO tosDAO;
	
	
	/**
	 * 
	 * @param tosDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map getTOSLookUpTable(TOSDTO tosDTO)
			throws ApplicationException {
		
		return tosDAO.getTOSLookUpTable(tosDTO);
	}

	/**
	 * 
	 * @param tosDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addNewTOS(TOSDTO tosDTO) throws ApplicationException {
		return tosDAO.addNewTOS(tosDTO);
	}

	/**
	 * 
	 * @param tosDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map deleteTOS(TOSDTO tosDTO) throws ApplicationException {
		return tosDAO.deleteTOS(tosDTO);
	}

	/**
	 * 
	 * @param editedTOSDTO
	 * @param tosDtoList
	 * @param index
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addUpdateTOS(TOSDTO editedTOSDTO, List<TOSDTO> tosDtoList, int index,char updatedInd)
			throws ApplicationException {
		return tosDAO.addUpdateTOS( editedTOSDTO,tosDtoList, index,updatedInd);
	}

}
