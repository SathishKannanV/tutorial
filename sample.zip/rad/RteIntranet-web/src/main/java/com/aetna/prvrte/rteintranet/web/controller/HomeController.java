package com.aetna.prvrte.rteintranet.web.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.vo.UserVO;

@Controller
public class HomeController {
	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(HomeController.class);

	@RequestMapping(value = "/home_unused", method = RequestMethod.GET)
	public ModelAndView getHomePage(Model model) {	   
		ModelAndView mav = new ModelAndView(".home", "userVO",  new UserVO());
		return mav;
	}
	
	
}