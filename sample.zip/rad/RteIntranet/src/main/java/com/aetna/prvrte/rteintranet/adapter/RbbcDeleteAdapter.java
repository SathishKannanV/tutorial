/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author n657186
 * Cognizant_Offshore
 */
public class RbbcDeleteAdapter extends StoredProcedure{

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RbbcDeleteAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RbbcDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_BNFT_ID_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_SVCTYP_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
	}
	
	@SuppressWarnings("unchecked")
	public Map deleteRbbc(String bnftIdCd, String svcTypeCd) throws ApplicationException {
		
		log.warn("Entered RbbcDeleteAdapter  - deleteRbbc");
		boolean isRbbcDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map rbbcMap = new HashMap();
			
		params.put(DBConstants.LS_BNFT_ID_CD, RteIntranetUtils.getTrimmedString(bnftIdCd));
		params.put(DBConstants.LS_SVCTYP_CD, RteIntranetUtils.getTrimmedString(svcTypeCd));
		
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("RbbcDeleteAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) 
				isRbbcDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			rbbcMap.put("rbbcMessage", newMessage);
			rbbcMap.put("isRbbcDeleted", isRbbcDeleted);
			return rbbcMap;
		}catch (Exception exception){
			
			log.error("RbbcDeleteAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	
	
}
