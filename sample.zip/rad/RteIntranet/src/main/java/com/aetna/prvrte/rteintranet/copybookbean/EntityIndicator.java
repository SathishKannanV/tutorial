package com.aetna.prvrte.rteintranet.copybookbean;


public class EntityIndicator {

	String individualInst;
	String nonIndividualInst;
	public String getIndividualInst() {
		
		return individualInst;
	}
	public void setIndividualInst(String individualInst) {
		
		this.individualInst = individualInst;
	}
	public String getNonIndividualInst() {
		
		return nonIndividualInst;
	}
	public void setNonIndividualInst(String nonIndividualInst) {
		
		this.nonIndividualInst = nonIndividualInst;
	}
	
	public StringBuilder getEntityIndicator(){
		return new StringBuilder(getIndividualInst())
		.append(getNonIndividualInst());
	}
}
