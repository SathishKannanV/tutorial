/* Created on Jan 26, 2008 */
package com.aetna.prvrte.rteintranet.vo;

/* @author A565267 */
import java.io.Serializable;
import java.util.ArrayList;

public class SbmrstSrapidtlVO implements Serializable {
	private String dbCoverageTypeCd = "";
	private String dbProgramName = "";
	private ArrayList dbEbsBenefitData = new ArrayList();
	
	public SbmrstSrapidtlVO(String coverageTypeCd, String programName, ArrayList ebsBenefitData)
	{
		super();
		dbCoverageTypeCd = coverageTypeCd;
		dbProgramName = programName;
		dbEbsBenefitData = ebsBenefitData;
	}

	public String getDbCoverageTypeCd() {
		return dbCoverageTypeCd;
	}

	public void setDbCoverageTypeCd(String dbCoverageTypeCd) {
		this.dbCoverageTypeCd = dbCoverageTypeCd;
	}

	public String getDbProgramName() {
		return dbProgramName;
	}

	public void setDbProgramName(String dbProgramName) {
		this.dbProgramName = dbProgramName;
	}

	public ArrayList getDbEbsBenefitData() {
		return dbEbsBenefitData;
	}

	public void setDbEbsBenefitData(ArrayList dbEbsBenefitData) {
		this.dbEbsBenefitData = dbEbsBenefitData;
	}
	
}
