package com.aetna.prvrte.rteintranet.copybookbean;

import java.util.List;

import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

public class DiganosisSet {

	String diganosisCtr;
	List<String> diganosisCode;
	public String getDiganosisCtr() {
		
		return diganosisCtr;
	}
	public void setDiganosisCtr(String diganosisCtr) {
		
		this.diganosisCtr = diganosisCtr;
	}
	public List<String> getDiganosisCode() {
		
		return diganosisCode;
	}
	public void setDiganosisCode(List<String> diganosisCode) {
		this.diganosisCode = diganosisCode;
	}
	public StringBuilder getDiganosisSet(){
		int popCount;
		StringBuilder type = new StringBuilder();
		
        popCount = getDiganosisCode().size();
       
		for(int i=0; i<popCount; i++) {
			
			type.append(RteIntranetUtils.spaceFiller(11, getDiganosisCode().get(i)));
		}
		for(int i=popCount; i<10; i++) {
			type.append(RteIntranetUtils.spaceFiller(11));
	}
		return type;
	
	
	}
	
}
