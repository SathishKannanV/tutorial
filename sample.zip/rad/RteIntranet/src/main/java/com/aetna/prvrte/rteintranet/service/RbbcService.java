/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.RbbcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author n657186
 * Cognizant_Offshore
 */
public interface RbbcService{

	Map getRbbcLookUp(RbbcDTO rbbcDTO) throws ApplicationException;;

	Map addNewRbbc(RbbcDTO rbbcDTO)throws ApplicationException ;

	Map deleteRbbc(String rbbcCd, String svcTypeCd) throws ApplicationException ;

	Map addUpdateRbbc(RbbcDTO existRbbcDTO, List<RbbcDTO> rbbcDtoList, int index, char updateInd) throws ApplicationException ;

}
