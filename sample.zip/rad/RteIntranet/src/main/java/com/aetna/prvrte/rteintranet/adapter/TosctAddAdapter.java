package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.TosctDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;


/**
 * @author N624926
 * Cognizant_Offshore
 */
public class TosctAddAdapter extends StoredProcedure{
	
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(TosctAddAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public TosctAddAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_STC_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_PNTFRMAGE_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(DBConstants.LS_PNTTOAGE_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(DBConstants.LS_PATIENTSX_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_TOS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_POS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_SPCLCOVG_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_ADA_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.TOSCT_AEXCEL, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.TOSCT_TOSCAT_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.TOSCT_PCPCVG_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.TOSCT_USAGE_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
	}
	
	/**
	 * Method to add new TOSCT to data store.
	 * 
	 * @param tosctDTO
	 *            tosctDTO object.
	 * @return Map of added TOSCT data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addNewTosct(TosctDTO tosctDTO) throws ApplicationException {
		log.warn("Entered TosctAddAdapter  - addNewTosct");
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map tosctMap = new HashMap();
		
		params.put(DBConstants.LS_STC_CD, RteIntranetUtils.getTrimmedString(tosctDTO.getDbSvcTypeCd()));
		params.put(DBConstants.LS_PNTFRMAGE_NO, RteIntranetUtils.getTrimmedString(tosctDTO.getDbPntfrmageNo()));
		params.put(DBConstants.LS_PNTTOAGE_NO, RteIntranetUtils.getTrimmedString(tosctDTO.getDbPnttoageNo()));
		params.put(DBConstants.LS_PATIENTSX_CD, RteIntranetUtils.getTrimmedString(tosctDTO.getDbPatientsxCd()));
		params.put(DBConstants.LS_TOS_CD, RteIntranetUtils.getTrimmedString(tosctDTO.getDbTosCd()));
		params.put(DBConstants.LS_POS_CD, RteIntranetUtils.getTrimmedString(tosctDTO.getDbPosCd()));
		params.put(DBConstants.LS_SPCLCOVG_CD, RteIntranetUtils.getTrimmedString(tosctDTO.getDbSpclcovgCd()));
		params.put(DBConstants.LS_ADA_CD, RteIntranetUtils.getTrimmedString(tosctDTO.getDbADACd()));
		params.put(DBConstants.TOSCT_AEXCEL, RteIntranetUtils.getTrimmedString(tosctDTO.getDbAxcelInd()));
		params.put(DBConstants.TOSCT_TOSCAT_CD, RteIntranetUtils.getTrimmedString(tosctDTO.getDbToscatCd()));
		params.put(DBConstants.TOSCT_PCPCVG_IND, RteIntranetUtils.getTrimmedString(tosctDTO.getDbPcpcovInd()));
		params.put(DBConstants.TOSCT_USAGE_CD, RteIntranetUtils.getTrimmedString(tosctDTO.getDbUsageCode()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("TosctAddAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			String actionCode =  String.valueOf(results
					.get(DBConstants.LS_ADD_UPDATE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				List<TosctDTO> tosctList = new LinkedList<TosctDTO>();
				tosctList.add(tosctDTO);
				tosctMap.put("tosctList", tosctList);
				if (ApplicationConstants.ZERO_0.equalsIgnoreCase(actionCode)) {
					newMessage = "This row added to the database";
				}else {
					newMessage ="Row already exists on the database. It was updated with these values.";					
					tosctDTO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
				}				
				}
			else {
				newMessage = "Unable to add row to the database. SQLCODE = " + sqlCode;
			}
			
			tosctMap.put("tosctMessage", newMessage);
		return tosctMap;
	}catch (Exception exception){
		log.error("TosctAddAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}

	/**
	 * Method to add/update list of TOSCT to data store.
	 * 
	 * @param existingTosct
	 *            
	 * @param tosctDtoList
	 *            list of TosctDTO object.
	 * @param index
	 *            index to update the data
	 * @param updateInd
	 * 			  update indicator to update the data
	 * @return Map of flag to delete the data from TOSCT list, success or
	 *         error message and list of TOSCT.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addUpdateTosct(TosctDTO existingTosct,
			List<TosctDTO> tosctDtoList, int index,char updateInd) throws ApplicationException{
		log.warn("Entered TosctAdapter  - addUpdateTosct");
		boolean isTosctAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map tosctMap = new HashMap();
		
		params.put(DBConstants.LS_STC_CD, RteIntranetUtils.getTrimmedString(existingTosct.getDbSvcTypeCd()));
		params.put(DBConstants.LS_PNTFRMAGE_NO, RteIntranetUtils.getTrimmedString(existingTosct.getDbPntfrmageNo()));
		params.put(DBConstants.LS_PNTTOAGE_NO, RteIntranetUtils.getTrimmedString(existingTosct.getDbPnttoageNo()));
		params.put(DBConstants.LS_PATIENTSX_CD, RteIntranetUtils.getTrimmedString(existingTosct.getDbPatientsxCd()));
		params.put(DBConstants.LS_TOS_CD, RteIntranetUtils.getTrimmedString(existingTosct.getDbTosCd()));
		params.put(DBConstants.LS_POS_CD, RteIntranetUtils.getTrimmedString(existingTosct.getDbPosCd()));
		params.put(DBConstants.LS_SPCLCOVG_CD, RteIntranetUtils.getTrimmedString(existingTosct.getDbSpclcovgCd()));
		params.put(DBConstants.LS_ADA_CD, RteIntranetUtils.getTrimmedString(existingTosct.getDbADACd()));
		params.put(DBConstants.TOSCT_AEXCEL, RteIntranetUtils.getTrimmedString(existingTosct.getDbAxcelInd()));
		params.put(DBConstants.TOSCT_TOSCAT_CD, RteIntranetUtils.getTrimmedString(existingTosct.getDbToscatCd()));
		params.put(DBConstants.TOSCT_PCPCVG_IND, RteIntranetUtils.getTrimmedString(existingTosct.getDbPcpcovInd()));
		params.put(DBConstants.TOSCT_USAGE_CD, RteIntranetUtils.getTrimmedString(existingTosct.getDbUsageCode()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("TosctAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				isTosctAddorUpdated = true;
				if (ApplicationConstants.ZERO_0.equalsIgnoreCase(actionCode)) {
					
					if (updateInd ==  ApplicationConstants.COPY)						
						tosctDtoList.set(index, existingTosct);						
					else
						tosctDtoList.add(existingTosct);
				}
				else{
				tosctDtoList.set(index, existingTosct);
				if (updateInd ==  ApplicationConstants.COPY)
					existingTosct.setDbUpdatedInd(ApplicationConstants.COPY);
				}
				newMessage = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted in RED";
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			tosctMap.put("tosctMsg",newMessage);
			tosctMap.put("tosctDtoList",tosctDtoList);
			tosctMap.put("isTosctAddorUpdated", isTosctAddorUpdated);
			return tosctMap;
		}catch (Exception exception){
			log.error("TosctAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}

}