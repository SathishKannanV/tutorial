package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RbrcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.RbrcVO;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class UserDisplayAdapter extends StoredProcedure{

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(UserDisplayAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public UserDisplayAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_SITE_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_RIDER_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_SVCTYP_CD, Types.CHAR));		
		declareParameter(new SqlParameter(DBConstants.LS_SQL_TYPE, Types.DECIMAL));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR3, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N; //Used by RBrCDisplay, not on database
				RbrcDTO rbrcDTO = new RbrcDTO();
				rbrcDTO.setDbSiteCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.SITE_CD)));
				rbrcDTO.setDbRiderCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RIDER_CD)));
				rbrcDTO.setDbSvcTypeCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RBRC_SVCTYP_CD)));
				rbrcDTO.setDbPostedDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RBRC_SRCE_PSTD_DT)));
				rbrcDTO.setDbDescTxt(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RBRC_DESC_TXT)));
				rbrcDTO.setDbIONtwkCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RBRC_IONTWK_CD)));
				rbrcDTO.setDbTOSCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOS_CD)));
				rbrcDTO.setDbHMOSrcBnInd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RBRC_HMOSRCBN_IND)));
				rbrcDTO.setTextSendInd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RBRC_TXT_SND_CD)));
				rbrcDTO.setPrevCareInd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.PREV_CARE_IND)));
				rbrcDTO.setGenderCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.GENDER_CD)));
				rbrcDTO.setDbUpdatedInd(updatedInd);
				return rbrcDTO;
			}

		}));

	}
	
	
	/**
	 * Method to get the RBRC list from data store.
	 * 
	 * @param rbrcDTO
	 * 			rbrcDTO parameter
	 * 
	 * @return Map of RBRC list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map getUserLookUpTable (RbrcDTO rbrcDTO) throws ApplicationException {
		log.warn("Entered UserDisplayAdapter  - getUserLookUpTable");
		int searchCd =3;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		String siteCode = RteIntranetUtils.getTrimmedString(rbrcDTO.getDbSiteCd());
		String riderCode = RteIntranetUtils.getTrimmedString(rbrcDTO.getDbRiderCd());
		String svcTypeCode = RteIntranetUtils.getTrimmedString(rbrcDTO.getDbSvcTypeCd());
		if (riderCode.equals(""))
			searchCd = 2;  
		Map rbrcMap = new HashMap();
		params.put(DBConstants.LS_SITE_CD, siteCode);
		params.put(DBConstants.LS_RIDER_CD, riderCode);
		params.put(DBConstants.LS_SVCTYP_CD, svcTypeCode);		
		params.put(DBConstants.LS_SQL_TYPE, String.valueOf(searchCd));		
		log.warn(params);
		
		Map results = null;		
		List<RbrcVO>rbrcList= new LinkedList<RbrcVO>();
		String newMessage="";
		try {
			log.warn("UserDisplayAdapter: Executing stored procedure : ");
					
			results = execute(params);
			log.warn("UserDisplayAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			rbrcList = (List<RbrcVO>) results
					.get(DBConstants.READ_CURSOR3);	
	
			if (rbrcList.isEmpty()){
				
				if (ApplicationConstants.ZERO_0.equals(sqlCode)) {

					newMessage = "No Data on database for User ID: " + riderCode ;
				} else {
					newMessage = "Problem in DB2. SQL Code: " + sqlCode + " || You asked for UserId  " + riderCode;
				}			  		  		  
			} else {
				newMessage = rbrcList.size() + " Row(s) found for requested User. " + riderCode;
				}
			rbrcMap.put("newMessage", newMessage);
			rbrcMap.put("rbrcList",rbrcList);
			return rbrcMap;
		}catch (Exception exception){
			log.error("UserDisplayAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
		

}
