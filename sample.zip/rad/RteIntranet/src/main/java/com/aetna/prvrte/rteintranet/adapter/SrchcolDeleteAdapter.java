/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.SrchcolDTO;
import com.aetna.prvrte.rteintranet.dto.SrchdtlDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.SrchcolVO;

/**
 * @author N731694
 * 
 */
public class SrchcolDeleteAdapter extends StoredProcedure {
	/**
	 * 
	 */
	public SrchcolDeleteAdapter() {
	}

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(SrchcolDeleteAdapter.class);
	private static final String LS_SRCHCOL_CD = "LS_SRCHCOL_CD";
	private static final String LS_SRCHCOL_EFF_DT = "LS_SRCHCOL_EFF_DT";
	private static final String LS_SQL_TYPE = "LS_SQL_TYPE";
	private static final String READ_CURSOR = "READ_CURSOR3";

	/**
	 * 
	 * @param datasource
	 * @param adasvctStoredProc
	 * @throws SQLException
	 */
	@SuppressWarnings("rawtypes")
	public SrchcolDeleteAdapter(DataSource datasource, String storedProc)
			throws SQLException {
		super(datasource, storedProc);
		log.info(" ------------------> " +storedProc);
		declareParameter(new SqlParameter(LS_SRCHCOL_CD, Types.CHAR));   
		declareParameter(new SqlParameter(LS_SRCHCOL_EFF_DT, Types.DATE));
		declareParameter(new SqlOutParameter(LS_SQL_TYPE, Types.INTEGER));
		//declareParameter(new SqlOutParameter(OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper()
		{
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;			
				SrchcolVO srchcolVO=new SrchcolVO();
				srchcolVO.setSrchcolCd(rs.getString("SRCHCOL_CD"));
				srchcolVO.setSrchcolDesc(rs.getString("SRCHCOL_DESC"));
				srchcolVO.setEffDate(rs.getString("SRCHCOL_EFF_DT"));
				srchcolVO.setExpDate(rs.getString("SRCHCOL_EXP_DT"));
				srchcolVO.setPostedDate(rs.getString("SRCHCOL_POSTED_DT"));
				srchcolVO.setUpdatedInd(updatedInd);
				
				return srchcolVO;
			}
		}));
	}


	@SuppressWarnings("unchecked")
	public Map deleteSrchcol(SrchcolDTO srchcolDTO) throws ApplicationException {
		
		log.debug("Entered SrchcolDeleteAdapter  - deleteSrchcol");
		boolean isSrchcolDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map srchcolMap = new HashMap();
		params.put(LS_SRCHCOL_CD, RteIntranetUtils.getTrimmedString(srchcolDTO.getSrchcolCd()));
		params.put(LS_SRCHCOL_EFF_DT, RteIntranetUtils.getTrimmedString(srchcolDTO.getEffDate()));
	
		log.debug(params);	
		try {
			results = execute(params);
			log.debug("SrchcolDeleteAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(LS_SQL_TYPE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) 
				isSrchcolDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			srchcolMap.put("srchcolMsg", newMessage);
			srchcolMap.put("isSrchcolDeleted", isSrchcolDeleted);
			return srchcolMap;
		}catch (Exception exception){
			
			log.error("SrchcolDeleteAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}


}
