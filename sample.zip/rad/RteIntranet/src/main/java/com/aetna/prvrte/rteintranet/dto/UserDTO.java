/**
 * 
 */
package com.aetna.prvrte.rteintranet.dto;

import java.io.Serializable;

/**
 * @author N657186
 *
 */
public class UserDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3378304167421298050L;
	private String securityLevel = "";
	private String name = "";
	private String aetnaId = "";
	private String dateSecLevPosted = "";
	
	public UserDTO() {
		super();
		setSecurityLevel("R");
		setName("Unknown User");
		setAetnaId("z000000");
		setDateSecLevPosted("0001-01-01");
	}
	
	/**
	 * @return the securityLevel
	 */
	public String getSecurityLevel() {
		return securityLevel;
	}
	/**
	 * @param securityLevel the securityLevel to set
	 */
	public void setSecurityLevel(String securityLevel) {
		this.securityLevel = securityLevel;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the aetnaId
	 */
	public String getAetnaId() {
		return aetnaId;
	}
	/**
	 * @param aetnaId the aetnaId to set
	 */
	public void setAetnaId(String aetnaId) {
		this.aetnaId = aetnaId;
	}
	/**
	 * @return the dateSecLevPosted
	 */
	public String getDateSecLevPosted() {
		return dateSecLevPosted;
	}
	/**
	 * @param dateSecLevPosted the dateSecLevPosted to set
	 */
	public void setDateSecLevPosted(String dateSecLevPosted) {
		this.dateSecLevPosted = dateSecLevPosted;
	}
	
	
	
	

}
