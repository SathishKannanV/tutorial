/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.BplvsDAO;
import com.aetna.prvrte.rteintranet.dto.BplvsDTO;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.SrchdtlDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.vo.BplvsVO;

/**
 * @author N657186
 * Cognizant_Offshore
 */
@Service
public class BplvsServiceImpl implements BplvsService {
	@Autowired(required=true)
	private BplvsDAO bplvsDAO;
	
	
	@Override
	public Map getBplvsLookUpTable(String bicId, String prov,String lineVal,String svcType)
			throws ApplicationException {
		
		return bplvsDAO.getBplvsLookUpTable(bicId, prov,lineVal,svcType);
	}

	@Override
	public Map addNewBplvs(BplvsDTO bplvsDTO) throws ApplicationException {
		
		return bplvsDAO.addNewBplvs(bplvsDTO);
	}

	
	@Override
	public Map deleteBplvs(BplvsDTO bplvsDTO) throws ApplicationException {
		return bplvsDAO.deleteBplvs(bplvsDTO);
	}

	@Override
	public Map addUpdateBplvs(BplvsDTO existBplvsDTO,
			List<BplvsDTO> bplvsDtoList, int index, char updateInd) throws ApplicationException {
		return bplvsDAO.addUpdateBplvs(existBplvsDTO,bplvsDtoList, index, updateInd);
	}


	public BplvsDAO getBplvsDAO() {
		return bplvsDAO;
	}

	public void setBplvsDAO(BplvsDAO bplvsDAO) {
		this.bplvsDAO = bplvsDAO;
	}



}
