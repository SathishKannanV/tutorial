/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.ProcexDAO;
import com.aetna.prvrte.rteintranet.dao.TosctDAO;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.TosctDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Service
public class TosctServiceImpl implements TosctService {
	@Autowired(required=true)
	private TosctDAO tosctDAO;
	
	
	/**
	 * 
	 * @param tosctDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map getTosctLookUpTable(TosctDTO tosctDTO)
			throws ApplicationException {
		
		return tosctDAO.getTosctLookUpTable(tosctDTO);
	}

	/**
	 * 
	 * @param tosctDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addNewTosct(TosctDTO tosctDTO) throws ApplicationException {
		return tosctDAO.addNewTosct(tosctDTO);
	}

	/**
	 * 
	 * @param tosctDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map deleteTosct(TosctDTO tosctDTO) throws ApplicationException {
		return tosctDAO.deleteTosct(tosctDTO);
	}

	/**
	 * 
	 * @param editedTosctDTO
	 * @param tosctDtoList
	 * @param index
	 * @param  updateInd
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addUpdateTosct(TosctDTO editedTosctDTO,
			List<TosctDTO> tosctDtoList, int index,char updateInd)
			throws ApplicationException {
		return tosctDAO.addUpdateTosct( editedTosctDTO,tosctDtoList, index, updateInd);
	}

}
