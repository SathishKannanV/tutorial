/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.BplvsDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.vo.BplvsVO;

/**
 * @author N731694
 *
 */
public interface BplvsDAO {

	Map getBplvsLookUpTable(String bicId, String prov,String lineVal,String svcType) throws ApplicationException ;
	
	Map addNewBplvs(BplvsDTO bplvsDTO) throws ApplicationException ;
	
	
	public Map deleteBplvs(BplvsDTO bplvsDTO)throws ApplicationException;


	Map addUpdateBplvs(BplvsDTO existBplvsDTO, List<BplvsDTO> bplvsDtoList, int index, char updateInd) throws ApplicationException ;

}

