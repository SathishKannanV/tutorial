/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class DedacsrDeleteAdapter extends StoredProcedure {
	
	public DedacsrDeleteAdapter() {}
	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(DedacsrAddAdapter.class);
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public DedacsrDeleteAdapter(DataSource datasource, String storedProc) throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of DedacsrAdapter : " + storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_RTESTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_DEFACUM_ACCUM_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
	}

	/**
	 * Method to delete the DEDACSR data from data store.
	 * 
	 * @param dbSvcTypeCd
	 *            String of dbSvcTypeCd.
	 * @param dbDefAccumCd
	 *            String of dbDefAccumCd.
	 * @return Map of flag to delete the data from DEDACSR list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	public Map<String, Object> deleteDedacsr(String dbSvcTypeCd, String dbDefAccumCd) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering getDedacsrLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		String newMessage = "";
		boolean isDedacsrDeleted = false;
		try {
			
			String defAccumCd = RteIntranetUtils.getTrimmedString(dbDefAccumCd);
			String svcTypeCd = RteIntranetUtils.getTrimmedString(dbSvcTypeCd);
			//Query params.
			params.put(DBConstants.LS_RTESTYP_CD, svcTypeCd);
			params.put(DBConstants.LS_DEFACUM_ACCUM_CD, defAccumCd);
			
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) 
				isDedacsrDeleted = true;
			else {
				newMessage = ApplicationConstants.DELETE_ROW_FAILS + sqlCode;
			}
				
			resultMap.put("dedacsrMsg", newMessage);
			resultMap.put("isDedacsrDeleted", isDedacsrDeleted);
			return resultMap;
		} catch (DataAccessException dae) {
			log.error("DedacsrDeleteAdapter : Data access excpetion occured "
					+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS,
					dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("DedacsrDeleteAdapter : generic error occured  "
					+ exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,
					exception.getMessage(), exception);
		} 
	}
}
