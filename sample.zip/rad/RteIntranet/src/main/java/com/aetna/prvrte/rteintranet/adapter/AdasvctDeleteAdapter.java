/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class AdasvctDeleteAdapter extends StoredProcedure {
	
	public AdasvctDeleteAdapter() {}

	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(AdasvctAddAdapter.class);

	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public AdasvctDeleteAdapter(DataSource datasource, String adasvctStoredProc)
			throws SQLException {
		super(datasource, adasvctStoredProc);
		log.info(" ------------------> " + adasvctStoredProc);
		declareParameter(new SqlParameter(DBConstants.LS_ADASVCT_ADA_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_ADASVCT_EFF_DT, Types.DATE));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
	}

	/**
	 * Method to delete the ADASVCT data from data store.
	 * 
	 * @param adaCd
	 *            String of adaCd.
	 * @param expDate
	 *            String of expiration data of adaCd.
	 * @return Map of flag to delete the data from ADASVCT list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	public Map<String, Object> deleteAdasvct(String adaCd, String effDate) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering getAdasvctLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		String newMessage = "";
		boolean isAdasvctDeleted = false;
		try {
			
			params.put(DBConstants.LS_ADASVCT_ADA_CD, RteIntranetUtils.getTrimmedString(adaCd));
			params.put(DBConstants.LS_ADASVCT_EFF_DT, RteIntranetUtils.getTrimmedString(effDate));

			log.info("Params to put new adavsct : " + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			
			if ("0".equals(sqlCode)){
				isAdasvctDeleted = true;
			} else {
				newMessage = ApplicationConstants.DELETE_ROW_FAILS + sqlCode;
			}
				
			resultMap.put("adasvctMsg", newMessage);
			resultMap.put("isAdasvctDeleted", isAdasvctDeleted);
			return resultMap;
		} catch (DataAccessException dae) {
			log.error("AdasvctDeleteAdapter : Data access excpetion occured "
					+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS,
					dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("AdasvctDeleteAdapter : generic error occured  "
					+ exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,
					exception.getMessage(), exception);
		} 
	}
}
