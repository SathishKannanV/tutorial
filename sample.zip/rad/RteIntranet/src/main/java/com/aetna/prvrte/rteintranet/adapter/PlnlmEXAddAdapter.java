/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.PlnlmEXDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.PlnlmEXVO;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class PlnlmEXAddAdapter extends StoredProcedure {

	public PlnlmEXAddAdapter() {}
	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(PlnlmEXAddAdapter.class);
	
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public PlnlmEXAddAdapter(DataSource datasource, String storedProc) throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of PlnlmEXAdapter : " + storedProc);
		//Input Params declaration
		declareParameter(new SqlParameter(DBConstants.PLNLMEX_EXPLNT_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.PLNLMEX_QLFR_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.PLNLMEX_RSPNSTP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.PLNLMEX_RSPNS_TXT, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.PLNLMEX_EPLC_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.PLNLMEX_TXT_SND_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.PLNLMEX_PLNLVL_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.PLNLMEX_FDB_IND, Types.CHAR));
		
		//Output Params declaration
		declareParameter(new SqlOutParameter(DBConstants.LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));

	}
	/**
	 * Method to add new PlnlmEX to data store.
	 * 
	 * @param plnlmEX
	 *            String of aetna id.
	 * @return Map of PlnlmEX list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	public Map<String, Object> addPlnlmEXToDb(PlnlmEXDTO plnlmEXDTO)throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<PlnlmEXVO> plnlmEXList = new LinkedList<PlnlmEXVO>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String plnlmEXMsg = "";
		try {
			String dbExplntCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbExplntCd());
			String dbQlfrCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbQlfrCd());
			String dbRspnstpCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbRspnstpCd());
			String dbRspnstpTxt = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbRspnstpTxt());
			String dbEligPerLmtCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbEligPerLmtCd());
			String dbTxtSndCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbTxtSndCd());
			String dbPlnLvlInd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbPlnLvlInd());
			String dbFdbInd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbFdbInd());
			char updatedInd= ApplicationConstants.UPDATE_IND_N;	
			
			//Query params
		
			
			params.put(DBConstants.PLNLMEX_EXPLNT_CD, dbExplntCd);
			params.put(DBConstants.PLNLMEX_QLFR_CD, dbQlfrCd);
			params.put(DBConstants.PLNLMEX_RSPNSTP_CD, dbRspnstpCd);
			params.put(DBConstants.PLNLMEX_RSPNS_TXT, dbRspnstpTxt);
			params.put(DBConstants.PLNLMEX_EPLC_CD, dbEligPerLmtCd);
			params.put(DBConstants.PLNLMEX_TXT_SND_CD, dbTxtSndCd);
			params.put(DBConstants.PLNLMEX_PLNLVL_IND, dbPlnLvlInd);
			params.put(DBConstants.PLNLMEX_FDB_IND, dbFdbInd);
			log.info("Params for getting PlnlmEX LookUp List : " + params);
			
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			String actionCode = String.valueOf(results.get(DBConstants.LS_ADD_UPDATE));
			if ("0".equals(sqlCode)) {
				if ("0".equals(actionCode))
					plnlmEXMsg = ApplicationConstants.ROW_ADDED;
				else {
					plnlmEXMsg = ApplicationConstants.ROW_ALREADY_EXISTS;
					updatedInd = ApplicationConstants.UPDATE_IND_Y;
				}
				
				plnlmEXMsg = ApplicationConstants.ROW_ADDED;
				PlnlmEXVO plnlmEXObj = new PlnlmEXVO(dbExplntCd, dbQlfrCd, dbRspnstpCd,
						dbRspnstpTxt, dbEligPerLmtCd, dbTxtSndCd,
						dbPlnLvlInd, dbFdbInd, updatedInd);
				plnlmEXList.add(plnlmEXObj);
			} else {
				plnlmEXMsg = ApplicationConstants.ADD_ROW_FAILS + sqlCode;
				
			}
			resultMap.put("plnlmEXMsg", plnlmEXMsg);
			resultMap.put("plnlmEXList", plnlmEXList);
		} catch (DataAccessException dae) {
			log.error("PlnlmEXAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("PlnlmEXAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
		return resultMap;
	}
	
	/**
	 * Method to add/update list of PlnlmEX to data store.
	 * 
	 * @param plnlmEXList
	 *            List of plnlmEX.
	 * @param takeAction
	 *            List of selected indexes to delete.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from PlnlmEX list, success or
	 *         error message and list of PlnlmEX.
	 * @throws ApplicationException
	 *             if insertion or update fails.
	 */
	public Map<String, Object> addUpdatePlnlmEX(PlnlmEXDTO plnlmEXDTO, List<PlnlmEXDTO> plnlmEXList, int index) throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String plnlmEXMsg = "";
		boolean isPlnlmEXAddorUpdated = false;
		boolean isAddUpdateCleanUp = false;
		try{
			String dbExplntCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbExplntCd());
			String dbQlfrCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbQlfrCd());
			String dbRspnstpCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbRspnstpCd());
			String dbRspnstpTxt = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbRspnstpTxt());
			String dbEligPerLmtCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbEligPerLmtCd());
			String dbTxtSndCd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbTxtSndCd());
			String dbPlnLvlInd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbPlnLvlInd());
			String dbFdbInd = RteIntranetUtils.getTrimmedString(plnlmEXDTO.getDbFdbInd());
			
			//Query params
			params.put(DBConstants.PLNLMEX_EXPLNT_CD, dbExplntCd);
			params.put(DBConstants.PLNLMEX_QLFR_CD, dbQlfrCd);
			params.put(DBConstants.PLNLMEX_RSPNSTP_CD, dbRspnstpCd);
			params.put(DBConstants.PLNLMEX_RSPNS_TXT, dbRspnstpTxt);
			params.put(DBConstants.PLNLMEX_EPLC_CD, dbEligPerLmtCd);
			params.put(DBConstants.PLNLMEX_TXT_SND_CD, dbTxtSndCd);
			params.put(DBConstants.PLNLMEX_PLNLVL_IND, dbPlnLvlInd);
			params.put(DBConstants.PLNLMEX_FDB_IND, dbFdbInd);
			
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			String actionCode =  String.valueOf(results.get(DBConstants.LS_ADD_UPDATE));
			if ("0".equalsIgnoreCase(sqlCode)) {
				isAddUpdateCleanUp = true;
				PlnlmEXDTO aPlnlmEXObj = new PlnlmEXDTO(dbExplntCd, dbQlfrCd, dbRspnstpCd,
						dbRspnstpTxt, dbEligPerLmtCd, dbTxtSndCd,
						dbPlnLvlInd, dbFdbInd, ApplicationConstants.UPDATE_IND_Y);
				plnlmEXMsg = ApplicationConstants.ADD_UPDATE_ROWS;
				if ("0".equals(actionCode)){
					if (plnlmEXDTO.getDbUpdatedInd() == ApplicationConstants.COPY){
						plnlmEXList.set(index, aPlnlmEXObj);
					} else {
						plnlmEXList.add(aPlnlmEXObj);
					}
				} else {
					plnlmEXList.set(index, aPlnlmEXObj);
				}
			}else {
				isPlnlmEXAddorUpdated = true;
				plnlmEXMsg = ApplicationConstants.ADD_UPDATE_ROW_FAILS + sqlCode;
			}
			resultMap.put("plnlmEXMsg", plnlmEXMsg);
			resultMap.put("plnlmEXList", plnlmEXList);
			resultMap.put("isPlnlmEXAddorUpdated", isPlnlmEXAddorUpdated);
			resultMap.put("isAddUpdateCleanUp", isAddUpdateCleanUp);
			return resultMap;
		}catch (DataAccessException dae) {
			log.error("PlnlmEXAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("PlnlmEXAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		}
	}
}
