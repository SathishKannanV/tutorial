/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.sql.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.ProcexVO;
import com.aetna.prvrte.rteintranet.vo.UserVO;

/**
 * @author N657186
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/procex/*")
public class ProcexController {

	public static final String PROCEX_HOME = ".procexHome";
	public static final String PROCEX_LOOKUP = ".procexLookUpDisplay";
	public static final String PROCEX_ADD = ".procexAdd";
	public static final String PROCEX_HELP= ".procexHelp";
	public static final String PROCEX_ST_LIST = ".stcList";

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(ProcexController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;
	
	@RequestMapping(value="/procexHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getProcexLookUpHome(final HttpServletRequest request,Model model) {	
		log.warn("Entered ProcexController - getProcexLookUpHome()");
		String securityLevel ="";
		try {
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(PROCEX_HOME, "ProcexVO",  new ProcexVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("ProcexController - securityLevel: "+ securityLevel);
		log.warn("Exit from ProcexController - getProcexLookUpHome()");
		return mav;
		} catch (ApplicationException e){
			log.error("Exception occured in ProcexController - getProcexLookUpTable() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherProcex", method = RequestMethod.POST)
	public ModelAndView getProcexLookUpTable(final HttpServletRequest request,@ModelAttribute("procexForm")ProcexVO procexVO){
		log.warn("Entered ProcexController - getProcexLookUpTable()");
		String procexCode ="";
		String svcTypeCode ="";
		String securityLevel ="";
		ModelAndView mav ;
		Map procexResultMap = new HashMap();
		List<ProcexVO> procexList = new LinkedList<ProcexVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		procexCode = procexVO.getDbProcexCd();
		svcTypeCode = procexVO.getDbSvcTypeCd();
		procexResultMap = facade.getProcexLookUpTable(procexCode, svcTypeCode);
		
		procexList = (List<ProcexVO>) procexResultMap.get("procexList");
		lookUpListVO.setProcexVOList(procexList);
		
		facade.getApplicationState().setProcexList(procexList);
		mav = new ModelAndView(PROCEX_LOOKUP, "lookUpListVO", lookUpListVO);
		mav.addObject("procexMessage", procexResultMap.get("newMessage"));
		mav.addObject("securityLevel", securityLevel);
	
		
		log.warn("getProcexLookUpTable - procexMessage: "+ procexResultMap.get("newMessage"));
		log.warn("Exit from ProcexController - getProcexLookUpTable()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in ProcexController - getProcexLookUpTable() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@RequestMapping(value="/AddNewProcexRow")
	public ModelAndView loadAddNewProcexRowScreen(final HttpServletRequest request,Model model)  {	
		log.warn("Entered ProcexController - loadAddNewProcexRowScreen()");
		ModelAndView mav = new ModelAndView(PROCEX_ADD, "ProcexVO",  new ProcexVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in ProcexController - loadAddNewProcexRowScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		log.warn("Exit from ProcexController - loadAddNewProcexRowScreen()");
		return mav;
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddProcex", method = RequestMethod.POST)
	public ModelAndView addNewProcex(final HttpServletRequest request, @ModelAttribute("addProcexForm")ProcexVO procexVO){
		log.warn("Entered ProcexController - addNewProcex()");
		ModelAndView mav ;
		String securityLevel ="";
		Map procexResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<ProcexDTO> procexDtoList = new LinkedList<ProcexDTO>();
		List<ProcexVO> procexVoList = new LinkedList<ProcexVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString();
			procexVO.setDbPostedDate(postedDate);
			procexVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
			ProcexDTO procexDTO = RTETranslator.toProcexDTO(procexVO);
			procexResultMap = facade.addNewProcex(procexDTO);
			
			if(procexResultMap.get("ProcexList")!=null){
				procexDtoList = (List<ProcexDTO>) procexResultMap.get("ProcexList");
				procexVoList = RTETranslator.toProcexVOList(procexDtoList);
			}
			
			lookUpListVO.setProcexVOList(procexVoList);
			facade.getApplicationState().setProcexList(procexVoList);
			mav = new ModelAndView(PROCEX_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("procexMessage", procexResultMap.get("procexMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("addNewProcex - procexMessage: "+ procexResultMap.get("procexMessage"));
			log.warn("Exit from ProcexController - addNewProcex()");			
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in ProcexController - addNewProcex() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when adding a row to the database (AddProcex). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	@RequestMapping(value="/procexHelp")
	public String loadProcexHelp() {   
		return PROCEX_HELP;
	}
	
	@RequestMapping(value="/procexSTlist")
	public String loadProcexSTList() {	   
		return PROCEX_ST_LIST;
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteProcex", method = RequestMethod.POST)
	public ModelAndView deleteProcex(final HttpServletRequest request,@ModelAttribute("procexDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered ProcexController - deleteProcex()");
		ModelAndView mav ;
		String procexMsg = "";
		boolean isProDeleted = true;
		String securityLevel ="";
		Map procexResultMap = new HashMap();
		List<ProcexVO> procexList = new LinkedList<ProcexVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			procexList = lookUpListVO.getProcexVOList();
			int i;
			
			if ((procexList != null) && (takeAction != null)) {
				for(ProcexVO procexVO : procexList){
					if(procexVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						procexVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);

					ProcexVO existingProcex = (ProcexVO) procexList.get(i);
					if (existingProcex.getDbUpdatedInd() != ApplicationConstants.COPY) {
						String procexCd = existingProcex.getDbProcexCd();
						String svcTypeCd = existingProcex.getDbSvcTypeCd();
						
						procexResultMap = facade.deleteProcex(procexCd, svcTypeCd);
						procexMsg = (String) procexResultMap.get("procexMsg");
						isProDeleted = (Boolean) procexResultMap.get("isProcxDeleted");
						
						if(isProDeleted){
							procexList.remove(i);
						}else{
							j = 0;
						}
					}else{
						procexList.remove(i);
					}				
			}
				if(isProDeleted)
					procexMsg = "Rows selected were Deleted in the database/list";
				
		}else
			procexMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setProcexList(procexList);
			lookUpListVO.setProcexVOList(procexList);
			mav = new ModelAndView(PROCEX_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("procexMessage",procexMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteProcex - procexMessage: "+ procexMsg);
		    log.warn("Exit from ProcexController - deleteProcex()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in ProcexController - deleteProcex() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessProcex). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	@RequestMapping(value="/copyProcex", method = RequestMethod.POST)
	public ModelAndView copyProcex(final HttpServletRequest request,@ModelAttribute("procexDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered from ProcexController - copyProcex()");
		ModelAndView mav ;
		String procexMsg = "";
		String securityLevel ="";
		int i;
		List<ProcexVO> procexList = new LinkedList<ProcexVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString(); //Initialize Posted Date to today's date
			procexList = lookUpListVO.getProcexVOList();
			if ((procexList != null) && (takeAction != null)) {
				for(ProcexVO procexVO : procexList){
					if(procexVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						procexVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					ProcexVO existingProcex = (ProcexVO) procexList.get(i);
					
					ProcexVO copyProcex = new ProcexVO(existingProcex.getDbProcexCd(), existingProcex.getDbSvcTypeCd(), 
							existingProcex.getDbDescTxt(),postedDate ,
							ApplicationConstants.COPY);
					procexList.add(copyProcex);
				}
				procexMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				procexMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setProcexList(procexList);
			lookUpListVO.setProcexVOList(procexList);
			mav = new ModelAndView(PROCEX_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("procexMessage",procexMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyProcex - procexMessage: "+ procexMsg);
		    log.warn("Exit from ProcexController - copyProcex()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in ProcexController - copyProcex() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessProcex). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateProcex", method = RequestMethod.POST)
	public ModelAndView addUpdateProcex(final HttpServletRequest request,@ModelAttribute("procexDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered from ProcexController - addUpdateProcex()");
		ModelAndView mav ;
		String procexMsg = "";
		String securityLevel ="";
		List<ProcexVO> updatedprocexList = new LinkedList<ProcexVO>();
		List<ProcexDTO> updatedProcexDtoList = new LinkedList<ProcexDTO>();
		List<ProcexVO> procexVoList = new LinkedList<ProcexVO>();
		List<ProcexVO> modifiedProcexVoList = new LinkedList<ProcexVO>();
		List<ProcexDTO> procexDtoList = new LinkedList<ProcexDTO>(); 
		boolean isProxAddOrUpdated = false;
		
		Map procexResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			 procexVoList = facade.getApplicationState().getProcexList();
			 modifiedProcexVoList = lookUpListVO.getProcexVOList();
			int i;
			
			
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString();
			
			
			if (takeAction != null && takeAction.length != 0) {
				if(procexVoList != null && procexVoList.size() != 0 &&
						modifiedProcexVoList != null && modifiedProcexVoList.size() != 0) {
				for(ProcexVO procexVO : procexVoList){
					if(procexVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						procexVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				procexDtoList = RTETranslator.toProcexDTOList(procexVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					ProcexVO seletedProcex = (ProcexVO) procexVoList.get(i);
					ProcexVO editedProcex = (ProcexVO) modifiedProcexVoList.get(i);
					ProcexVO editedProcexVO = new ProcexVO(editedProcex.getDbProcexCd(),editedProcex.getDbSvcTypeCd(),editedProcex.getDbDescTxt(),
							postedDate,updatedInd);
					//ProcexDTO existProcexDTO = RTETranslator.toProcexDTO(existingProcex);
					ProcexDTO editedProcexDTO = RTETranslator.toProcexDTO(editedProcexVO);
					procexResultMap = facade.addUpdateProcex(editedProcexDTO, procexDtoList, i , seletedProcex.getDbUpdatedInd());
					updatedProcexDtoList = (List<ProcexDTO>) procexResultMap.get("procexDtoList");
					updatedprocexList = RTETranslator.toProcexVOList(updatedProcexDtoList);
					isProxAddOrUpdated = (Boolean) procexResultMap.get("isProcxAddorUpdated") ;
					procexMsg = (String) procexResultMap.get("procexMsg") ;
					if(!isProxAddOrUpdated){
						j = takeAction.length;
					}
				}
				
				if(isProxAddOrUpdated){
					procexMsg = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted.";
					String xProcexCd, yProcexCd, xSTC, ySTC;
					for (int x = updatedprocexList.size() - 1 ; x > 0;  x--) {
						ProcexVO xProcex = (ProcexVO) updatedprocexList.get(x);
						xProcexCd= xProcex.getDbProcexCd();
						xSTC = xProcex.getDbSvcTypeCd();
						if (xProcex.getDbUpdatedInd() != 'C') {
							for (int y = x - 1; y > -1; y--) {
								ProcexVO yProcex = (ProcexVO) updatedprocexList.get(y);
								yProcexCd= yProcex.getDbProcexCd();
								ySTC = yProcex.getDbSvcTypeCd();
								if (xProcexCd.equals(yProcexCd) && xSTC.equals(ySTC)) {
									updatedprocexList.remove(y); 
									x--;
								}
							}
						}
					}
				}
				lookUpListVO.setProcexVOList(updatedprocexList);
				facade.getApplicationState().setProcexList(updatedprocexList);
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);
				}
		}else{
			procexMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setProcexVOList(procexVoList);
			facade.getApplicationState().setProcexList(procexVoList);
		}
			
			mav = new ModelAndView(PROCEX_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("procexMessage",procexMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateProcex - procexMessage: "+ procexMsg);
		    log.warn("Exit from ProcexController - addUpdateProcex()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in ProcexController - addUpdateProcex() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessProcex). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * Method to export Procex look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of procex object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/procexExport", method = RequestMethod.POST)
	public ModelAndView procexExport(HttpServletResponse response){
		List<ProcexVO> procexList = new LinkedList<ProcexVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String procexMsg="";
		try{
			procexList = facade.getApplicationState().getProcexList();
			if(procexList != null && procexList.size() != 0){
			// Key map to create header
			Map<String,String> keyMap = new LinkedHashMap<String,String>();
			keyMap.put("dbProcexCd", "Procex Code");
			keyMap.put("dbSvcTypeCd", "Svc Type");
			keyMap.put("dbDescTxt", "Description");
			keyMap.put("dbPostedDate", "Posted Date");
			
			RteIntranetUtils.exportToExcel(response, procexList, keyMap);
			procexMsg = "LookUp table exported successfully.";
			} else {
				procexMsg = "No data found.";
			}
			lookUpTableListVO.setProcexVOList(procexList);
	        mav = new ModelAndView(PROCEX_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
		    mav.addObject("procexMessage",procexMsg);
			return mav;
		}catch (ApplicationException e) {
			log.error("Exception occured in ProcexController - procexExport() method:"
					+ e.getErrorMessage());
			String errorMsg = "Error encountered while export to excel. "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errormav;
		}
	}
	
}
