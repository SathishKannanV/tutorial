/**
 * 
 */
package com.aetna.prvrte.rteintranet.util;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.vo.UserVO;


/**
 * @author N657186
 *
 */
public class RteIntranetUtils {
	/**
	* This method used to trim the string argument. If the string is null then
	* it will return blank value.
	* @param str
	* @return String
	* 
	*/
	private static final Log log = LogFactory
			.getLog(RteIntranetUtils.class);
	public static String getTrimmedString(String str) {
		if (str != null) {
			return str.trim();
		} else {
			return "";
		}
	}
	/**
	 * Method to return todays Date in the format of yyyy-MM-dd
	 * 
	 * @return string of current date.
	 */
	public static String getTodaysDate(){
		long systemTime = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(systemTime);
		String todaysDate = String.valueOf(date);
		return RteIntranetUtils.getTrimmedString(todaysDate);
	}
	/**
	 * Method to return todays Date in the format of yyyy-MM-dd HH:mm:ss
	 * 
	 * @return string of current date and time.
	 */
	public static String getTodaysDateTime(){
		long systemTime = System.currentTimeMillis();
		java.sql.Timestamp dateTime = new java.sql.Timestamp(systemTime);
		String todaysDateTime = String.valueOf(dateTime);
		return RteIntranetUtils.getTrimmedString(todaysDateTime);
		
		
	}
	
	/**
	 * Method to export the look up table to excel.
	 * 
	 * @param response
	 *            response object
	 * @param listToExport
	 *            list of object to export the look up table.
	 * @param keyMap
	 *            keyMap to create header.
	 * @throws IOException
	 *             IOException if write to export fails.
	 * @throws ApplicationException
	 *             ApplicationException if export fails.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void exportToExcel(HttpServletResponse response, List listToExport, Map<String,String> keyMap) throws ApplicationException{
		try{
			response.setContentType("application/csv");
			PrintWriter printWriter;
			printWriter = response.getWriter();
			response.reset();
			response.setHeader("Content-disposition", "attachment; filename=LookUpData.csv");
			response.setHeader("Cache-Control","private");
		    response.setHeader("Pragma","private");
			/*response.setHeader("Cache-Control", "no-cache");       
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setDateHeader("Expires", 0);*/ // Proxies.
			StringBuilder includeHeader = new StringBuilder();
			//excel header.
			for(String key :keyMap.keySet()){
				if(includeHeader != null && includeHeader.length() != 0) {
					includeHeader.append(ApplicationConstants.COMMA);
				}
				includeHeader.append(RteIntranetUtils.getTrimmedString(keyMap.get(key)));
			}
			//<< Placeholder for Defining Columns and Rows >>
			printWriter.println(includeHeader);
			//append content value
			for (int i = 0; i < listToExport.size(); i++) {
				StringBuilder contentValue = new StringBuilder();
				ObjectMapper mapper = new ObjectMapper();
				Object tempObj = listToExport.get(i);
				if(tempObj instanceof String){
					if(contentValue != null && contentValue.length() != 0) {
						contentValue.append(ApplicationConstants.COMMA);
					}
					contentValue.append(RteIntranetUtils.getTrimmedString(String.valueOf(listToExport.get(i))));
				} else {
					Map<String,Object> mapObject = mapper.convertValue(tempObj, Map.class);
					for (String mapKey : keyMap.keySet()) {
						if(contentValue != null && contentValue.length() != 0) {
							contentValue.append(ApplicationConstants.COMMA);
						}
						String mapValue = String.valueOf(mapObject.get(mapKey));
						mapValue = ApplicationConstants.DOUBLE_QUOTES + mapValue + ApplicationConstants.DOUBLE_QUOTES;
						contentValue.append(RteIntranetUtils.getTrimmedString(mapValue));
					}
				}
				
				printWriter.println(contentValue);
			}
			printWriter.flush();
			printWriter.close();
		} catch (IOException ioe) {
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, ioe.getMessage(), ioe);
		}catch (Exception e) {
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, e.getMessage(), e);
		}
	}
	
	/**
	 * Method to current user id.
	 * 
	 * @param request
	 * 		request Object.
	 * @return loggedIn user id.
	 */
	public static String getUserId(HttpServletRequest request) throws ApplicationException{
		String userId = "";
		try {
			HttpSession session = request.getSession(true);
			UserVO currentUser = (UserVO) session.getAttribute("user");
			userId = RteIntranetUtils.getTrimmedString(currentUser.getAetnaId());
			return userId;
		} catch (Exception e) {
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, e.getMessage(), e);
		}
	}
	/**
	 * Method to current user security level.
	 * 
	 * @param request
	 * 		request Object.
	 * @return loggedIn user security level.
	 */
	public static String getUserSecurityLevel(HttpServletRequest request) throws ApplicationException{
		String securityLevel = "";
		try {
			HttpSession session = request.getSession(true);
			//System.out.println("getUserSecurityLevel session : " + session  + " is session null " + (session == null));
			if(session != null){
				securityLevel = (String) session.getAttribute(ApplicationConstants.RTE_INTRANET_USER_ROLE);
				//System.out.println(securityLevel);
				//securityLevel = (securityLevel == null) ? securityLevel = "" : securityLevel;
			}
			return securityLevel;
		} catch (Exception e) {
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, e.getMessage(), e);
		}
		
	}
	
	public static String zeroFiller(int length, String value){
		if(value==null)
		{
			value="";
		}
		String paddedValue =StringUtils.leftPad(value, length, "0");
		return paddedValue;
	}
	
	/**
	 * @param length
	 * @param value
	 * @return
	 */
	public static String spaceFiller(int length, String value){
		
		String paddedValue =StringUtils.rightPad(value, length, " ");
		return paddedValue;
	}
public static String ZeroFiller(int length, String value){
		
		String paddedValue =StringUtils.leftPad(value, length, "0");
		return paddedValue;
	}
	public static String spaceCalculator(int length, String value){
		int lengString = value.length();
		int calcSpace = length - lengString;
		String paddedValue = "";
		paddedValue = spaceFiller(calcSpace, value);
		return paddedValue;
	}
	/**
	 * @param length
	 * @param value
	 * @return
	 */
	public static String spaceFiller(int length){
		StringBuilder paddedValue = new StringBuilder();
		for(int i = 0; i< length; i++){
			paddedValue.append(" ");
		}
		return paddedValue.toString();
	}
	
}
