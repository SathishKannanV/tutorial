/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.ProcexDAO;
import com.aetna.prvrte.rteintranet.dao.SitemsgDAO;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.SitemsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Service
public class SitemsgServiceImpl implements SitemsgService {
	
	@Autowired(required=true)
	private SitemsgDAO sitemsgDAO;
	
	
	@Override
	public Map getSitemsgLookUpTable(String siteCd, String svcTypeCode)
			throws ApplicationException {
		
		return sitemsgDAO.getSitemsgLookUpTable(siteCd, svcTypeCode);
	}


	/**
	 * 
	 * @param sitemsgDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addNewSitemsg(SitemsgDTO sitemsgDTO) throws ApplicationException {
		return sitemsgDAO.addNewSitemsg(sitemsgDTO);
	}

	/**
	 * 
	 * @param sitemsgDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map deleteSitemsg(SitemsgDTO sitemsgDTO) throws ApplicationException {
		return sitemsgDAO.deleteSitemsg(sitemsgDTO);
	}

	/**
	 * 
	 * @param editedSitemsgDTO
	 * @param sitemsgDtoList
	 * @param index
	 * @param updateInd
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addUpdateSitemsg(SitemsgDTO editedSitemsgDTO,
			List<SitemsgDTO> sitemsgDtoList, int index, char updateInd) throws ApplicationException {
		return sitemsgDAO.addUpdateSitemsg(editedSitemsgDTO,sitemsgDtoList, index,updateInd);
	}
	
	
	
/*
	@Override
	public Map addNewProcex(ProcexDTO procexDTO) throws ApplicationException {
		
		return procexDAO.addNewProcex(procexDTO);
	}


	@Override
	public Map deleteProcex(String procexCd, String svcTypeCd)
			throws ApplicationException {
		
		return procexDAO.deleteProcex(procexCd,svcTypeCd);
	}


	@Override
	public Map addUpdateProcex(ProcexDTO existProcexDTO,
			List<ProcexDTO> procexDtoList, int index) throws ApplicationException {
		return procexDAO.addUpdateProcex(existProcexDTO,procexDtoList, index);
	}*/

}
