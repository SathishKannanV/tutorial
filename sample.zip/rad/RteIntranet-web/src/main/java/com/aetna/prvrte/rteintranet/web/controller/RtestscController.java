package com.aetna.prvrte.rteintranet.web.controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.RtestscDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.RtestscVO;
import com.aetna.prvrte.rteintranet.vo.UserVO;


/**
 * @author N657186
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/rtestsc/*")
public class RtestscController {

	public static final String RTESTSC_HOME = ".rtestscHome";
	public static final String RTESTSC_LOOKUP = ".rtestscLookUp";
	public static final String RTESTSC_ADD = ".rtestscAddNew";
	
	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(RtestscController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/rtestscHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRtestscLookUpHome(final HttpServletRequest request, Model model) {
		log.warn("Entered RtestscController - getRtestscLookUpHome()");
		String securityLevel ="";
		try{
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(RTESTSC_HOME, "rtestscVO",  new RtestscVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("RtestscController - securityLevel: "+ securityLevel);
		log.warn("Exit from RtestscController - getRtestscLookUpHome()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtestscController - getRtestscLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherRTESTSC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rtestscVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherRtestsc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRtestscLookUp(HttpServletRequest request,@ModelAttribute("rtestscForm")RtestscVO rtestscVO){
		log.warn("Entered RtestscController - getRtestscLookUp()");
		ModelAndView mav ;
		Map rtestscResultMap = new HashMap();
		String securityLevel ="";
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<RtestscDTO> rtestscDtoList = new LinkedList<RtestscDTO>();
		List<RtestscVO> rtestscVoList = new LinkedList<RtestscVO>();
		try{
		RtestscDTO rtestscDTO = RTETranslator.toRtestscDTO(rtestscVO);
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		rtestscResultMap = facade.getRtestscLookUp(rtestscDTO);
		
		rtestscDtoList = (List<RtestscDTO>) rtestscResultMap.get("rtestscList");
		rtestscVoList = RTETranslator.toRtestscVOList(rtestscDtoList);
		lookUpListVO.setRtestscVOList(rtestscVoList);
		facade.getApplicationState().setRtestscList(rtestscVoList);
		log.warn("getRtestscLookUp - rtestscMessage: "+ rtestscResultMap.get("rbrcMessage"));
		mav = new ModelAndView(RTESTSC_LOOKUP, "lookUpListVO", lookUpListVO);
		mav.addObject("rtestscMessage", rtestscResultMap.get("rtestscMessage"));
			mav.addObject("securityLevel", securityLevel);
		log.warn("Exit from RtestscController - getRtestscLookUp()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in rtestscController - getrtestscLookUp() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherRTESTSC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/AddNewRtestscRow", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView loadAddNewRtestscRowScreen(final HttpServletRequest request,Model model) {	
		log.warn("Entered RtestscController - loadAddNewRtestscRowScreen()");
		ModelAndView mav = new ModelAndView(RTESTSC_ADD, "rtestscVO",  new RtestscVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in RtestscController - loadAddNewRtestscRowScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (loadAddNewRtestscRowScreen). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		log.warn("Exit from RtestscController - loadAddNewRtestscRowScreen()");
		return mav;
	}
	
	/**
	 * @param rtestscVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddRtestsc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addNewRtestsc(final HttpServletRequest request,@ModelAttribute("addRtestscForm")RtestscVO rtestscVO){
		log.warn("Entered RtestscController - addNewRtestsc()");
		
		String securityLevel ="";
		Map rtestscResultMap = new HashMap();
		List<RtestscDTO> rtestscDtoList = new LinkedList<RtestscDTO>();
		List<RtestscVO> rtestscVoList = new LinkedList<RtestscVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDate = currentTS.toString(); //Initialize Posted Date to the current timestamp
			rtestscVO.setPostedDateTimestamp(postedDate);
			rtestscVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
			RtestscDTO rtestscDTO = RTETranslator.toRtestscDTO(rtestscVO);
			rtestscResultMap = facade.addNewRtestsc(rtestscDTO);
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if(rtestscResultMap.get("rtestscList")!=null){
				rtestscDtoList = (List<RtestscDTO>) rtestscResultMap.get("rtestscList");
				rtestscVoList = RTETranslator.toRtestscVOList(rtestscDtoList);
			}
			lookUpListVO.setRtestscVOList(rtestscVoList);
			facade.getApplicationState().setRtestscList(rtestscVoList);
			mav = new ModelAndView(RTESTSC_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("securityLevel", securityLevel);
			mav.addObject("rtestscMessage", rtestscResultMap.get("rtestscMessage"));
			
			log.warn("addNewRtestsc - rtestscMessage: "+ rtestscResultMap.get("rtestscMessage"));
			log.warn("Exit from RtestscController - addNewRtestsc()");
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in RtestscController - addNewRtestsc() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when adding a row to the database (AddRTESTSC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * @param rtestscVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteRtestsc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView deleteRtestsc(final HttpServletRequest request,@ModelAttribute("rtestscDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtestscController - deleteRtestsc()");
		ModelAndView mav ;
		String rtestscMsg = "";
		boolean isRtestscDeleted = true;
		String securityLevel ="";
		Map rtestscResultMap = new HashMap();
		
		List<RtestscVO> rtestscVoList = new LinkedList<RtestscVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtestscVoList = lookUpListVO.getRtestscVOList();
			int i;
			
			if ((rtestscVoList != null) && (takeAction != null)) {
			
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);

					RtestscVO existingRtestsc = (RtestscVO) rtestscVoList.get(i);
					if (existingRtestsc.getUpdatedInd() != ApplicationConstants.COPY) {
						RtestscDTO rtestscDTO = RTETranslator.toRtestscDTO(existingRtestsc);
						
						rtestscResultMap = facade.deleteRtestsc(rtestscDTO);
						rtestscMsg = (String) rtestscResultMap.get("rtestscMessage");
						isRtestscDeleted = (Boolean) rtestscResultMap.get("isRtestscDeleted");
						
						if(isRtestscDeleted){
							rtestscVoList.remove(i);
						}else{
							j = 0;
						}
					}else{
						rtestscVoList.remove(i);
					}				
			}
				if(isRtestscDeleted)
					rtestscMsg = "Rows selected were Deleted in the database/list";
				
		}else
			rtestscMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRtestscList(rtestscVoList);
			lookUpListVO.setRtestscVOList(rtestscVoList);
			
			mav = new ModelAndView(RTESTSC_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtestscMessage",rtestscMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteRtestsc - rtestscMessage: "+ rtestscMsg);
		    log.warn("Exit from RtestscController - deleteRtestsc()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtestscController - deleteRtestsc() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRTESTSC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rtestscVO
	 * @param takeAction
	 * @return
	 */
	@RequestMapping(value="/copyRtestsc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView copyRtestsc(HttpServletRequest request, @ModelAttribute("rtestscDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtestscController - copyRtestsc()");
		ModelAndView mav ;
		String rtestscMsg = "";
		String securityLevel ="";
		int i;
		List<RtestscVO> rtestscVoList = new LinkedList<RtestscVO>();
		try{
			HttpSession session = request.getSession(true);
			UserVO currentUser = (UserVO) session.getAttribute("user");
			String userId = currentUser.getAetnaId(); 
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDateTimeStamp = currentTS.toString(); 
			rtestscVoList = lookUpListVO.getRtestscVOList();
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if ((rtestscVoList != null) && (takeAction != null)) {
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					RtestscVO existingRtestsc = (RtestscVO) rtestscVoList.get(i);
					
					RtestscVO copyRtestsc = new RtestscVO(existingRtestsc.getSvcTypeCd(), existingRtestsc.getScsrSvcTypeCd(),existingRtestsc.getScsrServiceCd(), 
							existingRtestsc.getEffDate(),existingRtestsc.getStscDescTxt(), existingRtestsc.getExpDate(),postedDateTimeStamp,
							userId, ApplicationConstants.COPY);
					rtestscVoList.add(copyRtestsc);
				}
				rtestscMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				rtestscMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRtestscList(rtestscVoList);
			lookUpListVO.setRtestscVOList(rtestscVoList);
			mav = new ModelAndView(RTESTSC_LOOKUP, "lookUpListVO", lookUpListVO);
			
		    mav.addObject("rtestscMessage",rtestscMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyRtestsc - rtestscMessage: "+ rtestscMsg);
		    log.warn("Exit from RtestscController - copyRtestsc()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in RtestscController - copyRtestsc() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRtestsc). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	/**
	 * @param request
	 * @param rtestscVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateRtestsc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addUpdateRtestsc(HttpServletRequest request,@ModelAttribute("rtestscDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtestscController - addUpdateRtestsc()");
		ModelAndView mav ;
		String rtestscMsg = "";
		List<RtestscVO> updatedRtestscList = new LinkedList<RtestscVO>();
		String securityLevel ="";
		List<RtestscDTO> updatedRtestscDtoList = new LinkedList<RtestscDTO>();
		List<RtestscVO> rtestscVoList = new LinkedList<RtestscVO>();
		List<RtestscVO> modifiedRtestscVoList = new LinkedList<RtestscVO>();
		List<RtestscDTO> rtestscDtoList = new LinkedList<RtestscDTO>();
		RtestscDTO editedRtestscDTO = new RtestscDTO();
		Map rtestscResultMap = new HashMap();
		boolean isRtestscAddOrUpdated = false;
		
		
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtestscVoList = facade.getApplicationState().getRtestscList();
			modifiedRtestscVoList = lookUpListVO.getRtestscVOList();
			int i;
			
			HttpSession session = request.getSession(true);
			UserVO currentUser = (UserVO) session.getAttribute("user");
			String userId = currentUser.getAetnaId(); 
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDateTimeStamp = currentTS.toString(); 
			
			
			if (takeAction != null && takeAction.length != 0) {
				if(rtestscVoList != null && rtestscVoList.size() != 0 
						&& modifiedRtestscVoList.size() != 0 && modifiedRtestscVoList != null){
				for(RtestscVO rtestscVO : rtestscVoList){
					if(rtestscVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtestscVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				rtestscDtoList = RTETranslator.toRtestscDTOList(rtestscVoList);
				
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					
					i = Integer.parseInt(takeAction[j]);
					RtestscVO seletedRtestsc = (RtestscVO) rtestscVoList.get(i);
					RtestscVO editedRtestsc = (RtestscVO) modifiedRtestscVoList.get(i);
					log.warn("addUpdateRtestsc - user selected: "+ i);
					RtestscVO editedRtestscVO = new RtestscVO(editedRtestsc.getSvcTypeCd(), editedRtestsc.getScsrSvcTypeCd(),editedRtestsc.getScsrServiceCd(), 
							editedRtestsc.getEffDate(),editedRtestsc.getStscDescTxt(), editedRtestsc.getExpDate(),postedDateTimeStamp,
							userId, updatedInd);
					
					if(editedRtestscVO!=null){
					editedRtestscDTO = RTETranslator.toRtestscDTO(editedRtestscVO);
					}
					rtestscResultMap = facade.addUpdateRtestsc(editedRtestscDTO, rtestscDtoList, i, seletedRtestsc.getUpdatedInd());
					updatedRtestscDtoList = (List<RtestscDTO>) rtestscResultMap.get("rtestscDtoList");
					if(updatedRtestscDtoList!=null){
					updatedRtestscList = RTETranslator.toRtestscVOList(updatedRtestscDtoList);
					}
					 isRtestscAddOrUpdated = (Boolean) rtestscResultMap.get("isrtestscAddorUpdated");
					rtestscMsg = (String) rtestscResultMap.get("rtestscMessage") ;
					if(!isRtestscAddOrUpdated){
						j = takeAction.length;
					}
				}
				
				if(isRtestscAddOrUpdated){
					rtestscMsg = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted.";
					String xSvcTypeCd, ySvcTypeCd, xEffDate, yEffDate;
					for (int x = updatedRtestscList.size() - 1 ; x > 0;  x--) {
						RtestscVO xRtestsc = (RtestscVO) updatedRtestscList.get(x);
						xSvcTypeCd = xRtestsc.getSvcTypeCd();
						xEffDate = xRtestsc.getEffDate();
						if (xRtestsc.getUpdatedInd() != 'C') {
							for (int y = x - 1; y > -1; y--) {
								RtestscVO aRtestsc = (RtestscVO) updatedRtestscList.get(y);
								ySvcTypeCd = aRtestsc.getSvcTypeCd();
								yEffDate = aRtestsc.getEffDate();
								if (xSvcTypeCd.equals(ySvcTypeCd) && xEffDate.equals(yEffDate)) {
									updatedRtestscList.remove(y); 
									x--;
								}
							}
						}
					}
				}
				lookUpListVO.setRtestscVOList(updatedRtestscList);
				facade.getApplicationState().setRtestscList(updatedRtestscList);
			} else {
				throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);				
			}
		}else{
			rtestscMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setRtestscVOList(rtestscVoList);	
			facade.getApplicationState().setRtestscList(rtestscVoList);
		}
			
			mav = new ModelAndView(RTESTSC_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtestscMessage",rtestscMsg);
			mav.addObject("securityLevel", securityLevel);
		    
		    log.warn("addUpdateRtestsc - rtestscMessage: "+ rtestscMsg);
		    log.warn("Exit from RtestscController - addUpdateRtestsc()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtestscController - deleteRtestsc() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRTESTSC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
     * Method to export Rtestsc look up table to excel work book
     * 
      * @param lookUpTableListVO
     *            list of rtestsc object.
     * @param response
     *            response object to return
     * @return exported file to view.
     */
     @RequestMapping(value = "/rtestscExport", method = RequestMethod.POST)
     public ModelAndView rtestscExport(HttpServletResponse response){
           List<RtestscVO> rtestscList = new LinkedList<RtestscVO>();
           LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
           String rtestscMsg="";
           try{
                 rtestscList = facade.getApplicationState().getRtestscList();
                 if(rtestscList != null && rtestscList.size() != 0){
                 // Key map to create header
                 Map<String,String> keyMap = new LinkedHashMap<String,String>();
                 keyMap.put("svcTypeCd", "SVC Type Cd");
                 keyMap.put("scsrSvcTypeCd", "SCSR SVC Type Cd");
                 keyMap.put("scsrServiceCd", "Service Code");
                 keyMap.put("stscDescTxt", "Description Type");
                 keyMap.put("effDate", "Effective Date");
                 keyMap.put("expDate", "Expiration Date");
                 keyMap.put("postedDateTimestamp", "Posted Date");
                 keyMap.put("userId", "User Id");
                 RteIntranetUtils.exportToExcel(response, rtestscList, keyMap);
                 rtestscMsg = "LookUp table exported successfully.";
                 } else {
                       rtestscMsg = "No data found.";
                 }
                 lookUpTableListVO.setRtestscVOList(rtestscList);
                 mav = new ModelAndView(RTESTSC_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
                 mav.addObject("rtestscMessage",rtestscMsg);
                 return mav;
           }catch (ApplicationException e) {
                 log.error("Exception occured in RtestscController - rtestscExport() method:" + e.getMessage());
                 String errorMsg = "Error encountered while export to excel. ";
                 errorMsg.concat(e.toString());
                 errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
                 errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
                 return errormav;
           }
     }

	
}




