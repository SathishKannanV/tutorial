package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;

/**
 * @author N726899
 *
 */
public class PlnlmEXVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 132825532936153746L;
	private String dbExplntCd = "";
	private String dbQlfrCd = "";
	private String dbRspnstpCd = "";
	private String dbRspnstpTxt = "";
	private String dbEligPerLmtCd = "";
	private String dbTxtSndCd = "";
	private String dbPlnLvlInd = "";
	private String dbFdbInd = "";
	private char dbUpdatedInd;

	/**
	 * Constructor for TOSCT
	 */
	public PlnlmEXVO() {
		super();
	}

	// setters
	public PlnlmEXVO(String explntCd, String qlfrCd, String rspnstpCd,
			String rspnstpTxt, String eligPerLmtCd, String txtSndCd,
			String plnLvlInd, String fdbInd,

			char updatedInd) {
		super();
		setDbExplntCd(explntCd);
		setDbQlfrCd(qlfrCd);
		setDbRspnstpCd(rspnstpCd);
		setDbRspnstpTxt(rspnstpTxt);
		setDbEligPerLmtCd(eligPerLmtCd);
		setDbTxtSndCd(txtSndCd);
		setDbPlnLvlInd(plnLvlInd);
		setDbFdbInd(fdbInd);
		setDbUpdatedInd(updatedInd);
	}

	/**
	 * @return the dbExplntCd
	 */
	public String getDbExplntCd() {
		return dbExplntCd;
	}

	/**
	 * @param dbExplntCd the dbExplntCd to set
	 */
	public void setDbExplntCd(String dbExplntCd) {
		this.dbExplntCd = dbExplntCd;
	}

	/**
	 * @return the dbQlfrCd
	 */
	public String getDbQlfrCd() {
		return dbQlfrCd;
	}

	/**
	 * @param dbQlfrCd the dbQlfrCd to set
	 */
	public void setDbQlfrCd(String dbQlfrCd) {
		this.dbQlfrCd = dbQlfrCd;
	}

	/**
	 * @return the dbRspnstpCd
	 */
	public String getDbRspnstpCd() {
		return dbRspnstpCd;
	}

	/**
	 * @param dbRspnstpCd the dbRspnstpCd to set
	 */
	public void setDbRspnstpCd(String dbRspnstpCd) {
		this.dbRspnstpCd = dbRspnstpCd;
	}

	/**
	 * @return the dbRspnstpTxt
	 */
	public String getDbRspnstpTxt() {
		return dbRspnstpTxt;
	}

	/**
	 * @param dbRspnstpTxt the dbRspnstpTxt to set
	 */
	public void setDbRspnstpTxt(String dbRspnstpTxt) {
		this.dbRspnstpTxt = dbRspnstpTxt;
	}

	/**
	 * @return the dbEligPerLmtCd
	 */
	public String getDbEligPerLmtCd() {
		return dbEligPerLmtCd;
	}

	/**
	 * @param dbEligPerLmtCd the dbEligPerLmtCd to set
	 */
	public void setDbEligPerLmtCd(String dbEligPerLmtCd) {
		this.dbEligPerLmtCd = dbEligPerLmtCd;
	}

	/**
	 * @return the dbTxtSndCd
	 */
	public String getDbTxtSndCd() {
		return dbTxtSndCd;
	}

	/**
	 * @param dbTxtSndCd the dbTxtSndCd to set
	 */
	public void setDbTxtSndCd(String dbTxtSndCd) {
		this.dbTxtSndCd = dbTxtSndCd;
	}

	/**
	 * @return the dbPlnLvlInd
	 */
	public String getDbPlnLvlInd() {
		return dbPlnLvlInd;
	}

	/**
	 * @param dbPlnLvlInd the dbPlnLvlInd to set
	 */
	public void setDbPlnLvlInd(String dbPlnLvlInd) {
		this.dbPlnLvlInd = dbPlnLvlInd;
	}

	/**
	 * @return the dbFdbInd
	 */
	public String getDbFdbInd() {
		return dbFdbInd;
	}

	/**
	 * @param dbFdbInd the dbFdbInd to set
	 */
	public void setDbFdbInd(String dbFdbInd) {
		this.dbFdbInd = dbFdbInd;
	}

	/**
	 * @return the dbUpdatedInd
	 */
	public char getDbUpdatedInd() {
		return dbUpdatedInd;
	}

	/**
	 * @param dbUpdatedInd the dbUpdatedInd to set
	 */
	public void setDbUpdatedInd(char dbUpdatedInd) {
		this.dbUpdatedInd = dbUpdatedInd;
	}
}