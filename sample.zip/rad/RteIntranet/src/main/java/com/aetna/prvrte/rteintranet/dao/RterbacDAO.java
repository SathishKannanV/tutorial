package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.RterbacDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public interface RterbacDAO {
	Map getRterbacLookUp(RterbacDTO rterbacDTO) throws ApplicationException;
	
	Map addNewRterbac(RterbacDTO rterbacDTO) throws ApplicationException ;

	Map deleteRterbac(RterbacDTO rterbacDTO) throws ApplicationException ;

	Map addUpdateRterbac(RterbacDTO existRterbacDTO, List<RterbacDTO> rterbacDtoList, int index) throws ApplicationException ;

}
