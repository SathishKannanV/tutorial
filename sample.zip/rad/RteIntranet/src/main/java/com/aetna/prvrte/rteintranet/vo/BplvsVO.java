package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;

/**
 * @author N726899
 *
 */
public class BplvsVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5977071815426498865L;
	private String reqBenCd = "";
	private String dSeqNo = "";
	private String postedDt = "";
	private String dNoQlfrCd = "";
	private String dNo = "";
	private String dDiscTxt = "";
	private String dElpDlmtCd= "";
	private String dTypeCd = "";
	private String bic = "";
	private String prov = "";
	private String lineVal = "";
	private String authCertCd = "";
	private String ioNtwkCd = "";
	private String svcType= "";
	private String userTxt = "";
	private char updatedInd;
	public BplvsVO() {
		super();
	}
	public BplvsVO(String reqBenCd, String dSeqNo, String postedDt,
			String dNoQlfrCd, String dNo, String dDiscTxt, String dElpDlmtCd,
			String dTypeCd, String bic, String prov, String lineVal,
			String authCertCd, String ioNtwkCd, String svcType, String userTxt,
			char updatedInd) {
		super();
		this.reqBenCd = reqBenCd;
		this.dSeqNo = dSeqNo;
		this.postedDt = postedDt;
		this.dNoQlfrCd = dNoQlfrCd;
		this.dNo = dNo;
		this.dDiscTxt = dDiscTxt;
		this.dElpDlmtCd = dElpDlmtCd;
		this.dTypeCd = dTypeCd;
		this.bic = bic;
		this.prov = prov;
		this.lineVal = lineVal;
		this.authCertCd = authCertCd;
		this.ioNtwkCd = ioNtwkCd;
		this.svcType = svcType;
		this.userTxt = userTxt;
		this.updatedInd = updatedInd;
	}
	public String getReqBenCd() {
		return reqBenCd;
	}
	public void setReqBenCd(String reqBenCd) {
		this.reqBenCd = reqBenCd;
	}
	public String getdSeqNo() {
		return dSeqNo;
	}
	public void setdSeqNo(String dSeqNo) {
		this.dSeqNo = dSeqNo;
	}
	public String getPostedDt() {
		return postedDt;
	}
	public void setPostedDt(String postedDt) {
		this.postedDt = postedDt;
	}
	public String getdNoQlfrCd() {
		return dNoQlfrCd;
	}
	public void setdNoQlfrCd(String dNoQlfrCd) {
		this.dNoQlfrCd = dNoQlfrCd;
	}
	public String getdNo() {
		return dNo;
	}
	public void setdNo(String dNo) {
		this.dNo = dNo;
	}
	public String getdDiscTxt() {
		return dDiscTxt;
	}
	public void setdDiscTxt(String dDiscTxt) {
		this.dDiscTxt = dDiscTxt;
	}
	public String getdElpDlmtCd() {
		return dElpDlmtCd;
	}
	public void setdElpDlmtCd(String dElpDlmtCd) {
		this.dElpDlmtCd = dElpDlmtCd;
	}
	public String getdTypeCd() {
		return dTypeCd;
	}
	public void setdTypeCd(String dTypeCd) {
		this.dTypeCd = dTypeCd;
	}
	public String getBic() {
		return bic;
	}
	public void setBic(String bic) {
		this.bic = bic;
	}
	public String getProv() {
		return prov;
	}
	public void setProv(String prov) {
		this.prov = prov;
	}
	public String getLineVal() {
		return lineVal;
	}
	public void setLineVal(String lineVal) {
		this.lineVal = lineVal;
	}
	public String getAuthCertCd() {
		return authCertCd;
	}
	public void setAuthCertCd(String authCertCd) {
		this.authCertCd = authCertCd;
	}
	public String getIoNtwkCd() {
		return ioNtwkCd;
	}
	public void setIoNtwkCd(String ioNtwkCd) {
		this.ioNtwkCd = ioNtwkCd;
	}
	public String getSvcType() {
		return svcType;
	}
	public void setSvcType(String svcType) {
		this.svcType = svcType;
	}
	public String getUserTxt() {
		return userTxt;
	}
	public void setUserTxt(String userTxt) {
		this.userTxt = userTxt;
	}
	public char getUpdatedInd() {
		return updatedInd;
	}
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}