package com.aetna.prvrte.rteintranet.dto;



import java.io.Serializable;



/**

 * @author N801539

 * Cognizant_Offshore

 */

public class HrpRuleDTO implements Serializable{

	

	/**

	 * 

	 */

	private static final long serialVersionUID = 1L;

	private String hrprlSvcTyp = ""; 

	private String hrprlRulecd = ""; 

	private String hrprlEffdt = ""; 

	private String hrprlTermdt = ""; 

	private String hrprlRuledesc = "";

	private String hrprlCondspec = "";

	private String hrprlRulectgry = ""; 

	private String hrprlCovgind = ""; 

	private String hrprlTextsnd = ""; 

	private String hrprlPosTob = "";
	
	private String hrprlTobcd = "";
	
	private String hrprlPoscd = "";
	
	private String hrprlStatecd = "";
	
	private String hrprlAmntrfmt = "";
	
	private String hrprlBus01 = "";
	
	private String hrprlBus02 = "";
	
	private String hrprlBus03 = "";
	
	private String hrprlBus04 = "";
	
	private String hrprlBus05 = "";
	
	private String hrprlBus06 = "";
	
	private String hrprlBus07 = "";
	
	private String hrprlBus08 = "";
	
	private String hrprlBus09 = "";
	
	private String hrprlBus10 = "";
	
	private String hrprlBus11 = "";
	
	private String hrprlBus12 = "";
	
	private String hrprlBus13 = "";
	
	private String hrprlBus14 = "";
	
	private String hrprlBus15 = "";

	private char   updatedInd;

	

	

	public HrpRuleDTO(String hrprlSvcTyp, String hrprlRulecd, String hrprlEffdt,

			String hrprlTermdt, String hrprlRuledesc, String hrprlCondspec,

			String hrprlRulectgry, String hrprlCovgind, String hrprlTextsnd,
			
			String hrprlPosTob, String hrprlTobcd, String hrprlPoscd,
			
			String hrprlStatecd, String hrprlAmntrfmt, String hrprlBus01,
			
			String hrprlBus02, String hrprlBus03, String hrprlBus04,
			
			String hrprlBus05, String hrprlBus06, String hrprlBus07,
			
			String hrprlBus08, String hrprlBus09, String hrprlBus10,
			
			String hrprlBus11, String hrprlBus12, String hrprlBus13,
			
			String hrprlBus14, String hrprlBus15, char updatedInd) {


		super();

		this.hrprlSvcTyp = hrprlSvcTyp;

		this.hrprlRulecd = hrprlRulecd;

		this.hrprlEffdt = hrprlEffdt;

		this.hrprlTermdt = hrprlTermdt;

		this.hrprlRuledesc = hrprlRuledesc;

		this.hrprlCondspec = hrprlCondspec;

		this.hrprlRulectgry = hrprlRulectgry;

		this.hrprlCovgind = hrprlCovgind;

		this.hrprlTextsnd = hrprlTextsnd;

		this.hrprlPosTob = hrprlPosTob;
		
		this.hrprlTobcd = hrprlTobcd;
		
		this.hrprlPoscd = hrprlPoscd;
		
		this.hrprlStatecd = hrprlStatecd;
		
		this.hrprlAmntrfmt = hrprlAmntrfmt;
		
		this.hrprlBus01 = hrprlBus01;
		
		this.hrprlBus02 = hrprlBus02;
		
		this.hrprlBus03 = hrprlBus03;
		
		this.hrprlBus04 = hrprlBus04;
		
		this.hrprlBus05 = hrprlBus05;
		
		this.hrprlBus06 = hrprlBus06;
		
		this.hrprlBus07 = hrprlBus07;
		
		this.hrprlBus08 = hrprlBus08;
		
		this.hrprlBus09 = hrprlBus09;
		
		this.hrprlBus10 = hrprlBus10;
		
		this.hrprlBus11 = hrprlBus11;
		
		this.hrprlBus12 = hrprlBus12;
		
		this.hrprlBus13 = hrprlBus13;
		
		this.hrprlBus14 = hrprlBus14;
		
		this.hrprlBus15 = hrprlBus15;

		this.updatedInd = updatedInd;

	}



	public HrpRuleDTO() {

		super();

	}



	
	public String getHrprlSvcTyp() {
		return hrprlSvcTyp;
	}



	public void setHrprlSvcTyp(String hrprlSvcTyp) {
		this.hrprlSvcTyp = hrprlSvcTyp;
	}



	public String getHrprlRulecd() {
		return hrprlRulecd;
	}



	public void setHrprlRulecd(String hrprlRulecd) {
		this.hrprlRulecd = hrprlRulecd;
	}



	public String getHrprlEffdt() {
		return hrprlEffdt;
	}



	public void setHrprlEffdt(String hrprlEffdt) {
		this.hrprlEffdt = hrprlEffdt;
	}



	public String getHrprlTermdt() {
		return hrprlTermdt;
	}



	public void setHrprlTermdt(String hrprlTermdt) {
		this.hrprlTermdt = hrprlTermdt;
	}



	public String getHrprlRuledesc() {
		return hrprlRuledesc;
	}



	public void setHrprlRuledesc(String hrprlRuledesc) {
		this.hrprlRuledesc = hrprlRuledesc;
	}



	public String getHrprlCondspec() {
		return hrprlCondspec;
	}



	public void setHrprlCondspec(String hrprlCondspec) {
		this.hrprlCondspec = hrprlCondspec;
	}



	public String getHrprlRulectgry() {
		return hrprlRulectgry;
	}



	public void setHrprlRulectgry(String hrprlRulectgry) {
		this.hrprlRulectgry = hrprlRulectgry;
	}



	public String getHrprlCovgind() {
		return hrprlCovgind;
	}



	public void setHrprlCovgind(String hrprlCovgind) {
		this.hrprlCovgind = hrprlCovgind;
	}



	public String getHrprlTextsnd() {
		return hrprlTextsnd;
	}



	public void setHrprlTextsnd(String hrprlTextsnd) {
		this.hrprlTextsnd = hrprlTextsnd;
	}



	public String getHrprlPosTob() {
		return hrprlPosTob;
	}



	public void setHrprlPosTob(String hrprlPosTob) {
		this.hrprlPosTob = hrprlPosTob;
	}



	public String getHrprlTobcd() {
		return hrprlTobcd;
	}



	public void setHrprlTobcd(String hrprlTobcd) {
		this.hrprlTobcd = hrprlTobcd;
	}



	public String getHrprlPoscd() {
		return hrprlPoscd;
	}



	public void setHrprlPoscd(String hrprlPoscd) {
		this.hrprlPoscd = hrprlPoscd;
	}



	public String getHrprlStatecd() {
		return hrprlStatecd;
	}



	public void setHrprlStatecd(String hrprlStatecd) {
		this.hrprlStatecd = hrprlStatecd;
	}



	public String getHrprlAmntrfmt() {
		return hrprlAmntrfmt;
	}



	public void setHrprlAmntrfmt(String hrprlAmntrfmt) {
		this.hrprlAmntrfmt = hrprlAmntrfmt;
	}



	public String getHrprlBus01() {
		return hrprlBus01;
	}



	public void setHrprlBus01(String hrprlBus01) {
		this.hrprlBus01 = hrprlBus01;
	}



	public String getHrprlBus02() {
		return hrprlBus02;
	}



	public void setHrprlBus02(String hrprlBus02) {
		this.hrprlBus02 = hrprlBus02;
	}



	public String getHrprlBus03() {
		return hrprlBus03;
	}



	public void setHrprlBus03(String hrprlBus03) {
		this.hrprlBus03 = hrprlBus03;
	}



	public String getHrprlBus04() {
		return hrprlBus04;
	}



	public void setHrprlBus04(String hrprlBus04) {
		this.hrprlBus04 = hrprlBus04;
	}



	public String getHrprlBus05() {
		return hrprlBus05;
	}



	public void setHrprlBus05(String hrprlBus05) {
		this.hrprlBus05 = hrprlBus05;
	}



	public String getHrprlBus06() {
		return hrprlBus06;
	}



	public void setHrprlBus06(String hrprlBus06) {
		this.hrprlBus06 = hrprlBus06;
	}



	public String getHrprlBus07() {
		return hrprlBus07;
	}



	public void setHrprlBus07(String hrprlBus07) {
		this.hrprlBus07 = hrprlBus07;
	}



	public String getHrprlBus08() {
		return hrprlBus08;
	}



	public void setHrprlBus08(String hrprlBus08) {
		this.hrprlBus08 = hrprlBus08;
	}



	public String getHrprlBus09() {
		return hrprlBus09;
	}



	public void setHrprlBus09(String hrprlBus09) {
		this.hrprlBus09 = hrprlBus09;
	}



	public String getHrprlBus10() {
		return hrprlBus10;
	}



	public void setHrprlBus10(String hrprlBus10) {
		this.hrprlBus10 = hrprlBus10;
	}



	public String getHrprlBus11() {
		return hrprlBus11;
	}



	public void setHrprlBus11(String hrprlBus11) {
		this.hrprlBus11 = hrprlBus11;
	}



	public String getHrprlBus12() {
		return hrprlBus12;
	}



	public void setHrprlBus12(String hrprlBus12) {
		this.hrprlBus12 = hrprlBus12;
	}



	public String getHrprlBus13() {
		return hrprlBus13;
	}



	public void setHrprlBus13(String hrprlBus13) {
		this.hrprlBus13 = hrprlBus13;
	}



	public String getHrprlBus14() {
		return hrprlBus14;
	}



	public void setHrprlBus14(String hrprlBus14) {
		this.hrprlBus14 = hrprlBus14;
	}



	public String getHrprlBus15() {
		return hrprlBus15;
	}



	public void setHrprlBus15(String hrprlBus15) {
		this.hrprlBus15 = hrprlBus15;
	}



	public char getUpdatedInd() {
		return updatedInd;
	}



	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}


	


}

	