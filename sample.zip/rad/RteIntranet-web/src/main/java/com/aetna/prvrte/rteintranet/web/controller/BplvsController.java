package com.aetna.prvrte.rteintranet.web.controller;

/**
 * 
 */


import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.BplvsDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.BplvsVO;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;

/**
 * @author N731694
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/bplvs/*")
public class BplvsController {

	public static final String BPLVS_HOME = ".bplvsHome";
	public static final String BPLVS_LOOKUP = ".bplvsLookUpDisplay";
	public static final String BPLVS_ADD = ".bplvsAdd";
	public static final String BPLVS_HELP= ".bplvsHelp";

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(BplvsController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;
	
	@RequestMapping(value="/bplvsHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getBplvsLookUpHome(final HttpServletRequest request,Model model) {	
		log.debug("Entered BplvsController - getBplvsLookUpHome()");
		String securityLevel ="";
		try {
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(BPLVS_HOME, "BplvsVO",  new BplvsVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("BplvsController - securityLevel: "+ securityLevel);
		log.debug("Exit from BplvsController - getBplvsLookUpHome()");
		return mav;
		}
		catch (ApplicationException e){
			log.error("Exception occured in BplvsController - getBplvsLookUpTable() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (bplvsHome). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@RequestMapping(value="/bplvsHelp")
	public String loadBplvsHelp() {   
		return BPLVS_HELP;
	}
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherBplvs", method = RequestMethod.POST)
	public ModelAndView getBplvsLookUpTable(final HttpServletRequest request,@ModelAttribute("bplvsForm")BplvsVO bplvsVO){
		log.debug("Entered BplvsController - getBplvsLookUpTable()");
		String bicId ="";
		String prov ="";
		String lineVal ="";
		String svcType ="";
		String securityLevel ="";
		
		ModelAndView mav ;
		Map bplvsResultMap = new HashMap();
		List<BplvsVO> bplvsList = new LinkedList<BplvsVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			bicId = bplvsVO.getBic();
			prov =bplvsVO.getProv();
			lineVal=bplvsVO.getLineVal();
			svcType=bplvsVO.getSvcType();

			bplvsResultMap = facade.getBplvsLookUpTable(bicId, prov,lineVal,svcType);
		
		bplvsList = (List<BplvsVO>) bplvsResultMap.get("bplvsList");
		lookUpListVO.setBplvsVOList(bplvsList);
		
		facade.getApplicationState().setBplvsList(bplvsList);
		mav = new ModelAndView(BPLVS_LOOKUP, "lookUpListVO", lookUpListVO);
		mav.addObject("bplvsMessage", bplvsResultMap.get("newMessage"));
		mav.addObject("securityLevel", securityLevel);
			
		
		log.debug("getBplvsLookupTable - bplvsMessage: "+ bplvsResultMap.get("newMessage"));
		log.debug("Exit from BplvsController - getBplvsLookUpTable()");
		return mav;
		}catch (Exception e){
			log.error("Exception occured in BplvsController - getBplvsLookUpTable() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (GatherBplvs). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteBplvs", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView deleteBplvs(final HttpServletRequest request,@ModelAttribute("bplvsDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String bplvsMsg = "";
		boolean isBplvsDeleted = true;
		String securityLevel ="";
		Map bplvsResultMap = new HashMap();
		List<BplvsVO> bplvsList = new LinkedList<BplvsVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			bplvsList = lookUpListVO.getBplvsVOList();
			int i;
			if ((bplvsList != null) && (takeAction != null)) {
				for(BplvsVO bplvsVO : bplvsList){
					if(bplvsVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						bplvsVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					BplvsVO editedBplvs = (BplvsVO) bplvsList.get(i);
					if (editedBplvs.getUpdatedInd() != ApplicationConstants.COPY) {
						BplvsDTO bplvsDTO = RTETranslator.toBplvsDTO(editedBplvs);
						bplvsResultMap = facade.deleteBplvs(bplvsDTO);
						bplvsMsg = (String) bplvsResultMap.get("bplvsMsg");
						isBplvsDeleted = (Boolean) bplvsResultMap.get("isBplvsDeleted");
						
						if(isBplvsDeleted == true){
							bplvsList.remove(i);
						}else{
							j = 0;
						}
					}else{
						bplvsList.remove(i);
					}				
			}
				if(isBplvsDeleted == true)
					bplvsMsg = "Rows selected were Deleted in the database/list";
		}else
			bplvsMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setBplvsList(bplvsList);
			lookUpListVO.setBplvsVOList(bplvsList);
			mav = new ModelAndView(BPLVS_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("bplvsMessage",bplvsMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.debug("deleteBplvs - bplvsMessage: "+ bplvsMsg);
		    log.debug("Exit from BplvsController - deleteBplvs()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in BplvsController - deleteBplvs() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteBplvs() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	
	@RequestMapping(value="/AddNewBplvsRow")
	public ModelAndView loadAddNewBplvsRowScreen(Model model, HttpServletRequest request) {	
		log.debug("Entered BplvsController - loadAddNewBplvsRowScreen()");
		try {
			String securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			ModelAndView mav = new ModelAndView(BPLVS_ADD, "BplvsVO",  new BplvsVO());
			mav.addObject("securityLevel", securityLevel);
			log.debug("Exit from BplvsController - BplvsController()");
			return mav;
		} catch (ApplicationException e) {
			log.error("Exception occured in BplvsController - loadAddNewBplvsRowScreen() method:"+e.getMessage());
			String errorMsg ="Error encountered when loading AddNewBplvs . ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddBplvs", method = RequestMethod.POST)
	public ModelAndView addNewBplvs(final HttpServletRequest request,@ModelAttribute("addBplvsForm")BplvsVO bplvsVO){
		log.debug("Entered BplvsController - addNewBplvs()");
		ModelAndView mav ;
		String securityLevel ="";
		Map bplvsResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<BplvsDTO> bplvsDtoList = new LinkedList<BplvsDTO>();
		List<BplvsVO> bplvsVoList = new LinkedList<BplvsVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			bplvsVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
			BplvsDTO bplvsDTO = RTETranslator.toBplvsDTO(bplvsVO);
			bplvsResultMap = facade.addNewBplvs(bplvsDTO);
			
			if(bplvsResultMap.get("BplvsList")!=null){
				bplvsDtoList = (List<BplvsDTO>) bplvsResultMap.get("BplvsList");
				bplvsVoList = RTETranslator.toBplvsVOList(bplvsDtoList);
			}
			
			lookUpListVO.setBplvsVOList(bplvsVoList);
			facade.getApplicationState().setBplvsList(bplvsVoList);
			mav = new ModelAndView(BPLVS_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("bplvsMessage", bplvsResultMap.get("bplvsMessage"));
			mav.addObject("securityLevel", securityLevel);
			
			log.debug("addNewBplvs -bplvsMessage: "+ bplvsResultMap.get("bplvsMessage"));
			log.debug("Exit from BplvsController - addNewBplvs()");			
			return mav;	
		}catch (Exception e){
			log.error("Exception occured in BplvsController - addNewBplsv() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when adding a row to the database (AddBplvs). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	

	
	@RequestMapping(value="/copyBplvs", method = RequestMethod.POST)
	public ModelAndView copyBplvs(final HttpServletRequest request,@ModelAttribute("bplvsDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.debug("Entered from BplvsController - copyBplvs()");
		ModelAndView mav ;
		String bplvsMsg = "";
		String securityLevel ="";
		int i;
		List<BplvsVO> bplvsList = new LinkedList<BplvsVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			String postedDate = RteIntranetUtils.getTodaysDate();
			bplvsList = lookUpListVO.getBplvsVOList();
			if ((bplvsList != null) && (takeAction != null)) {
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					BplvsVO existingBplvs = (BplvsVO) bplvsList.get(i);
					
					BplvsVO copyBplvs = new BplvsVO(existingBplvs.getReqBenCd(), existingBplvs.getdSeqNo(),postedDate,existingBplvs.getdNoQlfrCd(),existingBplvs.getdNo(),
							existingBplvs.getdDiscTxt(),existingBplvs.getdElpDlmtCd(),existingBplvs.getdTypeCd(),existingBplvs.getBic(),existingBplvs.getProv(),
							existingBplvs.getLineVal(),existingBplvs.getAuthCertCd(),existingBplvs.getIoNtwkCd(),existingBplvs.getSvcType(),existingBplvs.getUserTxt(),						
							ApplicationConstants.COPY);
					bplvsList.add(copyBplvs);
				}
				bplvsMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				bplvsMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setBplvsList(bplvsList);
			lookUpListVO.setBplvsVOList(bplvsList);
			mav = new ModelAndView(BPLVS_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("bplvsMessage",bplvsMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.debug("copyBplvs - bplvsMessage: "+ bplvsMsg);
		    log.debug("Exit from BplvsController - copyBplvs()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in BplvsController - copyBplvs() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessBplvs). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateBplvs", method = RequestMethod.POST)
	public ModelAndView addUpdateBplvs(final HttpServletRequest request,@ModelAttribute("bplvsDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.debug("Entered from BplvsController - addUpdateBplvs()");
		ModelAndView mav ;
		String bplvsMsg = "";
		String securityLevel ="";
		List<BplvsVO> updatedBplvsList = facade.getApplicationState().getBplvsList();
		List<BplvsDTO> updatedBplvsDtoList = new LinkedList<BplvsDTO>();
		List<BplvsVO> bplvsVoList = new LinkedList<BplvsVO>();
		List<BplvsVO> modifiedBplvsVoList = new LinkedList<BplvsVO>();
		List<BplvsDTO> bplvsDtoList = new LinkedList<BplvsDTO>(); 
		boolean isBplvsAddOrUpdated = false;
		Map bplvsResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			bplvsVoList = facade.getApplicationState().getBplvsList();
			modifiedBplvsVoList = lookUpListVO.getBplvsVOList();
			int i;
			String postedDate = RteIntranetUtils.getTodaysDate();
			if ((bplvsVoList != null) && (takeAction != null)) {
				for(BplvsVO bplvsVO : bplvsVoList){
					if(bplvsVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						bplvsVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				bplvsDtoList = RTETranslator.toBplvsDTOList(bplvsVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					BplvsVO selectedBplvs = (BplvsVO)bplvsVoList.get(i);
					BplvsVO editedBplvs = (BplvsVO) modifiedBplvsVoList.get(i);
					BplvsVO editedBplvsVO = new BplvsVO(editedBplvs.getReqBenCd(), editedBplvs.getdSeqNo(),postedDate,editedBplvs.getdNoQlfrCd(),editedBplvs.getdNo(),
							editedBplvs.getdDiscTxt(),editedBplvs.getdElpDlmtCd(),editedBplvs.getdTypeCd(),editedBplvs.getBic(),editedBplvs.getProv(),
							editedBplvs.getLineVal(),editedBplvs.getAuthCertCd(),editedBplvs.getIoNtwkCd(),editedBplvs.getSvcType(),editedBplvs.getUserTxt(),						
							updatedInd);
					BplvsDTO editedBplvsDTO = RTETranslator.toBplvsDTO(editedBplvsVO);
					bplvsResultMap = facade.addUpdateBplvs(editedBplvsDTO, bplvsDtoList, i , selectedBplvs.getUpdatedInd());
					updatedBplvsDtoList = (List<BplvsDTO>) bplvsResultMap.get("bplvsDtoList");
					updatedBplvsList = RTETranslator.toBplvsVOList(updatedBplvsDtoList);
					isBplvsAddOrUpdated = bplvsResultMap.get("isBplvsAddOrUpdated") != null ;
					bplvsMsg = (String) bplvsResultMap.get("bplvsMsg") ;
					if(isBplvsAddOrUpdated!= true){
						j = takeAction.length;
					}
				}
				lookUpListVO.setBplvsVOList(updatedBplvsList);
				facade.getApplicationState().setBplvsList(updatedBplvsList);
		}else{
			bplvsMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setBplvsVOList(bplvsVoList);
			facade.getApplicationState().setBplvsList(bplvsVoList);
		}
			mav = new ModelAndView(BPLVS_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("bplvsMessage",bplvsMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.debug("addUpdateBplvs - BplvsMessage: "+ bplvsMsg);
		    log.debug("Exit from BplvsController - adddUpdateBplvs()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in BplvsController - adddUpdateBplvs() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="adddUpdateBplvs() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	 @RequestMapping(value = "/bplvsExport", method = RequestMethod.POST)
     public ModelAndView bplvsExport(@ModelAttribute("bplvsDisplayForm")LookUpTableListVO lookUpTableListVO,HttpServletResponse response){
           List<BplvsVO> bplvsList = new LinkedList<BplvsVO>();
     String bplvsMsg="";
           try{
        	   bplvsList = lookUpTableListVO.getBplvsVOList();
                 if(bplvsList != null && bplvsList.size() != 0){
                 // Key map to create header
                 Map<String,String> keyMap = new LinkedHashMap<String,String>();
                 keyMap.put("reqBenCd", "Rq Ben Cd");
                 keyMap.put("dSeqNo", "Seq #");
                 keyMap.put("postedDt", "Posted Dt");
                 keyMap.put("dNoQlfrCd", "Qlfr Cd");
                 keyMap.put("dNo", "Number");
                 keyMap.put("dDiscTxt", "Provider Text");
                 keyMap.put("dElpDlmtCd", "Elig Period Lmt Cd");
                 keyMap.put("dTypeCd", "Type Cd");
                 keyMap.put("bic", "BIC");
                 keyMap.put("prov", "Prov");
                 keyMap.put("lineVal", "Line Val");
                 keyMap.put("authCertCd", "Auth Cert");
                 keyMap.put("ioNtwkCd", "I/O Net");
                 keyMap.put("svcType", "Svc Type");
                 keyMap.put("userTxt", "User Text (Use Mixed Case)");
                 RteIntranetUtils.exportToExcel(response, bplvsList, keyMap);
                 bplvsMsg = "LookUp table exported successfully.";
                 } else {
                	 bplvsMsg = "No data found.";
                 }
                 
                 mav = new ModelAndView(BPLVS_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
                 mav.addObject("bplvsMessage",bplvsMsg);
                 return mav;
           }catch (Exception e) {
                 log.error("Exception occured in BplvsController - bplvsExport() method:" + e.getMessage());
                 String errorMsg = "Error encountered while export to excel. ";
                 errorMsg.concat(e.toString());
                 errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
                 errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
                 return errormav;
           }
     }
	
}
