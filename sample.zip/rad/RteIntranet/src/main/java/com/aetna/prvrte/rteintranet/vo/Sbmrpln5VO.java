package com.aetna.prvrte.rteintranet.vo;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class Sbmrpln5VO {
	private String convIdCode = new String();
	private String vanId = new String();
	private String tranTypeCode = new String();
	private int seqNo;
	private String postedDate = new String();
	private int controlNo;
	private int suffixNo;
	private int accountNo;
	private String productName = new String();
	private String coverageLevelCode = new String();
	private String coverageToDate = new String();
	private String insuranceLineCd = new String();
	private String planNetworkCd = new String();
	private String siteCd = new String();
	private String subGroupCd = new String();
	private String covgFromDate = new String();
	private String benefitIdCd = new String();
	private int pbnfSeqNo;
	private int planNo;
	private String planSummaryCd = new String();
	private String planName = new String();
	private String patientBirthdate = new String();
	private String patientLastName = new String();
	private String patientFirstName = new String();
	private String patientMidName = new String();
	private String patientTitle = new String();
	private String subsLastName = new String();
	private String subsFirstName = new String();
	private String subsMidName = new String();
	private String subsTitle = new String();
	private String relationToSubsCode = new String();
	private String patientSexCode = new String();
	private String memberTermDate = new String();
	private String depTermDate = new String();
	private String memberIdCd = new String();
	private String subscriberIdCd = new String();
	private String depIdCd = new String();
	private String capLabName = new String();
	private String capXrayName = new String();
	private String capLabPhone = new String();
	private String capXrayPhone = new String();
	private String cumbOrigEffDate = new String();
	private int networkIdNo;
	private String employerName = new String();
	private String groupCd = new String();
	private List benefitCollection = new ArrayList();
	
	public Sbmrpln5VO(String convIdCode, String vanId, String tranTypeCd, int seqNo, String postedDate, int controlNo, int suffixNo, int accountNo, 
					String productName, String coverageLevelCode, String coverageToDate, String insuranceLineCd, 
					String planNetworkCd, String siteCd, String subGroupCd, String covgFromDate, String benefitIdCd, 
					int pbnfSeqNo, int planNo, String planSummaryCd, String planName, String patientBirthdate, 
					String patientLastName, String patientFirstName, String patientMidName, String patientTitle, 
					String subsLastName, String subsFirstName, String subsMidName, String subsTitle, 
					String relationToSubsCode, String patientSexCode, String memberTermDate, String depTermDate, 
					String memberIdCd, String subscriberIdCd, String depIdCd, String capLabName, String capXrayName, 
					String capLabPhone, String capXrayPhone, String cumbOrigEffDate, int networkIdNo, 
					String employerName, String groupCd, List benefitCollection) {
		super();
		this.convIdCode = convIdCode;
		this.vanId = vanId;
		this.tranTypeCode = tranTypeCd;
		this.seqNo = seqNo;
		this.postedDate = postedDate;
		this.controlNo = controlNo;
		this.suffixNo = suffixNo;
		this.accountNo = accountNo;
		this.productName = productName;
		this.coverageLevelCode = coverageLevelCode;
		this.coverageToDate = coverageToDate;
		this.insuranceLineCd = insuranceLineCd;
		this.planNetworkCd = planNetworkCd;
		this.siteCd = siteCd;
		this.subGroupCd = subGroupCd;
		this.covgFromDate = covgFromDate;
		this.benefitIdCd = benefitIdCd;
		this.pbnfSeqNo = pbnfSeqNo;
		this.planNo = planNo;
		this.planSummaryCd = planSummaryCd;
		this.planName = planName;
		this.patientBirthdate = patientBirthdate;
		this.patientLastName = patientLastName;
		this.patientFirstName = patientFirstName;
		this.patientMidName = patientMidName;
		this.patientTitle = patientTitle;
		this.subsLastName = subsLastName;
		this.subsFirstName = subsFirstName;
		this.subsMidName = subsMidName;
		this.subsTitle = subsTitle;
		this.relationToSubsCode = relationToSubsCode;
		this.patientSexCode = patientSexCode;
		this.memberTermDate = memberTermDate;
		this.depTermDate = depTermDate;
		this.memberIdCd = memberIdCd;
		this.subscriberIdCd = subscriberIdCd;
		this.depIdCd = depIdCd;
		this.capLabName = capLabName;
		this.capXrayName = capXrayName;
		this.capLabPhone = capLabPhone;
		this.capXrayPhone = capXrayPhone;
		this.cumbOrigEffDate = cumbOrigEffDate;
		this.networkIdNo = networkIdNo;
		this.employerName = employerName;
		this.groupCd = groupCd;
		this.benefitCollection = benefitCollection;
	}

	public String getConvIdCode() {
		return convIdCode;
	}

	public String getTranTypeCode() {
		return tranTypeCode;
	}

	public String getVanId() {
		return vanId;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public List getBenefitCollection() {
		return benefitCollection;
	}

	public void setBenefitCollection(List benefitCollection) {
		this.benefitCollection = benefitCollection;
	}

	public String getBenefitIdCd() {
		return benefitIdCd;
	}

	public String getCapLabName() {
		return capLabName;
	}

	public String getCapLabPhone() {
		return capLabPhone;
	}

	public String getCapXrayName() {
		return capXrayName;
	}

	public String getCapXrayPhone() {
		return capXrayPhone;
	}

	public int getControlNo() {
		return controlNo;
	}

	public String getCoverageLevelCode() {
		return coverageLevelCode;
	}

	public String getCoverageToDate() {
		return coverageToDate;
	}

	public String getCovgFromDate() {
		return covgFromDate;
	}

	public String getCumbOrigEffDate() {
		return cumbOrigEffDate;
	}

	public String getDepIdCd() {
		return depIdCd;
	}

	public String getDepTermDate() {
		return depTermDate;
	}

	public String getEmployerName() {
		return employerName;
	}

	public String getGroupCd() {
		return groupCd;
	}

	public String getInsuranceLineCd() {
		return insuranceLineCd;
	}

	public String getMemberIdCd() {
		return memberIdCd;
	}

	public String getMemberTermDate() {
		return memberTermDate;
	}

	public int getNetworkIdNo() {
		return networkIdNo;
	}

	public String getPatientBirthdate() {
		return patientBirthdate;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public String getPatientMidName() {
		return patientMidName;
	}

	public String getPatientSexCode() {
		return patientSexCode;
	}

	public String getPatientTitle() {
		return patientTitle;
	}

	public int getPbnfSeqNo() {
		return pbnfSeqNo;
	}

	public String getPlanName() {
		return planName;
	}

	public String getPlanNetworkCd() {
		return planNetworkCd;
	}

	public int getPlanNo() {
		return planNo;
	}

	public String getPlanSummaryCd() {
		return planSummaryCd;
	}

	public String getPostedDate() {
		return postedDate;
	}

	public String getProductName() {
		return productName;
	}

	public String getRelationToSubsCode() {
		return relationToSubsCode;
	}

	public int getSeqNo() {
		return seqNo;
	}

	public String getSiteCd() {
		return siteCd;
	}

	public String getSubGroupCd() {
		return subGroupCd;
	}

	public String getSubscriberIdCd() {
		return subscriberIdCd;
	}

	public String getSubsFirstName() {
		return subsFirstName;
	}

	public String getSubsLastName() {
		return subsLastName;
	}

	public String getSubsMidName() {
		return subsMidName;
	}

	public String getSubsTitle() {
		return subsTitle;
	}

	public int getSuffixNo() {
		return suffixNo;
	}
}
