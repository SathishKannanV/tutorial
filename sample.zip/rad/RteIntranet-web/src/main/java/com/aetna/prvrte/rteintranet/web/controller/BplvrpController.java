/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.BplvrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.BplvrpVO;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;

/**
 * <h1>Bplvrp Controller</h1> The Bplvrp Controller is responsible for handling
 * the actual request from DispatcherServlet and returning an appropriate
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * 
 * @author N657186 
 * 
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/bplvrp/*")
public class BplvrpController {
	/*
	 * Instance of logger for BplvrpController.
	 */
	private static final Log log = LogFactory.getLog(BplvrpController.class);
	/*
	 * Tile name of the bplvrp home view.
	 */
	public static final String BPLVRP_HOME = ".bplvrpHome";
	/*
	 * Tile name of the bplvrp display view.
	 */
	public static final String BPLVRP_DISPLAY = ".bplvrpDisplay";
	/*
	 * Tile name of the  add new bplvrp form view.
	 */
	public static final String BPLVRP_ADD_NEW = ".addBplvrp";
	/*
	 * Tile name of the  BIC list view.
	 */
	public static final String BPLVRP_BIC_LIST = ".bicList";
	/*
	 * Instance of Facade.
	 */
	@Autowired(required = true)
	private Facade facade;
	/*
	 * Model and view of success operation.
	 */
	private ModelAndView modelAndView;
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errorModelAndView;
	/**
	 * Method to display list of BIC
	 * 
	 * @return view of bic list view
	 */
	@RequestMapping(value="/bicList")
	public String loadBplvrpICList() {	   
		return BPLVRP_BIC_LIST;
	}
	/**
	 * Method to display bplvrpLookup view.
	 * 
	 * @return view of bplvrpLookUp, if fails return error page
	 */
	@RequestMapping(value = "/bplvrpHome", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView getBplvrpLookUp(HttpServletRequest request) {
		try {
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView = new ModelAndView(BPLVRP_HOME, "bplvrpVO", new BplvrpVO());
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in BplvrpController - getBplvrpLookUp() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_LOOKUP_VIEW + "(BplvrpController)" + RteIntranetUtils.getTrimmedString(e.getMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}
	/**
	 * Method to get the bplvrpLookUp List from data store.
	 * 
	 * @param bplvrpVO
	 *            form view object of bplvrp.
	 * @return view of bplvrpDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/bplvrpLookUp", method = RequestMethod.POST)
	public ModelAndView getBplvrpLookUpList(@ModelAttribute("bplvrpForm") BplvrpVO bplvrpVO,
			HttpServletRequest request) {
		try {
			BplvrpDTO bplvrpDTO = RTETranslator.toBplvrpDTO(bplvrpVO);
			
			Map<String, Object> bplvrpMap = facade.getBplvrpLookUpList(bplvrpDTO);
			
			//set BplvrpVOList in application state.
			List<BplvrpVO> bplvrpList = (List<BplvrpVO>) bplvrpMap.get("bplvrpList");
			facade.getApplicationState().setBplvrpList(bplvrpList);
			LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
			lookUpTableListVO.setBplvrpVOList(bplvrpList);
			
			modelAndView = new ModelAndView(BPLVRP_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("bplvrpMsg",bplvrpMap.get("bplvrpMsg"));
			modelAndView.addObject("bplvrpList", bplvrpList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e) {
			log.error("Exception occured in BplvrpController - getBplvrpLookUp() method:"	+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(BplvrpController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to display get add new Bplvrp form home view.
	 * 
	 * @return view of addBplvrpForm, if fails return error page
	 */
	@RequestMapping(value = "/addBplvrpForm", method = RequestMethod.POST)
	public ModelAndView getAddNewBplvrpFormHome(HttpServletRequest request) {
		try {
			String securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView = new ModelAndView(BPLVRP_ADD_NEW, "bplvrpVO", new BplvrpVO());
			modelAndView.addObject("securityLevel", securityLevel);
			
			return modelAndView;
			
		} catch (Exception e) {
			log.error("Exception occured in BplvrpController - getAddNewBplvrpFormHome() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_VIEW + "(BplvrpController)" + e.toString();
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the bplvrpLookUp List from data store.
	 * 
	 * @param bplvrpVO
	 *            form view object of bplvrp.
	 * @return view of bplvrpDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addBplvrp", method = RequestMethod.POST)
	public ModelAndView addBplvrp(final HttpServletRequest request, @ModelAttribute("addBplvrpForm") BplvrpVO bplvrpVO) {
		try {
			BplvrpDTO bplvrpDTO = RTETranslator.toBplvrpDTO(bplvrpVO);
			Map<String, Object> bplvrpMap = facade.addBplvrpToDb(bplvrpDTO);
			//set BplvrpVOList in application state.
			List<BplvrpVO> bplvrpList = (List<BplvrpVO>) bplvrpMap.get("bplvrpList");
			facade.getApplicationState().setBplvrpList(bplvrpList);
			LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
			lookUpTableListVO.setBplvrpVOList(bplvrpList);
			
			modelAndView = new ModelAndView(BPLVRP_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("bplvrpMsg",bplvrpMap.get("bplvrpMsg"));
			modelAndView.addObject("bplvrpList",bplvrpList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e) {
			log.error("Exception occured in BplvrpController - addBplvrp() method:"+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_ROW + "(BplvrpController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the bplvrpLookUp List from data store.
	 * @param request
	 *            request object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of bplvrpDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/deleteBplvrp", method = RequestMethod.POST)
	public ModelAndView deleteBplvrp(@RequestParam(required = false) String[] takeAction,
		HttpServletRequest request,	@ModelAttribute("bplvrpDisplay")LookUpTableListVO lookUpTableListVO) {
		int index;
		String bplvrpMsg ="";
		Map<String, Object> bplvrpMap = new HashedMap();
		List<BplvrpVO> bplvrpList = new LinkedList<BplvrpVO>();
		try {
			bplvrpList = lookUpTableListVO.getBplvrpVOList();
			if (takeAction != null && takeAction.length != 0) {
				if (bplvrpList != null && bplvrpList.size() != 0) {
					List<BplvrpDTO> updatedBplvrpList = RTETranslator.toBplvrpDTOList(bplvrpList);
					for (int j = takeAction.length - 1; j >= 0; j--) {
						index = Integer.parseInt(takeAction[j]);
						BplvrpDTO existingBplvrp = (BplvrpDTO) updatedBplvrpList.get(index);
						if (existingBplvrp.getDbUpdatedInd() != ApplicationConstants.COPY) {
							bplvrpMap = facade.deleteBplvrp(existingBplvrp);
							bplvrpMsg = (String) bplvrpMap.get("bplvrpMsg");
							Boolean isBplvrpDeleted = (Boolean) bplvrpMap.get("isBplvrpDeleted");
							if (isBplvrpDeleted) {
								bplvrpList.remove(index);
							} else {
								j = 0;
							}
						} else {
							bplvrpList.remove(index);
						}
					}
					
				}
			} else
				bplvrpMsg = ApplicationConstants.NO_ACTION_TAKEN;
			
			//update BplvrpVOList in application state, after delete operation.
			facade.getApplicationState().setBplvrpList(bplvrpList);
			lookUpTableListVO.setBplvrpVOList(bplvrpList);
			modelAndView = new ModelAndView(BPLVRP_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("bplvrpMsg",bplvrpMsg);
			modelAndView.addObject("bplvrpList",bplvrpList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in BplvrpController - deleteBplvrp() method:"+e.getErrorMessage());
            String errorMsg =ApplicationConstants.ERROR_GET_LOOKUP + "(BplvrpController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
      }
	}
	
	/**
	 * Method to get the bplvrpLookUp List from data store.
	 * 
	 * @param bplvrpVO
	 *            form view object of bplvrp.
	 * @param takeAction
	 *          List of takeAction to copy the row
	 * @return view of bplvrpDisplay, if fails return error page
	 */
	@RequestMapping(value = "/copyBplvrp", method = RequestMethod.POST)
	public ModelAndView copyBplvrp(@RequestParam(required = false) String[] takeAction,
		HttpServletRequest request,	@ModelAttribute("bplvrpDisplay")LookUpTableListVO lookUpTableListVO) {
			int index;
			String bplvrpMsg ="";
			List<BplvrpVO> bplvrpList = new LinkedList<BplvrpVO>();
		try {
			bplvrpList = lookUpTableListVO.getBplvrpVOList(); 
			if(takeAction != null && takeAction.length != 0){
				if(bplvrpList != null && bplvrpList.size() != 0){
					for (int j = 0; j < takeAction.length; j++) {
						index = Integer.parseInt(takeAction[j]);
						BplvrpVO existingBplvrp = (BplvrpVO) bplvrpList.get(index);
						// deep copy of existingBplvrp
						BplvrpVO copiedBenafrqVO =  (BplvrpVO) SerializationUtils.clone(existingBplvrp);
						copiedBenafrqVO.setDbUpdatedInd(ApplicationConstants.COPY);
						bplvrpList.add(copiedBenafrqVO);
					}
					bplvrpMsg = ApplicationConstants.ROWS_COPIED;
				}
			}else {
				bplvrpMsg = ApplicationConstants.NO_ACTION_TAKEN;
			}
			//update BplvrpVOList in application state.
			facade.getApplicationState().setBplvrpList(bplvrpList);
			lookUpTableListVO.setBplvrpVOList(bplvrpList);
			modelAndView = new ModelAndView(BPLVRP_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("bplvrpMsg",bplvrpMsg);
			modelAndView.addObject("bplvrpList",bplvrpList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in BplvrpController - copyBplvrp() method:" + e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(BplvrpController)" + RteIntranetUtils.getTrimmedString(e.getMessage());
			modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);
			return modelAndView;
		}
	}

	/**
	 * Method to get the bplvrpLookUp List from data store.
	 * 
	 * @param takeAction
	 *            list of selected indexes from view.
	 * @param request
	 *            request object.
	 * @return view of bplvrpDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addUpdateBplvrp", method = RequestMethod.POST)
	public ModelAndView addUpdateBplvrp(@RequestParam(required = false) String[] takeAction,
		HttpServletRequest request,	@ModelAttribute("bplvrpDisplay")LookUpTableListVO lookUpTableListVO) {
		
		int index;
		String bplvrpMsg ="";
		List<BplvrpVO> bplvrpList = new LinkedList<BplvrpVO>();
		List<BplvrpVO> modifiedBplvrpList = new LinkedList<BplvrpVO>();
		try {
			modifiedBplvrpList = lookUpTableListVO.getBplvrpVOList();
			bplvrpList = facade.getApplicationState().getBplvrpList();
			if(takeAction != null && takeAction.length != 0){
				for(BplvrpVO bplvrpVO : bplvrpList){
					if(bplvrpVO.getDbUpdatedInd() == ApplicationConstants.UPDATE_IND_Y){
						bplvrpVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				Map<String, Object> bplvrpMap = new HashedMap();
				List<BplvrpDTO> bplvrpDTOList = RTETranslator.toBplvrpDTOList(bplvrpList);
				if (bplvrpDTOList != null && bplvrpDTOList.size() != 0
						&& modifiedBplvrpList != null && modifiedBplvrpList.size() != 0) {
					for (int j = 0; j < takeAction.length; j++) {
						index = Integer.parseInt(takeAction[j]);
						BplvrpDTO updatedBplvrpDTO = RTETranslator.toBplvrpDTO(modifiedBplvrpList.get(index));
						bplvrpMap = facade.addUpdateBplvrp(updatedBplvrpDTO, bplvrpDTOList, index);
						List<BplvrpDTO> bplvrpDtoList = (List<BplvrpDTO>) bplvrpMap.get("bplvrpList");
						bplvrpList = RTETranslator.toBplvrpVOList(bplvrpDtoList);
						boolean isBplvrpAddorUpdated = (Boolean) bplvrpMap.get("isBplvrpAddorUpdated");
						bplvrpMsg = (String) bplvrpMap.get("bplvrpMsg") ;
						if(isBplvrpAddorUpdated){
							j = takeAction.length;
						}
					}
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);
				}
			} else {
				bplvrpMsg = ApplicationConstants.NO_ACTION_TAKEN;
			}
			//update BplvrpVOList in application state.
			facade.getApplicationState().setBplvrpList(bplvrpList);
			lookUpTableListVO.setBplvrpVOList(bplvrpList);
			modelAndView = new ModelAndView(BPLVRP_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("bplvrpMsg",bplvrpMsg);
			modelAndView.addObject("bplvrpList",bplvrpList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in BplvrpController - addUpdateBplvrp() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(BplvrpController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
      }
	}
	/**
	 * Method to export Bplvrp look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of bplvrp object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/bplvrpExport", method = RequestMethod.POST)
	public ModelAndView bplvrpExport(HttpServletResponse response){
		List<BplvrpVO> bplvrpList = new LinkedList<BplvrpVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String bplvrpMsg ="";
		try{
			bplvrpList = facade.getApplicationState().getBplvrpList();
			if(bplvrpList != null && bplvrpList.size() != 0){
				// Key map to create header
				Map<String,String> keyMap = new LinkedHashMap<String,String>();
				keyMap.put("dbBnftIdCd", "Benefit Id Code");
				keyMap.put("dbProvNo", "Prov No");
				keyMap.put("dbProvLinVal", "Prov Line Val");
				keyMap.put("dbRFRLInd", "Referral Ind");
				keyMap.put("dbPRCRTInd", "Pre Cert Ind");
				keyMap.put("dbPRXSTNGInd", "Pre Exstng Ind");
				RteIntranetUtils.exportToExcel(response, bplvrpList, keyMap);
				bplvrpMsg = ApplicationConstants.EXPORT_SUCCESS;
			} else {
				bplvrpMsg = ApplicationConstants.NO_DATA;;
			}
			lookUpTableListVO.setBplvrpVOList(bplvrpList);
	        modelAndView = new ModelAndView(BPLVRP_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
	        modelAndView.addObject("bplvrpMsg",bplvrpMsg);
		    return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in BplvrpController - bplvrpExport() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_EXPOT_TABLE + "(BplvrpController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
       }
	}
}