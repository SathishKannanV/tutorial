/**
 * 
 */
package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;

/**
 * 
 * @author N726899
 * Cognizant_Offshore
 */
public class AdasvctVO implements Serializable {
	/**
	 * Constant serialized ID used for compatibility. 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * String of adaCd
	 */
	private String adaCd = "";
	/**
	 * String of svcTypeCd
	 */
	private String svcTypeCd = "";
	/**
	 * String of effective date(yyyy-MM-dd)
	 */
	private String effDate = "";
	/**
	 * String of expiration date(yyyy-MM-dd)
	 */
	private String expDate = "";
	/**
	 * String of record posted date(yyyy-MM-dd)
	 */
	private String postedDate = "";
	/**
	 * char of index to update the record.
	 */
	private char updatedInd;

	/**
	 * Default Constructor.
	 */
	public AdasvctVO() {
		super();
	}
	
	/**
	 * Creates a new AdasvctVO
	 * 
	 * @param adaCd
	 *            the value for {@link adaCd}
	 * @param svcTypeCd
	 *            the value for {@link svcTypeCd}
	 * @param effDate
	 *            the value for {@link effDate}
	 * @param expDate
	 *            the value for {@link expDate}
	 * @param postedDate
	 *            the value for {@link postedDate}
	 * @param updatedInd
	 *            the value for {@link updatedInd}
	 */
	public AdasvctVO(String adaCd, String svcTypeCd, String effDate,
			String expDate, String postedDate, char updatedInd) {
		super();
		this.adaCd = adaCd;
		this.effDate = effDate;
		this.expDate = expDate;
		this.postedDate = postedDate;
		this.svcTypeCd = svcTypeCd;
		this.updatedInd = updatedInd;
	}
	
	/**
	 * @return the adaCd
	 */
	public String getAdaCd() {
		return adaCd;
	}

	/**
	 * @param adaCd the adaCd to set
	 */
	public void setAdaCd(String adaCd) {
		this.adaCd = adaCd;
	}

	/**
	 * @return the svcTypeCd
	 */
	public String getSvcTypeCd() {
		return svcTypeCd;
	}

	/**
	 * @param svcTypeCd the svcTypeCd to set
	 */
	public void setSvcTypeCd(String svcTypeCd) {
		this.svcTypeCd = svcTypeCd;
	}

	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}

	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	/**
	 * @return the expDate
	 */
	public String getExpDate() {
		return expDate;
	}

	/**
	 * @param expDate the expDate to set
	 */
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	/**
	 * @return the postedDate
	 */
	public String getPostedDate() {
		return postedDate;
	}

	/**
	 * @param postedDate the postedDate to set
	 */
	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}

	/**
	 * @return the updatedInd
	 */
	public char getUpdatedInd() {
		return updatedInd;
	}

	/**
	 * @param updatedInd the updatedInd to set
	 */
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}
}
