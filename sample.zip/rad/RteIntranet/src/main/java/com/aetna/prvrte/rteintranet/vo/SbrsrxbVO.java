package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;

public class SbrsrxbVO implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1278326886193102615L;
	private String tranType = new String(); 
	private String vanIdCd = new String();
	private String typeCd = new String();
	private String convIdCode = new String();
	private String	seqNo= new String();
	private String nameAddrDiffInd = new String();
	private String retailMailOrderInd = new String();
	private String formularyId = new String();
	private String altFormularyId = new String();
	private String rXECoverageId = new String();
	private String copayId = new String();
	private String planTypeCd = new String();
	private String formularyTypeCd = new String();
	private String businessSectorCd = new String();
	private String postedDt = new String();
	public SbrsrxbVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SbrsrxbVO(String tranType, String vanIdCd, String typeCd,
			String convIdCode, String seqNo, String nameAddrDiffInd,
			String retailMailOrderInd, String formularyId,
			String altFormularyId, String rXECoverageId, String copayId,
			String planTypeCd, String formularyTypeCd, String businessSectorCd,String postedDt ) {
		super();
		this.tranType = tranType;
		this.vanIdCd = vanIdCd;
		this.typeCd = typeCd;
		this.convIdCode = convIdCode;
		this.seqNo = seqNo;
		this.nameAddrDiffInd = nameAddrDiffInd;
		this.retailMailOrderInd = retailMailOrderInd;
		this.formularyId = formularyId;
		this.altFormularyId = altFormularyId;
		this.rXECoverageId = rXECoverageId;
		this.copayId = copayId;
		this.planTypeCd = planTypeCd;
		this.formularyTypeCd = formularyTypeCd;
		this.businessSectorCd = businessSectorCd;
		this.postedDt = postedDt;
	}
	public String getTranType() {
		return tranType;
	}
	public void setTranType(String tranType) {
		this.tranType = tranType;
	}
	public String getVanIdCd() {
		return vanIdCd;
	}
	public void setVanIdCd(String vanIdCd) {
		this.vanIdCd = vanIdCd;
	}
	public String getTypeCd() {
		return typeCd;
	}
	public void setTypeCd(String typeCd) {
		this.typeCd = typeCd;
	}
	public String getConvIdCode() {
		return convIdCode;
	}
	public void setConvIdCode(String convIdCode) {
		this.convIdCode = convIdCode;
	}
	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public String getNameAddrDiffInd() {
		return nameAddrDiffInd;
	}
	public void setNameAddrDiffInd(String nameAddrDiffInd) {
		this.nameAddrDiffInd = nameAddrDiffInd;
	}
	public String getRetailMailOrderInd() {
		return retailMailOrderInd;
	}
	public void setRetailMailOrderInd(String retailMailOrderInd) {
		this.retailMailOrderInd = retailMailOrderInd;
	}
	public String getFormularyId() {
		return formularyId;
	}
	public void setFormularyId(String formularyId) {
		this.formularyId = formularyId;
	}
	public String getAltFormularyId() {
		return altFormularyId;
	}
	public void setAltFormularyId(String altFormularyId) {
		this.altFormularyId = altFormularyId;
	}
	public String getrXECoverageId() {
		return rXECoverageId;
	}
	public void setrXECoverageId(String rXECoverageId) {
		this.rXECoverageId = rXECoverageId;
	}
	public String getCopayId() {
		return copayId;
	}
	public void setCopayId(String copayId) {
		this.copayId = copayId;
	}
	public String getPlanTypeCd() {
		return planTypeCd;
	}
	public void setPlanTypeCd(String planTypeCd) {
		this.planTypeCd = planTypeCd;
	}
	public String getFormularyTypeCd() {
		return formularyTypeCd;
	}
	public void setFormularyTypeCd(String formularyTypeCd) {
		this.formularyTypeCd = formularyTypeCd;
	}
	public String getBusinessSectorCd() {
		return businessSectorCd;
	}
	public void setBusinessSectorCd(String businessSectorCd) {
		this.businessSectorCd = businessSectorCd;
	}
	public String getPostedDt() {
		return postedDt;
	}
	public void setPostedDt(String postedDt) {
		this.postedDt = postedDt;
	}
	
}
