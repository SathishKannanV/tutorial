/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.IndmntrpAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.IndmntrpDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.IndmntrpDisplayAdapter;
import com.aetna.prvrte.rteintranet.dto.IndmntrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.service.RteIndmntrpService
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Repository
public class RteIndmntrpDAOImpl implements RteIndmntrpDAO {
	/*
	 * Instance of IndmntrpDisplayAdapter.
	 */
	@Autowired(required = true)
	private IndmntrpDisplayAdapter indmntrpDisplayAdapter;
	/*
	 * Instance of IndmntrpAddAdapter.
	 */
	@Autowired(required = true)
	private IndmntrpAddAdapter indmntrpAddAdapter;
	/*
	 * Instance of IndmntrpDeleteAdapter.
	 */
	@Autowired(required = true)
	private IndmntrpDeleteAdapter indmntrpDeleteAdapter;
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteIndmntrpDAO#getIndmntrpLookUpList(com.aetna.prvrte.rteintranet.dto.IndmntrpDTO)
	 */
	@Override
	public Map<String, Object> getIndmntrpLookUpList(IndmntrpDTO indmntrpDTO) throws ApplicationException {
		return indmntrpDisplayAdapter.getIndmntrpLookUpList(indmntrpDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteIndmntrpDAO#addIndmntrpToDb(com.aetna.prvrte.rteintranet.dto.IndmntrpDTO)
	 */
	@Override
	public Map<String, Object> addIndmntrpToDb(IndmntrpDTO indmntrpDTO) throws ApplicationException {
		return indmntrpAddAdapter.addIndmntrpToDb(indmntrpDTO);
	}
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteIndmntrpService#deleteIndmntrp(com.aetna.prvrte.rteintranet.dto.IndmntrpDTO)
	 */
	@Override
	public Map<String, Object> deleteIndmntrp(IndmntrpDTO indmntrpDTO) throws ApplicationException {
		return indmntrpDeleteAdapter.deleteIndmntrp(indmntrpDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteIndmntrpDAO#addUpdateIndmntrp(com.aetna.prvrte.rteintranet.dto.IndmntrpDTO, java.util.List, int)
	 */
	@Override
	public Map<String, Object> addUpdateIndmntrp(IndmntrpDTO indmntrpDTO, List<IndmntrpDTO> indmntrpList, int index) throws ApplicationException {
		return indmntrpAddAdapter.addUpdateIndmntrp(indmntrpDTO, indmntrpList, index);
	}
	

}
