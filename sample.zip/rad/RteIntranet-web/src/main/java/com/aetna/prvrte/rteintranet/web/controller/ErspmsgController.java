/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.ErspmsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.ErspmsgVO;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;

/**
 * <h1>Erspmsg Controller</h1> The Erspmsg Controller is responsible for handling
 * the actual request from DispatcherServlet and returning an appropriate
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * @version 0.0.0
 * @since November 24, 2014
 * @author N726899
 * 
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/erspmsg/*")
public class ErspmsgController {
	/*
	 * Instance of logger for ErspmsgController.
	 */
	private static final Log log = LogFactory.getLog(ErspmsgController.class);
	/*
	 * Tile name of the erspmsg home view.
	 */
	public static final String ERSPMSG_HOME = ".erspmsgHome";
	/*
	 * Tile name of the erspmsg display view.
	 */
	public static final String ERSPMSG_DISPLAY = ".erspmsgDisplay";
	/*
	 * Tile name of the  add new erspmsg form view.
	 */
	public static final String ERSPMSG_ADD_NEW = ".addErspmsg";
	
	/*
	 * Instance of Facade.
	 */
	@Autowired(required = true)
	private Facade facade;
	/*
	 * Model and view of success operation.
	 */
	private ModelAndView modelAndView;
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errorModelAndView;

	/**
	 * Method to display erspmsgLookup view.
	 * 
	 * @return view of erspmsgLookUp, if fails return error page
	 */
	@RequestMapping(value = "/erspmsgHome", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView getErspmsgLookUp(HttpServletRequest request) {
		try {
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView = new ModelAndView(ERSPMSG_HOME, "erspmsgVO", new ErspmsgVO());
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in ErspmsgController - getErspmsgLookUp() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_LOOKUP_VIEW + "(ErspmsgController)" + RteIntranetUtils.getTrimmedString(e.getMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}
	
	/**
	 * Method to get the erspmsgLookUp List from data store.
	 * 
	 * @param erspmsgVO
	 *            form view object of erspmsg.
	 * @return view of erspmsgDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/erspmsgLookUp", method = { RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getErspmsgLookUpList(@RequestParam(value="messageId" , required = false) String idString, 
		HttpServletRequest request,	@RequestParam(value="shortText" , required = false) String shortText){
		try {
			int messageId = 0;
			ErspmsgVO erspmsgVO = new ErspmsgVO();
			erspmsgVO.setShortText(shortText);
			if(!("".equals(idString))){
				messageId = Integer.parseInt(idString);
			}
			erspmsgVO.setMessageId(messageId);
			ErspmsgDTO erspmsgDTO = RTETranslator.toErspmsgDTO(erspmsgVO);
			
			Map<String, Object> erspmsgMap = facade.getErspmsgLookUpList(erspmsgDTO);
			//set ErspmsgVOList in application state.
			List<ErspmsgVO> erspmsgList = (List<ErspmsgVO>) erspmsgMap.get("erspmsgList");
			facade.getApplicationState().setErspmsgList(erspmsgList);
			LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
			lookUpTableListVO.setErspmsgVOList(erspmsgList);
			modelAndView = new ModelAndView(ERSPMSG_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("erspmsgMsg",erspmsgMap.get("erspmsgMsg"));
			modelAndView.addObject("erspmsgList", erspmsgList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e) {
			log.error("Exception occured in ErspmsgController - getErspmsgLookUp() method:"	+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(ErspmsgController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to display get add new Erspmsg form home view.
	 * 
	 * @return view of addErspmsgForm, if fails return error page
	 */
	@RequestMapping(value = "/addErspmsgForm", method = RequestMethod.POST)
	public ModelAndView getAddNewErspmsgFormHome(HttpServletRequest request) {
		try {
			String securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView = new ModelAndView(ERSPMSG_ADD_NEW, "erspmsgVO", new ErspmsgVO());
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in ErspmsgController - getAddNewErspmsgFormHome() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_VIEW + "(ErspmsgController)" + e.toString();
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the erspmsgLookUp List from data store.
	 * 
	 * @param erspmsgVO
	 *            form view object of erspmsg.
	 * @return view of erspmsgDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addErspmsg", method = RequestMethod.POST)
	public ModelAndView addErspmsg(final HttpServletRequest request, @ModelAttribute("addErspmsgForm") ErspmsgVO erspmsgVO) {
		try {
			String userId = RteIntranetUtils.getUserId(request); // "n242716";
			ErspmsgDTO erspmsgDTO = RTETranslator.toErspmsgDTO(erspmsgVO);
			erspmsgDTO.setUserId(userId);
			Map<String, Object> erspmsgMap = facade.addErspmsgToDb(erspmsgDTO);
			
			//set ErspmsgVOList in application state.
			List<ErspmsgVO> erspmsgList = (List<ErspmsgVO>) erspmsgMap.get("erspmsgList");
			facade.getApplicationState().setErspmsgList(erspmsgList);
			LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
			lookUpTableListVO.setErspmsgVOList(erspmsgList);
			modelAndView = new ModelAndView(ERSPMSG_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("erspmsgMsg",erspmsgMap.get("erspmsgMsg"));
			modelAndView.addObject("erspmsgList",erspmsgList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e) {
			log.error("Exception occured in ErspmsgController - addErspmsg() method:"+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_ROW + "(ErspmsgController) : " + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}
	
	/**
	 * Method to get the erspmsgLookUp List from data store.
	 * @param request
	 *            request object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of erspmsgDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/deleteErspmsg", method = RequestMethod.POST)
	public ModelAndView deleteErspmsg(@RequestParam(required = false) String[] takeAction,
		HttpServletRequest request,	@ModelAttribute("erspmsgDisplay")LookUpTableListVO lookUpTableListVO) {
		List<ErspmsgVO> erspmsgList = new LinkedList<ErspmsgVO>();
		try {
			int index;
			Map<String, Object> erspmsgMap = new HashedMap();
			String erspmsgMsg = "";
			erspmsgList = lookUpTableListVO.getErspmsgVOList();
			if(takeAction != null && takeAction.length != 0){
				boolean isErspmsgDeleted = false;
				if (erspmsgList != null && erspmsgList.size() != 0) {
					List<ErspmsgDTO> updatedErspmsgList = RTETranslator.toErspmsgDTOList(erspmsgList);
					for (int j = takeAction.length - 1; j >= 0; j--) {
						index = Integer.parseInt(takeAction[j]);
						ErspmsgDTO existingErspmsg = (ErspmsgDTO) updatedErspmsgList.get(index);
						if (existingErspmsg.getUpdatedInd() != ApplicationConstants.COPY) {
							int messageId = existingErspmsg.getMessageId();
							erspmsgMap = facade.deleteErspmsg(messageId);
							erspmsgMsg = (String) erspmsgMap.get("erspmsgMsg");
							isErspmsgDeleted = (Boolean) erspmsgMap.get("isErspmsgDeleted");
							if(isErspmsgDeleted){
								erspmsgList.remove(index);
							}else{
								j = 0;
							}
						} else{
							erspmsgList.remove(index);
						}
						
					}
					if(isErspmsgDeleted)
					erspmsgMsg = ApplicationConstants.ROWS_DELETED;
				
				}
			} else
				erspmsgMsg = ApplicationConstants.NO_ACTION_TAKEN;
			
			//update ErspmsgVOList in application state.
			facade.getApplicationState().setErspmsgList(erspmsgList);
			lookUpTableListVO.setErspmsgVOList(erspmsgList);
			modelAndView = new ModelAndView(ERSPMSG_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("erspmsgMsg",erspmsgMsg);
			modelAndView.addObject("erspmsgList",erspmsgList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in ErspmsgController - deleteErspmsg() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(ErspmsgController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
		}
	}

	/**
	 * Method to get the erspmsgLookUp List from data store.
	 * 
	 * @param erspmsgVO
	 *            form view object of erspmsg.
	 * @param takeAction
	 *          List of takeAction to copy the row
	 * @return view of erspmsgDisplay, if fails return error page
	 */
	@RequestMapping(value = "/copyErspmsg", method = RequestMethod.POST)
	public ModelAndView copyErspmsg(@RequestParam(required = false) String[] takeAction,
		HttpServletRequest request,	@ModelAttribute("erspmsgDisplay")LookUpTableListVO lookUpTableListVO) {
			int index;
			String erspmsgMsg ="";
			List<ErspmsgVO> erspmsgList = new LinkedList<ErspmsgVO>();
		try {
			erspmsgList = lookUpTableListVO.getErspmsgVOList();
			if(takeAction != null && takeAction.length != 0){
				if(erspmsgList != null && erspmsgList.size() != 0){
					for (int j = 0; j < takeAction.length; j++) {
						index = Integer.parseInt(takeAction[j]);
						ErspmsgVO existingErspmsgVO = (ErspmsgVO) erspmsgList.get(index);
						ErspmsgVO copiedErspmsgVO =  (ErspmsgVO) SerializationUtils.clone(existingErspmsgVO);
						copiedErspmsgVO.setUpdatedInd(ApplicationConstants.COPY);
						Timestamp currentTS = new Timestamp(System.currentTimeMillis());
						String postedDateTimeStamp = currentTS.toString();
						copiedErspmsgVO.setPostedDateTimeStamp(postedDateTimeStamp);
						copiedErspmsgVO.setMessageId(0);
						erspmsgList.add(copiedErspmsgVO);
					}
					erspmsgMsg = ApplicationConstants.ROWS_COPIED;
				}
			} else {
				erspmsgMsg = ApplicationConstants.NO_ACTION_TAKEN;
			}
			//update ErspmsgVOList in application state.
			facade.getApplicationState().setErspmsgList(erspmsgList);
			lookUpTableListVO.setErspmsgVOList(erspmsgList);
			modelAndView = new ModelAndView(ERSPMSG_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("erspmsgMsg",erspmsgMsg);
			modelAndView.addObject("erspmsgList",erspmsgList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in ErspmsgController - copyErspmsg() method:" + e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(ErspmsgController)" + RteIntranetUtils.getTrimmedString(e.getMessage());
			modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);
			return modelAndView;
		}
	}

	/**
	 * Method to get the erspmsgLookUp List from data store.
	 * 
	 * @param takeAction
	 *            list of selected indexes from view.
	 * @param request
	 *            request object.
	 * @return view of erspmsgDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addUpdateErspmsg", method = RequestMethod.POST)
	public ModelAndView addUpdateErspmsg(@RequestParam(required = false) String[] takeAction,
			@ModelAttribute("erspmsgDisplay")LookUpTableListVO lookUpTableListVO,HttpServletRequest request) {
		int index;
		String erspmsgMsg ="";
		List<ErspmsgVO> erspmsgList = new LinkedList<ErspmsgVO>();
		List<ErspmsgVO> modifiedErspmsgVOList = new LinkedList<ErspmsgVO>();
		try {
			modifiedErspmsgVOList = lookUpTableListVO.getErspmsgVOList();
			erspmsgList = facade.getApplicationState().getErspmsgList();
			if(takeAction != null && takeAction.length != 0){
				for(ErspmsgVO erspmsgVO : erspmsgList){
					if(erspmsgVO.getUpdatedInd() == ApplicationConstants.UPDATE_IND_Y){
						erspmsgVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				if(modifiedErspmsgVOList != null && modifiedErspmsgVOList.size() != 0
						&& erspmsgList != null && erspmsgList.size() != 0){
					Map<String, Object> erspmsgMap = new HashedMap();
					List<ErspmsgDTO> erspmsgDTOList = RTETranslator.toErspmsgDTOList(erspmsgList);
					for (int j = 0; j < takeAction.length; j++) {
						index = Integer.parseInt(takeAction[j]);
						ErspmsgDTO updatedErspmsgDTO = RTETranslator.toErspmsgDTO(modifiedErspmsgVOList.get(index));
						String userId = RteIntranetUtils.getUserId(request); // "n242716";
						updatedErspmsgDTO.setUserId(userId);
						Timestamp currentTS = new Timestamp(System.currentTimeMillis());
						String postedDateTimeStamp = currentTS.toString();
						updatedErspmsgDTO.setPostedDateTimeStamp(postedDateTimeStamp);
						
						erspmsgMap = facade.addUpdateErspmsg(updatedErspmsgDTO, erspmsgDTOList, index);
						List<ErspmsgDTO> erspmsgDtoList = (List<ErspmsgDTO>) erspmsgMap.get("erspmsgList");
						erspmsgList = RTETranslator.toErspmsgVOList(erspmsgDtoList);
						boolean isErspmsgAddorUpdated = (Boolean) erspmsgMap.get("isErspmsgAddorUpdated");
						erspmsgMsg = (String) erspmsgMap.get("erspmsgMsg") ;
						if(isErspmsgAddorUpdated){
							j = takeAction.length;
						} 
					}
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);
				}
			} else {
				erspmsgMsg = ApplicationConstants.NO_ACTION_TAKEN;
			}
			//update ErspmsgVOList in application state.
			facade.getApplicationState().setErspmsgList(erspmsgList);
			lookUpTableListVO.setErspmsgVOList(erspmsgList);
			modelAndView = new ModelAndView(ERSPMSG_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("erspmsgMsg",erspmsgMsg);
			modelAndView.addObject("erspmsgList",erspmsgList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in ErspmsgController - addUpdateErspmsg() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(ErspmsgController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
		}
	}
	/**
	 * Method to export Erspmsg look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of erspmsg object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/erspmsgExport", method = RequestMethod.POST)
	public ModelAndView erspmsgExport(HttpServletResponse response){
		List<ErspmsgVO> erspmsgList = new LinkedList<ErspmsgVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String erspmsgMsg="";
		try{
			erspmsgList = facade.getApplicationState().getErspmsgList();
			if(erspmsgList != null && erspmsgList.size() != 0){
				// Key map to create header
				Map<String,String> keyMap = new LinkedHashMap<String,String>();
				keyMap.put("messageId", "Message Id");
				keyMap.put("messageTypeCd", "Message Type Cd");
				keyMap.put("shortText", "Short Provider Text");
				keyMap.put("fullText", "Long Provider Text");
				keyMap.put("userId", "User Id");
				keyMap.put("postedDateTimeStamp", "Posted Timestamp");
				
				RteIntranetUtils.exportToExcel(response, erspmsgList, keyMap);
				erspmsgMsg = ApplicationConstants.EXPORT_SUCCESS;
			} else {
				erspmsgMsg = ApplicationConstants.NO_DATA;
			}
			lookUpTableListVO.setErspmsgVOList(erspmsgList);
	        modelAndView = new ModelAndView(ERSPMSG_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
	        modelAndView.addObject("erspmsgMsg",erspmsgMsg);
		    return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in ErspmsgController - erspmsgExport() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_EXPOT_TABLE + "(ErspmsgController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
       }
	}
}
