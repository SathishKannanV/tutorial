/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.sql.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.RtestypDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.RtestypVO;
import com.aetna.prvrte.rteintranet.vo.RtestypVO;

/**
 * @author N657186
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/rtestyp/*")
public class RtestypController {

	
	public static final String RTESTYP_HOME = ".rtestypHome";
	public static final String RTESTYP_LOOKUP = ".rtestypLookUp";
	public static final String RTESTYP_ADD = ".rtestypAdd";
	public static final String RTESTYP_LIST = ".rtestypList";

	

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(RtestypController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/rtestypHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRtestypLookUpHome(final HttpServletRequest request,Model model) {
		log.warn("Entered RtestypController - getRtestypLookUpHome()");
		String securityLevel ="";
		try{
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(RTESTYP_HOME, "rtestypVO",  new RtestypVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("RtestypController - securityLevel: "+ securityLevel);
		log.warn("Exit from RtestypController - getRtestypLookUpHome()");
		return mav;
		} catch (ApplicationException e){
			log.error("Exception occured in RtestypController - getRtestypLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (RtestypList). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rtestypVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherRtestyp", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRtestypLookUp(final HttpServletRequest request,@ModelAttribute("rtestypForm")RtestypVO rtestypVO){
		log.warn("Entered RtestypController - getRtestypLookUp()");
		ModelAndView mav ;
		String securityLevel ="";
		Map rtestypResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<RtestypDTO> rtestypDtoList = new LinkedList<RtestypDTO>();
		List<RtestypVO> rtestypVoList = new LinkedList<RtestypVO>();
		try{
		RtestypDTO rtestypDTO = RTETranslator.toRtestypDTO(rtestypVO);
		rtestypResultMap = facade.getRtestypLookUp(rtestypDTO);
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		rtestypDtoList = (List<RtestypDTO>) rtestypResultMap.get("rtestypList");
		rtestypVoList = RTETranslator.toRtestypVOList(rtestypDtoList);
		lookUpListVO.setRtestypVOList(rtestypVoList);
		facade.getApplicationState().setRtestypList(rtestypVoList);
		
		log.warn("getRtestypLookUp - rtestypMessage: "+ rtestypResultMap.get("rtestypMessage"));
		mav = new ModelAndView(RTESTYP_LOOKUP, "lookUpListVO", lookUpListVO);
		mav.addObject("rtestypMessage", rtestypResultMap.get("rtestypMessage"));
		mav.addObject("securityLevel", securityLevel);
		log.warn("Exit from RtestypController - getRtestypLookUp()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in rtestypController - getrtestypLookUp() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (RtestypList). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/AddNewRtestypRow")
	public ModelAndView loadAddNewRtestypScreen(final HttpServletRequest request,Model model) {	
		log.warn("Entered RtestypController - loadAddNewRtestypScreen()");
		ModelAndView mav = new ModelAndView(RTESTYP_ADD, "rtestypVO",  new RtestypVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in RtestypController - loadAddNewRtestypScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (loadAddNewRtestypScreen). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		log.warn("Exit from RtestypController - loadAddNewRtestypScreen()");
		return mav;
	}
	
	/**
	 * @param rtestypVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddRtestyp", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addNewRtestyp(final HttpServletRequest request, @ModelAttribute("addRtestypForm")RtestypVO rtestypVO){
		log.warn("Entered RtestypController - addNewRtestyp()");
		String securityLevel ="";
		Map rtestypResultMap = new HashMap();
		List<RtestypDTO> rtestypDtoList = new LinkedList<RtestypDTO>();
		List<RtestypVO> rtestypVoList = new LinkedList<RtestypVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString();
			//set current date to DbPostedDate
			rtestypVO.setPostedDate(postedDate);
			rtestypVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
			RtestypDTO rtestypDTO = RTETranslator.toRtestypDTO(rtestypVO);
			rtestypResultMap = facade.addNewRtestyp(rtestypDTO);

			if(rtestypResultMap.get("rtestypList")!=null){
				rtestypDtoList = (List<RtestypDTO>) rtestypResultMap.get("rtestypList");
				rtestypVoList = RTETranslator.toRtestypVOList(rtestypDtoList);
				
			}
			lookUpListVO.setRtestypVOList(rtestypVoList);
			facade.getApplicationState().setRtestypList(rtestypVoList);
			mav = new ModelAndView(RTESTYP_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("rtestypMessage", rtestypResultMap.get("rtestypMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("addNewRtestyp - rtestypMessage: "+ rtestypResultMap.get("rtestypMessage"));
			log.warn("Exit from RtestypController - addNewRtestyp()");
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in RtestypController - addNewRtestyp() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when adding a row to the database (AddRtestsc). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	@RequestMapping(value="/rtestypList")
	public String loadRtestypList() {   
		return RTESTYP_LIST;
	}
	
	
	
	/**
	 * @param rtestypVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteRtestyp", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView deleteRtestyp(final HttpServletRequest request,@ModelAttribute("rtestypDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtestypController - deleteRtestyp()");
		ModelAndView mav ;
		String rtestypMsg = "";
		boolean isRtestypDeleted = true;
		Map rtestypResultMap = new HashMap();
		String securityLevel ="";
		List<RtestypVO> rtestypList = new LinkedList<RtestypVO>();
		try{
			rtestypList = lookUpListVO.getRtestypVOList();
			int i;
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if ((rtestypList != null) && (takeAction != null)) {
				for(RtestypVO rtestypVO : rtestypList){
					if(rtestypVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtestypVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);

					RtestypVO existingRtestyp = (RtestypVO) rtestypList.get(i);
					if (existingRtestyp.getUpdatedInd() != ApplicationConstants.COPY) {
						String svcTypeCd = existingRtestyp.getSvcTypeCd();
						String effDate = existingRtestyp.getEffDate();
						
						rtestypResultMap = facade.deleteRtestyp(svcTypeCd, effDate);
						rtestypMsg = (String) rtestypResultMap.get("rtestypMessage");
						isRtestypDeleted = (Boolean) rtestypResultMap.get("isRtestypDeleted");
						
						if(isRtestypDeleted){
							rtestypList.remove(i);
						}else{
							j = 0;
						}
					}else{
						rtestypList.remove(i);
					}				
			}
				if(isRtestypDeleted)
					rtestypMsg = "Rows selected were Deleted in the database/list";
				
		}else
			rtestypMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRtestypList(rtestypList);
			lookUpListVO.setRtestypVOList(rtestypList);
			mav = new ModelAndView(RTESTYP_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtestypMessage",rtestypMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteRtestyp - rtestypMessage: "+ rtestypMsg);
		    log.warn("Exit from RtestypController - deleteRtestyp()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtestypController - deleteRtestyp() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (RtestypListChange). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rtestypVO
	 * @param takeAction
	 * @return
	 */
	@RequestMapping(value="/copyRtestyp", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView copyRtestyp(final HttpServletRequest request,@ModelAttribute("rtestypDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtestypController - copyRtestyp()");
		ModelAndView mav ;
		String rtestypMsg = "";
		int i;
		String securityLevel ="";
		List<RtestypVO> rtestypList = new LinkedList<RtestypVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtestypList = lookUpListVO.getRtestypVOList();
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString(); //Initialize Posted Date to today's date
			if ((rtestypList != null) && (takeAction != null)) {
				for(RtestypVO rtestypVO : rtestypList){
					if(rtestypVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtestypVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					RtestypVO existingRtestyp = (RtestypVO) rtestypList.get(i);
					
					RtestypVO copyRtestyp = new RtestypVO(existingRtestyp.getSvcTypeCd(), existingRtestyp.getCatCd(), 
							existingRtestyp.getDescription(), existingRtestyp.getPcpEligInd(),
							existingRtestyp.getEffDate(), existingRtestyp.getExpDate(), postedDate, 
							existingRtestyp.getBenTypeCd(), existingRtestyp.getSrcInd(),
							existingRtestyp.getAshInd(), existingRtestyp.getGenderCd(),
							existingRtestyp.getPlnsvctCd(), ApplicationConstants.COPY);
					rtestypList.add(copyRtestyp);
				}
				rtestypMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				rtestypMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRtestypList(rtestypList);
			lookUpListVO.setRtestypVOList(rtestypList);
			mav = new ModelAndView(RTESTYP_LOOKUP, "lookUpListVO", lookUpListVO);

		    mav.addObject("rtestypMessage",rtestypMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyRtestyp - rtestypMessage: "+ rtestypMsg);
		    log.warn("Exit from RtestypController - copyRtestyp()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in RtestypController - copyRtestyp() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (RtestypListChange). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	/**
	 * @param request
	 * @param rtestypVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateRtestyp", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addUpdateRtestyp(final HttpServletRequest request,@ModelAttribute("rtestypDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtestypController - addUpdateRtestyp()");
		ModelAndView mav ;
		String rtestypMsg = "";
		List<RtestypVO> updatedRtestypList = new LinkedList<RtestypVO>();
		List<RtestypDTO> updatedRtestypDtoList = new LinkedList<RtestypDTO>();
		List<RtestypVO> rtestypVoList = new LinkedList<RtestypVO>();
		List<RtestypVO> modifiedRtestypVoList = new LinkedList<RtestypVO>();
		List<RtestypDTO> rtestypDtoList = new LinkedList<RtestypDTO>();
		boolean isRtestypAddOrUpdated = false;
		Map rtestypResultMap = new HashMap();
		RtestypDTO editedRtestypDTO = new RtestypDTO();
		String securityLevel ="";
		try{
			rtestypVoList = facade.getApplicationState().getRtestypList();
			modifiedRtestypVoList = lookUpListVO.getRtestypVOList();
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			int i;
			
			
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString();
			
			
			if (takeAction != null && takeAction.length != 0) {
				if(rtestypVoList != null && rtestypVoList.size() != 0 
						&& modifiedRtestypVoList.size() != 0 && modifiedRtestypVoList != null){
				
				for(RtestypVO rtestypVO : rtestypVoList){
					if(rtestypVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtestypVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				rtestypDtoList = RTETranslator.toRtesypDTOList(rtestypVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					
					i = Integer.parseInt(takeAction[j]);
					RtestypVO seletedRtestyp = (RtestypVO) rtestypVoList.get(i);
					RtestypVO editedRtestyp = (RtestypVO) modifiedRtestypVoList.get(i);
					log.warn("addUpdateRtestyp - user selected: "+ i);
						
					
					RtestypVO editedRtestypVO = new RtestypVO(editedRtestyp.getSvcTypeCd(),editedRtestyp.getCatCd(), 
							editedRtestyp.getDescription(),editedRtestyp.getPcpEligInd(),editedRtestyp.getEffDate(),
							editedRtestyp.getExpDate(),postedDate,editedRtestyp.getBenTypeCd(),
							editedRtestyp.getSrcInd(),editedRtestyp.getAshInd(),editedRtestyp.getGenderCd(),
							editedRtestyp.getPlnsvctCd(),updatedInd);
					if(editedRtestypVO!=null){
					editedRtestypDTO = RTETranslator.toRtestypDTO(editedRtestypVO);
					}
					rtestypResultMap = facade.addUpdateRtestyp(editedRtestypDTO, rtestypDtoList, i, seletedRtestyp.getUpdatedInd());
					updatedRtestypDtoList = (List<RtestypDTO>) rtestypResultMap.get("rtestypDtoList");
					if(updatedRtestypDtoList!=null){
					updatedRtestypList = RTETranslator.toRtestypVOList(updatedRtestypDtoList);
					}
					isRtestypAddOrUpdated = (Boolean) rtestypResultMap.get("isrtestypAddorUpdated");
					rtestypMsg = (String) rtestypResultMap.get("rtestypMessage") ;
					if(!isRtestypAddOrUpdated){
						j = takeAction.length;
					}
				}
				
				if(isRtestypAddOrUpdated){
					rtestypMsg = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted.";
					String xSvcTypeCd, ySvcTypeCd, xEffDate, yEffDate;
					for (int x = updatedRtestypList.size() - 1 ; x > 0;  x--) {
						RtestypVO xRtestyp = (RtestypVO) updatedRtestypList.get(x);
						xSvcTypeCd= xRtestyp.getSvcTypeCd();
						xEffDate= xRtestyp.getEffDate();
						if (xRtestyp.getUpdatedInd() != ApplicationConstants.COPY) {
							for (int y = x - 1; y > -1; y--) {
								RtestypVO aRtestyp = (RtestypVO) updatedRtestypList.get(y);
								ySvcTypeCd= aRtestyp.getSvcTypeCd();
								yEffDate= aRtestyp.getEffDate();
								if (xSvcTypeCd.equals(ySvcTypeCd) && xEffDate.equals(yEffDate)) {
									updatedRtestypList.remove(y); 
									x--;
								}
							}
						}
					}
				}
				lookUpListVO.setRtestypVOList(updatedRtestypList);
				facade.getApplicationState().setRtestypList(updatedRtestypList);
				}else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);				
				}
		}else{
			rtestypMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setRtestypVOList(rtestypVoList);
			facade.getApplicationState().setRtestypList(rtestypVoList);
		}
			mav = new ModelAndView(RTESTYP_LOOKUP, "lookUpListVO", lookUpListVO);

		    mav.addObject("rtestypMessage",rtestypMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateRtestyp - rtestypMessage: "+ rtestypMsg);
		    log.warn("Exit from RtestypController - addUpdateRtestyp()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtestypController - deleteRtestyp() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (RtestypListChange). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * Method to export Rtestyp look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of rtestyp object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/rtestypExport", method = RequestMethod.POST)
	public ModelAndView rtestypExport(HttpServletResponse response){
		List<RtestypVO> rtestypList = new LinkedList<RtestypVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String rtestypMsg="";
		try{
			rtestypList = facade.getApplicationState().getRtestypList();
			if(rtestypList != null && rtestypList.size() != 0){
			// Key map to create header
			Map<String,String> keyMap = new LinkedHashMap<String,String>();
			keyMap.put("svcTypeCd", "Svc Type CD");
			keyMap.put("catCd", "Category Code");
			keyMap.put("description", "Description");
			keyMap.put("pcpEligInd", "PCP Elig Ind");
			keyMap.put("benTypeCd", "Ben Type CD");
			keyMap.put("effDate", "Effective Date");
			keyMap.put("expDate", "Expiration Date");
			keyMap.put("postedDate", "Posted Date");
			keyMap.put("srcInd", "Src Ind");
			keyMap.put("ashInd", "Ash Ind");
			keyMap.put("genderCd", "Gender CD");
			keyMap.put("plnsvctCd", "Plnsvct CD");
			
			RteIntranetUtils.exportToExcel(response, rtestypList, keyMap);
			rtestypMsg = "LookUp table exported successfully.";
			} else {
				rtestypMsg = "No data found.";
			}
			lookUpTableListVO.setRtestypVOList(rtestypList);
	        mav = new ModelAndView(RTESTYP_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
		    mav.addObject("rtestypMessage",rtestypMsg);
			return mav;
		}catch (ApplicationException e) {
			log.error("Exception occured in RtestypController - rtestypExport() method:"
					+ e.getErrorMessage());
			String errorMsg = "Error encountered while export to excel. "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errormav;
		}
	}
}
