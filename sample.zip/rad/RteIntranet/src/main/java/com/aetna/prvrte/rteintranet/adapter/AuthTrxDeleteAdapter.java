/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class AuthTrxDeleteAdapter extends StoredProcedure {

	public AuthTrxDeleteAdapter() {}

	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(AuthTrxDeleteAdapter.class);
	
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public AuthTrxDeleteAdapter(DataSource datasource, String storedProc) throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of AdasvctAdapter : " + storedProc);
		declareParameter(new SqlParameter(DBConstants.IN_USERID_NO, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));

	}
	
	/**
	 * Method to delete the AuthTrx data from data store.
	 * 
	 * @param authTrxList
	 *            List of aetna ids.
	 * @param takeAction
	 *            List of selected indexes to delete aetna id.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from AuthTrx list and success or
	 *         error message.
	 * @throws ApplicationException
	 *             if deletion fails.
	 */
	public Map<String, Object> deleteAuthTrx(List<String> authTrxList, String authTrx, int index) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering getAdasvctLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, String> params = new LinkedHashMap<String, String>();
		String newMessage = "";
		boolean isAuthTrxDeleted = false;
		try {
			params.put(DBConstants.IN_USERID_NO, authTrx);
			log.info("Params for getting Adasvct LookUp List : " + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			if ("0".equals(sqlCode)){
				authTrxList.remove(index);
				newMessage = ApplicationConstants.ROWS_DELETED;
			} else {
				isAuthTrxDeleted = true; 
				newMessage = ApplicationConstants.DELETE_ROW_FAILS + sqlCode;
				
			}
			
			resultMap.put("authTrxMsg", newMessage);
			resultMap.put("authTrxList", authTrxList);
			resultMap.put("isAuthTrxDeleted", isAuthTrxDeleted);
			return resultMap;
		} catch (DataAccessException dae) {
			log.error("AuthTrxDisplayAdapter : Data access excpetion occured " + dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("AuthTrxDisplayAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} finally {

		}
	}
}
