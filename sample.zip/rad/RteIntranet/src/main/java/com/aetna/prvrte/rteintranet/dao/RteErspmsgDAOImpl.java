/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.ErspmsgAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.ErspmsgDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.ErspmsgDisplayAdapter;
import com.aetna.prvrte.rteintranet.dto.ErspmsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.service.RteErspmsgService
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Repository
public class RteErspmsgDAOImpl implements RteErspmsgDAO {
	/*
	 * Instance of ErspmsgDisplayAdapter.
	 */
	@Autowired(required = true)
	private ErspmsgDisplayAdapter erspmsgDisplayAdapter;
	/*
	 * Instance of ErspmsgAddAdapter.
	 */
	@Autowired(required = true)
	private ErspmsgAddAdapter erspmsgAddAdapter;
	/*
	 * Instance of ErspmsgDeleteAdapter.
	 */
	@Autowired(required = true)
	private ErspmsgDeleteAdapter erspmsgDeleteAdapter;
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteErspmsgDAO#getErspmsgLookUpList(com.aetna.prvrte.rteintranet.dto.ErspmsgDTO)
	 */
	@Override
	public Map<String, Object> getErspmsgLookUpList(ErspmsgDTO erspmsgDTO) throws ApplicationException {
		return erspmsgDisplayAdapter.getErspmsgLookUpList(erspmsgDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteErspmsgDAO#addErspmsgToDb(com.aetna.prvrte.rteintranet.dto.ErspmsgDTO)
	 */
	@Override
	public Map<String, Object> addErspmsgToDb(ErspmsgDTO erspmsgDTO) throws ApplicationException {
		return erspmsgAddAdapter.addErspmsgToDb(erspmsgDTO);
	}

	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteErspmsgDAO#deleteErspmsg(java.lang.Integer)
	 */
	@Override
	public Map<String, Object> deleteErspmsg(int messageId) throws ApplicationException {
		return erspmsgDeleteAdapter.deleteErspmsg(messageId);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteErspmsgDAO#addUpdateErspmsg(com.aetna.prvrte.rteintranet.dto.ErspmsgDTO, java.util.List, int)
	 */
	@Override
	public Map<String, Object> addUpdateErspmsg(ErspmsgDTO erspmsgDTO, List<ErspmsgDTO> erspmsgList, int index) throws ApplicationException {
		return erspmsgAddAdapter.addUpdateErspmsg(erspmsgDTO, erspmsgList, index);
	}
	

}
