/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.vo;

public class RtestscVO {

	private String svcTypeCd = ""; 
	private String scsrSvcTypeCd = "";
	private String scsrServiceCd = "";
	private String effDate = "";
	private String stscDescTxt = "";
	private String expDate = "";
	private String postedDateTimestamp = "";
	private String userId = "";
	private char   updatedInd;
	
	
	/**
	 * @param svcTypeCd
	 * @param scsrSvcTypeCd
	 * @param scsrServiceCd
	 * @param effDate
	 * @param stscDescTxt
	 * @param expDate
	 * @param postedDateTimestamp
	 * @param userId
	 * @param updatedInd
	 */
	public RtestscVO(String svcTypeCd, String scsrSvcTypeCd,
			String scsrServiceCd, String effDate, String stscDescTxt,
			String expDate, String postedDateTimestamp, String userId,
			char updatedInd) {
		this.svcTypeCd = svcTypeCd;
		this.scsrSvcTypeCd = scsrSvcTypeCd;
		this.scsrServiceCd = scsrServiceCd;
		this.effDate = effDate;
		this.stscDescTxt = stscDescTxt;
		this.expDate = expDate;
		this.postedDateTimestamp = postedDateTimestamp;
		this.userId = userId;
		this.updatedInd = updatedInd;
	}
	
	
	/**
	 * 
	 */
	public RtestscVO() {
		super();
		
	}




	/**
	 * @return the svcTypeCd
	 */
	public String getSvcTypeCd() {
		return svcTypeCd;
	}
	/**
	 * @param svcTypeCd the svcTypeCd to set
	 */
	public void setSvcTypeCd(String svcTypeCd) {
		this.svcTypeCd = svcTypeCd;
	}
	/**
	 * @return the scsrSvcTypeCd
	 */
	public String getScsrSvcTypeCd() {
		return scsrSvcTypeCd;
	}
	/**
	 * @param scsrSvcTypeCd the scsrSvcTypeCd to set
	 */
	public void setScsrSvcTypeCd(String scsrSvcTypeCd) {
		this.scsrSvcTypeCd = scsrSvcTypeCd;
	}
	/**
	 * @return the scsrServiceCd
	 */
	public String getScsrServiceCd() {
		return scsrServiceCd;
	}
	/**
	 * @param scsrServiceCd the scsrServiceCd to set
	 */
	public void setScsrServiceCd(String scsrServiceCd) {
		this.scsrServiceCd = scsrServiceCd;
	}
	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}
	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	/**
	 * @return the stscDescTxt
	 */
	public String getStscDescTxt() {
		return stscDescTxt;
	}
	/**
	 * @param stscDescTxt the stscDescTxt to set
	 */
	public void setStscDescTxt(String stscDescTxt) {
		this.stscDescTxt = stscDescTxt;
	}
	/**
	 * @return the expDate
	 */
	public String getExpDate() {
		return expDate;
	}
	/**
	 * @param expDate the expDate to set
	 */
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	/**
	 * @return the postedDateTimestamp
	 */
	public String getPostedDateTimestamp() {
		return postedDateTimestamp;
	}
	/**
	 * @param postedDateTimestamp the postedDateTimestamp to set
	 */
	public void setPostedDateTimestamp(String postedDateTimestamp) {
		this.postedDateTimestamp = postedDateTimestamp;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the updatedInd
	 */
	public char getUpdatedInd() {
		return updatedInd;
	}
	/**
	 * @param updatedInd the updatedInd to set
	 */
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}
	
	
}
