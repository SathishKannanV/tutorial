/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.ProcexAdapter;
import com.aetna.prvrte.rteintranet.adapter.ProcexPRX2Adapter;
import com.aetna.prvrte.rteintranet.adapter.ProcexPRX3Adapter;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 * Cognizant_Offshore
 */
@Repository
public class ProcexDAOImpl implements ProcexDAO {
	
	@Autowired(required=true)
	private ProcexAdapter procexAdapter;
	
	@Autowired(required=true)
	private ProcexPRX2Adapter procexPRX2Adapter;
	
	@Autowired(required=true)
	private ProcexPRX3Adapter procexPRX3Adapter;
	
	@Override
	public Map getProcexLookUpTable(String procexCode, String svcTypeCode)
			throws ApplicationException {
		
		return procexAdapter.getProcexLookUpTable(procexCode, svcTypeCode);
	}

	@Override
	public Map addNewProcex(ProcexDTO procexDTO) throws ApplicationException {
		return procexPRX2Adapter.addNewProcex(procexDTO);
	}

	@Override
	public Map deleteProcex(String procexCd, String svcTypeCd)
			throws ApplicationException {
		return procexPRX3Adapter.deleteProcex(procexCd, svcTypeCd);
	}

	@Override
	public Map addUpdateProcex(ProcexDTO existProcexDTO,
			List<ProcexDTO> procexDtoList, int index, char updateInd) throws ApplicationException {
		return procexPRX2Adapter.addUpdateProcex(existProcexDTO, procexDtoList, index, updateInd);
	}

}
