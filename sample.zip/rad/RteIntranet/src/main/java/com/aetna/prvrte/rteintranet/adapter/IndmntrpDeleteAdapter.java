/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.IndmntrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class IndmntrpDeleteAdapter extends StoredProcedure {

	public IndmntrpDeleteAdapter() {}

	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(IndmntrpDeleteAdapter.class);
	
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public IndmntrpDeleteAdapter(DataSource datasource, String storedProc) throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of IndmntrpAdapter : " + storedProc);
		//Input Params declaration
		declareParameter(new SqlParameter(DBConstants.LS_INDMNTY_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_RFRL_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_PRCRT_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_SHRT_NM, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_NM, Types.CHAR));
		
		//Output Params declaration
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
	}
	
	/**
	 * Method to delete the Indmntrp data from data store.
	 * 
	 * @param indmntrpDTO
	 *            indmntrpDTO object to delete.
	 * @return Map of flag to delete the data from Indmntrp list and success or
	 *         error message.
	 * @throws ApplicationException
	 *             if deletion fails.
	 */
	public Map<String, Object> deleteIndmntrp(IndmntrpDTO indmntrpDTO) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering deleteIndmntrp ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, String> params = new LinkedHashMap<String, String>();
		String erspmsgMsg = "";
		boolean isIndmntrpDeleted = false;
		try {
			String dbIndmntyCd = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyCd());
			String dbIndmntyRFRLInd = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyRFRLInd());
			String dbIndmntyPRCRTInd = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyPRCRTInd());
			String dbIndmntyShrtNm = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyShrtNm());
			String dbIndmntyNm = RteIntranetUtils.getTrimmedString(indmntrpDTO.getDbIndmntyNm());
			
			//Query params
			params.put(DBConstants.LS_INDMNTY_CD, dbIndmntyCd);
			params.put(DBConstants.LS_RFRL_IND, dbIndmntyRFRLInd);
			params.put(DBConstants.LS_PRCRT_IND, dbIndmntyPRCRTInd);
			params.put(DBConstants.LS_SHRT_NM, dbIndmntyShrtNm);
			params.put(DBConstants.LS_NM, dbIndmntyNm);
			//params.put(LS_SELRQ_IND, dbPcpSelReqInd);
			log.info("Params ro delete Indmntrp LookUp List : " + params);
			
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			if ("0".equals(sqlCode)){
				isIndmntrpDeleted = true;
				erspmsgMsg = ApplicationConstants.ROWS_DELETED;
				
			} else {
				erspmsgMsg = ApplicationConstants.DELETE_ROW_FAILS + sqlCode;
				
			}
			resultMap.put("indmntrpMsg", erspmsgMsg);
			resultMap.put("isIndmntrpDeleted", isIndmntrpDeleted);
			return resultMap;
			
		} catch (DataAccessException dae) {
			log.error("IndmntrpDeleteAdapter : Data access excpetion occured " + dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("IndmntrpDeleteAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} finally {

		}
	}
}
