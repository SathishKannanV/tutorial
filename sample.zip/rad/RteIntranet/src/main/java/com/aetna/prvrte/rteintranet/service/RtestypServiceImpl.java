/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.RtestypDAO;
import com.aetna.prvrte.rteintranet.dto.RtestypDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 * Cognizant_Offshore
 */
@Service
public class RtestypServiceImpl implements RtestypService {

	@Autowired(required=true)
	private RtestypDAO rtestypDAO;

	@Override
	public Map getRtestypLookUp(RtestypDTO rtestypDTO) throws ApplicationException {
		return rtestypDAO.getRtestypLookUp(rtestypDTO);
	}

	@Override
	public Map addNewRtestyp(RtestypDTO rtestypDTO) throws ApplicationException {
		return rtestypDAO.addNewRtestyp(rtestypDTO);
	}

	@Override
	public Map deleteRtestyp(String rtestypCd, String svcTypeCd)
			throws ApplicationException {
		return rtestypDAO.deleteRtestyp(rtestypCd,svcTypeCd);
	}

	@Override
	public Map addUpdateRtestyp(RtestypDTO existRtestypDTO, List<RtestypDTO> rtestypDtoList,
			int index, char updateInd) throws ApplicationException {
		return rtestypDAO.addUpdateRtestyp(existRtestypDTO,rtestypDtoList, index, updateInd);
	}

	
}
