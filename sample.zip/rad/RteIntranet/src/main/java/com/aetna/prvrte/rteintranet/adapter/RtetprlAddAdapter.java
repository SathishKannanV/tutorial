package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.RtetprlDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;



/**
 * @author N624926
 * Cognizant_Offshore
 */
public class RtetprlAddAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RtetprlAddAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtetprlAddAdapter(DataSource datasource, String storedProc) throws SQLException{
		super(datasource, storedProc);
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_STC_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_TOS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_POS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_GROUP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_RULE_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_ORDER_NO, Types.INTEGER));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_EXPRTN_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_POSTED_DTS, Types.TIMESTAMP));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_USER_ID, Types.CHAR));

		declareParameter(new SqlOutParameter(DBConstants.OUT_LS_ADD_UPDATE, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.OUT_LS_SQLCODE, Types.INTEGER));
	}
	
	
	/**
	 * Method to add new RTETPRL to data store.
	 * 
	 * @param rtetprlDTO
	 *            rtetprlDTO object.
	 * @return Map of added RTETPRL data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addNewRtetprl(RtetprlDTO rtetprlDTO) throws ApplicationException {
		
		log.warn("Entered RtetprlAddAdapter  - addNewRtetprl");
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map rtetprlMap = new HashMap();
		Timestamp currentTS = new Timestamp(System.currentTimeMillis());
		String postedDate = currentTS.toString(); 
		rtetprlDTO.setPostedDate(postedDate);
		rtetprlDTO.setUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
		params.put(DBConstants.IN_RTETPRL_STC_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getStcCd()));
		params.put(DBConstants.IN_RTETPRL_TOS_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getTosCd()));
		params.put(DBConstants.IN_RTETPRL_POS_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getPosCd()));
		params.put(DBConstants.IN_RTETPRL_GROUP_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getGroupCd()));
		params.put(DBConstants.IN_RTETPRL_RULE_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getRuleCd()));
		params.put(DBConstants.IN_RTETPRL_ORDER_NO, String.valueOf(rtetprlDTO.getOrderNo()));
		params.put(DBConstants.IN_RTETPRL_EFF_DT, RteIntranetUtils.getTrimmedString(rtetprlDTO.getEffDate()));
		params.put(DBConstants.IN_RTETPRL_EXPRTN_DT, RteIntranetUtils.getTrimmedString(rtetprlDTO.getExpDate()));
		params.put(DBConstants.IN_RTETPRL_POSTED_DTS, RteIntranetUtils.getTrimmedString(rtetprlDTO.getPostedDate()));
		params.put(DBConstants.IN_RTETPRL_USER_ID, RteIntranetUtils.getTrimmedString(rtetprlDTO.getUserId()));
		log.warn(params);	
		
		try {
			results = execute(params);
			log.warn("RtetprlAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.OUT_LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_LS_SQLCODE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				List<RtetprlDTO> rtetprlList = new LinkedList<RtetprlDTO>();
				rtetprlList.add(rtetprlDTO);
				rtetprlMap.put("rtetprlList", rtetprlList);
				if ("A".equalsIgnoreCase(actionCode)) {
					newMessage = "This row added to the database";
				}else {
					newMessage ="Row already exists on the database. It was updated with these values.";					
					rtetprlDTO.setUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
				}				
				}
			else {
				newMessage = "Unable to add row to the database. SQLCODE = " + sqlCode;
			}
			rtetprlMap.put("rtetprlMessage", newMessage);
		return rtetprlMap;
	}catch (Exception exception){
		log.error("RtetprlAddAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}

	
	/**
	 * Method to add/update list of RTETPRL to data store.
	 * 
	 * @param existingRtetprl
	 *            
	 * @param rtetprlDtoList
	 *            list of RtetprlDTO object.
	 * @param index
	 *            index to update the data
	 * @param updateInd
	 * 			  update indicator to update the data
	 * @return Map of flag to delete the data from RTETPRL list, success or
	 *         error message and list of RTETPBR.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addUpdateRtetprl(RtetprlDTO existingRtetprl,
			List<RtetprlDTO> rtetprlDtoList, int index,char updateInd) throws ApplicationException{
		log.warn("Entered RtetprlAddAdapter  - addUpdateRtetprl");
		boolean isRtetprlAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map rtetprlMap = new HashMap();
		Timestamp currentTS = new Timestamp(System.currentTimeMillis());
		String postedDate = currentTS.toString(); 
		existingRtetprl.setPostedDate(postedDate);
		params.put(DBConstants.IN_RTETPRL_STC_CD, RteIntranetUtils.getTrimmedString(existingRtetprl.getStcCd()));
		params.put(DBConstants.IN_RTETPRL_TOS_CD, RteIntranetUtils.getTrimmedString(existingRtetprl.getTosCd()));
		params.put(DBConstants.IN_RTETPRL_POS_CD, RteIntranetUtils.getTrimmedString(existingRtetprl.getPosCd()));
		params.put(DBConstants.IN_RTETPRL_GROUP_CD, RteIntranetUtils.getTrimmedString(existingRtetprl.getGroupCd()));
		params.put(DBConstants.IN_RTETPRL_RULE_CD, RteIntranetUtils.getTrimmedString(existingRtetprl.getRuleCd()));
		params.put(DBConstants.IN_RTETPRL_ORDER_NO, String.valueOf(existingRtetprl.getOrderNo()));
		params.put(DBConstants.IN_RTETPRL_EFF_DT, RteIntranetUtils.getTrimmedString(existingRtetprl.getEffDate()));
		params.put(DBConstants.IN_RTETPRL_EXPRTN_DT, RteIntranetUtils.getTrimmedString(existingRtetprl.getExpDate()));
		params.put(DBConstants.IN_RTETPRL_POSTED_DTS, RteIntranetUtils.getTrimmedString(existingRtetprl.getPostedDate()));
		params.put(DBConstants.IN_RTETPRL_USER_ID, RteIntranetUtils.getTrimmedString(existingRtetprl.getUserId()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("RtetprlAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.OUT_LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_LS_SQLCODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				isRtetprlAddorUpdated = true;
				if (ApplicationConstants.ZERO_0.equalsIgnoreCase(actionCode)) {
					
					if (updateInd == ApplicationConstants.COPY)						
						rtetprlDtoList.set(index, existingRtetprl);						
					else
						rtetprlDtoList.add(existingRtetprl);
				}
				else
					rtetprlDtoList.set(index, existingRtetprl);
				
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			rtetprlMap.put("rtetprlMsg",newMessage);
			rtetprlMap.put("rtetprlDtoList",rtetprlDtoList);
			rtetprlMap.put("isRtetprlAddorUpdated", isRtetprlAddorUpdated);
			return rtetprlMap;
		}catch (Exception exception){
			log.error("RtetprlAddAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}

	
}