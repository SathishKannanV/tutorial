package com.aetna.prvrte.rteintranet.vo;

public class SrchdtlVO {

	
	private String srchscFirstId=new String();
	private String srchcolCd = new String(); 
	private String srchresCd = new String();
	private String srchscSecondId;
	private String srchdtlStCd = new String(); 
	private String srcherrCd = new String();
	private String effDate = new String(); 
	private String expDate = new String();
	private String postedDate = new String();
	private String cmRollCode = new String();
	private String srchdtlId=new String();
	private char   updatedInd;
	
	public SrchdtlVO() {
		super();
	}

	public SrchdtlVO( String srchscFirstId, String srchcolCd, String srchresCd, String srchscSecondId,
			String srchdtlStCd, String srcherrCd, String cmRollCode,String effDate, String expDate, String postedDate, String srchdtlId, char updatedInd) {
		super();
		this.srchdtlId = srchdtlId;
		this.srchscFirstId = srchscFirstId;
		this.srchcolCd = srchcolCd;
		this.srchresCd = srchresCd;
		this.srchscSecondId = srchscSecondId;
		this.srchdtlStCd = srchdtlStCd;
		this.srcherrCd = srcherrCd;
		this.effDate = effDate;
		this.expDate = expDate;
		this.postedDate = postedDate;
		this.cmRollCode = cmRollCode;
		this.updatedInd = updatedInd;
	}

	public String getcmRollCode() {
		return cmRollCode;
	}

	public String getEffDate() {
		return effDate;
	}

	public String getExpDate() {
		return expDate;
	}

	public String getPostedDate() {
		return postedDate;
	}

	public String getSrchcolCd() {
		return srchcolCd;
	}

	public String getSrchdtlId() {
		return srchdtlId;
	}

	public String getSrchdtlStCd() {
		return srchdtlStCd;
	}

	public String getSrcherrCd() {
		return srcherrCd;
	}

	public String getSrchresCd() {
		return srchresCd;
	}

	public String getSrchscFirstId() {
		return srchscFirstId;
	}

	public String getSrchscSecondId() {
		return srchscSecondId;
	}

	public char getUpdatedInd() {
		return updatedInd;
	}

	public void setCmRollCode(String cmRollCode) {
		this.cmRollCode= cmRollCode;
	}

	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}

	public void setSrchcolCd(String srchcolCd) {
		this.srchcolCd = srchcolCd;
	}

	public void setSrchdtlId(String srchdtlId) {
		this.srchdtlId = srchdtlId;
	}

	public void setSrchdtlStCd(String srchdtlStCd) {
		this.srchdtlStCd = srchdtlStCd;
	}

	public void setSrcherrCd(String srcherrCd) {
		this.srcherrCd = srcherrCd;
	}

	public void setSrchresCd(String srchresCd) {
		this.srchresCd = srchresCd;
	}

	public void setSrchscFirstId(String srchscFirstId) {
		this.srchscFirstId = srchscFirstId;
	}

	public void setSrchscSecondId(String srchscSecondId) {
		this.srchscSecondId = srchscSecondId;
	}

	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}

}
