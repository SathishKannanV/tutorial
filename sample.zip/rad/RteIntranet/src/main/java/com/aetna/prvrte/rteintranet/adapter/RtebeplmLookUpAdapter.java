/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RtebeplmDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N657186
 *
 */
public class RtebeplmLookUpAdapter extends StoredProcedure{
	private final Log log = LogFactory.getLog(RtebeplmLookUpAdapter.class);
	
	public RtebeplmLookUpAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_RTEBEPLM_BNFT_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_RTEBEPLM_EPLC_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR1, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N; //Used by RTEBEPLMDisplay, not on database
				RtebeplmDTO rtebeplmDTO = new RtebeplmDTO();
				rtebeplmDTO.setHmoBenefitCd(RteIntranetUtils.getTrimmedString(rs.getString("RTEBEPLM_BNFT_CD")));
				rtebeplmDTO.setFrequencyInd(RteIntranetUtils.getTrimmedString(rs.getString("RTEBEPLM_FREQ_IND")));
				rtebeplmDTO.setEligPerLimitCd(RteIntranetUtils.getTrimmedString(rs.getString("RTEBEPLM_EPLC_CD")));
				rtebeplmDTO.setEffDate(RteIntranetUtils.getTrimmedString(rs.getString("RTEBEPLM_EFF_DT")));
				rtebeplmDTO.setExpDate(RteIntranetUtils.getTrimmedString(rs.getString("RTEBEPLM_EXP_DT")));
				rtebeplmDTO.setPostedDateTimestamp(RteIntranetUtils.getTrimmedString(rs.getString("RTEBEPLM_POSTED_DTS")));
				rtebeplmDTO.setUpdatedInd(updatedInd);
				return rtebeplmDTO;
			}

		}));

	}
	
	@SuppressWarnings("unchecked")
	public Map getRtebeplmLookUpTable (RtebeplmDTO rtebeplmDTO) throws ApplicationException {
		log.warn("Entered RtebeplmLookUpAdapter  - getRtebeplmLookUp");
		//It fetches rtebeplm list based on the criteria selected by user
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map rtebeplmMap = new HashMap();
		String hmoBenefitCd = RteIntranetUtils.getTrimmedString(rtebeplmDTO.getHmoBenefitCd());
		String eligPerLimitCd = RteIntranetUtils.getTrimmedString(rtebeplmDTO.getEligPerLimitCd());
		
		params.put(DBConstants.LS_RTEBEPLM_BNFT_CD, hmoBenefitCd);
		params.put(DBConstants.LS_RTEBEPLM_EPLC_CD, eligPerLimitCd);
		
		log.warn(params);
		Map results = null;
		
		List<RtebeplmDTO> rtebeplmList = new LinkedList<RtebeplmDTO>();
		String newMessage="";
		
		try {
			log.warn("RtebeplmLookUpAdapter: Executing stored procedure : " + "hmoBenefitCd : " + hmoBenefitCd + " ; eligPerLimitCd : "+eligPerLimitCd);
					
			results = execute(params);
			log.warn("RtebeplmLookUpAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			rtebeplmList = (List<RtebeplmDTO>) results
					.get(DBConstants.READ_CURSOR1);	
	
			
			//if (null != results) {
			if (rtebeplmList.isEmpty()){
				
				if ("0".equals(sqlCode)) {
					newMessage = "No Data on database for HMO Benefit Cd: " + hmoBenefitCd
							+ ", EPLC: " + eligPerLimitCd;
					
				} else {
					newMessage = "Problem in DB2. sqlcode: " + sqlCode +
							" HMO Benefit Cd: " + hmoBenefitCd+ ", EPLC: " + eligPerLimitCd; 
					
				}			  		  		  
			} else {
				newMessage = "Data found on database for HMO Benefit Cd: " + hmoBenefitCd
						+ ", EPLC: " + eligPerLimitCd;
			}
			/*}else{
				newMessage = "No Data found on the table.";
			}*/
			rtebeplmMap.put("rtebeplmMessage", newMessage);
			rtebeplmMap.put("rtebeplmList",rtebeplmList);
			return rtebeplmMap;
		}catch (Exception exception){
			log.error("RtebeplmLookUpAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
		
	}
	
	
}
