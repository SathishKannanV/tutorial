/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;


/**
 * <h1>Aetctls Controller</h1> The Aetctls Controller is responsible for handling
 * the actual request from DispatcherServlet and returning an appropriate
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * 
 * @author N726899 Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/aetCtls/*")
public class AetCtlsController {
	/*
	 * Instance of logger for AetctlsController.
	 */
	private static final Log log = LogFactory.getLog(AetCtlsController.class);
	/*
	 * Tile name of the AETCTLS home view.
	 */
	public static final String AETCTLS_HOME = ".aetCtlsHome";
	/*
	 * Tile name of the AETCTLS display view.
	 */
	public static final String AETCTLS_DISPLAY = ".aetCtlsDisplay";

	/*
	 * Instance of Facade.
	 */
	@Autowired(required = true)
	private Facade facade;
	/*
	 * Model and view of success operation.
	 */
	private ModelAndView modelAndView;
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errorModelAndView;

	/**
	 * Method to display aetCtlsLookup view.
	 * 
	 * @return view of aetCtlsLookUp, if fails return error page
	 */
	@RequestMapping(value = "/aetCtlsHome", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView getAetctlsLookUp(HttpServletRequest request) {
		try {
			String userSecurityLevel ="";
			userSecurityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView = new ModelAndView(AETCTLS_HOME, "aetCtls", new Object());
			modelAndView.addObject("securityLevel", userSecurityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in AetCtlsController - getAetctlsLookUp() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_LOOKUP_VIEW + "(AetCtlsController) " + RteIntranetUtils.getTrimmedString(e.getMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the aetCtlsLookUp List from data store.
	 * 
	 * @param request
	 *            request object from view.
	 *            
	 * @return view of aetCtlsDisplay
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/aetCtlsLookUp", method = {RequestMethod.POST})
	public ModelAndView getAetctlsLookUpList(@RequestParam(required = false)String aetCtl, HttpServletRequest request) {
		try {
			String userSecurityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if (ApplicationConstants.USER_SECURITY_LEVEL_A.equalsIgnoreCase(userSecurityLevel)) {
				Map<String, Object> adasvclookUpMap = facade.getAetCtlsLookUpList(aetCtl);
				LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
				List<String> aetCtlsList =  (List<String>) adasvclookUpMap.get("aetCtlsList");
				//set updateAetCtlsList in application state
				facade.getApplicationState().setAetCtlsList(aetCtlsList);
				lookUpTableListVO.setAetCtlsVOList(aetCtlsList);
				
				modelAndView = new ModelAndView(AETCTLS_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
				modelAndView.addObject("aetCtlsMsg",adasvclookUpMap.get("aetCtlsMsg"));
				modelAndView.addObject("aetCtlsList", aetCtlsList);
				modelAndView.addObject("securityLevel", userSecurityLevel);
				return modelAndView;
			} else {
				String errorMsg = ApplicationConstants.NO_AUTHORITY;
				errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
				errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
				return errorModelAndView;
			}
			
		} catch (ApplicationException e) {
			log.error("Exception occured in AetCtlsController - getAetCtlsLookUp() method:"	+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(AetCtlsController) " + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the aetCtlsLookUp List from data store.
	 * 
	 * @param request
	 *            request object from view.
	 * @return view of aetCtlsDisplay
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addAetCtls", method = RequestMethod.POST)
	public ModelAndView addAetCtls(@RequestParam(required = false) String aetCtl, HttpServletRequest request) {
		try {
			String userSecurityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if (ApplicationConstants.USER_SECURITY_LEVEL_A.equalsIgnoreCase(userSecurityLevel)) {
				Map<String, Object> aetctlsMap = facade.addAetCtlsToDb(aetCtl);
				
				List<String> aetCtlsList =  (List<String>) aetctlsMap.get("aetCtlsList");
				//set aetCtlsList in application state
				facade.getApplicationState().setAetCtlsList(aetCtlsList);
				LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
				lookUpTableListVO.setAetCtlsVOList(aetCtlsList);
				
				modelAndView = new ModelAndView(AETCTLS_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
				modelAndView.addObject("aetCtlsMsg",aetctlsMap.get("aetCtlsMsg"));
				modelAndView.addObject("aetCtlsList", aetCtlsList);
				modelAndView.addObject("securityLevel", userSecurityLevel);
				return modelAndView;
			} else {
				String errorMsg = ApplicationConstants.NO_AUTHORITY;
				errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
				errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
				return errorModelAndView;
			}
		} catch (ApplicationException e) {
			log.error("Exception occured in AetCtlsController - addAetCtls() method:"+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_ROW + "(AetCtlsController)   " + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the aetCtlsLookUp List from data store.
	 * 
	 * @param request
	 *           request object from view
	 * @return view of aetCtlsDisplay
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/deleteAetctls", method = RequestMethod.POST)
	public ModelAndView deleteAetctls(@RequestParam(required = false) String[] takeAction,
			@ModelAttribute("aetCtlsDisplayForm")LookUpTableListVO lookUpTableListVO, HttpServletRequest request) {
		Map<String, Object> aetCtlsMap = new HashedMap();
		String aetCtlsMsg = "";
		List<String> aetCtlsList = new LinkedList<String>();
		try {
			String userSecurityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if (ApplicationConstants.USER_SECURITY_LEVEL_A.equalsIgnoreCase(userSecurityLevel)) {
				aetCtlsList = lookUpTableListVO.getAetCtlsVOList();
				if (takeAction != null && takeAction.length != 0) {
					int index;
					if(aetCtlsList != null){
						for (int j = takeAction.length - 1; j >= 0; j--) {
							index = Integer.parseInt(takeAction[j]);
							String aetnaControl = aetCtlsList.get(index);
							String padAetnaControl = aetnaControl;
							for (int l = 0; (l + aetnaControl.length() < 9); l++) {
								padAetnaControl = "0" + padAetnaControl;
							}
							aetCtlsMap = facade.deleteAetCtls(aetCtlsList, padAetnaControl, index);
							aetCtlsList = (List<String>) aetCtlsMap.get("aetCtlsList");
							aetCtlsMsg = (String) aetCtlsMap.get("aetCtlsMsg");
							boolean isAetCtlsDeleted = (Boolean) aetCtlsMap.get("isAetCtlsDeleted");
							if (isAetCtlsDeleted) {
								j = 0; // end the for loop
							}
						}
					}
				} else {
					aetCtlsMsg = ApplicationConstants.NO_ACTION_TAKEN;
				}
				
				//update updateAetCtlsList in application state.
				facade.getApplicationState().setAetCtlsList(aetCtlsList);
				lookUpTableListVO.setAetCtlsVOList(aetCtlsList);
				
				modelAndView = new ModelAndView(AETCTLS_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
				modelAndView.addObject("aetCtlsMsg",aetCtlsMsg);
				modelAndView.addObject("aetCtlsList",aetCtlsList);
				modelAndView.addObject("securityLevel", userSecurityLevel);
				return modelAndView;
			} else {
				String errorMsg = ApplicationConstants.NO_AUTHORITY;
				errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
				errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
				return errorModelAndView;
			}
		} catch (ApplicationException e){
            log.error("Exception occured in AetCtlsController - deleteAetCtls() method:"+e.getErrorMessage());
            String errorMsg =ApplicationConstants.ERROR_GET_LOOKUP + "(AetCtlsController)  " + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
      }
	}
	/**
	 * Method to get the aetCtlsLookUp List from data store.
	 * 
	 * @param takeAction
	 *           List of selected indexes to add/update.
	 * @param request
	 *           request object
	 * @return view of aetCtlsDisplay
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addUpdateAetCtls", method = RequestMethod.POST)
	public ModelAndView addUpdateAetCtls(@RequestParam(required = false) String[] takeAction,
			@ModelAttribute("aetCtlsDisplayForm")LookUpTableListVO lookUpTableListVO, HttpServletRequest request) {
		int index;
		String aetCtlsMsg ="";
		List<String> modifiedAetCtlsList = new LinkedList<String>();
		List<String> aetCtlsList = new LinkedList<String>();
		try {
			String userSecurityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if (ApplicationConstants.USER_SECURITY_LEVEL_A.equalsIgnoreCase(userSecurityLevel)) {
				modifiedAetCtlsList = lookUpTableListVO.getAetCtlsVOList();
				aetCtlsList = facade.getApplicationState().getAetCtlsList();
				if(takeAction != null && takeAction.length != 0){
					Map<String, Object> aetCtlsMap = new HashedMap();
					if (modifiedAetCtlsList != null && aetCtlsList != null 
							&& modifiedAetCtlsList.size() != 0 && aetCtlsList.size() != 0) {
						for (int j = 0; j < takeAction.length; j++) {
							index = Integer.parseInt(takeAction[j]);
							String aetCtl = modifiedAetCtlsList.get(index);
							aetCtlsMap = facade.addUpdateAetCtls(aetCtlsList, aetCtl, index);
							aetCtlsList = (List<String>) aetCtlsMap.get("aetCtlsList");
							boolean isAetctlsAddorUpdated = (Boolean) aetCtlsMap.get("isAetCtlsAddorUpdated");
							aetCtlsMsg = (String) aetCtlsMap.get("aetCtlsMsg") ;
							if(isAetctlsAddorUpdated){
								j = takeAction.length;
							}
						}
						//update updateAetCtlsList in application state.
						facade.getApplicationState().setAetCtlsList(aetCtlsList);
						
						lookUpTableListVO.setAetCtlsVOList(modifiedAetCtlsList);
					} else {
						throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);
					}
				} else {
					aetCtlsMsg = ApplicationConstants.NO_ACTION_TAKEN;
				}
				
				lookUpTableListVO.setAetCtlsVOList(aetCtlsList);
				modelAndView = new ModelAndView(AETCTLS_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
				modelAndView.addObject("aetCtlsMsg",aetCtlsMsg);
				modelAndView.addObject("aetCtlsList",aetCtlsList);
				modelAndView.addObject("securityLevel", userSecurityLevel);
				return modelAndView;
			} else {
				String errorMsg = ApplicationConstants.NO_AUTHORITY;
				errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
				errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
				return errorModelAndView;
			}
		} catch (ApplicationException e){
            log.error("Exception occured in AetCtlsController - addUpdateAetCtls() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(AetCtlsController)  " + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
      }
	}
	/**
	 * Method to export AetCtls look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of aetCtls object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/aetCtlsExport", method = RequestMethod.POST)
	public ModelAndView aetCtlsExport(HttpServletResponse response, HttpServletRequest request){
		List<String> aetCtlsList = new LinkedList<String>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String aetCtlsMsg="";
		try{
			String userSecurityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if (ApplicationConstants.USER_SECURITY_LEVEL_A.equalsIgnoreCase(userSecurityLevel)) {
				aetCtlsList = facade.getApplicationState().getAetCtlsList();
				if(aetCtlsList != null && aetCtlsList.size() != 0){
					// Key map to create header
					Map<String,String> keyMap = new LinkedHashMap<String,String>();
					keyMap.put("aetCtl", "Aetna Control Number");
					
					RteIntranetUtils.exportToExcel(response, aetCtlsList, keyMap);
					aetCtlsMsg = ApplicationConstants.EXPORT_SUCCESS;
				} else {
					aetCtlsMsg = ApplicationConstants.NO_DATA;
				}
				lookUpTableListVO.setAetCtlsVOList(aetCtlsList);
		        modelAndView = new ModelAndView(AETCTLS_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
		        modelAndView.addObject("aetCtlsMsg",aetCtlsMsg);
		        modelAndView.addObject("securityLevel", userSecurityLevel);
			    return modelAndView;
			} else {
				String errorMsg = ApplicationConstants.NO_AUTHORITY;
				errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
				errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
				return errorModelAndView;
			}
		} catch (ApplicationException e){
            log.error("Exception occured in AetCtlsController - aetCtlsExport() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_EXPOT_TABLE + "(AetCtlsController)  " + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
      }
	}
}
