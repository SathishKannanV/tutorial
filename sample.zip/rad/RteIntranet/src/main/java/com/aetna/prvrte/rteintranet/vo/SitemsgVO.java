/**
 * 
 */
package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class SitemsgVO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3604695426295267181L;
	private String dbAuthCertCd = "";
	private String dbResponseCd = "";
	private String dbCompanyCd = "";
	private String dbCustServText = "";
	private String dbInOutNetInd = "";
	private String dbNetworkIdNo = "";
	private String dbPCPInd = "";
	private String dbPlanNtwkCd = "";
	private String dbPlanTypeCd = "";
	private String dbPostedDate = "";
	private String dbPrvdrText = "";
	private String dbSeqNo = "";
	private String dbSiteCd = "";
	private String dbSvcTypeCd = "";
	private char   dbUpdatedInd;
		
	public SitemsgVO(String dbAuthCertCd, String dbResponseCd, String dbCompanyCd, String dbCustServText,
			String dbInOutNetInd, String dbNetworkIdNo, String dbPCPInd, String dbPlanNtwkCd,
			String dbPlanTypeCd,String dbPostedDate, String dbPrvdrText, String dbSeqNo,
			String dbSiteCd, String dbSvcTypeCd, char dbUpdatedInd) {
			
		this.dbAuthCertCd =dbAuthCertCd;
		this.dbResponseCd=dbResponseCd;
		this.dbCompanyCd=dbCompanyCd;
		this.dbCustServText=dbCustServText;
		this.dbInOutNetInd=dbInOutNetInd;
		this.dbNetworkIdNo=dbNetworkIdNo;
		this.dbPCPInd=dbPCPInd;
		this.dbPlanNtwkCd=dbPlanNtwkCd;
		this.dbPlanTypeCd=dbPlanTypeCd;
		this.dbPostedDate=dbPostedDate;
		this.dbPrvdrText=dbPrvdrText;
		this.dbSeqNo=dbSeqNo;
		this.dbSiteCd=dbSiteCd;
		this.dbSvcTypeCd=dbSvcTypeCd;
		this.dbUpdatedInd=dbUpdatedInd;
	}
	public SitemsgVO() {
		super();
	}
	
	/**
	 * @return the dbAuthCertCd
	 */
	public String getDbAuthCertCd() {
		return dbAuthCertCd;
	}
	/**
	 * @param dbAuthCertCd the dbAuthCertCd to set
	 */
	public void setDbAuthCertCd(String dbAuthCertCd) {
		this.dbAuthCertCd = dbAuthCertCd;
	}
	/**
	 * @return the dbResponseCd
	 */
	public String getDbResponseCd() {
		return dbResponseCd;
	}
	/**
	 * @param dbResponseCd the dbResponseCd to set
	 */
	public void setDbResponseCd(String dbResponseCd) {
		this.dbResponseCd = dbResponseCd;
	}
	/**
	 * @return the dbCompanyCd
	 */
	public String getDbCompanyCd() {
		return dbCompanyCd;
	}
	/**
	 * @param dbCompanyCd the dbCompanyCd to set
	 */
	public void setDbCompanyCd(String dbCompanyCd) {
		this.dbCompanyCd = dbCompanyCd;
	}
	/**
	 * @return the dbCustServText
	 */
	public String getDbCustServText() {
		return dbCustServText;
	}
	/**
	 * @param dbCustServText the dbCustServText to set
	 */
	public void setDbCustServText(String dbCustServText) {
		this.dbCustServText = dbCustServText;
	}
	/**
	 * @return the dbInOutNetInd
	 */
	public String getDbInOutNetInd() {
		return dbInOutNetInd;
	}
	/**
	 * @param dbInOutNetInd the dbInOutNetInd to set
	 */
	public void setDbInOutNetInd(String dbInOutNetInd) {
		this.dbInOutNetInd = dbInOutNetInd;
	}
	/**
	 * @return the dbNetworkIdNo
	 */
	public String getDbNetworkIdNo() {
		return dbNetworkIdNo;
	}
	/**
	 * @param dbNetworkIdNo the dbNetworkIdNo to set
	 */
	public void setDbNetworkIdNo(String dbNetworkIdNo) {
		this.dbNetworkIdNo = dbNetworkIdNo;
	}
	/**
	 * @return the dbPCPInd
	 */
	public String getDbPCPInd() {
		return dbPCPInd;
	}
	/**
	 * @param dbPCPInd the dbPCPInd to set
	 */
	public void setDbPCPInd(String dbPCPInd) {
		this.dbPCPInd = dbPCPInd;
	}
	/**
	 * @return the dbPlanNtwkCd
	 */
	public String getDbPlanNtwkCd() {
		return dbPlanNtwkCd;
	}
	/**
	 * @param dbPlanNtwkCd the dbPlanNtwkCd to set
	 */
	public void setDbPlanNtwkCd(String dbPlanNtwkCd) {
		this.dbPlanNtwkCd = dbPlanNtwkCd;
	}
	/**
	 * @return the dbPlanTypeCd
	 */
	public String getDbPlanTypeCd() {
		return dbPlanTypeCd;
	}
	/**
	 * @param dbPlanTypeCd the dbPlanTypeCd to set
	 */
	public void setDbPlanTypeCd(String dbPlanTypeCd) {
		this.dbPlanTypeCd = dbPlanTypeCd;
	}
	/**
	 * @return the dbPostedDate
	 */
	public String getDbPostedDate() {
		return dbPostedDate;
	}
	/**
	 * @param dbPostedDate the dbPostedDate to set
	 */
	public void setDbPostedDate(String dbPostedDate) {
		this.dbPostedDate = dbPostedDate;
	}
	/**
	 * @return the dbPrvdrText
	 */
	public String getDbPrvdrText() {
		return dbPrvdrText;
	}
	/**
	 * @param dbPrvdrText the dbPrvdrText to set
	 */
	public void setDbPrvdrText(String dbPrvdrText) {
		this.dbPrvdrText = dbPrvdrText;
	}
	/**
	 * @return the dbSeqNo
	 */
	public String getDbSeqNo() {
		return dbSeqNo;
	}
	/**
	 * @param dbSeqNo the dbSeqNo to set
	 */
	public void setDbSeqNo(String dbSeqNo) {
		this.dbSeqNo = dbSeqNo;
	}
	/**
	 * @return the dbSiteCd
	 */
	public String getDbSiteCd() {
		return dbSiteCd;
	}
	/**
	 * @param dbSiteCd the dbSiteCd to set
	 */
	public void setDbSiteCd(String dbSiteCd) {
		this.dbSiteCd = dbSiteCd;
	}
	/**
	 * @return the dbSvcTypeCd
	 */
	public String getDbSvcTypeCd() {
		return dbSvcTypeCd;
	}
	/**
	 * @param dbSvcTypeCd the dbSvcTypeCd to set
	 */
	public void setDbSvcTypeCd(String dbSvcTypeCd) {
		this.dbSvcTypeCd = dbSvcTypeCd;
	}
	/**
	 * @return the dbUpdatedInd
	 */
	public char getDbUpdatedInd() {
		return dbUpdatedInd;
	}
	/**
	 * @param dbUpdatedInd the dbUpdatedInd to set
	 */
	public void setDbUpdatedInd(char dbUpdatedInd) {
		this.dbUpdatedInd = dbUpdatedInd;
	}
	
	
}
