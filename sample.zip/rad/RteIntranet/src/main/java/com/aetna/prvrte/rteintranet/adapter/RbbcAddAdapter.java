/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.RbbcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author n657186
 * Cognizant_Offshore
 */

public class RbbcAddAdapter extends StoredProcedure{	
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RbbcAddAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RbbcAddAdapter(DataSource datasource, String storedProc) throws SQLException{
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_RBBC_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_EFF_DATE, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.LS_POSTED, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.LS_BNFT_ID_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_SVCTYP_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
	}
	
	
	/**
	 * 
	 * @param rbbcDTO	
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	public Map addNewRbbc(RbbcDTO rbbcDTO) throws ApplicationException {
		
		log.warn("Entered RbbcAddAdapter  - addNewRbbc");
		
		String newMessage ="";
		Map results = null;
		Map<String, Object> params = new java.util.HashMap<String, Object>();
		Map rbbcMap = new HashMap();
		
		params.put(DBConstants.LS_RBBC_CD, RteIntranetUtils.getTrimmedString(rbbcDTO.getDbRBBCCd()));
		params.put(DBConstants.LS_EFF_DATE, Date.valueOf(RteIntranetUtils.getTrimmedString(rbbcDTO.getDbEffDate())));
		params.put(DBConstants.LS_POSTED, Date.valueOf(RteIntranetUtils.getTrimmedString(rbbcDTO.getDbPostedDate())));
		params.put(DBConstants.LS_BNFT_ID_CD, RteIntranetUtils.getTrimmedString(rbbcDTO.getDbBnftIdCd()));
		params.put(DBConstants.LS_SVCTYP_CD, RteIntranetUtils.getTrimmedString(rbbcDTO.getDbSvcTypeCd()));
		log.warn(params);	
		
		try {
			
					
			results = execute(params);
			log.warn("RbbcAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) {
				
				List<RbbcDTO> rbbcList = new LinkedList<RbbcDTO>();
				rbbcList.add(rbbcDTO);
				rbbcMap.put("rbbcList", rbbcList);
				if ("0".equalsIgnoreCase(actionCode)) {
					newMessage = "This row added to the database";
				}else {
					newMessage ="Row already exists on the database. It was updated with these values.";					
					rbbcDTO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
				}				
				}
			else {
				newMessage = "Unable to add row to the database. SQLCODE = " + sqlCode;
			}
			
			rbbcMap.put("rbbcMessage", newMessage);
							
		return rbbcMap;
	}catch (Exception exception){
		log.error("RbbcAddAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}
	
	
	@SuppressWarnings("unchecked")
	public Map addUpdateRbbc(RbbcDTO existingRbbc,
			List<RbbcDTO> rbbcDtoList, int index, char currUpdateInd) throws ApplicationException{
		log.warn("Entered RbbcAddAdapter  - addUpdateRbbc");
		boolean isRbbcAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, Object> params = new java.util.HashMap<String, Object>();
		Map rbbcMap = new HashMap();
		
		params.put(DBConstants.LS_RBBC_CD, RteIntranetUtils.getTrimmedString(existingRbbc.getDbRBBCCd()));
		params.put(DBConstants.LS_EFF_DATE, Date.valueOf(RteIntranetUtils.getTrimmedString(existingRbbc.getDbEffDate())));
		params.put(DBConstants.LS_POSTED, Date.valueOf(RteIntranetUtils.getTrimmedString(existingRbbc.getDbPostedDate())));
		params.put(DBConstants.LS_BNFT_ID_CD, RteIntranetUtils.getTrimmedString(existingRbbc.getDbBnftIdCd()));
		params.put(DBConstants.LS_SVCTYP_CD, RteIntranetUtils.getTrimmedString(existingRbbc.getDbSvcTypeCd()));
		
		log.warn(params);	
		
		try {
					
			results = execute(params);
			log.warn("RbbcAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			if ("0".equalsIgnoreCase(sqlCode)) {
				isRbbcAddorUpdated = true;
				if ("0".equalsIgnoreCase(actionCode)) {
					
					if (currUpdateInd == ApplicationConstants.COPY)						
						rbbcDtoList.set(index, existingRbbc);						
					else
						rbbcDtoList.add(existingRbbc);
				}
				else
					rbbcDtoList.set(index, existingRbbc);
				
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			rbbcMap.put("rbbcMessage",newMessage);
			rbbcMap.put("rbbcDtoList",rbbcDtoList);
			rbbcMap.put("isrbbcAddorUpdated", isRbbcAddorUpdated);
			return rbbcMap;
		}catch (Exception exception){
			log.error("RbbcAddAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
	
}
