/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.RtetierAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.RtetierDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.RtetierLookUpAdapter;
import com.aetna.prvrte.rteintranet.dto.RtetierDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

@Repository
public class RtetierDAOImpl implements RtetierDAO {

	@Autowired(required=true)
	private RtetierLookUpAdapter rtetierLookUpAdapter;
	
	@Autowired(required=true)
	private RtetierAddAdapter rtetierAddAdapter;
	
	@Autowired(required=true)
	private RtetierDeleteAdapter rtetierDeleteAdapter;
	
	@Override
	public Map getRtetierLookUp(RtetierDTO rtetierDTO) throws ApplicationException {
		return rtetierLookUpAdapter.getRtetierLookUpTable(rtetierDTO);
	}
	@Override
	public Map addNewRtetier(RtetierDTO rtetierDTO) throws ApplicationException {
		return rtetierAddAdapter.addNewRtetier(rtetierDTO);
	}
	
	@Override
	public Map deleteRtetier(RtetierDTO rtetierDTO)
			throws ApplicationException {
		return rtetierDeleteAdapter.deleteRtetier(rtetierDTO);
	}

	@Override
	public Map addUpdateRtetier(RtetierDTO existRtetierDTO,
			List<RtetierDTO> rtetierDtoList, int index, char updateInd) throws ApplicationException {
		return rtetierAddAdapter.addUpdateRtetier(existRtetierDTO, rtetierDtoList, index, updateInd);
	}
}
