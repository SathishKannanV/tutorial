/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.aetna.prvrte.rteintranet.adapter.RbrcAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.RbrcDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.RbrcLookUpAdapter;
import com.aetna.prvrte.rteintranet.dto.RbrcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 * Cognizant_Offshore
 */

@Repository
public class RbrcDAOImpl implements RbrcDAO {

	@Autowired(required=true)
	private RbrcLookUpAdapter rbrcLookUpAdapter;
	
	@Autowired(required=true)
	private RbrcAddAdapter rbrcAddAdapter;
	
	@Autowired(required=true)
	private RbrcDeleteAdapter rbrcDeleteAdapter;
	
	@Override
	public Map getRbrcLookUp(RbrcDTO rbrcDTO) throws ApplicationException {
		return rbrcLookUpAdapter.getRbrcLookUp(rbrcDTO);
	}
	@Override
	public Map addNewRbrc(RbrcDTO rbrcDTO) throws ApplicationException {
		return rbrcAddAdapter.addNewRbrc(rbrcDTO);
	}
	

	@Override
	public Map deleteRbrc(RbrcDTO rbrcDTO)
			throws ApplicationException {
		return rbrcDeleteAdapter.deleteRbrc(rbrcDTO);
	}

	@Override
	public Map addUpdateRbrc(RbrcDTO existRbrcDTO,
			List<RbrcDTO> rbrcDtoList, int index, char updateInd) throws ApplicationException {
		return rbrcAddAdapter.addUpdateRbrc(existRbrcDTO, rbrcDtoList, index, updateInd);
	}
}
