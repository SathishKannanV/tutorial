/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.BplvrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.BplvrpVO;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class BplvrpAddAdapter extends StoredProcedure {

	public BplvrpAddAdapter() {}
	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(BplvrpAddAdapter.class);
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public BplvrpAddAdapter(DataSource datasource, String storedProc) throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of BplvrpAdapter : " + storedProc);
		//Input parameter declaration
		declareParameter(new SqlParameter(DBConstants.LS_BNFT_ID_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_BPRO_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(DBConstants.LS_BPLV_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(DBConstants.LS_RFRL_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_PRCRT_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_PRXSTNG_IND, Types.CHAR));
		//Output parameter declaration
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		declareParameter(new SqlOutParameter(DBConstants.LS_ADD_UPDATE, Types.DECIMAL));

	}
	/**
	 * Method to add new Bplvrp to data store.
	 * 
	 * @param bplvrp
	 *            String of aetna id.
	 * @return Map of Bplvrp list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	public Map<String, Object> addBplvrpToDb(BplvrpDTO bplvrpDTO)throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<BplvrpVO> bplvrpList = new LinkedList<BplvrpVO>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String bplvrpMsg = "";
		try {
			String bnftIdCd = RteIntranetUtils.getTrimmedString(bplvrpDTO.getDbBnftIdCd());
			String provNo = String.valueOf(bplvrpDTO.getDbProvNo());
			String provLineVal = String.valueOf(bplvrpDTO.getDbProvLinVal());
			String rfrlInd = RteIntranetUtils.getTrimmedString(bplvrpDTO.getDbRFRLInd());
			String prcrtInd = RteIntranetUtils.getTrimmedString(bplvrpDTO.getDbPRCRTInd());
			String prxstngInd = RteIntranetUtils.getTrimmedString(bplvrpDTO.getDbPRXSTNGInd());
			
			params.put(DBConstants.LS_BNFT_ID_CD, bnftIdCd);
			params.put(DBConstants.LS_BPRO_NO, provNo);
			params.put(DBConstants.LS_BPLV_NO, provLineVal);
			params.put(DBConstants.LS_RFRL_IND, rfrlInd);
			params.put(DBConstants.LS_PRCRT_IND, prcrtInd);
			params.put(DBConstants.LS_PRXSTNG_IND, prxstngInd);
			char updatedInd = ApplicationConstants.UPDATE_IND_N;					//Used by BplvrpDisplay.jsp, not on database
			log.info("Params for getting Bplvrp LookUp List : " + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			if ("0".equals(sqlCode)) {
				String actionCode = String.valueOf(results.get(DBConstants.LS_ADD_UPDATE));
				if ("0".equals(actionCode)) {
					bplvrpMsg = ApplicationConstants.ROW_ADDED;
				} else {
					bplvrpMsg = ApplicationConstants.ROW_ALREADY_EXISTS;
					updatedInd = ApplicationConstants.UPDATE_IND_Y;
				}
				BplvrpVO bplvrpObj = new BplvrpVO( bnftIdCd,Short.valueOf(provNo),  Short.valueOf(provLineVal),
						 rfrlInd,  prcrtInd,  prxstngInd,  updatedInd);
				bplvrpList.add(bplvrpObj);
			} else {
				bplvrpMsg = ApplicationConstants.ADD_ROW_FAILS + sqlCode;
				
			}
			resultMap.put("bplvrpMsg", bplvrpMsg);
			resultMap.put("bplvrpList", bplvrpList);
		} catch (DataAccessException dae) {
			log.error("BplvrpAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("BplvrpAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
		return resultMap;
	}
	
	/**
	 * Method to add/update list of Bplvrp to data store.
	 * 
	 * @param bplvrpList
	 *            List of aetna ids.
	 * @param takeAction
	 *            List of selected indexes to delete aetna id.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from Bplvrp list, success or
	 *         error message and list of Bplvrp.
	 * @throws ApplicationException
	 *             if insertion or update fails.
	 */
	public Map<String, Object> addUpdateBplvrp(BplvrpDTO bplvrpDTO, List<BplvrpDTO> bplvrpList, int index) throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String bplvrpMsg = "";
		boolean isBplvrpAddorUpdated = false;
		try{
			String bnftIdCd = RteIntranetUtils.getTrimmedString(bplvrpDTO.getDbBnftIdCd());
			String provNo = String.valueOf(bplvrpDTO.getDbProvNo());
			String provLineVal = String.valueOf(bplvrpDTO.getDbProvLinVal());
			String rfrlInd = RteIntranetUtils.getTrimmedString(bplvrpDTO.getDbRFRLInd());
			String prcrtInd = RteIntranetUtils.getTrimmedString(bplvrpDTO.getDbPRCRTInd());
			String prxstngInd = RteIntranetUtils.getTrimmedString(bplvrpDTO.getDbPRXSTNGInd());
			
			params.put(DBConstants.LS_BNFT_ID_CD, bnftIdCd);
			params.put(DBConstants.LS_BPRO_NO, provNo);
			params.put(DBConstants.LS_BPLV_NO, provLineVal);
			params.put(DBConstants.LS_RFRL_IND, rfrlInd);
			params.put(DBConstants.LS_PRCRT_IND, prcrtInd);
			params.put(DBConstants.LS_PRXSTNG_IND, prxstngInd);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			String actionCode =  String.valueOf(results.get(DBConstants.LS_ADD_UPDATE));
			short dbProvNo = Short.valueOf(provNo);
			short dbProvLineVal = Short.valueOf(provLineVal);
			BplvrpDTO bplvrpObj = new BplvrpDTO( bnftIdCd, dbProvNo, dbProvLineVal,
					 rfrlInd,  prcrtInd,  prxstngInd,  ApplicationConstants.UPDATE_IND_Y);
			if ("0".equals(sqlCode)) {
				if ("0".equals(actionCode)) {
					if (bplvrpDTO.getDbUpdatedInd() == ApplicationConstants.COPY)
						bplvrpList.set(index, bplvrpObj);
					else
						bplvrpList.add(bplvrpObj);
				}
				else
					bplvrpList.set(index, bplvrpObj);
			} else {
				isBplvrpAddorUpdated = true;
				bplvrpMsg = ApplicationConstants.ADD_UPDATE_ROW_FAILS + sqlCode;
			}
			resultMap.put("bplvrpMsg", bplvrpMsg);
			resultMap.put("bplvrpList", bplvrpList);
			resultMap.put("isBplvrpAddorUpdated", isBplvrpAddorUpdated);
			return resultMap;
		}catch (DataAccessException dae) {
			log.error("BplvrpAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("BplvrpAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
	}
}
