package com.aetna.prvrte.rteintranet.exception;

import org.springframework.stereotype.Component;

@Component("ex")
public class ApplicationException extends Exception {

	private static final long serialVersionUID = 1L;
	// private static final long serialVersionUID = 1L;
	private String errorCode       = null;
	private String errorMessage    = null;
	private Throwable objThrowable = null;

	/**
	 * Constructor with no arguments.
	 */
	public ApplicationException() {

		// Call for Super Class Constructor.
		super();
	}

	/**
	 * Constructor with error Code argument.
	 * 
	 * @param errorCode
	 * @param errorMessage
	 * @param objException
	 */
	public ApplicationException(final String errorCode,
			final Throwable objException) {

		// Call to Super Class Constructor with error Code as argument.
		super(errorCode);
		this.errorCode    = errorCode;
		this.objThrowable = objException;
	}

	/**
	 * Constructor with error Code and error Message as arguments.
	 * 
	 * @param errorCode
	 * @param errorMessage
	 * @param objException
	 */
	public ApplicationException(final String errorCode,
			final String errorMessage, final Throwable objException) {
		super();
		this.errorCode    = errorCode;
		this.errorMessage = errorMessage;
		this.objThrowable = objException;
	}

	/**
	 * Constructor with error Code and error Message as arguments.
	 * 
	 * @param errorMessage
	 */
	public ApplicationException(final String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
	}

	/**
	 * Constructor with error Code and error Message as arguments.
	 * 
	 * @param objException
	 */
	public ApplicationException(final Throwable objException) {
		super(objException);
		this.objThrowable = objException;
	}

	/**
	 * @return Returns the errorCode.
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode
	 *            The errorCode to set.
	 */
	public void setErrorCode(final String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return Returns the errorMessage.
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage
	 *            The errorMessage to set.
	 */
	public void setErrorMessage(final String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
