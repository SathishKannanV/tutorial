package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;
import java.util.Vector;

public class SbmrplnVO implements Serializable {

	private String convIdCode = new String();
	private String vanIdCd = new String();
	private String typeCd = new String();
	private String seqNo=new String();;
	private String postedDt = new String();
	private String controlNo= new String();
	private String suffixNo = new String();
	private String accountNo = new String();
	private String productName = new String();
	private String coverageLevelCode = new String();
	private String coverageToDate = new String();
	private String insuranceLineCd = new String();
	private String planNetworkCd = new String();
	private String siteCd = new String();
	private String subGroupCd = new String();
	private String covgFromDate = new String();
	private String benefitIdCd = new String();
	private String pbnfSeqNo = new String();
	private String planNo = new String();
	private String planSummaryCd = new String();
	private String planName = new String();
	private String patientBirthdate = new String();
	private String patientLastName = new String();
	private String patientFirstName = new String();
	private String patientMidName = new String();
	private String patientTitle = new String();
	private String subsLastName = new String();
	private String subsFirstName = new String();
	private String subsMidName = new String();
	private String subsTitle = new String();
	private String relationToSubsCode = new String();
	private String patientSexCode = new String();
	private String memberTermDate = new String();
	private String depTermDate = new String();
	private String memberIdCd = new String();
	private String subscriberIdCd = new String();
	private String depIdCd = new String();
	private String capLabName = new String();
	private String capXrayName = new String();
	private String capLabPhone = new String();
	private String capXrayPhone = new String();
	private String cumbOrigEffDate = new String();
	private String networkIdNo= new String();
	private String employerName = new String();
	private String groupCd = new String();
	private Vector benefitCollection = new Vector();
	
	
	private String	sbmsnrdSeqNo= new String();
	private String responseCode = new String();
	private String number = new String();
	private String numberQualCd = new String();
	private String eligPeriodLmtCd = new String();
	private String sentPvdInd = new String();
	private String quantityQualCd = new String();
	private String authCertCd = new String();
	private String iONetCd = new String();
	private String categoryCd = new String();
	private String benPeriodStartDate = new String();
	private String benPeriodEndDate = new String();
	private String highBenAgeNo= new String();;
	private String	lowBenAgeNo= new String();;
	private String eligPeriodLmtQuanNo = new String();
	private String	highAgeLmtNo= new String();;
	private String	lowAgeLmtNo= new String();;
	private String levelCode = new String();
	private String	svcLimitHighNo= new String();;
	private String	svcLimitLowNo= new String();;
	private String textZSegment = new String();
	private String benCatCd = new String();
	private String sbmsnrdPostedDate = new String();
	private String lastServiceDate = new String();
	private String count="" ;
	
	private String	tableIdentifier= new String();;
	private String	providerMsgText= new String();;
	private String custSvcMsgText = new String();
	private String qualifierCd = new String();
	private String procedureCd = new String();
	private String diagnosisCd = new String();
	private String serviceTypeCd=new String();
	
	
	
	public SbmrplnVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SbmrplnVO(String convIdCode, String vanIdCd, String typeCd,
			String seqNo, String postedDt, String controlNo, String suffixNo,
			String accountNo, String productName, String coverageLevelCode,
			String coverageToDate, String insuranceLineCd,
			String planNetworkCd, String siteCd, String subGroupCd,
			String covgFromDate, String benefitIdCd, String pbnfSeqNo,
			String planNo, String planSummaryCd, String planName,
			String patientBirthdate, String patientLastName,
			String patientFirstName, String patientMidName,
			String patientTitle, String subsLastName, String subsFirstName,
			String subsMidName, String subsTitle, String relationToSubsCode,
			String patientSexCode, String memberTermDate, String depTermDate,
			String memberIdCd, String subscriberIdCd, String depIdCd,
			String capLabName, String capXrayName, String capLabPhone,
			String capXrayPhone, String cumbOrigEffDate, String networkIdNo,
			String employerName, String groupCd, Vector benefitCollection,
			String sbmsnrdSeqNo, String responseCode, String number,
			String numberQualCd, String eligPeriodLmtCd, String sentPvdInd,
			String quantityQualCd, String authCertCd, String iONetCd,
			String categoryCd, String benPeriodStartDate,
			String benPeriodEndDate, String highBenAgeNo, String lowBenAgeNo,
			String eligPeriodLmtQuanNo, String highAgeLmtNo,
			String lowAgeLmtNo, String levelCode, String svcLimitHighNo,
			String svcLimitLowNo, String textZSegment, String benCatCd,
			String sbmsnrdPostedDate, String lastServiceDate) {
		super();
		this.convIdCode = convIdCode;
		this.vanIdCd = vanIdCd;
		this.typeCd = typeCd;
		this.seqNo = seqNo;
		this.postedDt = postedDt;
		this.controlNo = controlNo;
		this.suffixNo = suffixNo;
		this.accountNo = accountNo;
		this.productName = productName;
		this.coverageLevelCode = coverageLevelCode;
		this.coverageToDate = coverageToDate;
		this.insuranceLineCd = insuranceLineCd;
		this.planNetworkCd = planNetworkCd;
		this.siteCd = siteCd;
		this.subGroupCd = subGroupCd;
		this.covgFromDate = covgFromDate;
		this.benefitIdCd = benefitIdCd;
		this.pbnfSeqNo = pbnfSeqNo;
		this.planNo = planNo;
		this.planSummaryCd = planSummaryCd;
		this.planName = planName;
		this.patientBirthdate = patientBirthdate;
		this.patientLastName = patientLastName;
		this.patientFirstName = patientFirstName;
		this.patientMidName = patientMidName;
		this.patientTitle = patientTitle;
		this.subsLastName = subsLastName;
		this.subsFirstName = subsFirstName;
		this.subsMidName = subsMidName;
		this.subsTitle = subsTitle;
		this.relationToSubsCode = relationToSubsCode;
		this.patientSexCode = patientSexCode;
		this.memberTermDate = memberTermDate;
		this.depTermDate = depTermDate;
		this.memberIdCd = memberIdCd;
		this.subscriberIdCd = subscriberIdCd;
		this.depIdCd = depIdCd;
		this.capLabName = capLabName;
		this.capXrayName = capXrayName;
		this.capLabPhone = capLabPhone;
		this.capXrayPhone = capXrayPhone;
		this.cumbOrigEffDate = cumbOrigEffDate;
		this.networkIdNo = networkIdNo;
		this.employerName = employerName;
		this.groupCd = groupCd;
		this.benefitCollection = benefitCollection;
		this.sbmsnrdSeqNo = sbmsnrdSeqNo;
		this.responseCode = responseCode;
		this.number = number;
		this.numberQualCd = numberQualCd;
		this.eligPeriodLmtCd = eligPeriodLmtCd;
		this.sentPvdInd = sentPvdInd;
		this.quantityQualCd = quantityQualCd;
		this.authCertCd = authCertCd;
		this.iONetCd = iONetCd;
		this.categoryCd = categoryCd;
		this.benPeriodStartDate = benPeriodStartDate;
		this.benPeriodEndDate = benPeriodEndDate;
		this.highBenAgeNo = highBenAgeNo;
		this.lowBenAgeNo = lowBenAgeNo;
		this.eligPeriodLmtQuanNo = eligPeriodLmtQuanNo;
		this.highAgeLmtNo = highAgeLmtNo;
		this.lowAgeLmtNo = lowAgeLmtNo;
		this.levelCode = levelCode;
		this.svcLimitHighNo = svcLimitHighNo;
		this.svcLimitLowNo = svcLimitLowNo;
		this.textZSegment = textZSegment;
		this.benCatCd = benCatCd;
		this.sbmsnrdPostedDate = sbmsnrdPostedDate;
		this.lastServiceDate = lastServiceDate;
	}
	public String getConvIdCode() {
		return convIdCode;
	}
	public void setConvIdCode(String convIdCode) {
		this.convIdCode = convIdCode;
	}
	public String getVanIdCd() {
		return vanIdCd;
	}
	public void setVanIdCd(String vanIdCd) {
		this.vanIdCd = vanIdCd;
	}
	public String getTypeCd() {
		return typeCd;
	}
	public void setTypeCd(String typeCd) {
		this.typeCd = typeCd;
	}
	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public String getPostedDt() {
		return postedDt;
	}
	public void setPostedDt(String postedDt) {
		this.postedDt = postedDt;
	}
	public String getControlNo() {
		return controlNo;
	}
	public void setControlNo(String controlNo) {
		this.controlNo = controlNo;
	}
	public String getSuffixNo() {
		return suffixNo;
	}
	public void setSuffixNo(String suffixNo) {
		this.suffixNo = suffixNo;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCoverageLevelCode() {
		return coverageLevelCode;
	}
	public void setCoverageLevelCode(String coverageLevelCode) {
		this.coverageLevelCode = coverageLevelCode;
	}
	public String getCoverageToDate() {
		return coverageToDate;
	}
	public void setCoverageToDate(String coverageToDate) {
		this.coverageToDate = coverageToDate;
	}
	public String getInsuranceLineCd() {
		return insuranceLineCd;
	}
	public void setInsuranceLineCd(String insuranceLineCd) {
		this.insuranceLineCd = insuranceLineCd;
	}
	public String getPlanNetworkCd() {
		return planNetworkCd;
	}
	public void setPlanNetworkCd(String planNetworkCd) {
		this.planNetworkCd = planNetworkCd;
	}
	public String getSiteCd() {
		return siteCd;
	}
	public void setSiteCd(String siteCd) {
		this.siteCd = siteCd;
	}
	public String getSubGroupCd() {
		return subGroupCd;
	}
	public void setSubGroupCd(String subGroupCd) {
		this.subGroupCd = subGroupCd;
	}
	public String getCovgFromDate() {
		return covgFromDate;
	}
	public void setCovgFromDate(String covgFromDate) {
		this.covgFromDate = covgFromDate;
	}
	public String getBenefitIdCd() {
		return benefitIdCd;
	}
	public void setBenefitIdCd(String benefitIdCd) {
		this.benefitIdCd = benefitIdCd;
	}
	public String getPbnfSeqNo() {
		return pbnfSeqNo;
	}
	public void setPbnfSeqNo(String pbnfSeqNo) {
		this.pbnfSeqNo = pbnfSeqNo;
	}
	public String getPlanNo() {
		return planNo;
	}
	public void setPlanNo(String planNo) {
		this.planNo = planNo;
	}
	public String getPlanSummaryCd() {
		return planSummaryCd;
	}
	public void setPlanSummaryCd(String planSummaryCd) {
		this.planSummaryCd = planSummaryCd;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getPatientBirthdate() {
		return patientBirthdate;
	}
	public void setPatientBirthdate(String patientBirthdate) {
		this.patientBirthdate = patientBirthdate;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientMidName() {
		return patientMidName;
	}
	public void setPatientMidName(String patientMidName) {
		this.patientMidName = patientMidName;
	}
	public String getPatientTitle() {
		return patientTitle;
	}
	public void setPatientTitle(String patientTitle) {
		this.patientTitle = patientTitle;
	}
	public String getSubsLastName() {
		return subsLastName;
	}
	public void setSubsLastName(String subsLastName) {
		this.subsLastName = subsLastName;
	}
	public String getSubsFirstName() {
		return subsFirstName;
	}
	public void setSubsFirstName(String subsFirstName) {
		this.subsFirstName = subsFirstName;
	}
	public String getSubsMidName() {
		return subsMidName;
	}
	public void setSubsMidName(String subsMidName) {
		this.subsMidName = subsMidName;
	}
	public String getSubsTitle() {
		return subsTitle;
	}
	public void setSubsTitle(String subsTitle) {
		this.subsTitle = subsTitle;
	}
	public String getRelationToSubsCode() {
		return relationToSubsCode;
	}
	public void setRelationToSubsCode(String relationToSubsCode) {
		this.relationToSubsCode = relationToSubsCode;
	}
	public String getPatientSexCode() {
		return patientSexCode;
	}
	public void setPatientSexCode(String patientSexCode) {
		this.patientSexCode = patientSexCode;
	}
	public String getMemberTermDate() {
		return memberTermDate;
	}
	public void setMemberTermDate(String memberTermDate) {
		this.memberTermDate = memberTermDate;
	}
	public String getDepTermDate() {
		return depTermDate;
	}
	public void setDepTermDate(String depTermDate) {
		this.depTermDate = depTermDate;
	}
	public String getMemberIdCd() {
		return memberIdCd;
	}
	public void setMemberIdCd(String memberIdCd) {
		this.memberIdCd = memberIdCd;
	}
	public String getSubscriberIdCd() {
		return subscriberIdCd;
	}
	public void setSubscriberIdCd(String subscriberIdCd) {
		this.subscriberIdCd = subscriberIdCd;
	}
	public String getDepIdCd() {
		return depIdCd;
	}
	public void setDepIdCd(String depIdCd) {
		this.depIdCd = depIdCd;
	}
	public String getCapLabName() {
		return capLabName;
	}
	public void setCapLabName(String capLabName) {
		this.capLabName = capLabName;
	}
	public String getCapXrayName() {
		return capXrayName;
	}
	public void setCapXrayName(String capXrayName) {
		this.capXrayName = capXrayName;
	}
	public String getCapLabPhone() {
		return capLabPhone;
	}
	public void setCapLabPhone(String capLabPhone) {
		this.capLabPhone = capLabPhone;
	}
	public String getCapXrayPhone() {
		return capXrayPhone;
	}
	public void setCapXrayPhone(String capXrayPhone) {
		this.capXrayPhone = capXrayPhone;
	}
	public String getCumbOrigEffDate() {
		return cumbOrigEffDate;
	}
	public void setCumbOrigEffDate(String cumbOrigEffDate) {
		this.cumbOrigEffDate = cumbOrigEffDate;
	}
	public String getNetworkIdNo() {
		return networkIdNo;
	}
	public void setNetworkIdNo(String networkIdNo) {
		this.networkIdNo = networkIdNo;
	}
	public String getEmployerName() {
		return employerName;
	}
	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}
	public String getGroupCd() {
		return groupCd;
	}
	public void setGroupCd(String groupCd) {
		this.groupCd = groupCd;
	}
	public Vector getBenefitCollection() {
		return benefitCollection;
	}
	public void setBenefitCollection(Vector benefitCollection) {
		this.benefitCollection = benefitCollection;
	}
	public String getSbmsnrdSeqNo() {
		return sbmsnrdSeqNo;
	}
	public void setSbmsnrdSeqNo(String sbmsnrdSeqNo) {
		this.sbmsnrdSeqNo = sbmsnrdSeqNo;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getNumberQualCd() {
		return numberQualCd;
	}
	public void setNumberQualCd(String numberQualCd) {
		this.numberQualCd = numberQualCd;
	}
	public String getEligPeriodLmtCd() {
		return eligPeriodLmtCd;
	}
	public void setEligPeriodLmtCd(String eligPeriodLmtCd) {
		this.eligPeriodLmtCd = eligPeriodLmtCd;
	}
	public String getSentPvdInd() {
		return sentPvdInd;
	}
	public void setSentPvdInd(String sentPvdInd) {
		this.sentPvdInd = sentPvdInd;
	}
	public String getQuantityQualCd() {
		return quantityQualCd;
	}
	public void setQuantityQualCd(String quantityQualCd) {
		this.quantityQualCd = quantityQualCd;
	}
	public String getAuthCertCd() {
		return authCertCd;
	}
	public void setAuthCertCd(String authCertCd) {
		this.authCertCd = authCertCd;
	}
	public String getiONetCd() {
		return iONetCd;
	}
	public void setiONetCd(String iONetCd) {
		this.iONetCd = iONetCd;
	}
	public String getCategoryCd() {
		return categoryCd;
	}
	public void setCategoryCd(String categoryCd) {
		this.categoryCd = categoryCd;
	}
	public String getBenPeriodStartDate() {
		return benPeriodStartDate;
	}
	public void setBenPeriodStartDate(String benPeriodStartDate) {
		this.benPeriodStartDate = benPeriodStartDate;
	}
	public String getBenPeriodEndDate() {
		return benPeriodEndDate;
	}
	public void setBenPeriodEndDate(String benPeriodEndDate) {
		this.benPeriodEndDate = benPeriodEndDate;
	}
	public String getHighBenAgeNo() {
		return highBenAgeNo;
	}
	public void setHighBenAgeNo(String highBenAgeNo) {
		this.highBenAgeNo = highBenAgeNo;
	}
	public String getLowBenAgeNo() {
		return lowBenAgeNo;
	}
	public void setLowBenAgeNo(String lowBenAgeNo) {
		this.lowBenAgeNo = lowBenAgeNo;
	}
	public String getEligPeriodLmtQuanNo() {
		return eligPeriodLmtQuanNo;
	}
	public void setEligPeriodLmtQuanNo(String eligPeriodLmtQuanNo) {
		this.eligPeriodLmtQuanNo = eligPeriodLmtQuanNo;
	}
	public String getHighAgeLmtNo() {
		return highAgeLmtNo;
	}
	public void setHighAgeLmtNo(String highAgeLmtNo) {
		this.highAgeLmtNo = highAgeLmtNo;
	}
	public String getLowAgeLmtNo() {
		return lowAgeLmtNo;
	}
	public void setLowAgeLmtNo(String lowAgeLmtNo) {
		this.lowAgeLmtNo = lowAgeLmtNo;
	}
	public String getLevelCode() {
		return levelCode;
	}
	public void setLevelCode(String levelCode) {
		this.levelCode = levelCode;
	}
	public String getSvcLimitHighNo() {
		return svcLimitHighNo;
	}
	public void setSvcLimitHighNo(String svcLimitHighNo) {
		this.svcLimitHighNo = svcLimitHighNo;
	}
	public String getSvcLimitLowNo() {
		return svcLimitLowNo;
	}
	public void setSvcLimitLowNo(String svcLimitLowNo) {
		this.svcLimitLowNo = svcLimitLowNo;
	}
	public String getTextZSegment() {
		return textZSegment;
	}
	public void setTextZSegment(String textZSegment) {
		this.textZSegment = textZSegment;
	}
	public String getBenCatCd() {
		return benCatCd;
	}
	public void setBenCatCd(String benCatCd) {
		this.benCatCd = benCatCd;
	}
	public String getSbmsnrdPostedDate() {
		return sbmsnrdPostedDate;
	}
	public void setSbmsnrdPostedDate(String sbmsnrdPostedDate) {
		this.sbmsnrdPostedDate = sbmsnrdPostedDate;
	}
	public String getLastServiceDate() {
		return lastServiceDate;
	}
	public void setLastServiceDate(String lastServiceDate) {
		this.lastServiceDate = lastServiceDate;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getTableIdentifier() {
		return tableIdentifier;
	}
	public void setTableIdentifier(String tableIdentifier) {
		this.tableIdentifier = tableIdentifier;
	}
	public String getProviderMsgText() {
		return providerMsgText;
	}
	public void setProviderMsgText(String providerMsgText) {
		this.providerMsgText = providerMsgText;
	}
	public String getCustSvcMsgText() {
		return custSvcMsgText;
	}
	public void setCustSvcMsgText(String custSvcMsgText) {
		this.custSvcMsgText = custSvcMsgText;
	}
	public String getQualifierCd() {
		return qualifierCd;
	}
	public void setQualifierCd(String qualifierCd) {
		this.qualifierCd = qualifierCd;
	}
	public String getProcedureCd() {
		return procedureCd;
	}
	public void setProcedureCd(String procedureCd) {
		this.procedureCd = procedureCd;
	}
	public String getDiagnosisCd() {
		return diagnosisCd;
	}
	public void setDiagnosisCd(String diagnosisCd) {
		this.diagnosisCd = diagnosisCd;
	}
	public String getServiceTypeCd() {
		return serviceTypeCd;
	}
	public void setServiceTypeCd(String serviceTypeCd) {
		this.serviceTypeCd = serviceTypeCd;
	}
	
	}
