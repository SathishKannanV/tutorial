package com.aetna.prvrte.rteintranet.dao;

import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.LongRunTransactionDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

public interface LongRunTransLookUpDAO {

	Map getLongRunTransLookUpList(LongRunTransactionDTO longrunTransDTO) throws ApplicationException;
	
}
