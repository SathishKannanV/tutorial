/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;


import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RtebeplmDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RtebeplmAddAdapter extends StoredProcedure{

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RtebeplmAddAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtebeplmAddAdapter(DataSource datasource, String storedProc) throws SQLException{
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_RTEBEPLM_BNFT_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_RTEBEPLM_FREQ_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_RTEBEPLM_ELPC_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_RTEBEPLM_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.LS_RTEBEPLM_EXP_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.LS_RTEBEPLM_POSTED_DTS, Types.TIMESTAMP));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_ADD_UPDATE, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
	}
	
	@SuppressWarnings("unchecked")
	public Map addUpdateRtebeplm(RtebeplmDTO modifiedRtebeplm,
			List<RtebeplmDTO> rtebeplmDtoList, int index, char updateInd) throws ApplicationException{
		log.warn("Entered RtebeplmAddAdapter  - addUpdateRtebeplm");
		boolean isRtebeplmAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map rtebeplmMap = new HashMap();
		modifiedRtebeplm.setUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
		params.put(DBConstants.LS_RTEBEPLM_BNFT_CD, RteIntranetUtils.getTrimmedString(modifiedRtebeplm.getHmoBenefitCd()));
		params.put(DBConstants.LS_RTEBEPLM_FREQ_IND, RteIntranetUtils.getTrimmedString(modifiedRtebeplm.getFrequencyInd()));
		params.put(DBConstants.LS_RTEBEPLM_ELPC_CD, RteIntranetUtils.getTrimmedString(modifiedRtebeplm.getEligPerLimitCd()));
		params.put(DBConstants.LS_RTEBEPLM_EFF_DT, RteIntranetUtils.getTrimmedString(modifiedRtebeplm.getEffDate()));
		params.put(DBConstants.LS_RTEBEPLM_EXP_DT, RteIntranetUtils.getTrimmedString(modifiedRtebeplm.getExpDate()));
		params.put(DBConstants.LS_RTEBEPLM_POSTED_DTS, RteIntranetUtils.getTrimmedString(modifiedRtebeplm.getPostedDateTimestamp()));
		
		log.warn(params);	
		
		try {
					
			results = execute(params);
			log.warn("RtebeplmAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			if ("0".equalsIgnoreCase(sqlCode)) {
				isRtebeplmAddorUpdated = true;
				if ("0".equalsIgnoreCase(actionCode)) {
					
					if (updateInd == ApplicationConstants.COPY)						
						rtebeplmDtoList.set(index, modifiedRtebeplm);						
					else
						rtebeplmDtoList.add(modifiedRtebeplm);
				}
				else
					rtebeplmDtoList.set(index, modifiedRtebeplm);
				
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			rtebeplmMap.put("rtebeplmMessage",newMessage);
			rtebeplmMap.put("rtebeplmDtoList",rtebeplmDtoList);
			rtebeplmMap.put("isrtebeplmAddorUpdated", isRtebeplmAddorUpdated);
			return rtebeplmMap;
		}catch (Exception exception){
			log.error("RtebeplmAddAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
	
}
