/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.BenafrqDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.BenafrqVO;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class BenafrqAddAdapter extends StoredProcedure {

	public BenafrqAddAdapter() {}
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(BenafrqAddAdapter.class);
	
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public BenafrqAddAdapter(DataSource datasource, String benafrqStoredProc)
			throws SQLException {
		super(datasource, benafrqStoredProc);
		log.info(" ------------------> " + benafrqStoredProc);
		//InPut Parameters
		declareParameter(new SqlParameter(DBConstants.DEFACUM_ACCUM_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.BENAFRQ_AFREQ_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.RTEBEPLM_BNFT_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.BENAFRQ_LIMIT_TXT, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.RTEBEPLM_EPLC_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.BENAFRQ_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.BENAFRQ_EXP_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.BENAFRQ_POSTED_DTS, Types.TIMESTAMP));
		declareParameter(new SqlParameter(DBConstants.APPL_USER_ID, Types.CHAR));
		//Out Parameters
		declareParameter(new SqlOutParameter(DBConstants.LS_ADD_UPDATE, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
	}
	/**
	 * Method to get the BENAFRQ list from data store.
	 * 
	 * @param benafrqDTO
	 * 			benafrqDTO object.
	 * @return Map of BENAFRQ list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	public Map<String, Object> addBenafrqToDb(BenafrqDTO benafrqDTO)throws ApplicationException {
		char updatedInd = 'Y';
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<BenafrqVO> benafrqList = new LinkedList<BenafrqVO>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String newMessage = "";
		try {
			String postedDate = RteIntranetUtils.getTodaysDateTime(); //Initialize Posted Date to the current timestamp
			String defacumAccumCd = RteIntranetUtils.getTrimmedString(benafrqDTO.getDefacumAccumCd());
			String benafrqAfreqCd = RteIntranetUtils.getTrimmedString(benafrqDTO.getBenafrqAfreqCd());
			String hmobBenefitCd = RteIntranetUtils.getTrimmedString(benafrqDTO.getHmobBenefitCd());
			String benafrqLmtTxt = RteIntranetUtils.getTrimmedString(benafrqDTO.getBenafrqLmtTxt());
			String rtebeplmEplcCd = RteIntranetUtils.getTrimmedString(benafrqDTO.getRtebeplmEplcCd());
			String effDate = RteIntranetUtils.getTrimmedString(benafrqDTO.getEffDate());
			String expDate = RteIntranetUtils.getTrimmedString(benafrqDTO.getExpDate());
			String userId = RteIntranetUtils.getTrimmedString(benafrqDTO.getUserId());
			
			//query params		
			
			params.put(DBConstants.DEFACUM_ACCUM_CD, defacumAccumCd);
			params.put(DBConstants.BENAFRQ_AFREQ_CD, benafrqAfreqCd);
			params.put(DBConstants.RTEBEPLM_BNFT_CD, hmobBenefitCd);
			params.put(DBConstants.BENAFRQ_LIMIT_TXT, benafrqLmtTxt);
			params.put(DBConstants.RTEBEPLM_EPLC_CD, rtebeplmEplcCd);
			params.put(DBConstants.BENAFRQ_EFF_DT, effDate);
			params.put(DBConstants.BENAFRQ_EXP_DT, expDate);
			params.put(DBConstants.BENAFRQ_POSTED_DTS, postedDate);
			params.put(DBConstants.APPL_USER_ID, userId);
			
			log.info("Params to put new benafrq : " + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			
			if ("0".equals(sqlCode)) {
				String actionCode = String.valueOf(results.get(DBConstants.LS_ADD_UPDATE));
				if ("0".equals(actionCode)) {
					newMessage = ApplicationConstants.ROW_ADDED;
				} else {
					newMessage = ApplicationConstants.ROW_ALREADY_EXISTS;
					updatedInd = ApplicationConstants.COPY;
				}
				BenafrqVO benafrqVO = new BenafrqVO(defacumAccumCd, benafrqAfreqCd,
						hmobBenefitCd, benafrqLmtTxt, rtebeplmEplcCd, effDate,
						expDate, postedDate, userId, updatedInd);
				benafrqList.add(benafrqVO);
			} else {
				newMessage = ApplicationConstants.ADD_ROW_FAILS + sqlCode;
			}
			
			resultMap.put("benafrqMsg", newMessage);
			resultMap.put("benafrqList", benafrqList);
		} catch (DataAccessException dae) {
			log.error("BenafrqADA2Adapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("BenafrqADA2Adapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} finally {

		}
		return resultMap;
	}
	
	/**
	 * Method to add/update list of BENAFRQ to data store.
	 * 
	 * @param benafrqDTO
	 *            benafrqDTO object.
	 * @param benafrqDTOList
	 *            list of benafrqDTO object.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from BENAFRQ list, success or
	 *         error message and list of BENAFRQ.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	public Map<String, Object> addUpdateBenafrq(BenafrqDTO existingBenafrq,List<BenafrqDTO> benafrqDTOList, int index) throws ApplicationException {
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String newMessage = "";
		String sqlCode ="";
		boolean isBenafrqAddorUpdated = false;
		boolean isAddUpdateCleanUp = false;
		try{
			String postedDate = RteIntranetUtils.getTodaysDateTime();
			String defacumAccumCd = RteIntranetUtils.getTrimmedString(existingBenafrq.getDefacumAccumCd());
			String benafrqAfreqCd = RteIntranetUtils.getTrimmedString(existingBenafrq.getBenafrqAfreqCd());
			String hmobBenefitCd = RteIntranetUtils.getTrimmedString(existingBenafrq.getHmobBenefitCd());
			String benafrqLmtTxt = RteIntranetUtils.getTrimmedString(existingBenafrq.getBenafrqLmtTxt());
			String rtebeplmEplcCd = RteIntranetUtils.getTrimmedString(existingBenafrq.getRtebeplmEplcCd());
			String effDate = RteIntranetUtils.getTrimmedString(existingBenafrq.getEffDate());
			String expDate = RteIntranetUtils.getTrimmedString(existingBenafrq.getExpDate());
			String userId = RteIntranetUtils.getTrimmedString(existingBenafrq.getUserId());
	
			// query params
			params.put(DBConstants.DEFACUM_ACCUM_CD, defacumAccumCd);
			params.put(DBConstants.BENAFRQ_AFREQ_CD, benafrqAfreqCd);
			params.put(DBConstants.RTEBEPLM_BNFT_CD, hmobBenefitCd);
			params.put(DBConstants.BENAFRQ_LIMIT_TXT, benafrqLmtTxt);
			params.put(DBConstants.RTEBEPLM_EPLC_CD, rtebeplmEplcCd);
			params.put(DBConstants.BENAFRQ_EFF_DT, effDate);
			params.put(DBConstants.BENAFRQ_EXP_DT, expDate);
			params.put(DBConstants.BENAFRQ_POSTED_DTS, postedDate);
			params.put(DBConstants.APPL_USER_ID, userId);
		
			Map<String, Object> results = execute(params);
			sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			String actionCode =  String.valueOf(results.get(DBConstants.LS_ADD_UPDATE));
			BenafrqDTO brnafrqDTO =
					new BenafrqDTO(defacumAccumCd, benafrqAfreqCd, hmobBenefitCd , benafrqLmtTxt , rtebeplmEplcCd, effDate,
								expDate,postedDate, userId , ApplicationConstants.UPDATE_IND_Y);
			if ("0".equals(sqlCode)) {
				isAddUpdateCleanUp = true;
				if (ApplicationConstants.ADD.equalsIgnoreCase(actionCode)) {	// 'A' Add, 'U' Update
					if (existingBenafrq.getUpdatedInd() == ApplicationConstants.COPY){
						benafrqDTOList.set(index, brnafrqDTO);
					} else {
						benafrqDTOList.add(brnafrqDTO);
					}
				}
				else
					benafrqDTOList.set(index, brnafrqDTO);
			} else {
				isBenafrqAddorUpdated = true;
				newMessage = ApplicationConstants.ADD_UPDATE_ROW_FAILS + sqlCode;
			}
			resultMap.put("benafrqMsg", newMessage);
			resultMap.put("benafrqList", benafrqDTOList);
			resultMap.put("isBenafrqAddorUpdated", isBenafrqAddorUpdated);
			resultMap.put("isAddUpdateCleanUp", isAddUpdateCleanUp);
			return resultMap;
		} catch (DataAccessException dae) {
			log.error("BenafrqAddAdapter : Data access excpetion occured "	+ dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("BenafrqAddAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
		
	}
}
