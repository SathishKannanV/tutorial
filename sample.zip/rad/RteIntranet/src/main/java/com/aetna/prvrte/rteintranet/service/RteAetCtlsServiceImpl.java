/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.RteAetCtlsDAO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.service.RteAetCtlsService
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Service
public class RteAetCtlsServiceImpl implements RteAetCtlsService {
	/*
	 * Instance of RteAetCtlsDAO
	 */
	@Autowired(required=true)
	private RteAetCtlsDAO rteAetCtlsDAO;
	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteAetCtlsService#getAetCtlsLookUpList(java.lang.String)
	 */
	@Override
	public Map<String, Object> getAetCtlsLookUpList(String aetCtl) throws ApplicationException {
		return rteAetCtlsDAO.getAetCtlsLookUpList(aetCtl);
	}

	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteAetCtlsService#addAetCtlsToDb(java.lang.String)
	 */
	@Override
	public Map<String, Object> addAetCtlsToDb(String aetCtl) throws ApplicationException {
		return rteAetCtlsDAO.addAetCtlsToDb(aetCtl);
	}
	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteAetCtlsService#deleteAetCtls(java.util.List, java.lang.String, int)
	 */
	@Override
	public Map<String, Object> deleteAetCtls(List<String>aetCtlsList, String aetCtl, int index) throws ApplicationException {
		return rteAetCtlsDAO.deleteAetCtls(aetCtlsList, aetCtl, index);
	}

	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteAetCtlsService#addUpdateAetCtls(java.util.List, java.lang.String, int)
	 */
	@Override
	public Map<String, Object> addUpdateAetCtls(List<String>aetCtlsList, String aetCtl, int index) throws ApplicationException {
		return rteAetCtlsDAO.addUpdateAetCtls(aetCtlsList, aetCtl, index);
	}
}
