/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.PlnlmEXAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.PlnlmEXDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.PlnlmEXDisplayAdapter;
import com.aetna.prvrte.rteintranet.dto.PlnlmEXDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.service.RtePlnlmEXService
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Repository
public class RtePlnlmEXDAOImpl implements RtePlnlmEXDAO {
	/*
	 * Instance of PlnlmEXDisplayAdapter.
	 */
	@Autowired(required = true)
	private PlnlmEXDisplayAdapter erspmsgDisplayAdapter;
	/*
	 * Instance of PlnlmEXAddAdapter.
	 */
	@Autowired(required = true)
	private PlnlmEXAddAdapter erspmsgAddAdapter;
	/*
	 * Instance of PlnlmEXDeleteAdapter.
	 */
	@Autowired(required = true)
	private PlnlmEXDeleteAdapter erspmsgDeleteAdapter;
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RtePlnlmEXDAO#getPlnlmEXLookUpList(com.aetna.prvrte.rteintranet.dto.PlnlmEXDTO)
	 */
	@Override
	public Map<String, Object> getPlnlmEXLookUpList(PlnlmEXDTO erspmsgDTO) throws ApplicationException {
		return erspmsgDisplayAdapter.getPlnlmEXLookUpList(erspmsgDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RtePlnlmEXDAO#addPlnlmEXToDb(com.aetna.prvrte.rteintranet.dto.PlnlmEXDTO)
	 */
	@Override
	public Map<String, Object> addPlnlmEXToDb(PlnlmEXDTO erspmsgDTO) throws ApplicationException {
		return erspmsgAddAdapter.addPlnlmEXToDb(erspmsgDTO);
	}

	
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RtePlnlmEXDAO#deletePlnlmEX(java.lang.Integer)
	 */
	@Override
	public Map<String, Object> deletePlnlmEX(String explntCd) throws ApplicationException {
		return erspmsgDeleteAdapter.deletePlnlmEX(explntCd);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RtePlnlmEXDAO#addUpdatePlnlmEX(com.aetna.prvrte.rteintranet.dto.PlnlmEXDTO, java.util.List, int)
	 */
	@Override
	public Map<String, Object> addUpdatePlnlmEX(PlnlmEXDTO erspmsgDTO, List<PlnlmEXDTO> erspmsgList, int index) throws ApplicationException {
		return erspmsgAddAdapter.addUpdatePlnlmEX(erspmsgDTO, erspmsgList, index);
	}
	

}
