package com.aetna.prvrte.rteintranet.web.controller;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.aetna.prvrte.rteintranet.dto.RtetprlDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.RtetprlVO;
import com.aetna.prvrte.rteintranet.vo.UserVO;

/**
 * 
 * The RtetprlController is responsible for handling
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * @author N624926
 * Cognizant_Offshore
 */

@Controller
@RequestMapping(value = "/rtetprl/*")
public class RtetprlController {

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(RtetprlController.class);
	/*
	 * Tile name of the rtetprl Home view.
	 */
	public static final String RTETPRL_HOME = ".rtetprlHome";
	/*
	 * Tile name of the rtetprl Display view.
	 */
	public static final String RTETPRL_LOOKUP = ".rtetprlLookUpDisplay";
	/*
	 * Tile name of the Add New rtetprl Form view.
	 */
	public static final String RTETPRL_ADD = ".rtetprlAdd";
	/*
	 * Constant name used for COPY indicator.
	 */
	public static final char COPY = 'C';
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errormav;
	
	
	/**
	 * Method to getRtetprlLookUpHome view
	 * 
	 * @param model
	 * 
	 * @return view of rtetprlLookUp, if fails return error page
	 */
	@RequestMapping(value="/rtetprlHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRtetprlLookUpHome(final HttpServletRequest request,Model model) {	
		log.warn("Entered RtetprlController - getRtetprlLookUpHome()");
		String securityLevel ="";
		try {
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(RTETPRL_HOME, "rtetprlVO",  new RtetprlVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("RtetprlController - securityLevel: "+ securityLevel);
		log.warn("Exit from RtetprlController - getRtetprlLookUpHome()");
		return mav;
		} catch (ApplicationException e){
			log.error("Exception occured in RtetprlController - getRtetprlLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * Method to get the rtetpbrLookUp List from data store.
	 * 
	 * @param rtetprlVO
	 *            form view object of rtetprl.
	 * @return view of rtetprlDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherRtetprl", method = RequestMethod.POST)
	public ModelAndView getRtetprlLookUpTable(HttpServletRequest request,@ModelAttribute("rtetprlForm")RtetprlVO rtetprlVO){
		log.warn("Entered RtetprlController - getRtetprlLookUpTable()");
		String securityLevel ="";
		ModelAndView mav ;
		Map rtetprlResultMap = new HashMap();
		List<RtetprlVO> rtetprlList = new LinkedList<RtetprlVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			RtetprlDTO rtetprlDTO = RTETranslator.toRtetprlDTO(rtetprlVO);
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtetprlResultMap = facade.getRtetprlLookUpTable(rtetprlDTO);
			rtetprlList = (List<RtetprlVO>) rtetprlResultMap.get("rtetprlList");
			lookUpListVO.setRtetprlVOList(rtetprlList);
			facade.getApplicationState().setRtetprlList(rtetprlList);
			mav = new ModelAndView(RTETPRL_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("rtetprlMessage", rtetprlResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("getRtetprlLookUpTable - rtetprlMessage: "+ rtetprlResultMap.get("newMessage"));
			log.warn("Exit from RtetprlController - getRtetprlLookUpTable()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtetprlController - getRtetprlLookUpTable() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="getRtetprlLookUpTable() :"+ApplicationConstants.ERROR_GET_LOOKUP + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * Method to display get add new Rtetprl form home view.
	 * 
	 * @return view of loadAddNewRtetprlRowScreen, if fails return error page
	 */
	@RequestMapping(value="/AddNewRtetprlRow")
	public ModelAndView loadAddNewRtetprlRowScreen(final HttpServletRequest request,Model model) {	
		log.warn("Entered RtetprlController - loadAddNewRtetprlRowScreen()");
		ModelAndView mav = new ModelAndView(RTETPRL_ADD, "rtetprlVO",  new RtetprlVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in RtetprlController - loadAddNewRtetprlRowScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		log.warn("Exit from RtetprlController - loadAddNewRtetprlRowScreen()");
		return mav;
	}
	
	/**
	 * Method to add the data database
	 * 
	 * @param rtetprlVO form view object of Rtetprl.
	 * @param request request object for Rtetprl to get userVO          
	 * @return view of rtetprlDisplay, if fails return error page
	 * 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddRtetprl", method = RequestMethod.POST)
	public ModelAndView addNewRtetprl(@ModelAttribute("addRtetprlForm")RtetprlVO rtetprlVO,final HttpServletRequest request){
		log.warn("Entered RtetprlController - addNewRtetprl()");
		ModelAndView mav ;
		Map rtetprlResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<RtetprlDTO> rtetprlDtoList = new LinkedList<RtetprlDTO>();
		List<RtetprlVO> rtetprlVoList = new LinkedList<RtetprlVO>();
		String securityLevel ="";
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtetprlVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
            String userId = RteIntranetUtils.getUserId(request); //Ex: n242716 
			rtetprlVO.setUserId(userId);
			RtetprlDTO rtetprlDTO = RTETranslator.toRtetprlDTO(rtetprlVO);
			rtetprlResultMap = facade.addNewRtetprl(rtetprlDTO);
			
			if(rtetprlResultMap.get("rtetprlList")!=null){
				rtetprlDtoList = (List<RtetprlDTO>) rtetprlResultMap.get("rtetprlList");
				rtetprlVoList = RTETranslator.toRtetprlVOList(rtetprlDtoList);
			}
			lookUpListVO.setRtetprlVOList(rtetprlVoList);
			facade.getApplicationState().setRtetprlList(rtetprlVoList);
			mav = new ModelAndView(RTETPRL_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("securityLevel", securityLevel);
			mav.addObject("rtetprlMessage", rtetprlResultMap.get("rtetprlMessage"));
			log.warn("addNewRtetprl - rtetprlMessage: "+ rtetprlResultMap.get("rtetprlMessage"));
			log.warn("Exit from RtetprlController - addNewRtetprl()");			
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in RtetprlController - addNewRtetprl() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addNewRtetprl() :"+ApplicationConstants.ERROR_ADD_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to delete the Rtetprl List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of rtetprlDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteRtetprl", method = RequestMethod.POST)
	public ModelAndView deleteRtetprl(final HttpServletRequest request,@ModelAttribute("rtetprlDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		
		ModelAndView mav ;
		String rtetprlMsg = "";
		boolean isRtetprlDeleted = true;
		String securityLevel ="";
		Map rtetprlResultMap = new HashMap();
		List<RtetprlVO> rtetprlList = new LinkedList<RtetprlVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtetprlList = lookUpListVO.getRtetprlVOList();
			int i;
			if ((rtetprlList != null) && (takeAction != null)) {
				for(RtetprlVO rtetprlVO : rtetprlList){
					if(rtetprlVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtetprlVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					RtetprlVO existingRtetprl = (RtetprlVO) rtetprlList.get(i);
					if (existingRtetprl.getUpdatedInd() != ApplicationConstants.COPY) {
						RtetprlDTO rtetprlDTO = RTETranslator.toRtetprlDTO(existingRtetprl);
						rtetprlResultMap = facade.deleteRtetprl(rtetprlDTO);
						rtetprlMsg = (String) rtetprlResultMap.get("rtetprlMsg");
						isRtetprlDeleted = (Boolean) rtetprlResultMap.get("isRtetprlDeleted");
						
						if(isRtetprlDeleted == true){
							rtetprlList.remove(i);
						}else{
							j = 0;
						}
					}else{
						rtetprlList.remove(i);
					}				
			}
				if(isRtetprlDeleted == true)
					rtetprlMsg = "Rows selected were Deleted in the database/list";
		}else
			rtetprlMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setRtetprlList(rtetprlList);
			lookUpListVO.setRtetprlVOList(rtetprlList);
			mav = new ModelAndView(RTETPRL_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtetprlMessage",rtetprlMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteRtetprl - rtetprlMessage: "+ rtetprlMsg);
		    log.warn("Exit from RtetprlController - deleteRtetprl()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtetprlController - deleteRtetprl() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteRtetprl() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}


	/**
	 * Method to copy the Rtetprl List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of rtetprlDisplay, if fails return error page
	 */
	@RequestMapping(value="/copyRtetprl", method = RequestMethod.POST)
	public ModelAndView copyRtetprl(final HttpServletRequest request,@ModelAttribute("rtetprlDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String rtetprlMsg = "";
		String securityLevel ="";
		int i;
		List<RtetprlVO> rtetprlList = new LinkedList<RtetprlVO>();
		try{
			//String postedDate =RteIntranetUtils.getPostedDate(); //Initialize Posted Date to today's date
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtetprlList = lookUpListVO.getRtetprlVOList();
			if ((rtetprlList != null) && (takeAction != null)) {
				for(RtetprlVO rtetprlVO : rtetprlList){
					if(rtetprlVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtetprlVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					RtetprlVO existingRtetprl = (RtetprlVO) rtetprlList.get(i);
					RtetprlVO copyRtetprl = new RtetprlVO(existingRtetprl.getStcCd(), existingRtetprl.getTosCd() , existingRtetprl.getPosCd() , existingRtetprl.getGroupCd() , existingRtetprl.getRuleCd() , existingRtetprl.getOrderNo() , existingRtetprl.getEffDate() ,
							existingRtetprl.getExpDate() ,	existingRtetprl.getPostedDate() , existingRtetprl.getUserId() , COPY);
					rtetprlList.add(copyRtetprl);
				}
				rtetprlMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				rtetprlMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setRtetprlList(rtetprlList);
			lookUpListVO.setRtetprlVOList(rtetprlList);
			mav = new ModelAndView(RTETPRL_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtetprlMessage",rtetprlMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyRtetprl - rtetprlMessage: "+ rtetprlMsg);
		    log.warn("Exit from RtetprlController - copyRtetprl()");
			return mav;		
		}catch (Exception e){
			log.error("Exception occured in RtetprlController - copyRtetprl() method:"+e.getMessage());
			String errorMsg ="copyRtetprl() :"+ApplicationConstants.ERROR_COPY_ROW + RteIntranetUtils.getTrimmedString(e.getMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	
	/**
	 * Method to Add/Update the Rtetprl List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of rtetprlDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateRtetprl", method = RequestMethod.POST)
	public ModelAndView addUpdateRtetprl(final HttpServletRequest request,@ModelAttribute("rtetprlDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered from RtetprlController - addUpdateRtetprl()");
		ModelAndView mav ;
		String rtetprlMsg = "";
		String securityLevel ="";
		List<RtetprlVO> updatedrtetprlList = new LinkedList<RtetprlVO>();
		List<RtetprlDTO> updatedRtetprlDtoList = new LinkedList<RtetprlDTO>();
		List<RtetprlVO> rtetprlVoList = new LinkedList<RtetprlVO>();
		List<RtetprlVO> modifiedRtetprlVoList = new LinkedList<RtetprlVO>();
		List<RtetprlDTO> rtetprlDtoList = new LinkedList<RtetprlDTO>(); 
		boolean isRtetprlAddOrUpdated = false;
		Map rtetprlResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			 rtetprlVoList = facade.getApplicationState().getRtetprlList();
			 modifiedRtetprlVoList = lookUpListVO.getRtetprlVOList();
			int i;
			if (takeAction != null && takeAction.length != 0) {
				if(rtetprlVoList != null && rtetprlVoList.size() != 0 
						&& modifiedRtetprlVoList.size() != 0 && modifiedRtetprlVoList != null){
				for(RtetprlVO rtetprlVO : rtetprlVoList){
					if(rtetprlVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtetprlVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				rtetprlDtoList = RTETranslator.toRtetprlDTOList(rtetprlVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					RtetprlVO seletedRtetprl = (RtetprlVO) rtetprlVoList.get(i);
					RtetprlVO editedRtetprl = (RtetprlVO) modifiedRtetprlVoList.get(i);
					RtetprlVO editedRtetprlVO = new RtetprlVO(editedRtetprl.getStcCd() , editedRtetprl.getTosCd() , editedRtetprl.getPosCd() , editedRtetprl.getGroupCd() , editedRtetprl.getRuleCd() , editedRtetprl.getOrderNo() , editedRtetprl.getEffDate() ,
							editedRtetprl.getExpDate() ,	editedRtetprl.getPostedDate() , editedRtetprl.getUserId() ,  updatedInd);
					RtetprlDTO editedRtetprlDTO = RTETranslator.toRtetprlDTO(editedRtetprlVO);
					rtetprlResultMap = facade.addUpdateRtetprl(editedRtetprlDTO, rtetprlDtoList, i , seletedRtetprl.getUpdatedInd());
					updatedRtetprlDtoList = (List<RtetprlDTO>) rtetprlResultMap.get("rtetprlDtoList");
					updatedrtetprlList = RTETranslator.toRtetprlVOList(updatedRtetprlDtoList);
					isRtetprlAddOrUpdated = (Boolean) rtetprlResultMap.get("isRtetprlAddorUpdated");
					rtetprlMsg = (String) rtetprlResultMap.get("rtetprlMsg") ;
					if(isRtetprlAddOrUpdated!= true){
						j = takeAction.length;
					}
				}
				if(isRtetprlAddOrUpdated==true){
					rtetprlMsg = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted.";
					String xStcCd, xTosCd, yStcCd, yTosCd, xPosCd, yPosCd, xGroupCd, yGroupCd, xRuleCd, yRuleCd, xEffDate, yEffDate;
					for (int x = updatedrtetprlList.size() - 1 ; x > 0;  x--) {
						RtetprlVO xRtetprl = (RtetprlVO) updatedrtetprlList.get(x);
						xStcCd = xRtetprl.getStcCd();
						xTosCd = xRtetprl.getTosCd();
						xPosCd = xRtetprl.getPosCd();
						xGroupCd = xRtetprl.getGroupCd();
						xRuleCd = xRtetprl.getRuleCd();
						xEffDate = xRtetprl.getEffDate();
						if (xRtetprl.getUpdatedInd() != 'C') {
							for (int y = x - 1; y > -1; y--) {
								RtetprlVO yRtetprl = (RtetprlVO) updatedrtetprlList.get(y);
								yStcCd = yRtetprl.getStcCd();
								yTosCd = yRtetprl.getTosCd();
								yPosCd = yRtetprl.getPosCd();
								yGroupCd = yRtetprl.getGroupCd();
								yRuleCd = yRtetprl.getRuleCd();
								yEffDate = yRtetprl.getEffDate();
								if (xStcCd.equals(yStcCd) && xTosCd.equals(yTosCd) && xPosCd.equals(yPosCd) && xGroupCd.equals(yGroupCd) && xRuleCd.equals(yRuleCd) && xEffDate.equals(yEffDate)) {
									rtetprlDtoList.remove(y); 
									x--;
								}
							}
						}
					}
				}
				lookUpListVO.setRtetprlVOList(updatedrtetprlList);
				facade.getApplicationState().setRtetprlList(updatedrtetprlList);
			} else {
				throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	
			}
		}else{
			rtetprlMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setRtetprlVOList(rtetprlVoList);
			facade.getApplicationState().setRtetprlList(rtetprlVoList);
		}
			mav = new ModelAndView(RTETPRL_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtetprlMessage",rtetprlMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateRtetprl - rtetprlMessage: "+ rtetprlMsg);
		    log.warn("Exit from RtetprlController - addUpdateRtetprl()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtetprlController - addUpdateRtetprl() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addUpdateRtetprl() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
     * Method to export Rtetprl look up table to excel work book
     * 
      * @param lookUpTableListVO
     *            list of rtetprl object.
     * @param response
     *            response object to return
     * @return exported file to view.
     */
	@RequestMapping(value = "/rtetprlExport", method = RequestMethod.POST)
	public ModelAndView rtetprlExport(HttpServletResponse response) {
		List<RtetprlVO> rtetprlList = new LinkedList<RtetprlVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String rtetprlMsg = "";
		try {
			rtetprlList = facade.getApplicationState().getRtetprlList();
			if (rtetprlList != null && rtetprlList.size() != 0) {
				// Key map to create header
				Map<String, String> keyMap = new LinkedHashMap<String, String>();
				keyMap.put("stcCd", "STC CD");
				keyMap.put("tosCd", "TOS CD");
				keyMap.put("posCd", "POS CD");
				keyMap.put("groupCd", "Group CD");
				keyMap.put("ruleCd", "Rule CD");
				keyMap.put("orderNo", "Order No");
				keyMap.put("effDate", "Effective Date");
				keyMap.put("expDate", "Expiration Date");
				keyMap.put("userId", "User Id");
				keyMap.put("postedDate", "Posted Date");
				RteIntranetUtils.exportToExcel(response, rtetprlList, keyMap);
				rtetprlMsg = "LookUp table exported successfully.";
			} else {
				rtetprlMsg = "No data found.";
			}
			lookUpTableListVO.setRtetprlVOList(rtetprlList);
			mav = new ModelAndView(RTETPRL_LOOKUP, "lookUpTableListVO", lookUpTableListVO);
			mav.addObject("rtetprlMessage", rtetprlMsg);
			return mav;
		} catch (ApplicationException e) {
			log.error("Exception occured in RtetprlController - rtetprlExport() method:"
					+ e.getMessage());
			String errorMsg = "rtetprlExport() :"
					+ ApplicationConstants.ERROR_EXPOT_TABLE
					+ RteIntranetUtils.getTrimmedString(e.getMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);
			return errormav;
		}
	}
}
