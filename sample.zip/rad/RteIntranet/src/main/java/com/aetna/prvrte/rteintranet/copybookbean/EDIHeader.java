package com.aetna.prvrte.rteintranet.copybookbean;


public class EDIHeader {

	String transactionType;
	String vanId;
	String conversation;
	String versionRels;
	String typeOfSearch;
	String eligilibilityServiceDate;
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		
		this.transactionType = transactionType;
	}
	public String getVanId() {
		
		return vanId;
	}
	public void setVanId(String vanId) {
		
		this.vanId = vanId;
	}
	public String getConversation() {
		
		return conversation;
	}
	public void setConversation(String conversation) {
		
		this.conversation = conversation;
	}
	public String getVersionRels() {
		
		return versionRels;
	}
	public void setVersionRels(String versionRels) {
		
		this.versionRels = versionRels;
	}
	public String getTypeOfSearch() {
		
		return typeOfSearch;
	}
	public void setTypeOfSearch(String typeOfSearch) {
		
		this.typeOfSearch = typeOfSearch;
	}
	public String getEligilibilityServiceDate() {
		
		return eligilibilityServiceDate;
	}
	public void setEligilibilityServiceDate(String eligilibilityServiceDate) {
		eligilibilityServiceDate=eligilibilityServiceDate.replaceAll("-", "");
		this.eligilibilityServiceDate = eligilibilityServiceDate;
	}
	
	public StringBuilder getHeader(){
		return new StringBuilder(getTransactionType())
		.append(getVanId())
		.append(getConversation())
		.append(getVersionRels())
		.append(getTypeOfSearch())
		.append(getEligilibilityServiceDate());
	}
}
