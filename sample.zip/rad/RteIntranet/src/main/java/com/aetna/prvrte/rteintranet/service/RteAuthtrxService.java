/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * 
 * <h1>RteAuthtrxService</h1> The RteAuthtrxService is responsible for handling
 * the business logic of Authtrx Look up.
 * 
 * @author N726899 Cognizant_Offshore
 * 
 */
public interface RteAuthtrxService {
	/**
	 * Method to get the AuthTrx list from data store.
	 * 
	 * @param authTrx
	 *            String of aetna id.
	 * @return Map of AetCtls list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if data not found in data store.
	 */
	Map<String, Object> getAuthTrxLookUpList(String authTrx) throws ApplicationException;
	/**
	 * Method to add new AuthTrx to data store.
	 * 
	 * @param authTrx
	 *            String of aetna id.
	 * @return Map of AetCtls list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	Map<String, Object> addAuthTrxToDb(String authTrx) throws ApplicationException;
	/**
	 * Method to delete the AuthTrx data from data store.
	 * 
	 * @param authTrxList
	 *            List of aetna ids.
	 * @param takeAction
	 *            List of selected indexes to delete aetna id.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from AuthTrx list and success or
	 *         error message.
	 * @throws ApplicationException
	 *             if deletion fails.
	 */
	Map<String, Object> deleteAuthTrx(List<String> authTrxList, String authTrx, int index) throws ApplicationException;
	
	/**
	 * Method to add/update list of AuthTrx to data store.
	 * 
	 * @param authTrxList
	 *            List of aetna ids.
	 * @param takeAction
	 *            List of selected indexes to delete aetna id.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from AuthTrx list, success or
	 *         error message and list of AuthTrx.
	 * @throws ApplicationException
	 *             if insertion or update fails.
	 */
	Map<String, Object> addUpdateAuthTrx(List<String> authTrxList, String authTrx, int index) throws ApplicationException;
}
