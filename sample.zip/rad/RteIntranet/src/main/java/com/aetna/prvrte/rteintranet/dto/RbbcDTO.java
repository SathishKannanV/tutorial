/**
 * 
 */
package com.aetna.prvrte.rteintranet.dto;

/**
 * @author N657186
 *
 */
public class RbbcDTO {
	private String dbRBBCCd = "";
	private String dbEffDate = "";
	private String dbPostedDate = "";
	private String dbBnftIdCd = "";
	private String dbSvcTypeCd = "";
	private char dbUpdatedInd;
	
	
	/**
	 * @return the dbRBBCCd
	 */
	public String getDbRBBCCd() {
		return dbRBBCCd;
	}
	/**
	 * @param dbRBBCCd the dbRBBCCd to set
	 */
	public void setDbRBBCCd(String dbRBBCCd) {
		this.dbRBBCCd = dbRBBCCd;
	}
	/**
	 * @return the dbEffDate
	 */
	public String getDbEffDate() {
		return dbEffDate;
	}
	/**
	 * @param dbEffDate the dbEffDate to set
	 */
	public void setDbEffDate(String dbEffDate) {
		this.dbEffDate = dbEffDate;
	}
	/**
	 * @return the dbPostedDate
	 */
	public String getDbPostedDate() {
		return dbPostedDate;
	}
	/**
	 * @param dbPostedDate the dbPostedDate to set
	 */
	public void setDbPostedDate(String dbPostedDate) {
		this.dbPostedDate = dbPostedDate;
	}
	/**
	 * @return the dbBnftIdCd
	 */
	public String getDbBnftIdCd() {
		return dbBnftIdCd;
	}
	/**
	 * @param dbBnftIdCd the dbBnftIdCd to set
	 */
	public void setDbBnftIdCd(String dbBnftIdCd) {
		this.dbBnftIdCd = dbBnftIdCd;
	}
	/**
	 * @return the dbSvcTypeCd
	 */
	public String getDbSvcTypeCd() {
		return dbSvcTypeCd;
	}
	/**
	 * @param dbSvcTypeCd the dbSvcTypeCd to set
	 */
	public void setDbSvcTypeCd(String dbSvcTypeCd) {
		this.dbSvcTypeCd = dbSvcTypeCd;
	}
	/**
	 * @return the dbUpdatedInd
	 */
	public char getDbUpdatedInd() {
		return dbUpdatedInd;
	}
	/**
	 * @param dbUpdatedInd the dbUpdatedInd to set
	 */
	public void setDbUpdatedInd(char dbUpdatedInd) {
		this.dbUpdatedInd = dbUpdatedInd;
	}
	
	
}
