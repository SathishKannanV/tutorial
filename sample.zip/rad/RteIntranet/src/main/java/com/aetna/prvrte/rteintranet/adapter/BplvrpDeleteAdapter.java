/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.BplvrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class BplvrpDeleteAdapter extends StoredProcedure {

	public BplvrpDeleteAdapter() {}
	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(BplvrpDeleteAdapter.class);
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public BplvrpDeleteAdapter(DataSource datasource, String storedProc)
			throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of BplvrpAdapter : " + storedProc);
		//Input parameter declaration
		declareParameter(new SqlParameter(DBConstants.LS_BNFT_ID_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_BPRO_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(DBConstants.LS_BPLV_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(DBConstants.LS_RFRL_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_PRCRT_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_PRXSTNG_IND, Types.CHAR));
		//Output parameter declaration
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));

	}
	
	/**
	 * Method to delete the Bplvrp data from data store.
	 * 
	 * @param bplvrpsList
	 *            List of aetna ids.
	 * @param takeAction
	 *            List of selected indexes to delete aetna id.
	 * 
	 * @return Map of flag to delete the data from Bplvrp list and success or
	 *         error message.
	 * @throws ApplicationException
	 *             if deletion fails.
	 */
	public Map<String, Object> deleteBplvrp(BplvrpDTO bplvrpDTO) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering getBplvrpLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, String> params = new LinkedHashMap<String, String>();
		String bplvrpMsg = "";
		boolean isBplvrpDeleted = false;
		try {
			String bnftIdCd = RteIntranetUtils.getTrimmedString(bplvrpDTO.getDbBnftIdCd());
			String provNo = String.valueOf(bplvrpDTO.getDbProvNo());
			String provLineVal = String.valueOf(bplvrpDTO.getDbProvLinVal());
			String rfrlInd = RteIntranetUtils.getTrimmedString(bplvrpDTO.getDbRFRLInd());
			String prcrtInd = RteIntranetUtils.getTrimmedString(bplvrpDTO.getDbPRCRTInd());
			String prxstngInd = RteIntranetUtils.getTrimmedString(bplvrpDTO.getDbPRXSTNGInd());
			
			params.put(DBConstants.LS_BNFT_ID_CD, bnftIdCd);
			params.put(DBConstants.LS_BPRO_NO, provNo);
			params.put(DBConstants.LS_BPLV_NO, provLineVal);
			params.put(DBConstants.LS_RFRL_IND, rfrlInd);
			params.put(DBConstants.LS_PRCRT_IND, prcrtInd);
			params.put(DBConstants.LS_PRXSTNG_IND, prxstngInd);
			
			log.info("Params for getting Bplvrp LookUp List : " + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			if ("0".equals(sqlCode)){
				isBplvrpDeleted = true;
				bplvrpMsg = ApplicationConstants.ROWS_DELETED;
			} else {
				bplvrpMsg = ApplicationConstants.DELETE_ROW_FAILS + sqlCode;
				
			}
			resultMap.put("bplvrpMsg", bplvrpMsg);
			resultMap.put("isBplvrpDeleted", isBplvrpDeleted);
			return resultMap;
			
		} catch (DataAccessException dae) {
			log.error("BplvrpDisplayAdapter : Data access excpetion occured " + dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("BplvrpDisplayAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} finally {

		}
	}
}
