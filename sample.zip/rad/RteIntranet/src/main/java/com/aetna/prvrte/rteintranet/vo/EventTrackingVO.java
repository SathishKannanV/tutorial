package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;

public class EventTrackingVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String convIdCode ="";
	private String vanIdCd = "";
	private String typeCd = "";
	private String postedDt = "";
	private String tranType ="";

	public  EventTrackingVO() {
		super();
	} 
		
	
	
	public EventTrackingVO(String convIdCode, String vanIdCd, String typeCd,
			String postedDt, String tranType) {
		super();
		this.convIdCode = convIdCode;
		this.vanIdCd = vanIdCd;
		this.typeCd = typeCd;
		this.postedDt = postedDt;
		this.tranType = tranType;
	}
	public String getConvIdCode() {
		return convIdCode;
	}
	public void setConvIdCode(String convIdCode) {
		this.convIdCode = convIdCode;
	}
	public String getVanIdCd() {
		return vanIdCd;
	}
	public void setVanIdCd(String vanIdCd) {
		this.vanIdCd = vanIdCd;
	}
	public String getTypeCd() {
		return typeCd;
	}
	public void setTypeCd(String typeCd) {
		this.typeCd = typeCd;
	}
	public String getPostedDt() {
		return postedDt;
	}
	public void setPostedDt(String postedDt) {
		this.postedDt = postedDt;
	}
	public String getTranType() {
		return tranType;
	}
	public void setTranType(String tranType) {
		this.tranType = tranType;
	}
	
	
	
}
