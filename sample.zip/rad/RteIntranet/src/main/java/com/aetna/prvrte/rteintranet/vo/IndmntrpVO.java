package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;

/**
 * @author N726899
 * Cognizant_Offshore
 */
public class IndmntrpVO implements Serializable {
	/**
	 * Constant serialized ID used for compatibility. 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * String of dbIndmntyCd
	 */
	private String dbIndmntyCd = "";
	/**
	 * String of dbIndmntyRFRLInd
	 */
	private String dbIndmntyRFRLInd = "";
	/**
	 * String of dbIndmntyPRCRTInd
	 */
	private String dbIndmntyPRCRTInd = "";
	/**
	 * String of dbIndmntyShrtNm
	 */
	private String dbIndmntyShrtNm = "";
	/**
	 * String of dbIndmntyNm
	 */
	private String dbIndmntyNm = "";
	/**
	 * String of dbPcpSelReqInd
	 */
	private String dbPcpSelReqInd = "";
	/**
	 * char of dbUpdatedInd
	 */
	private char dbUpdatedInd;

	/**
	 * Default Constructor.
	 */
	public IndmntrpVO() {
		super();
	}

	/**
	 * Creates a new IndmntrpVO
	 * 
	 * @param indmntyCd
	 *            the value for {@link dbIndmntyCd}
	 * @param indmntyRFRLInd
	 *            the value for {@link dbIndmntyRFRLInd}
	 * @param indmntyPRCRTInd
	 *            the value for {@link dbIndmntyPRCRTInd}
	 * @param indmntyShrtNm
	 *            the value for {@link dbIndmntyShrtNm}
	 * @param indmntyNm
	 *            the value for {@link dbIndmntyNm}
	 * @param pcpSelReqInd
	 *            the value for {@link dbPcpSelReqInd}
	 * @param updatedInd
	 *            the value for {@link dbUpdatedInd}
	 */
	public IndmntrpVO(String indmntyCd, String indmntyRFRLInd,
			String indmntyPRCRTInd, String indmntyShrtNm, String indmntyNm,
			String pcpSelReqInd, char updatedInd) {
		super();
		setDbIndmntyCd(indmntyCd);
		setDbIndmntyRFRLInd(indmntyRFRLInd);
		setDbIndmntyPRCRTInd(indmntyPRCRTInd);
		setDbIndmntyShrtNm(indmntyShrtNm);
		setDbIndmntyNm(indmntyNm);
		setDbPcpSelReqInd(pcpSelReqInd);
		setDbUpdatedInd(updatedInd);
	}

	/**
	 * @return the dbIndmntyCd
	 */
	public String getDbIndmntyCd() {
		return dbIndmntyCd;
	}

	/**
	 * @param dbIndmntyCd the dbIndmntyCd to set
	 */
	public void setDbIndmntyCd(String dbIndmntyCd) {
		this.dbIndmntyCd = dbIndmntyCd;
	}

	/**
	 * @return the dbIndmntyRFRLInd
	 */
	public String getDbIndmntyRFRLInd() {
		return dbIndmntyRFRLInd;
	}

	/**
	 * @param dbIndmntyRFRLInd the dbIndmntyRFRLInd to set
	 */
	public void setDbIndmntyRFRLInd(String dbIndmntyRFRLInd) {
		this.dbIndmntyRFRLInd = dbIndmntyRFRLInd;
	}

	/**
	 * @return the dbIndmntyPRCRTInd
	 */
	public String getDbIndmntyPRCRTInd() {
		return dbIndmntyPRCRTInd;
	}

	/**
	 * @param dbIndmntyPRCRTInd the dbIndmntyPRCRTInd to set
	 */
	public void setDbIndmntyPRCRTInd(String dbIndmntyPRCRTInd) {
		this.dbIndmntyPRCRTInd = dbIndmntyPRCRTInd;
	}

	/**
	 * @return the dbIndmntyShrtNm
	 */
	public String getDbIndmntyShrtNm() {
		return dbIndmntyShrtNm;
	}

	/**
	 * @param dbIndmntyShrtNm the dbIndmntyShrtNm to set
	 */
	public void setDbIndmntyShrtNm(String dbIndmntyShrtNm) {
		this.dbIndmntyShrtNm = dbIndmntyShrtNm;
	}

	/**
	 * @return the dbIndmntyNm
	 */
	public String getDbIndmntyNm() {
		return dbIndmntyNm;
	}

	/**
	 * @param dbIndmntyNm the dbIndmntyNm to set
	 */
	public void setDbIndmntyNm(String dbIndmntyNm) {
		this.dbIndmntyNm = dbIndmntyNm;
	}

	/**
	 * @return the dbPcpSelReqInd
	 */
	public String getDbPcpSelReqInd() {
		return dbPcpSelReqInd;
	}

	/**
	 * @param dbPcpSelReqInd the dbPcpSelReqInd to set
	 */
	public void setDbPcpSelReqInd(String dbPcpSelReqInd) {
		this.dbPcpSelReqInd = dbPcpSelReqInd;
	}

	/**
	 * @return the dbUpdatedInd
	 */
	public char getDbUpdatedInd() {
		return dbUpdatedInd;
	}

	/**
	 * @param dbUpdatedInd the dbUpdatedInd to set
	 */
	public void setDbUpdatedInd(char dbUpdatedInd) {
		this.dbUpdatedInd = dbUpdatedInd;
	}
}