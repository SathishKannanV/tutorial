package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.RtetprlDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.RtetprlVO;


/**
 * @author N624926
 * Cognizant_Offshore
 */
public class RtetprlDisplayAdapter extends StoredProcedure{
	/*
	 * Log factory initialization
	 */
	private final Log log = LogFactory.getLog(RtetprlDisplayAdapter.class);
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtetprlDisplayAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_STC_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_TOS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_POS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_GROUP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPRL_RULE_CD, Types.CHAR));
		
		declareParameter(new SqlOutParameter(DBConstants.OUT_LS_SQLCODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR3, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd =  ApplicationConstants.UPDATE_IND_N;			//Used by RtetprlDisplay, not on database
				RtetprlVO rtetprlVO = new RtetprlVO();
				rtetprlVO.setStcCd(rs.getString(DBConstants.RTETPRL_STC_CD));
				rtetprlVO.setTosCd(rs.getString(DBConstants.RTETPRL_TOS_CD));
				rtetprlVO.setPosCd(rs.getString(DBConstants.RTETPRL_POS_CD));
				rtetprlVO.setGroupCd(rs.getString(DBConstants.RTETPRL_GROUP_CD));
				rtetprlVO.setRuleCd(rs.getString(DBConstants.RTETPRL_RULE_CD));
				rtetprlVO.setOrderNo(rs.getString(DBConstants.RTETPRL_ORDER_NO));
				rtetprlVO.setEffDate(rs.getString(DBConstants.RTETPRL_EFF_DT));
				rtetprlVO.setExpDate(rs.getString(DBConstants.RTETPRL_EXPRTN_DT));
				rtetprlVO.setPostedDate(rs.getString(DBConstants.RTETPRL_POSTED_DTS));
				rtetprlVO.setUserId(rs.getString(DBConstants.RTETPRL_USER_ID));	
				rtetprlVO.setUpdatedInd(updatedInd);
				return rtetprlVO;
			}

		}));

	}
	
	
	/**
	 * Method to get the RTETPRL list from data store.
	 * 
	 * @param rtetprlDTO
	 * 			rtetprlDTO object.
	 * 
	 * @return Map of RTETPRL list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map getRtetprlLookUpTable (RtetprlDTO rtetprlDTO) throws ApplicationException {
		log.warn("Entered RtetprlAdapter  - getRtetprlLookUpTable");
		int searchCd ;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map rtetprlMap = new HashMap();
		params.put(DBConstants.IN_RTETPRL_STC_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getStcCd()));
		params.put(DBConstants.IN_RTETPRL_TOS_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getTosCd()));
		params.put(DBConstants.IN_RTETPRL_POS_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getPosCd()));
		params.put(DBConstants.IN_RTETPRL_GROUP_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getGroupCd()));
		params.put(DBConstants.IN_RTETPRL_RULE_CD, RteIntranetUtils.getTrimmedString(rtetprlDTO.getRuleCd()));
		
		log.warn(params);
		Map results = null;
		
		List<RtetprlVO> rtetprlList= new LinkedList<RtetprlVO>();
		String newMessage="";
		try {
			log.warn("RtetprlAdapter: Executing stored procedure : ");
					
			results = execute(params);
			log.warn("RtetprlAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_LS_SQLCODE));
			
			rtetprlList = (List<RtetprlVO>) results
					.get(DBConstants.READ_CURSOR3);	
	
			if (rtetprlList.isEmpty()){
				
				if (ApplicationConstants.ZERO_0.equals(sqlCode)) {

					newMessage = "No Data on database for STC Cd: " + rtetprlDTO.getStcCd() + ", TOS Cd: " + rtetprlDTO.getTosCd() + ", POS Code: " + rtetprlDTO.getPosCd() + ", Group Code: " + rtetprlDTO.getGroupCd() + ", Rule Code: " + rtetprlDTO.getRuleCd();
				} else {
					newMessage = "Problem in DB2. sqlcode: " + sqlCode + " STC Cd: " + rtetprlDTO.getStcCd() + " TOS Cd: " + rtetprlDTO.getTosCd() + " POS Cd: " + rtetprlDTO.getPosCd() + " Group Cd: " + rtetprlDTO.getGroupCd() + " Rule Cd: " + rtetprlDTO.getRuleCd();
				}			  		  		  
			} else {
				newMessage = "Data found on database for STC Cd: " + rtetprlDTO.getStcCd() + ", TOS Code: " + rtetprlDTO.getTosCd() + ", POS Code: " + rtetprlDTO.getPosCd() + ", Group Code: " + rtetprlDTO.getGroupCd() + ", Rule Code: " + rtetprlDTO.getRuleCd();
				}
			/*}else{
				newMessage = "You must enter a Rtetprl Code with or without combination of Rider Code and/or Service Type Code on the Look Up page.";
			}*/
			rtetprlMap.put("newMessage", newMessage);
			rtetprlMap.put("rtetprlList",rtetprlList);
			return rtetprlMap;
		}catch (Exception exception){
			log.error("RtetprlAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
		
		
		public String getMessage (String newMessage, String queryRtetprlCd, String querySvcTypeCd) {
			String getMessage = newMessage;
		    if (!queryRtetprlCd.equals("")) 
			    getMessage = getMessage + " Rtetprl  : " + queryRtetprlCd;
		    if (!querySvcTypeCd.equals(""))
			    getMessage = getMessage + " Service Type  : " + querySvcTypeCd;
			return getMessage;
}	

}
