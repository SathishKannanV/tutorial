/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.DedacsrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.DedacsrVO;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;

/**
 * <h1>Dedacsr Controller</h1> The Dedacsr Controller is responsible for handling
 * the actual request from DispatcherServlet and returning an appropriate
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * 
 * @author N726899 
 * 
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/dedacsr/*")
public class DedacsrController {
	/*
	 * Instance of logger for DedacsrController.
	 */
	private static final Log log = LogFactory.getLog(DedacsrController.class);
	/*
	 * Tile name of the dedacsr home view.
	 */
	public static final String DEDACSR_HOME = ".dedacsrHome";
	/*
	 * Tile name of the dedacsr display view.
	 */
	public static final String DEDACSR_DISPLAY = ".dedacsrDisplay";
	/*
	 * Tile name of the  add new dedacsr form view.
	 */
	public static final String DEDACSR_ADD_NEW = ".addDedacsr";
	
	/*
	 * Instance of Facade.
	 */
	@Autowired(required = true)
	private Facade facade;
	/*
	 * Model and view of success operation.
	 */
	private ModelAndView modelAndView;
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errorModelAndView;

	/**
	 * Method to display dedacsrLookup view.
	 * 
	 * @return view of dedacsrLookUp, if fails return error page
	 */
	@RequestMapping(value = "/dedacsrHome", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView getDedacsrLookUp(HttpServletRequest request) {
		try {
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView = new ModelAndView(DEDACSR_HOME, "dedacsrVO", new DedacsrVO());
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in DedacsrController - getDedacsrLookUp() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_LOOKUP_VIEW + "(DedacsrController)" + RteIntranetUtils.getTrimmedString(e.getMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the dedacsrLookUp List from data store.
	 * 
	 * @param dedacsrVO
	 *            form view object of dedacsr.
	 * @return view of dedacsrDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/dedacsrLookUp", method = RequestMethod.POST)
	public ModelAndView getDedacsrLookUpList(@ModelAttribute("dedacsrForm") DedacsrVO dedacsrVO,
			HttpServletRequest request) {
		try {
			DedacsrDTO dedacsrDTO = RTETranslator.toDedacsrDTO(dedacsrVO);
			
			Map<String, Object> dedacsrMap = facade.getDedacsrLookUpList(dedacsrDTO);
			//set DedacsrVOList in application state.
			List<DedacsrVO> dedacsrList = (List<DedacsrVO>) dedacsrMap.get("dedacsrList");
			facade.getApplicationState().setDedacsrList(dedacsrList);
			LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
			lookUpTableListVO.setDedacsrVOList(dedacsrList);
			modelAndView = new ModelAndView(DEDACSR_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("dedacsrMsg",dedacsrMap.get("dedacsrMsg"));
			modelAndView.addObject("dedacsrList", dedacsrList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e) {
			log.error("Exception occured in DedacsrController - getDedacsrLookUp() method:"	+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(DedacsrController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to display get add new Dedacsr form home view.
	 * 
	 * @return view of addDedacsrForm, if fails return error page
	 */
	@RequestMapping(value = "/addDedacsrForm", method = RequestMethod.POST)
	public ModelAndView getAddNewDedacsrFormHome(HttpServletRequest request) {
		try {
			String securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView =  new ModelAndView(DEDACSR_ADD_NEW, "dedacsrVO", new DedacsrVO());
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in DedacsrController - getAddNewDedacsrFormHome() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_VIEW + "(DedacsrController)" + e.toString();
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the dedacsrLookUp List from data store.
	 * 
	 * @param dedacsrVO
	 *            form view object of dedacsr.
	 * @return view of dedacsrDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addDedacsr", method = RequestMethod.POST)
	public ModelAndView addDedacsr(final HttpServletRequest request, @ModelAttribute("addDedacsrForm") DedacsrVO dedacsrVO) {
		try {
			DedacsrDTO dedacsrDTO = RTETranslator.toDedacsrDTO(dedacsrVO);
			Map<String, Object> dedacsrMap = facade.addDedacsrToDb(dedacsrDTO);
			
			//set DedacsrVOList in application state.
			List<DedacsrVO> dedacsrList = (List<DedacsrVO>) dedacsrMap.get("dedacsrList");
			facade.getApplicationState().setDedacsrList(dedacsrList);
			LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
			lookUpTableListVO.setDedacsrVOList(dedacsrList);
			
			modelAndView = new ModelAndView(DEDACSR_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("dedacsrMsg",dedacsrMap.get("dedacsrMsg"));
			modelAndView.addObject("dedacsrList",dedacsrList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e) {
			log.error("Exception occured in DedacsrController - addDedacsr() method:"+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_ROW + "(DedacsrController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}
	
	/**
	 * Method to get the dedacsrLookUp List from data store.
	 * @param request
	 *            request object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of dedacsrDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/deleteDedacsr", method = RequestMethod.POST)
	public ModelAndView deleteDedacsr(@RequestParam(required = false) String[] takeAction,
		HttpServletRequest request,	@ModelAttribute("dedacsrDisplay")LookUpTableListVO lookUpTableListVO) {
		List<DedacsrVO> dedacsrList = new LinkedList<DedacsrVO>();
		int index;
		Map<String, Object> dedacsrMap = new HashedMap();
		String dedacsrMsg = "";
		try {
			dedacsrList = lookUpTableListVO.getDedacsrVOList();
			if(takeAction != null && takeAction.length != 0){
				boolean isDedacsrDeleted = false;
				if (dedacsrList != null && dedacsrList.size() != 0) {
					List<DedacsrDTO> updatedDedacsrList = RTETranslator.toDedacsrDTOList(dedacsrList);
					for (int j = takeAction.length - 1; j >= 0; j--) {
						index = Integer.parseInt(takeAction[j]);
						DedacsrDTO existingDedacsr = (DedacsrDTO) updatedDedacsrList.get(index);
						if (existingDedacsr.getDbUpdatedInd() != ApplicationConstants.COPY) {
							String dbSvcTypeCd = existingDedacsr.getDbSvcTypeCd();
							String dbDefAccumCd = existingDedacsr.getDbDefAccumCd();
							dedacsrMap = facade.deleteDedacsr(dbSvcTypeCd, dbDefAccumCd);
							dedacsrMsg = (String) dedacsrMap.get("dedacsrMsg");
							isDedacsrDeleted = (Boolean) dedacsrMap.get("isDedacsrDeleted");
							if(isDedacsrDeleted){
								dedacsrList.remove(index);
							}else{
								j = 0;
							}
						} else{
							dedacsrList.remove(index);
						}
						
					}
					if(isDedacsrDeleted)
					dedacsrMsg = ApplicationConstants.ROWS_DELETED;
				
				}
			} else
				dedacsrMsg = ApplicationConstants.NO_ACTION_TAKEN;
			
			//update DedacsrVOList in application state.
			facade.getApplicationState().setDedacsrList(dedacsrList);
			lookUpTableListVO.setDedacsrVOList(dedacsrList);
			modelAndView = new ModelAndView(DEDACSR_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("dedacsrMsg",dedacsrMsg);
			modelAndView.addObject("dedacsrList",dedacsrList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in DedacsrController - deleteDedacsr() method:"+e.getErrorMessage());
            String errorMsg =ApplicationConstants.ERROR_GET_LOOKUP + "(DedacsrController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
		}
	}

	/**
	 * Method to get the dedacsrLookUp List from data store.
	 * 
	 * @param dedacsrVO
	 *            form view object of dedacsr.
	 * @param takeAction
	 *          List of takeAction to copy the row
	 * @return view of dedacsrDisplay, if fails return error page
	 */
	@RequestMapping(value = "/copyDedacsr",  method = { RequestMethod.POST})
	public ModelAndView copyDedacsr(@RequestParam(required = false) String[] takeAction,
		HttpServletRequest request,	@ModelAttribute("dedacsrDisplay")LookUpTableListVO lookUpTableListVO) {
			int index;
			String dedacsrMsg ="";
			List<DedacsrVO> dedacsrList = new LinkedList<DedacsrVO>();
		try {
			dedacsrList = lookUpTableListVO.getDedacsrVOList();
			if(takeAction != null && takeAction.length != 0){
				if(dedacsrList != null && dedacsrList.size() != 0){
					for (int j = 0; j < takeAction.length; j++) {
						index = Integer.parseInt(takeAction[j]);
						DedacsrVO existingDedacsr = (DedacsrVO) dedacsrList.get(index);
						DedacsrVO copiedDedacsrVO =  (DedacsrVO) SerializationUtils.clone(existingDedacsr);
						copiedDedacsrVO.setDbUpdatedInd(ApplicationConstants.COPY);
						dedacsrList.add(copiedDedacsrVO);
					}
					dedacsrMsg = ApplicationConstants.ROWS_COPIED;
				}
			} else {
				dedacsrMsg = ApplicationConstants.NO_ACTION_TAKEN;
			}
			//update DedacsrVOList in application state.
			facade.getApplicationState().setDedacsrList(dedacsrList);
			lookUpTableListVO.setDedacsrVOList(dedacsrList);
			modelAndView = new ModelAndView(DEDACSR_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("dedacsrMsg",dedacsrMsg);
			modelAndView.addObject("dedacsrList",dedacsrList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in DedacsrController - copyDedacsr() method:" + e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(DedacsrController)" + RteIntranetUtils.getTrimmedString(e.getMessage());
			modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);
			return modelAndView;
		}
	}

	/**
	 * Method to get the dedacsrLookUp List from data store.
	 * 
	 * @param takeAction
	 *            list of selected indexes from view.
	 * @param request
	 *            request object.
	 * @return view of dedacsrDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addUpdateDedacsr", method = RequestMethod.POST)
	public ModelAndView addUpdateDedacsr(@RequestParam(required = false) String[] takeAction,
		HttpServletRequest request,	@ModelAttribute("dedacsrDisplay")LookUpTableListVO lookUpTableListVO) {
		int index;
		String dedacsrMsg ="";
		List<DedacsrVO> modifiedDedacsrList = new LinkedList<DedacsrVO>();
		List<DedacsrVO> dedacsrList = new LinkedList<DedacsrVO>();
		try {
			modifiedDedacsrList = lookUpTableListVO.getDedacsrVOList();
			dedacsrList = facade.getApplicationState().getDedacsrList();
			if(takeAction != null && takeAction.length != 0){
				for(DedacsrVO dedacsrVO : dedacsrList){
					if(dedacsrVO.getDbUpdatedInd() == ApplicationConstants.UPDATE_IND_Y){
						dedacsrVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				if(dedacsrList != null && dedacsrList.size() != 0
						&& modifiedDedacsrList != null && modifiedDedacsrList.size() != 0){
					Map<String, Object> dedacsrMap = new HashedMap();
					List<DedacsrDTO> dedacsrDTOList = RTETranslator.toDedacsrDTOList(dedacsrList);
					for (int j = 0; j < takeAction.length; j++) {
						index = Integer.parseInt(takeAction[j]);
						DedacsrDTO updatedDedacsrDTO = RTETranslator.toDedacsrDTO(modifiedDedacsrList.get(index));
						dedacsrMap = facade.addUpdateDedacsr(updatedDedacsrDTO, dedacsrDTOList, index);
						List<DedacsrDTO> dedacsrDtoList = (List<DedacsrDTO>) dedacsrMap.get("dedacsrList");
						dedacsrList = RTETranslator.toDedacsrVOList(dedacsrDtoList);
						boolean isDedacsrAddorUpdated = (Boolean) dedacsrMap.get("isDedacsrAddorUpdated");
						dedacsrMsg = (String) dedacsrMap.get("dedacsrMsg") ;
						if(isDedacsrAddorUpdated){
							j = takeAction.length;
						} 
					}
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);
				}
			} else {
				dedacsrMsg = ApplicationConstants.NO_ACTION_TAKEN;
			}
			//update DedacsrVOList in application state.
			facade.getApplicationState().setDedacsrList(dedacsrList);
			lookUpTableListVO.setDedacsrVOList(dedacsrList);
			modelAndView = new ModelAndView(DEDACSR_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("dedacsrMsg",dedacsrMsg);
			modelAndView.addObject("dedacsrList",dedacsrList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in DedacsrController - addUpdateDedacsr() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(DedacsrController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
      }
	}
	/**
	 * Method to export Dedacsr look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of dedacsr object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/dedacsrExport", method = RequestMethod.POST)
	public ModelAndView dedacsrExport(HttpServletResponse response){
		List<DedacsrVO> dedacsrList = new LinkedList<DedacsrVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String dedacsrMsg="";
		try{
			dedacsrList = facade.getApplicationState().getDedacsrList();
			if(dedacsrList != null && dedacsrList.size() != 0){
				// Key map to create header
				Map<String,String> keyMap = new LinkedHashMap<String,String>();
				keyMap.put("dbSvcTypeCd", "Svc Type");
				keyMap.put("dbDefAccumCd", "Accum Code");
				
				RteIntranetUtils.exportToExcel(response, dedacsrList, keyMap);
				dedacsrMsg = ApplicationConstants.EXPORT_SUCCESS;
			} else {
				dedacsrMsg = ApplicationConstants.NO_DATA;
			}
			lookUpTableListVO.setDedacsrVOList(dedacsrList);
	        modelAndView = new ModelAndView(DEDACSR_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
	        modelAndView.addObject("dedacsrMsg",dedacsrMsg);
		    return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in DedacsrController - dedacsrExport() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_EXPOT_TABLE + "(DedacsrController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
       }
	}
}
