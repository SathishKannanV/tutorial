/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.BplvrpDisplayAdapter;
import com.aetna.prvrte.rteintranet.adapter.BplvrpAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.BplvrpDeleteAdapter;
import com.aetna.prvrte.rteintranet.dto.BplvrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.dao.RteBplvrpDAO
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Repository
public class RteBplvrpDAOImpl implements RteBplvrpDAO {
	/*
	 * Instance of BplvrpDisplayAdapter.
	 */
	@Autowired(required = true)
	private BplvrpDisplayAdapter bplvrpDisplayAdapter;
	/*
	 * Instance of BplvrpAddAdapter.
	 */
	@Autowired(required = true)
	private BplvrpAddAdapter bplvrpAddAdapter;
	/*
	 * Instance of BplvrpDeleteAdapter.
	 */
	@Autowired(required = true)
	private BplvrpDeleteAdapter bplvrpDeleteAdapter;

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteBplvrpDAO#getBplvrpLookUpList(com.aetna.prvrte.rteintranet.dto.BplvrpDTO)
	 */
	@Override
	public Map<String, Object> getBplvrpLookUpList(BplvrpDTO bplvrpDTO) throws ApplicationException {
			return bplvrpDisplayAdapter.getBplvrpLookUpList(bplvrpDTO);
		
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteBplvrpDAO#addBplvrp(com.aetna.prvrte.rteintranet.dto.BplvrpDTO)
	 */
	@Override
	public Map<String, Object> addBplvrpToDb(BplvrpDTO bplvrpDTO) throws ApplicationException {
		return bplvrpAddAdapter.addBplvrpToDb(bplvrpDTO);
	}
	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteBplvrpDAO#deleteBplvrp(com.aetna.prvrte.rteintranet.dto.BplvrpDTO)
	 */
	@Override
	public Map<String, Object> deleteBplvrp(BplvrpDTO bplvrpDTO) throws ApplicationException {
		return bplvrpDeleteAdapter.deleteBplvrp(bplvrpDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.dao.RteBplvrpDAO#addUpdateBplvrp(java.util.List, java.lang.String[])
	 */
	@Override
	public Map<String, Object> addUpdateBplvrp(BplvrpDTO bplvrpDTO, List<BplvrpDTO> bplvrpDTOList, int index)
			throws ApplicationException {
		return bplvrpAddAdapter.addUpdateBplvrp(bplvrpDTO, bplvrpDTOList,index);
	}
}
