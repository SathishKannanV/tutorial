/* Created on Jan 27, 2008 */
package com.aetna.prvrte.rteintranet.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Vector;

/* @author N726899 */

public class SbmrstVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String dbTranType = new String();
	private String dbVanIdCd = new String();
	private String dbTypeCd = new String();
	private String dbConvCode = new String();
	private int dbSeqNo;
	private String dbQualifierCd = new String();
	private String dbProcedureCd = new String();
	private String dbDiagnosisCd = new String();
	private String dbServiceTypeCd = new String();
	private ArrayList dbBenefitCollection = new ArrayList();

	public SbmrstVO() {
	};

	public SbmrstVO(String tranType, String vanIdCd, String typeCd,
			String convCode, int seqNo, String qualifierCd, String procedureCd,
			String diagnosisCd, String serviceTypeCd,
			ArrayList benefitCollection) {
		super();
		dbVanIdCd = vanIdCd;
		dbTypeCd = typeCd;
		dbConvCode = convCode;
		dbSeqNo = seqNo;
		dbQualifierCd = qualifierCd;
		dbProcedureCd = procedureCd;
		dbDiagnosisCd = diagnosisCd;
		dbServiceTypeCd = serviceTypeCd;
		dbBenefitCollection = benefitCollection;
		dbTranType = tranType;
	}

	/**
	 * @return the dbTranType
	 */
	public String getDbTranType() {
		return dbTranType;
	}

	/**
	 * @param dbTranType
	 *            the dbTranType to set
	 */
	public void setDbTranType(String dbTranType) {
		this.dbTranType = dbTranType;
	}

	/**
	 * @return the dbVanIdCd
	 */
	public String getDbVanIdCd() {
		return dbVanIdCd;
	}

	/**
	 * @param dbVanIdCd
	 *            the dbVanIdCd to set
	 */
	public void setDbVanIdCd(String dbVanIdCd) {
		this.dbVanIdCd = dbVanIdCd;
	}

	/**
	 * @return the dbTypeCd
	 */
	public String getDbTypeCd() {
		return dbTypeCd;
	}

	/**
	 * @param dbTypeCd
	 *            the dbTypeCd to set
	 */
	public void setDbTypeCd(String dbTypeCd) {
		this.dbTypeCd = dbTypeCd;
	}

	/**
	 * @return the dbConvCode
	 */
	public String getDbConvCode() {
		return dbConvCode;
	}

	/**
	 * @param dbConvCode
	 *            the dbConvCode to set
	 */
	public void setDbConvCode(String dbConvCode) {
		this.dbConvCode = dbConvCode;
	}

	/**
	 * @return the dbSeqNo
	 */
	public int getDbSeqNo() {
		return dbSeqNo;
	}

	/**
	 * @param dbSeqNo
	 *            the dbSeqNo to set
	 */
	public void setDbSeqNo(int dbSeqNo) {
		this.dbSeqNo = dbSeqNo;
	}

	/**
	 * @return the dbQualifierCd
	 */
	public String getDbQualifierCd() {
		return dbQualifierCd;
	}

	/**
	 * @param dbQualifierCd
	 *            the dbQualifierCd to set
	 */
	public void setDbQualifierCd(String dbQualifierCd) {
		this.dbQualifierCd = dbQualifierCd;
	}

	/**
	 * @return the dbProcedureCd
	 */
	public String getDbProcedureCd() {
		return dbProcedureCd;
	}

	/**
	 * @param dbProcedureCd
	 *            the dbProcedureCd to set
	 */
	public void setDbProcedureCd(String dbProcedureCd) {
		this.dbProcedureCd = dbProcedureCd;
	}

	/**
	 * @return the dbDiagnosisCd
	 */
	public String getDbDiagnosisCd() {
		return dbDiagnosisCd;
	}

	/**
	 * @param dbDiagnosisCd
	 *            the dbDiagnosisCd to set
	 */
	public void setDbDiagnosisCd(String dbDiagnosisCd) {
		this.dbDiagnosisCd = dbDiagnosisCd;
	}

	/**
	 * @return the dbServiceTypeCd
	 */
	public String getDbServiceTypeCd() {
		return dbServiceTypeCd;
	}

	/**
	 * @param dbServiceTypeCd
	 *            the dbServiceTypeCd to set
	 */
	public void setDbServiceTypeCd(String dbServiceTypeCd) {
		this.dbServiceTypeCd = dbServiceTypeCd;
	}

	/**
	 * @return the dbBenefitCollection
	 */
	public ArrayList getDbBenefitCollection() {
		return dbBenefitCollection;
	}

	/**
	 * @param dbBenefitCollection
	 *            the dbBenefitCollection to set
	 */
	public void setDbBenefitCollection(ArrayList dbBenefitCollection) {
		this.dbBenefitCollection = dbBenefitCollection;
	}
}
