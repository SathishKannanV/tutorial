/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.RtetierDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.RtetierVO;

/**
 * @author N657186
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/rtetier/*")
public class RtetierController {
	public static final String RTETIER_HOME = ".rtetierHome";
	public static final String RTETIER_LOOKUP = ".rtetierLookUp";
	public static final String RTETIER_ADD = ".rtetierAddNew";

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(RtetierController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/rtetierHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRtetierLookUpHome(final HttpServletRequest request, Model model) {
		log.warn("Entered RtetierController - getRtetierLookUpHome()");
		String securityLevel ="";
		try{
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(RTETIER_HOME, "rtetierVO",  new RtetierVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("RtetierController - securityLevel: "+ securityLevel);
		log.warn("Exit from RtetierController - getRtetierLookUpHome()");
		return mav;
		} catch (ApplicationException e){
			log.error("Exception occured in RtetierController - getRtetierLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherRTETIER). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rtetierVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherRtetier", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRtetierLookUp(HttpServletRequest request,@ModelAttribute("rtetierForm")RtetierVO rtetierVO){
		log.warn("Entered RtetierController - getRtetierLookUp()");
		ModelAndView mav ;
		Map rtetierResultMap = new HashMap();
		String securityLevel ="";
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<RtetierDTO> rtetierDtoList = new LinkedList<RtetierDTO>();
		List<RtetierVO> rtetierVoList = new LinkedList<RtetierVO>();
		try{
		RtetierDTO rtetierDTO = RTETranslator.toRtetierDTO(rtetierVO);
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		rtetierResultMap = facade.getRtetierLookUp(rtetierDTO);
		
		rtetierDtoList = (List<RtetierDTO>) rtetierResultMap.get("rtetierList");
		rtetierVoList = RTETranslator.toRtetierVOList(rtetierDtoList);
		lookUpListVO.setRtetierVOList(rtetierVoList);
		facade.getApplicationState().setRtetierList(rtetierVoList);
		log.warn("getRtetierLookUp - rtetierMessage: "+ rtetierResultMap.get("rbrcMessage"));
		mav = new ModelAndView(RTETIER_LOOKUP, "lookUpListVO", lookUpListVO);
		mav.addObject("rtetierMessage", rtetierResultMap.get("rtetierMessage"));
			mav.addObject("securityLevel", securityLevel);
		log.warn("Exit from RtetierController - getRtetierLookUp()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in rtetierController - getrtetierLookUp() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherRTETIER). "+
			RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/AddNewRtetierRow", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView loadAddNewRtetierRowScreen(final HttpServletRequest request,Model model) {	
		log.warn("Entered RtetierController - loadAddNewRtetierRowScreen()");
		ModelAndView mav = new ModelAndView(RTETIER_ADD, "rtetierVO",  new RtetierVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in RtetierController - loadAddNewRtetierRowScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (loadAddNewRtetierRowScreen). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		log.warn("Exit from RtetierController - loadAddNewRtetierRowScreen()");
		return mav;
	}
	
	/**
	 * @param rtetierVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddRtetier", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addNewRtetier(final HttpServletRequest request,@ModelAttribute("addRtetierForm")RtetierVO rtetierVO){
		log.warn("Entered RtetierController - addNewRtetier()");
		
		String securityLevel ="";
		Map rtetierResultMap = new HashMap();
		List<RtetierDTO> rtetierDtoList = new LinkedList<RtetierDTO>();
		List<RtetierVO> rtetierVoList = new LinkedList<RtetierVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			
			Timestamp currentTS = new Timestamp(System.currentTimeMillis());
			String postedDate = currentTS.toString(); //Initialize Posted Date to the current timestamp
			rtetierVO.setPostedDateTimestamp(postedDate);
			rtetierVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
			RtetierDTO rtetierDTO = RTETranslator.toRtetierDTO(rtetierVO);
			rtetierResultMap = facade.addNewRtetier(rtetierDTO);
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if(rtetierResultMap.get("rtetierList")!=null){
				rtetierDtoList = (List<RtetierDTO>) rtetierResultMap.get("rtetierList");
				rtetierVoList = RTETranslator.toRtetierVOList(rtetierDtoList);
			}
			lookUpListVO.setRtetierVOList(rtetierVoList);
			facade.getApplicationState().setRtetierList(rtetierVoList);
			mav = new ModelAndView(RTETIER_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("securityLevel", securityLevel);
			mav.addObject("rtetierMessage", rtetierResultMap.get("rtetierMessage"));
			
			log.warn("addNewRtetier - rtetierMessage: "+ rtetierResultMap.get("rtetierMessage"));
			log.warn("Exit from RtetierController - addNewRtetier()");
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in RtetierController - addNewRtetier() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when adding a row to the database (AddRTETIER). " +
			RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * @param rtetierVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteRtetier", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView deleteRtetier(final HttpServletRequest request,@ModelAttribute("rtetierDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtetierController - deleteRtetier()");
		ModelAndView mav ;
		String rtetierMsg = "";
		boolean isRtetierDeleted = true;
		String securityLevel ="";
		Map rtetierResultMap = new HashMap();
		
		List<RtetierVO> rtetierVoList = new LinkedList<RtetierVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtetierVoList = lookUpListVO.getRtetierVOList();
			int i;
			
			if ((rtetierVoList != null) && (takeAction != null)) {
			
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);

					RtetierVO existingRtetier = (RtetierVO) rtetierVoList.get(i);
					if (existingRtetier.getUpdatedInd() != ApplicationConstants.COPY) {
						RtetierDTO rtetierDTO = RTETranslator.toRtetierDTO(existingRtetier);
						rtetierResultMap = facade.deleteRtetier(rtetierDTO);
						rtetierMsg = (String) rtetierResultMap.get("rtetierMessage");
						isRtetierDeleted = (Boolean) rtetierResultMap.get("isRtetierDeleted");
						
						if(isRtetierDeleted){
							rtetierVoList.remove(i);
						}else{
							j = 0;
						}
					}else{
						rtetierVoList.remove(i);
					}				
			}
				if(isRtetierDeleted)
					rtetierMsg = "Rows selected were Deleted in the database/list";
				
		}else
			rtetierMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRtetierList(rtetierVoList);
			lookUpListVO.setRtetierVOList(rtetierVoList);
			
			mav = new ModelAndView(RTETIER_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtetierMessage",rtetierMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteRtetier - rtetierMessage: "+ rtetierMsg);
		    log.warn("Exit from RtetierController - deleteRtetier()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtetierController - deleteRtetier() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRTETIER). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rtetierVO
	 * @param takeAction
	 * @return
	 */
	@RequestMapping(value="/copyRtetier", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView copyRtetier(final HttpServletRequest request,@ModelAttribute("rtetierDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RtetierController - copyRtetier()");
		ModelAndView mav ;
		String rtetierMsg = "";
		String securityLevel ="";
		int i;
		List<RtetierVO> rtetierVoList = new LinkedList<RtetierVO>();
		try{
			rtetierVoList = lookUpListVO.getRtetierVOList();
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString(); //Initialize Posted Date to today's date
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if ((rtetierVoList != null) && (takeAction != null)) {
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					RtetierVO existingRtetier = (RtetierVO) rtetierVoList.get(i);
					
					RtetierVO copyRtetier = new RtetierVO(existingRtetier.getRtetierSavingsCd(), existingRtetier.getRtetierCd(), 
							existingRtetier.getEffDate(),existingRtetier.getRtetierDescTxt(),existingRtetier.getExpDate(),
							postedDate, existingRtetier.getUserId(), ApplicationConstants.COPY);
					rtetierVoList.add(copyRtetier);
				}
				rtetierMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				rtetierMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRtetierList(rtetierVoList);
			lookUpListVO.setRtetierVOList(rtetierVoList);
			mav = new ModelAndView(RTETIER_LOOKUP, "lookUpListVO", lookUpListVO);
			
		    mav.addObject("rtetierMessage",rtetierMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyRtetier - rtetierMessage: "+ rtetierMsg);
		    log.warn("Exit from RtetierController - copyRtetier()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in RtetierController - copyRtetier() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRtetier). "+
					RteIntranetUtils.getTrimmedString(e.getMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	/**
	 * @param request
	 * @param rtetierVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateRtetier", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addUpdateRtetier(@ModelAttribute("rtetierDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction,
			HttpServletRequest request){
		log.warn("Entered RtetierController - addUpdateRtetier()");
		ModelAndView mav ;
		String rtetierMsg = "";
		List<RtetierVO> updatedRtetierList = new LinkedList<RtetierVO>();
		String securityLevel ="";
		List<RtetierDTO> updatedRtetierDtoList = new LinkedList<RtetierDTO>();
		List<RtetierVO> rtetierVoList = new LinkedList<RtetierVO>();
		List<RtetierVO> modifiedRtetierVoList = new LinkedList<RtetierVO>();
		List<RtetierDTO> rtetierDtoList = new LinkedList<RtetierDTO>();
		RtetierDTO editedRtetierDTO = new RtetierDTO();
		Map rtetierResultMap = new HashMap();
		boolean isRtetierAddOrUpdated = false;
		
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rtetierVoList = facade.getApplicationState().getRtetierList();
			modifiedRtetierVoList = lookUpListVO.getRtetierVOList();
			int i;
			
			String postedDate = RteIntranetUtils.getTodaysDateTime();
			
			if (takeAction != null && takeAction.length != 0) {
				if(rtetierVoList != null && rtetierVoList.size() != 0 
						&& modifiedRtetierVoList.size() != 0 && modifiedRtetierVoList != null){
				for(RtetierVO rtetierVO : rtetierVoList){
					if(rtetierVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rtetierVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				rtetierDtoList = RTETranslator.toRtetierDTOList(rtetierVoList);
				
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					
					i = Integer.parseInt(takeAction[j]);
					RtetierVO seletedRtetier = (RtetierVO) rtetierVoList.get(i);
					RtetierVO editedRtetier = (RtetierVO) modifiedRtetierVoList.get(i);
					String userId = RteIntranetUtils.getUserId(request);
					log.warn("addUpdateRtetier - user selected: "+ i);
					RtetierVO editedRtetierVO = new RtetierVO(editedRtetier.getRtetierSavingsCd(), editedRtetier.getRtetierCd(), 
							editedRtetier.getEffDate(),editedRtetier.getRtetierDescTxt(),editedRtetier.getExpDate(),
							postedDate, userId, updatedInd);
					
					if(editedRtetierVO!=null){
					editedRtetierDTO = RTETranslator.toRtetierDTO(editedRtetierVO);
					}
					rtetierResultMap = facade.addUpdateRtetier(editedRtetierDTO, rtetierDtoList, i, seletedRtetier.getUpdatedInd());
					updatedRtetierDtoList = (List<RtetierDTO>) rtetierResultMap.get("rtetierDtoList");
					if(updatedRtetierDtoList!=null){
					updatedRtetierList = RTETranslator.toRtetierVOList(updatedRtetierDtoList);
					}
					 isRtetierAddOrUpdated = (Boolean) rtetierResultMap.get("isrtetierAddorUpdated");
					rtetierMsg = (String) rtetierResultMap.get("rtetierMessage") ;
					if(!isRtetierAddOrUpdated){
						j = takeAction.length;
					}
				}
				
				if(isRtetierAddOrUpdated){
					rtetierMsg = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted.";
				String xRtetierSavingsCd, yRtetierSavingsCd, xEffDate, yEffDate;
				for (int x = updatedRtetierList.size() - 1 ; x > 0;  x--) {
					RtetierVO xRtetier = (RtetierVO) updatedRtetierList.get(x);
					xRtetierSavingsCd = xRtetier.getRtetierSavingsCd();
					xEffDate = xRtetier.getEffDate();
					if (xRtetier.getUpdatedInd() != 'C') {
						for (int y = x - 1; y > -1; y--) {
							RtetierVO aRtetier = (RtetierVO) updatedRtetierList.get(y);
							yRtetierSavingsCd = aRtetier.getRtetierSavingsCd();
							yEffDate = aRtetier.getEffDate();
							if (xRtetierSavingsCd.equals(yRtetierSavingsCd) && xEffDate.equals(yEffDate)) {
								updatedRtetierList.remove(y); 
								x--;
							}
						}
					}
				}
				}
				lookUpListVO.setRtetierVOList(updatedRtetierList);
				facade.getApplicationState().setRtetierList(updatedRtetierList);
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	
				}
		}else{
			rtetierMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setRtetierVOList(rtetierVoList);	
			facade.getApplicationState().setRtetierList(rtetierVoList);
		}
			
			mav = new ModelAndView(RTETIER_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rtetierMessage",rtetierMsg);
			mav.addObject("securityLevel", securityLevel);
		    
		    log.warn("addUpdateRtetier - rtetierMessage: "+ rtetierMsg);
		    log.warn("Exit from RtetierController - addUpdateRtetier()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RtetierController - deleteRtetier() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRTETIER). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}


	/**
     * Method to export Rtetier look up table to excel work book
     * 
      * @param lookUpTableListVO
     *            list of rtetier object.
     * @param response
     *            response object to return
     * @return exported file to view.
     */
	@RequestMapping(value = "/rteTierExport", method = RequestMethod.POST)
	public ModelAndView rteTierExport(final HttpServletResponse response){
		List<RtetierVO> rteTierList = new LinkedList<RtetierVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String rteTierMsg="";
		try{
			rteTierList = facade.getApplicationState().getRtetierList();
			if(rteTierList != null && rteTierList.size() != 0){
				// Key map to create header
				Map<String,String> keyMap = new LinkedHashMap<String,String>();
				
				keyMap.put("rtetierSavingsCd", "Savings Code");
				keyMap.put("rtetierCd", "Tier Code");
				keyMap.put("rtetierDescTxt", "Description");
				keyMap.put("effDate", "Effective Date");
				keyMap.put("expDate", "Expiration Date");
				keyMap.put("postedDateTimestamp", "Posted Date");
				keyMap.put("userId", "User Id");
				
				RteIntranetUtils.exportToExcel(response, rteTierList, keyMap);
				rteTierMsg = ApplicationConstants.EXPORT_SUCCESS;
			} else {
				rteTierMsg = ApplicationConstants.NO_DATA;
			}
			lookUpTableListVO.setRtetierVOList(rteTierList);
			mav = new ModelAndView(RTETIER_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
			mav.addObject("rtetierMessage",rteTierMsg);
		    return mav;
		} catch (ApplicationException e){
			log.error("Exception occured in RtetierController - rteTierExport() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_EXPOT_TABLE + "(RtetierController) " + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return errormav;
       }
	}
	
	
}
