/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class PlnlmEXDeleteAdapter extends StoredProcedure {

	public PlnlmEXDeleteAdapter() {}
	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(PlnlmEXDeleteAdapter.class);
	
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	public PlnlmEXDeleteAdapter(DataSource datasource, String storedProc) throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of PlnlmEXAdapter : " + storedProc);
		//Input Params declaration
		declareParameter(new SqlParameter(DBConstants.PLNLMEX_EXPLNT_CD, Types.CHAR));
		
		
		//Output Params declaration
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
	}
	
	/**
	 * Method to delete the PlnlmEX data from data store.
	 * 
	 * @param explntCd
	 *            String of explntCd.
	 * @return Map of flag to delete the data from PlnlmEX list and success or
	 *         error message.
	 * @throws ApplicationException
	 *             if deletion fails.
	 */
	public Map<String, Object> deletePlnlmEX(String explntCd) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering deletePlnlmEX ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, String> params = new LinkedHashMap<String, String>();
		String erspmsgMsg = "";
		boolean isPlnlmEXDeleted = false;
		try {
			String dbExplntCd = RteIntranetUtils.getTrimmedString(explntCd);
			
			//Query params
			params.put(DBConstants.PLNLMEX_EXPLNT_CD, dbExplntCd);
			
			log.info("Params ro delete PlnlmEX LookUp List : " + params);
			
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			if ("0".equals(sqlCode)){
				isPlnlmEXDeleted = true;
				erspmsgMsg = ApplicationConstants.ROWS_DELETED;
				
			} else {
				erspmsgMsg = ApplicationConstants.DELETE_ROW_FAILS + sqlCode;
				
			}
			resultMap.put("erspmsgsMsg", erspmsgMsg);
			resultMap.put("isPlnlmEXDeleted", isPlnlmEXDeleted);
			return resultMap;
			
		} catch (DataAccessException dae) {
			log.error("PlnlmEXDeleteAdapter : Data access excpetion occured " + dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("PlnlmEXDeleteAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} finally {

		}
	}
}
