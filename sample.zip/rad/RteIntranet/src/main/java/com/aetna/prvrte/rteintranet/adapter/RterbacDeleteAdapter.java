/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RterbacDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RterbacDeleteAdapter extends StoredProcedure{

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RterbacDeleteAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RterbacDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.IN_RTERBAC_ACCUM_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTERBAC_BNFT_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTERBAC_RSTRCT_IND, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.IN_RTERBAC_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.IN_ERSPMSG_ID, Types.INTEGER));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
	}
	
	@SuppressWarnings("unchecked")
	public Map deleteRterbac(RterbacDTO rterbacDTO) throws ApplicationException {
		
		log.warn("Entered RterbacDeleteAdapter  - deleteRterbac");
		boolean isRterbacDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, Object> params = new java.util.LinkedHashMap<String, Object>();
		Map rterbacMap = new HashMap();
			String effDate = RteIntranetUtils.getTrimmedString(rterbacDTO.getEffDt());
		params.put(DBConstants.IN_RTERBAC_ACCUM_CD, RteIntranetUtils.getTrimmedString(rterbacDTO.getAccuCd()));
		params.put(DBConstants.IN_RTERBAC_BNFT_CD, String.valueOf(rterbacDTO.getBenCd()));
		params.put(DBConstants.IN_RTERBAC_RSTRCT_IND, RteIntranetUtils.getTrimmedString(rterbacDTO.getResInd()));
		params.put(DBConstants.IN_RTERBAC_EFF_DT,effDate!=""?Date.valueOf(effDate):"");
		params.put(DBConstants.IN_ERSPMSG_ID, RteIntranetUtils.getTrimmedString(rterbacDTO.getMessageId()));
		
		
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("RterbacDeleteAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) 
				isRterbacDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			rterbacMap.put("rterbacMessage", newMessage);
			rterbacMap.put("isRterbacDeleted", isRterbacDeleted);
			return rterbacMap;
		}catch (Exception exception){
			
			log.error("RterbacDeleteAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
}

