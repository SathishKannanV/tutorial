/**
 * 
 */
package com.aetna.prvrte.rteintranet.vo;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RtestypVO {

	private String svcTypeCd = "";
	private String catCd = "";
	private String description = "";
	private String pcpEligInd = "";
	private String effDate = "";
	private String expDate = "";
	private String postedDate = "";
	private String benTypeCd = "";
	private String srcInd = "";
	private String ashInd = "";
	private String genderCd = "";
	private String plnsvctCd = "";
	private char   updatedInd;
	/**
	 * @param svcTypeCd
	 * @param catCd
	 * @param description
	 * @param pcpEligInd
	 * @param effDate
	 * @param expDate
	 * @param postedDate
	 * @param benTypeCd
	 * @param srcInd
	 * @param ashInd
	 * @param genderCd
	 * @param plnsvctCd
	 * @param updatedInd
	 */
	public RtestypVO(String svcTypeCd, String catCd, String description,
			String pcpEligInd, String effDate, String expDate,
			String postedDate, String benTypeCd, String srcInd, String ashInd,
			String genderCd, String plnsvctCd, char updatedInd) {
		super();
		this.svcTypeCd = svcTypeCd;
		this.catCd = catCd;
		this.description = description;
		this.pcpEligInd = pcpEligInd;
		this.effDate = effDate;
		this.expDate = expDate;
		this.postedDate = postedDate;
		this.benTypeCd = benTypeCd;
		this.srcInd = srcInd;
		this.ashInd = ashInd;
		this.genderCd = genderCd;
		this.plnsvctCd = plnsvctCd;
		this.updatedInd = updatedInd;
	}
	
	public RtestypVO() {
		super();
	}

	/**
	 * @return the svcTypeCd
	 */
	public String getSvcTypeCd() {
		return svcTypeCd;
	}

	/**
	 * @param svcTypeCd the svcTypeCd to set
	 */
	public void setSvcTypeCd(String svcTypeCd) {
		this.svcTypeCd = svcTypeCd;
	}

	/**
	 * @return the catCd
	 */
	public String getCatCd() {
		return catCd;
	}

	/**
	 * @param catCd the catCd to set
	 */
	public void setCatCd(String catCd) {
		this.catCd = catCd;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the pcpEligInd
	 */
	public String getPcpEligInd() {
		return pcpEligInd;
	}

	/**
	 * @param pcpEligInd the pcpEligInd to set
	 */
	public void setPcpEligInd(String pcpEligInd) {
		this.pcpEligInd = pcpEligInd;
	}

	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}

	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	/**
	 * @return the expDate
	 */
	public String getExpDate() {
		return expDate;
	}

	/**
	 * @param expDate the expDate to set
	 */
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	/**
	 * @return the postedDate
	 */
	public String getPostedDate() {
		return postedDate;
	}

	/**
	 * @param postedDate the postedDate to set
	 */
	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}

	/**
	 * @return the benTypeCd
	 */
	public String getBenTypeCd() {
		return benTypeCd;
	}

	/**
	 * @param benTypeCd the benTypeCd to set
	 */
	public void setBenTypeCd(String benTypeCd) {
		this.benTypeCd = benTypeCd;
	}

	/**
	 * @return the srcInd
	 */
	public String getSrcInd() {
		return srcInd;
	}

	/**
	 * @param srcInd the srcInd to set
	 */
	public void setSrcInd(String srcInd) {
		this.srcInd = srcInd;
	}

	/**
	 * @return the ashInd
	 */
	public String getAshInd() {
		return ashInd;
	}

	/**
	 * @param ashInd the ashInd to set
	 */
	public void setAshInd(String ashInd) {
		this.ashInd = ashInd;
	}

	/**
	 * @return the genderCd
	 */
	public String getGenderCd() {
		return genderCd;
	}

	/**
	 * @param genderCd the genderCd to set
	 */
	public void setGenderCd(String genderCd) {
		this.genderCd = genderCd;
	}

	/**
	 * @return the plnsvctCd
	 */
	public String getPlnsvctCd() {
		return plnsvctCd;
	}

	/**
	 * @param plnsvctCd the plnsvctCd to set
	 */
	public void setPlnsvctCd(String plnsvctCd) {
		this.plnsvctCd = plnsvctCd;
	}

	/**
	 * @return the updatedInd
	 */
	public char getUpdatedInd() {
		return updatedInd;
	}

	/**
	 * @param updatedInd the updatedInd to set
	 */
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}
	
	
	
}
