/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.SbmletkVO;


/**
 * @author N731694
 * Cognizant_Offshore
 */
public class SbmletkEventTrackAdapter extends StoredProcedure{

	private final Log log = LogFactory.getLog(SbmletkEventTrackAdapter.class);
	private static final String CNVRSTN_CD = "CNVRSTN_CD";
	private static final String VAN_ID_CD = "VAN_ID_CD";
	private static final String IN_TY_CD = "IN_TY_CD";
	private static final String POSTED_DT = "POSTED_DT";
	private static final String SECONDS = "SECONDS";
	private static final String OUT_CODE = "OUT_CODE";
	private static final String READ_CURSOR = "READ_CURSOR3";
	
	
	public SbmletkEventTrackAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(CNVRSTN_CD, Types.CHAR));   
		declareParameter(new SqlParameter(VAN_ID_CD, Types.CHAR));
		declareParameter(new SqlParameter(IN_TY_CD, Types.CHAR));
		declareParameter(new SqlParameter(POSTED_DT, Types.DATE));
		declareParameter(new SqlParameter(SECONDS, Types.INTEGER));
		declareParameter(new SqlOutParameter(OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException 
					{
						SbmletkVO sbmletkVO=new SbmletkVO();
						sbmletkVO.setLoadName(rs.getString("SBMLETK_LOAD_NM"));
						sbmletkVO.setSeconds(rs.getString(2));
						sbmletkVO.setConvIdCode(rs.getString("SUBMSN_CNVRSTN_CD"));
						sbmletkVO.setVanIdCd(rs.getString("SUBMSN_VAN_ID_CD"));
						sbmletkVO.setTranType(rs.getString("SUBMSN_TY_CD"));
						sbmletkVO.setStartTimeStamp(rs.getString("SBMLETK_ST_TMS"));
						sbmletkVO.setEndTimeStamp(rs.getString("SBMLETK_END_TMS"));
						
						return sbmletkVO;
			}

		}));

	}
	
	
	
	@SuppressWarnings("unchecked")
	public Map getEventTrackSbmletkLookUpTable (String convIdCode, String vanIdCd,String tranType,String postedDt,String seconds) throws ApplicationException {
		log.debug("Entered SbmletkrAdapter  - getSbmletkLookUpTable");
		
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map sbmletkMap = new HashMap();
		if (postedDt.equals("")){
			postedDt = "0001-01-01";
		}
		if (seconds.equals("")){
			seconds = "0";
		}
		
		params.put(CNVRSTN_CD, RteIntranetUtils.getTrimmedString(convIdCode));
		params.put(VAN_ID_CD, RteIntranetUtils.getTrimmedString(vanIdCd));
		params.put(IN_TY_CD, RteIntranetUtils.getTrimmedString(tranType));
		params.put(POSTED_DT, RteIntranetUtils.getTrimmedString(postedDt));
		params.put(SECONDS, RteIntranetUtils.getTrimmedString(seconds));
		
		log.debug(params);
		Map results = null;
		
		List<SbmletkVO> sbmletkList= new LinkedList<SbmletkVO>();
		String newMessage="";
		int noOfElements;
		try {
			results = execute(params);
			log.debug("SbmletkAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(OUT_CODE));
			sbmletkList = (List<SbmletkVO>) results
					.get(READ_CURSOR);	
	
			noOfElements = sbmletkList.size();
			//if (null != results) {
			if (sbmletkList.isEmpty()){
				
				if ("0".equals(sqlCode))
					newMessage = "No Data for Conversation ID: " + convIdCode + 
								" Van Id: " +  vanIdCd + 
								" Tran Type: " + tranType + 
								" or Posted Date: " + postedDt +
								" greater than " + seconds;
					
				else
					newMessage = "Problem in DB2. sqlcode: " + sqlCode + "  Conversation ID: " + convIdCode + 
								" Van Id: " +  vanIdCd + 
								" Tran Type: " + tranType + 
								"  Posted Date: " + postedDt +
								" Seconds " + seconds; 
			} else {
				if (noOfElements > 1) {
			    	newMessage = "Data found for Conversation ID: " + convIdCode +
							" Van Id: " +  vanIdCd + 
							" Tran Type: " + tranType+" and Posted Date: " + postedDt +
							" Seconds "+seconds ; 
							
				} else {
			    newMessage = noOfElements + "Data found for Conversation ID: " + convIdCode +
						" Van Id: " +  vanIdCd + 
						" Tran Type: " + tranType 
						;
				}
				//newMessage = getMessage(newMessage, bicId, prov);
			}
			/*}else{
				newMessage = "You must enter a Procex Code with or without combination of Rider Code and/or Service Type Code on the Look Up page.";
			}*/
			sbmletkMap.put("newMessage", newMessage);
			sbmletkMap.put("sbmletkList",sbmletkList);
			return sbmletkMap;
		}catch (Exception exception){
			log.error("SbmletkAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}

}
