/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.BplvsAdapter;
import com.aetna.prvrte.rteintranet.adapter.BplvsBPL2Adapter;
import com.aetna.prvrte.rteintranet.adapter.BplvsBPL3Adapter;
import com.aetna.prvrte.rteintranet.dto.BplvsDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.vo.BplvsVO;

/**
 * @author N731694
 * Cognizant_Offshore
 */
@Repository
public class BplvsDAOImpl implements BplvsDAO {
	
	@Autowired(required=true)
	private BplvsAdapter bplvsAdapter;
	
	@Autowired(required=true)
	private BplvsBPL2Adapter bplvsbpl2Adapter;
	
	@Autowired(required=true)
	private BplvsBPL3Adapter bplvsbpl3Adapter;
	
	
	@Override
	public Map getBplvsLookUpTable(String bicId, String prov,String lineVal,String svcType)
			throws ApplicationException {
		
		return bplvsAdapter.getBplvsLookUpTable(bicId, prov,lineVal,svcType);
	}

	
	@Override
	public Map deleteBplvs(BplvsDTO bplvsDTO) throws ApplicationException {
		return bplvsbpl3Adapter.deleteBplvs(bplvsDTO);
	}
	@Override
	public Map addNewBplvs(BplvsDTO bplvsDTO) throws ApplicationException {
		return bplvsbpl2Adapter.addNewBplvs(bplvsDTO);
	}

	@Override
	public Map addUpdateBplvs(BplvsDTO existBplvsDTO,
			List<BplvsDTO> bplvsDtoList, int index, char updateInd) throws ApplicationException {
		return bplvsbpl2Adapter.addUpdateBplvs(existBplvsDTO, bplvsDtoList, index, updateInd);
	}

}
