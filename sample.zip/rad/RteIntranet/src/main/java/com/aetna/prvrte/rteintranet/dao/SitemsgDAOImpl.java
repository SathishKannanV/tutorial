/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.ProcexAdapter;
import com.aetna.prvrte.rteintranet.adapter.ProcexPRX2Adapter;
import com.aetna.prvrte.rteintranet.adapter.ProcexPRX3Adapter;
import com.aetna.prvrte.rteintranet.adapter.SitemsgAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.SitemsgDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.SitemsgDisplayAdapter;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.SitemsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N242712
 * Cognizant_Offshore
 */
@Repository
public class SitemsgDAOImpl implements SitemsgDAO {
	
	@Autowired(required=true)
	private SitemsgDisplayAdapter sitemsgDisplayAdapter;
	
	@Autowired(required=true)
	private SitemsgAddAdapter sitemsgAddAdapter;
	
	@Autowired(required=true)
	private SitemsgDeleteAdapter sitemsgDeleteAdapter;
	
	@Override
	public Map getSitemsgLookUpTable(String siteCd, String svcTypeCode)
			throws ApplicationException {
		
		return sitemsgDisplayAdapter.getSitemsgLookUpTable(siteCd, svcTypeCode);
	}

	@Override
	public Map addNewSitemsg(SitemsgDTO sitemsgDTO) throws ApplicationException {
		return sitemsgAddAdapter.addNewSitemsg(sitemsgDTO);
	}

	@Override
	public Map deleteSitemsg(SitemsgDTO sitemsgDTO) throws ApplicationException {
		return sitemsgDeleteAdapter.deleteSitemsg(sitemsgDTO);
	}

	@Override
	public Map addUpdateSitemsg(SitemsgDTO editedSitemsgDTO,
			List<SitemsgDTO> sitemsgDtoList, int index,char updateInd) throws ApplicationException{
		return sitemsgAddAdapter.addUpdateSitemsg(editedSitemsgDTO,sitemsgDtoList,index, updateInd);
	}
}
