/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.RterbacDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;



public interface RterbacService {
	Map getRterbacLookUp(RterbacDTO rterbacDTO) throws ApplicationException;;

	Map addNewRterbac(RterbacDTO rterbacDTO)throws ApplicationException ;

	Map deleteRterbac(RterbacDTO rterbacDTO) throws ApplicationException ;

	Map addUpdateRterbac(RterbacDTO existRterbacDTO, List<RterbacDTO> rterbacDtoList, int index) throws ApplicationException ;
	
}


