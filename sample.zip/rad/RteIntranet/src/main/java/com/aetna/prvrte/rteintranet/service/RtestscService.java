/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.RtestscDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

public interface RtestscService {

	Map getRtestscLookUp(RtestscDTO rtestscDTO) throws ApplicationException;;

	Map addNewRtestsc(RtestscDTO rtestscDTO)throws ApplicationException ;

	Map deleteRtestsc(RtestscDTO rtestscDTO) throws ApplicationException ;

	Map addUpdateRtestsc(RtestscDTO existRtestscDTO, List<RtestscDTO> rtestscDtoList, int index, char updateInd) throws ApplicationException ;
}
