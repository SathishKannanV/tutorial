/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.BplvrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * 
 * <h1>RteBplvrpDAO</h1> The RteBplvrpDAO is responsible for handling the
 * storage, retrieval, and search data from/to data store.
 * 
 * @author N726899 Cognizant_Offshore
 * 
 */
public interface RteBplvrpDAO {
	/**
	 * Method to get the BPLVRP list from data store.
	 * 
	 * @param DTO
	 * 			DTO object.
	 * @return Map of BPLVRP list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	Map<String, Object> getBplvrpLookUpList(BplvrpDTO DTO) throws ApplicationException;
	/**
	 * Method to add new BPLVRP to data store.
	 * 
	 * @param DTO
	 *            DTO object.
	 * @return Map of added BPLVRP data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	Map<String, Object> addBplvrpToDb(BplvrpDTO DTO) throws ApplicationException;
	/**
	 * Method to delete the BPLVRP data from data store.
	 * 
	 * @param dbBplvrpDTO
	 *          dbBplvrpDTO object.
	 * @return Map of flag to delete the data from BPLVRP list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	Map<String, Object> deleteBplvrp(BplvrpDTO bplvrpDTO)throws ApplicationException;
	
	/**
	 * Method to add/update list of BPLVRP to data store.
	 * 
	 * @param dbBplvrpDTO
	 *           dbBplvrpDTO object.
	 * @param DTOList
	 *            list of DTO object.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from BPLVRP list, success or
	 *         error message and list of BPLVRP.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	Map<String, Object> addUpdateBplvrp(BplvrpDTO dbBplvrpDTO,	List<BplvrpDTO> DTOList, int index)throws ApplicationException;
}
