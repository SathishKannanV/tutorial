/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RtedictrDTO;
import com.aetna.prvrte.rteintranet.dto.RtedictrDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N657186
 * Cognizant_Offshore
 */
public class RtedictrDeleteAdapter extends StoredProcedure{

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RtedictrDeleteAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtedictrDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.RTESTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.RTEDICTR_DITEM_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.RTEDICTR_DICT_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.RTEDICTR_EFF_DATE, Types.DATE));
		declareParameter(new SqlParameter(DBConstants.ERSPMSG_ID, Types.INTEGER));
		
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));
		
	}
	
	@SuppressWarnings("unchecked")
	public Map deleteRtedictr(RtedictrDTO rtedictrDTO) throws ApplicationException {
		
		log.warn("Entered RtedictrDeleteAdapter  - deleteRtedictr");
		boolean isRtedictrDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new LinkedHashMap<String, String>();
		Map rtedictrMap = new HashMap();
			
		params.put(DBConstants.RTESTYP_CD, RteIntranetUtils.getTrimmedString(rtedictrDTO.getRtestypCd()));
		params.put(DBConstants.RTEDICTR_DITEM_CD, RteIntranetUtils.getTrimmedString(rtedictrDTO.getDitemCd()));
		params.put(DBConstants.RTEDICTR_DICT_CD, RteIntranetUtils.getTrimmedString(rtedictrDTO.getDictCd()));
		params.put(DBConstants.RTEDICTR_EFF_DATE, RteIntranetUtils.getTrimmedString(rtedictrDTO.getEffDt()));
		params.put(DBConstants.ERSPMSG_ID, String.valueOf(rtedictrDTO.getMessageId()));
		
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("RtedictrDeleteAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.LS_SQLCODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) 
				isRtedictrDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			rtedictrMap.put("rtedictrMessage", newMessage);
			rtedictrMap.put("isRtedictrDeleted", isRtedictrDeleted);
			return rtedictrMap;
		}catch (Exception exception){
			
			log.error("RtedictrDeleteAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
}

