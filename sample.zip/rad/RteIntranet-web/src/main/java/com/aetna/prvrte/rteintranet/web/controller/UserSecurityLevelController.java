/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.UserVO;

/**
 * @author N657186
 * Cognizant_Offshore
 */
@Controller
public class UserSecurityLevelController {
	
	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(UserSecurityLevelController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;

	@RequestMapping(value="/home", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getSecurityLevel(final HttpServletRequest request, final HttpSession session,Model model){
		try{
			log.error("getSecurityLevel Login Start");
			String userMsg = "";
			log.warn("UserSecurityLevelController getSecurityLevel() : IsSessionNull " + (session == null));
			UserVO currentUser = (UserVO) session.getAttribute("user");
			log.warn("UserSecurityLevelController getSecurityLevel() : IsCurrentUserNull " + (currentUser == null));
			if(currentUser != null) {
				String firstName = RteIntranetUtils.getTrimmedString(currentUser.getFirstName());
				String lastName = RteIntranetUtils.getTrimmedString(currentUser.getLastName());
				if(!"".equals(firstName) || !"".equals(lastName)){
					userMsg = ApplicationConstants.WELCOME + firstName+ " "+lastName;
				}
			} 
			mav = new ModelAndView(".rteHome", "userVO", currentUser);
			log.warn("user message: "+ userMsg);
			mav.addObject("userMessage", userMsg);
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
			log.error("getSecurityLevel Login End");
			return mav;
			
		}catch (Exception e){
			log.error("Exception occured in UserSecurityLevelController - getSecurityLevel() method:"+e.getMessage());
			
			String errorMsg ="Error encountered getting security level from the database (UserSecurityLevel). "+
			RteIntranetUtils.getTrimmedString(e.getMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);
			return errormav;
		}
		
		}
	
	
	
	
	

}
