package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.TOSDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.TOSVO;


/**
 * @author N624926
 * Cognizant_Offshore
 */
public class TOSDisplayAdapter extends StoredProcedure{

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(TOSDisplayAdapter.class);

	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public TOSDisplayAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.WS_TOS_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR3, new RowMapper(){
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;				//Used by TosTextDisplay, not on database
				TOSDTO tosDTO = new TOSDTO();
				tosDTO.setDbTosCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOS_CD)));
				tosDTO.setDbEffDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOS_EFF_DT)));
				tosDTO.setDbExpDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOS_EXP_DT)));
				tosDTO.setDbStatusCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOS_STATUS_CD)));
				tosDTO.setDbApprovalCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.APPRVL_CD)));
				tosDTO.setDbDisplayName(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOS_DSPLY_NM)));
				tosDTO.setDbShortName(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOS_SHRT_NM)));
				tosDTO.setDbTosName(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOS_NM)));
				tosDTO.setDbPostedDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOS_POSTED_DTS)));
				tosDTO.setDbLastUpdtDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOS_LSTUPD_DTS)));
				tosDTO.setDbUserId(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.APPL_USER_ID)));
				tosDTO.setDbTosComments(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOS_CMMNTS_TXT)));
				tosDTO.setDbUpdateReason(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.TOS_UPDRSN_TXT)));
				tosDTO.setDbUpdatedInd(updatedInd);
				return tosDTO;
			}

		}));

	}
	
	/**
	 * Method to get the TOS list from data store.
	 * 
	 * @param tosDTO
	 * 			tosDTO parameter
	 * 
	 * @return Map of TOS list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map getTOSLookUpTable (TOSDTO tosDTO) throws ApplicationException {
		log.warn("Entered TOSDisplayAdapter  - getTOSLookUpTable");
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map tosMap = new HashMap();
		String tosCd = RteIntranetUtils.getTrimmedString(tosDTO.getDbTosCd());
		String queryTosCd;
		if (tosCd.equals("")){
			tosCd = "%";
			queryTosCd = "All";
		} else {
			queryTosCd = tosCd;
		}
		params.put(DBConstants.WS_TOS_CD, tosCd);
		log.warn(params);
		Map results = null;
		
		List<TOSDTO> tosList = new LinkedList<TOSDTO>();
		String newMessage="";
		try {
			log.warn("TOSDisplayAdapter: Executing stored procedure : " + "siteCd : " + tosCd);
			results = execute(params);
			log.warn("TOSAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results.get(DBConstants.OUT_CODE));
			tosList = (List<TOSDTO>) results.get(DBConstants.READ_CURSOR3);	
			if (tosList.isEmpty()){
				
				if (ApplicationConstants.ZERO_0.equals(sqlCode)) {
					newMessage ="No Data on database for TosCd: " + queryTosCd  ; 

				} else {
					newMessage = "Problem in DB2. sqlcode: " + sqlCode + " TosCd: " + queryTosCd ; 
				}			  		  		  
			} else {
				newMessage = "Data found on database for TosCd: " + queryTosCd ;
			}
			tosMap.put("newMessage", newMessage);
			tosMap.put("tosList",tosList);
			return tosMap;
		}catch (Exception exception){
			log.error("TOSDisplayAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
		
}	