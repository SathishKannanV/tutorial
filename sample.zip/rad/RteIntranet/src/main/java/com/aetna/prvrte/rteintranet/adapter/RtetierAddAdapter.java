/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RtetierDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

public class RtetierAddAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(RtetierAddAdapter.class);
	
	private static final String LS_ADD_UPDATE = "LS_ADD_UPDATE";
	private static final String LS_SQLCODE = "LS_SQLCODE";


	private static final String RTETIER_SAVINGS_CD = "RTETIER_SAVINGS_CD";
	private static final String RTETIER_CD = "RTETIER_CD";
	private static final String RTETIER_EFF_DT = "RTETIER_EFF_DT";
	private static final String RTETIER_DESC_TXT = "RTETIER_DESC_TXT";
	private static final String RTETIER_EXP_DT = "RTETIER_EXP_DT";
	private static final String RTETIER_POSTED_DTS = "RTETIER_POSTED_DTS";
	private static final String APPL_USER_ID = "APPL_USER_ID";
	
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtetierAddAdapter(DataSource datasource, String storedProc) throws SQLException{
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(RTETIER_SAVINGS_CD, Types.CHAR));
		declareParameter(new SqlParameter(RTETIER_CD, Types.CHAR));
		declareParameter(new SqlParameter(RTETIER_EFF_DT, Types.DATE));
		declareParameter(new SqlParameter(RTETIER_DESC_TXT, Types.VARCHAR));
		declareParameter(new SqlParameter(RTETIER_EXP_DT, Types.DATE));
		declareParameter(new SqlParameter(RTETIER_POSTED_DTS, Types.TIMESTAMP));
		declareParameter(new SqlParameter(APPL_USER_ID, Types.CHAR));
		
		declareParameter(new SqlOutParameter(LS_ADD_UPDATE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(LS_SQLCODE, Types.INTEGER));
		
	}
	
	
	/**
	 * 
	 * @param rtetierDTO	
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	public Map addNewRtetier(RtetierDTO rtetierDTO) throws ApplicationException {
		
		log.warn("Entered RtetierAddAdapter  - addNewRtetier");
		
		String newMessage ="";
		Map results = null;
		Map<String, Object> params = new java.util.HashMap<String, Object>();
		Map rtetierMap = new HashMap();
		
		params.put(RTETIER_SAVINGS_CD, RteIntranetUtils.getTrimmedString(rtetierDTO.getRtetierSavingsCd()));
		params.put(RTETIER_CD, RteIntranetUtils.getTrimmedString(rtetierDTO.getRtetierCd()));
		params.put(RTETIER_EFF_DT, RteIntranetUtils.getTrimmedString(rtetierDTO.getEffDate()));
		params.put(RTETIER_DESC_TXT, RteIntranetUtils.getTrimmedString(rtetierDTO.getRtetierDescTxt()));
		params.put(RTETIER_EXP_DT, RteIntranetUtils.getTrimmedString(rtetierDTO.getExpDate()));
		params.put(RTETIER_POSTED_DTS, RteIntranetUtils.getTrimmedString(rtetierDTO.getPostedDateTimestamp()));
		params.put(APPL_USER_ID, RteIntranetUtils.getTrimmedString(rtetierDTO.getUserId()));
		
		log.warn(params);	
		
		try {
					
			results = execute(params);
			log.warn("RtetierAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(LS_SQLCODE));
			
			if ("0".equalsIgnoreCase(sqlCode)) {
				
				List<RtetierDTO> rtetierList = new LinkedList<RtetierDTO>();
				rtetierList.add(rtetierDTO);
				rtetierMap.put("rtetierList", rtetierList);
				if (ApplicationConstants.EMPTY.equalsIgnoreCase(actionCode)) {
					newMessage = "This row added to the database";
				}else {
					newMessage ="Row already exists on the database. It was updated with these values.";					
					rtetierDTO.setUpdatedInd(ApplicationConstants.COPY);
				}				
				}
			else {
				newMessage = "Unable to add row to the database. SQLCODE = " + sqlCode;
			}
			
			rtetierMap.put("rtetierMessage", newMessage);
							
		return rtetierMap;
	}catch (Exception exception){
		log.error("RtetierAddAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}
	
	
	@SuppressWarnings("unchecked")
	public Map addUpdateRtetier(RtetierDTO existingRtetier,
			List<RtetierDTO> rtetierDtoList, int index, char currUpdateInd) throws ApplicationException{
		log.warn("Entered RtetierAddAdapter  - addUpdateRtetier");
		boolean isRtetierAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, Object> params = new java.util.HashMap<String, Object>();
		Map rtetierMap = new HashMap();
		
		params.put(RTETIER_SAVINGS_CD, RteIntranetUtils.getTrimmedString(existingRtetier.getRtetierSavingsCd()));
		params.put(RTETIER_CD, RteIntranetUtils.getTrimmedString(existingRtetier.getRtetierCd()));
		params.put(RTETIER_EFF_DT, RteIntranetUtils.getTrimmedString(existingRtetier.getEffDate()));
		params.put(RTETIER_DESC_TXT, RteIntranetUtils.getTrimmedString(existingRtetier.getRtetierDescTxt()));
		params.put(RTETIER_EXP_DT, RteIntranetUtils.getTrimmedString(existingRtetier.getExpDate()));
		params.put(RTETIER_POSTED_DTS, RteIntranetUtils.getTrimmedString(existingRtetier.getPostedDateTimestamp()));
		params.put(APPL_USER_ID, RteIntranetUtils.getTrimmedString(existingRtetier.getUserId()));		
		log.warn(params);	
		
		try {
					
			results = execute(params);
			log.warn("RtetierAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(LS_ADD_UPDATE));
			String sqlCode =  String.valueOf(results
					.get(LS_SQLCODE));
			if ("0".equalsIgnoreCase(sqlCode)) {
				isRtetierAddorUpdated = true;
				if (ApplicationConstants.ADD.equalsIgnoreCase(actionCode)) {
					
					if (currUpdateInd == ApplicationConstants.COPY)						
						rtetierDtoList.set(index, existingRtetier);						
					else
						rtetierDtoList.add(existingRtetier);
				}
				else
					rtetierDtoList.set(index, existingRtetier);
				
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			rtetierMap.put("rtetierMessage",newMessage);
			rtetierMap.put("rtetierDtoList",rtetierDtoList);
			rtetierMap.put("isrtetierAddorUpdated", isRtetierAddorUpdated);
			return rtetierMap;
		}catch (Exception exception){
			log.error("RtetierAddAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}
}
