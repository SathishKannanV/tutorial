package com.aetna.prvrte.rteintranet.web.controller;

import java.sql.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.RbbcDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.RbbcVO;
import com.aetna.prvrte.rteintranet.vo.RbbcVO;

/**
 * @author N657186
 * Cognizant_Offshore
 */

@Controller
@RequestMapping(value = "/rbbc/*")
public class RbbcController {

	public static final String RBBC_HOME = ".rbbcHome";
	public static final String RBBC_LOOKUP = ".rbbcLookUp";
	public static final String RBBC_ADD = ".rbbcAdd";
	public static final String RBBC_HELP= ".rbbcHelp";
	public static final String RBBC_LIST = ".rbbcList";
	private static final String STC_LIST = ".stcList";
	private static final String BIC_LIST = ".bicList";
	

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(RbbcController.class);
	
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	
	private ModelAndView errormav;
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/rbbcHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRbbcLookUpHome(final HttpServletRequest request, Model model) {
		log.warn("Entered RbbcController - getRbbcLookUpHome()");
		String securityLevel ="";
		try{
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(RBBC_HOME, "rbbcVO",  new RbbcVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("RbbcController - securityLevel: "+ securityLevel);
		log.warn("Exit from RbbcController - getRbbcLookUpHome()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RbbcController - getRbbcLookUpHome() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (GatherRBBC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rbbcVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherRbbc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getRbbcLookUp(final HttpServletRequest request, @ModelAttribute("rbbcForm")RbbcVO rbbcVO){
		log.warn("Entered RbbcController - getRbbcLookUp()");
		String securityLevel ="";
		Map rbbcResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<RbbcDTO> rbbcDtoList = new LinkedList<RbbcDTO>();
		List<RbbcVO> rbbcVoList = new LinkedList<RbbcVO>();
		try{
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		RbbcDTO rbbcDTO = RTETranslator.toRbbcDTO(rbbcVO);
		rbbcResultMap = facade.getRbbcLookUp(rbbcDTO);
		
		rbbcDtoList = (List<RbbcDTO>) rbbcResultMap.get("rbbcList");
		rbbcVoList = RTETranslator.toRbbcVOList(rbbcDtoList);
		lookUpListVO.setRbbcVOList(rbbcVoList);
		facade.getApplicationState().setRbbcList(rbbcVoList);
		log.warn("getRbbcLookUp - rbbcMessage: "+ rbbcResultMap.get("rbrcMessage"));
		mav = new ModelAndView(RBBC_LOOKUP, "lookUpListVO", lookUpListVO);
		mav.addObject("rbbcMessage", rbbcResultMap.get("rbbcMessage"));
		mav.addObject("securityLevel", securityLevel);
		log.warn("Exit from RbbcController - getRbbcLookUp()");
		return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in rbbcController - getrbbcLookUp() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherRBBC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/AddNewRbbcRow", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView loadAddNewRbbcRowScreen(Model model, HttpServletRequest request) {
		try {
			String securityLevel = RteIntranetUtils .getUserSecurityLevel(request);
			log.warn("Entered RbbcController - loadAddNewRbbcRowScreen()");
			ModelAndView mav = new ModelAndView(RBBC_ADD, "rbbcVO", new RbbcVO());
			mav.addObject("securityLevel", securityLevel);
			log.warn("Exit from RbbcController - loadAddNewRbbcRowScreen()");
			return mav;
		} catch (Exception e) {
			log.error("Exception occured in RbbcController - loadAddNewRbbcRowScreen() method:"
					+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_VIEW
					+ "(RbbcController)" + e.toString();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);
			return errormav;
		}
	}
	
	/**
	 * @param rbbcVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddRbbc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addNewRbbc(final HttpServletRequest request, @ModelAttribute("addRbbcForm")RbbcVO rbbcVO){
		log.warn("Entered RbbcController - addNewRbbc()");
		String securityLevel ="";
		Map rbbcResultMap = new HashMap();
		List<RbbcDTO> rbbcDtoList = new LinkedList<RbbcDTO>();
		List<RbbcVO> rbbcVoList = new LinkedList<RbbcVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString(); //Initialize Posted Date to today's date
			rbbcVO.setDbPostedDate(postedDate);
			rbbcVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
			RbbcDTO rbbcDTO = RTETranslator.toRbbcDTO(rbbcVO);
			rbbcResultMap = facade.addNewRbbc(rbbcDTO);
			
			if(rbbcResultMap.get("rbbcList")!=null){
				rbbcDtoList = (List<RbbcDTO>) rbbcResultMap.get("rbbcList");
				rbbcVoList = RTETranslator.toRbbcVOList(rbbcDtoList);
			}
			lookUpListVO.setRbbcVOList(rbbcVoList);
			facade.getApplicationState().setRbbcList(rbbcVoList);
			mav = new ModelAndView(RBBC_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("rbbcMessage", rbbcResultMap.get("rbbcMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("addNewRbbc - rbbcMessage: "+ rbbcResultMap.get("rbbcMessage"));
			log.warn("Exit from RbbcController - addNewRbbc()");
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in RbbcController - addNewRbbc() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when adding a row to the database (AddRBBC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	@RequestMapping(value="/rbbcHelp")
	public String loadRbbcHelp() {   
		return RBBC_HELP;
	}
	
	@RequestMapping(value="/rbbcList")
	public String loadRbbcList() {	   
		return RBBC_LIST;
	}
	
	@RequestMapping(value="/stcList")
	public String loadStcList() {	   
		return STC_LIST;
	}
	
	@RequestMapping(value="/bicList")
	public String loadBicList() {	   
		return BIC_LIST;
	}
	
	/**
	 * @param rbbcVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteRbbc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView deleteRbbc(final HttpServletRequest request, @ModelAttribute("rbbcDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RbbcController - deleteRbbc()");
		ModelAndView mav ;
		String rbbcMsg = "";
		boolean isRbbcDeleted = true;
		Map rbbcResultMap = new HashMap();
		String securityLevel ="";
		List<RbbcVO> rbbcVoList = new LinkedList<RbbcVO>();
		try{
			rbbcVoList = lookUpListVO.getRbbcVOList();
			int i;
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			if ((rbbcVoList != null) && (takeAction != null)) {
				
				for(RbbcVO rbbcVO : rbbcVoList){
					if(rbbcVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rbbcVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
			
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);

					RbbcVO existingRbbc = (RbbcVO) rbbcVoList.get(i);
					if (existingRbbc.getDbUpdatedInd() != ApplicationConstants.COPY) {
						String bnftIdCd = existingRbbc.getDbBnftIdCd();
						String svcTypeCd = existingRbbc.getDbSvcTypeCd();
						
						rbbcResultMap = facade.deleteRbbc(bnftIdCd, svcTypeCd);
						rbbcMsg = (String) rbbcResultMap.get("rbbcMessage");
						isRbbcDeleted = (Boolean) rbbcResultMap.get("isRbbcDeleted");
						
						if(isRbbcDeleted){
							rbbcVoList.remove(i);
						}else{
							j = 0;
						}
					}else{
						rbbcVoList.remove(i);
					}				
			}
				if(isRbbcDeleted)
					rbbcMsg = "Rows selected were Deleted in the database/list";
				
		}else
			rbbcMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRbbcList(rbbcVoList);
			lookUpListVO.setRbbcVOList(rbbcVoList);
			
			mav = new ModelAndView(RBBC_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rbbcMessage",rbbcMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteRbbc - rbbcMessage: "+ rbbcMsg);
		    log.warn("Exit from RbbcController - deleteRbbc()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RbbcController - deleteRbbc() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRBBC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * @param rbbcVO
	 * @param takeAction
	 * @return
	 */
	@RequestMapping(value="/copyRbbc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView copyRbbc(final HttpServletRequest request, @ModelAttribute("rbbcDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RbbcController - copyRbbc()");
		ModelAndView mav ;
		String rbbcMsg = "";
		String securityLevel ="";
		int i;
		List<RbbcVO> rbbcVoList = new LinkedList<RbbcVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			rbbcVoList = lookUpListVO.getRbbcVOList();
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString(); //Initialize Posted Date to today's date
			if ((rbbcVoList != null) && (takeAction != null)) {
				
				for(RbbcVO rbbcVO : rbbcVoList){
					if(rbbcVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rbbcVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					RbbcVO existingRbbc = (RbbcVO) rbbcVoList.get(i);
					
					RbbcVO copyRbbc = new RbbcVO(existingRbbc.getDbRBBCCd(), existingRbbc.getDbEffDate(), 
							postedDate, existingRbbc.getDbBnftIdCd(),
							existingRbbc.getDbSvcTypeCd(), ApplicationConstants.COPY);
					rbbcVoList.add(copyRbbc);
				}
				rbbcMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				rbbcMsg = "Take action was not selected for any of the displayed rows";
			
			facade.getApplicationState().setRbbcList(rbbcVoList);
			lookUpListVO.setRbbcVOList(rbbcVoList);
			mav = new ModelAndView(RBBC_LOOKUP, "lookUpListVO", lookUpListVO);
			
		    mav.addObject("rbbcMessage",rbbcMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyRbbc - rbbcMessage: "+ rbbcMsg);
		    log.warn("Exit from RbbcController - copyRbbc()");
			return mav;		
			
		}catch (Exception e){
			log.error("Exception occured in RbbcController - copyRbbc() method:"+e.getMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRbbc). ";
			errorMsg.concat(e.toString());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
				
	}
	
	/**
	 * @param request
	 * @param rbbcVO
	 * @param takeAction
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateRbbc", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addUpdateRbbc(final HttpServletRequest request, @ModelAttribute("rbbcDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered RbbcController - addUpdateRbbc()");
		ModelAndView mav ;
		String rbbcMsg = "";
		List<RbbcVO> updatedRbbcList = new LinkedList<RbbcVO>();
		List<RbbcDTO> updatedRbbcDtoList = new LinkedList<RbbcDTO>();
		List<RbbcVO> rbbcVoList = new LinkedList<RbbcVO>();
		List<RbbcVO> modifiedRbbcVoList = new LinkedList<RbbcVO>();
		List<RbbcDTO> rbbcDtoList = new LinkedList<RbbcDTO>();
		RbbcDTO editedRbbcDTO = new RbbcDTO();
		Map rbbcResultMap = new HashMap();
		boolean isRbbcAddOrUpdated = false;
		String securityLevel ="";
		
		try{
			rbbcVoList = facade.getApplicationState().getRbbcList();
			modifiedRbbcVoList = lookUpListVO.getRbbcVOList();
			int i;
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString();
			
			
			if (takeAction != null && takeAction.length != 0) {
				if (rbbcVoList != null && rbbcVoList.size() != 0 
						&& modifiedRbbcVoList.size() != 0 && modifiedRbbcVoList != null){
				for(RbbcVO rbbcVO : rbbcVoList){
					if(rbbcVO.getDbUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						rbbcVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				rbbcDtoList = RTETranslator.toRbbcDTOList(rbbcVoList);
				
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					
					i = Integer.parseInt(takeAction[j]);
					RbbcVO seletedRbbc = (RbbcVO) rbbcVoList.get(i);
					RbbcVO editedRbbc = (RbbcVO) modifiedRbbcVoList.get(i);
					log.warn("addUpdateRbbc - user selected: "+ i);
					RbbcVO editedRbbcVO = new RbbcVO(editedRbbc.getDbRBBCCd(), editedRbbc.getDbEffDate(), postedDate, editedRbbc.getDbBnftIdCd(), editedRbbc.getDbSvcTypeCd(), updatedInd);
					
					if(editedRbbcVO!=null){
					editedRbbcDTO = RTETranslator.toRbbcDTO(editedRbbcVO);
					}
					rbbcResultMap = facade.addUpdateRbbc(editedRbbcDTO, rbbcDtoList, i, seletedRbbc.getDbUpdatedInd());
					updatedRbbcDtoList = (List<RbbcDTO>) rbbcResultMap.get("rbbcDtoList");
					if(updatedRbbcDtoList!=null){
					updatedRbbcList = RTETranslator.toRbbcVOList(updatedRbbcDtoList);
					}
					 isRbbcAddOrUpdated = (Boolean) rbbcResultMap.get("isrbbcAddorUpdated");
					rbbcMsg = (String) rbbcResultMap.get("rbbcMessage") ;
					if(!isRbbcAddOrUpdated){
						j = takeAction.length;
					}
				}
				
				if(isRbbcAddOrUpdated){
					rbbcMsg = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted.";
				String xBICCd, yBICCd, xSTC, ySTC;
				for (int x = updatedRbbcList.size() - 1 ; x > 0;  x--) {
					RbbcVO xRBBC = (RbbcVO) updatedRbbcList.get(x);
					xBICCd= xRBBC.getDbBnftIdCd();
					xSTC = xRBBC.getDbSvcTypeCd();
					if (xRBBC.getDbUpdatedInd() != ApplicationConstants.COPY) {
						for (int y = x - 1; y > -1; y--) {
							RbbcVO yRBBC = (RbbcVO) updatedRbbcList.get(y);
							yBICCd = yRBBC.getDbBnftIdCd();
							ySTC = yRBBC.getDbSvcTypeCd();
							if (xBICCd.equals(yBICCd) && xSTC.equals(ySTC)) {
								updatedRbbcList.remove(y); 
								x--;
							}
						}
					}
				}
				}
				lookUpListVO.setRbbcVOList(updatedRbbcList);
				facade.getApplicationState().setRbbcList(updatedRbbcList);
			} else {
				throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);
			}
		}else{
			rbbcMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setRbbcVOList(rbbcVoList);	
			facade.getApplicationState().setRbbcList(rbbcVoList);
		}
			
			mav = new ModelAndView(RBBC_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("rbbcMessage",rbbcMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateRbbc - rbbcMessage: "+ rbbcMsg);
		    log.warn("Exit from RbbcController - addUpdateRbbc()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in RbbcController - deleteRbbc() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (ProcessRBBC). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}
	
	/**
	 * Method to export Rbbc look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of rbbc object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/rbbcExport", method = RequestMethod.POST)
	public ModelAndView rbbcExport(HttpServletResponse response){
		List<RbbcVO> rbbcList = new LinkedList<RbbcVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String rbbcMsg="";
		try{
			rbbcList = facade.getApplicationState().getRbbcList();
			if(rbbcList != null && rbbcList.size() != 0){
			// Key map to create header
			Map<String,String> keyMap = new LinkedHashMap<String,String>();
			keyMap.put("dbSvcTypeCd", "Svc Type");
			keyMap.put("dbBnftIdCd", "Benefit Id Cd");
			keyMap.put("dbRBBCCd", "RBBC Cd");
			keyMap.put("dbEffDate", "Effective Date");
			keyMap.put("dbPostedDate", "Posted Date");
			
			
			RteIntranetUtils.exportToExcel(response, rbbcList, keyMap);
			rbbcMsg = "LookUp table exported successfully.";
			} else {
				rbbcMsg = "No data found.";
			}
			lookUpTableListVO.setRbbcVOList(rbbcList);
	        mav = new ModelAndView(RBBC_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
		    mav.addObject("rbbcMessage",rbbcMsg);
			return mav;
		}catch (ApplicationException e) {
			log.error("Exception occured in RbbcController - rbbcExport() method:"
					+ e.getErrorMessage());
			String errorMsg = "Error encountered while export to excel. "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errormav;
		}
	}
	
}
