/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.ErspmsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.ErspmsgVO;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class ErspmsgDisplayAdapter extends StoredProcedure {

	public ErspmsgDisplayAdapter() {}

	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(ErspmsgDisplayAdapter.class);
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	@SuppressWarnings("rawtypes")
	public ErspmsgDisplayAdapter(DataSource datasource, String storedProc)
			throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of ErspmsgDisplayAdapter : " + storedProc);
		//Input Params declaration
		declareParameter(new SqlParameter(DBConstants.LS_ERSPMSG_ID, Types.INTEGER));
		declareParameter(new SqlParameter(DBConstants.LS_ERSPMSG_SHORT_TXT, Types.CHAR));
		
		//Output Params declaration
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));

		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR4, new RowMapper() {
			/*
			 * (non-Javadoc)
			 * 
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet , int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1) throws SQLException {
				ErspmsgVO erspmsgVO = new ErspmsgVO();
				erspmsgVO.setMessageId(rs.getInt((DBConstants.ERSPMSG_ID)));
				erspmsgVO.setMessageTypeCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.ERSPMSG_MSGTYP_CD)));
				erspmsgVO.setShortText(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.ERSPMSG_SHORT_TXT)));
				erspmsgVO.setFullText(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.ERSPMSG_LONG_TXT)));
				erspmsgVO.setUserId(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.ERSPMSG_USER_ID)));
				erspmsgVO.setPostedDateTimeStamp(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.ERSPMSG_POSTED_DTS)));
				erspmsgVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
				return erspmsgVO;
			}
		}));
	}
	
	/**
	 * Method to get the Erspmsg list from data store.
	 * 
	 * @param erspmsg
	 *            String of aetna id.
	 * @return Map of Erspmsg list and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getErspmsgLookUpList(ErspmsgDTO erspmsgDTO) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering getErspmsgLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<ErspmsgDTO> erspmsgList = new LinkedList<ErspmsgDTO>();
		String erspmsgMsg = "";
		try {
			
			int messageId = erspmsgDTO.getMessageId();
			String shorttext = erspmsgDTO.getShortText();
			//Query Param
			params.put(DBConstants.LS_ERSPMSG_ID, messageId);
			params.put(DBConstants.LS_ERSPMSG_SHORT_TXT, shorttext);
			
			log.info("Params for getting Erspmsg LookUp List : " + params);
			
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			if ("0".equals(sqlCode)){
				erspmsgList =  (ArrayList<ErspmsgDTO>) results.get(DBConstants.READ_CURSOR4);
				if (erspmsgList.isEmpty()){
					erspmsgMsg = "No Data found on the table.";
				} else {
					erspmsgMsg = "Data found on database for Short Text: " + shorttext + ", Message Id: " + messageId;
				}
			} else {
				erspmsgMsg = "Problem in DB2. Sqlcode: " + sqlCode + " Short Text: " + shorttext + ", Message Id: " + messageId;
			}
			resultMap.put("erspmsgMsg", erspmsgMsg);
			resultMap.put("erspmsgList", erspmsgList);
			return resultMap;
			
		} catch (DataAccessException dae) {
			log.error("ErspmsgDisplayAdapter : Data access excpetion occured " + dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("ErspmsgDisplayAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} 
	}
}
