package com.aetna.prvrte.rteintranet.dto;

public class SrchscDTO {

	private String   srchscId; 
	private String srchscDesc = new String(); 
	private String effDate = new String(); 
	private String expDate = new String();
	private String postedDate = new String();
	private char   updatedInd;
	public SrchscDTO() {
		super();
	}
	public SrchscDTO(String srchscId, String srchscDesc, String effDate, String expDate, String postedDate, char updatedInd) {
		super();
		this.srchscId = srchscId;
		this.srchscDesc = srchscDesc;
		this.effDate = effDate;
		this.expDate = expDate;
		this.postedDate = postedDate;
		this.updatedInd = updatedInd;
	}
	public String getEffDate() {
		return effDate;
	}
	public String getExpDate() {
		return expDate;
	}
	public String getPostedDate() {
		return postedDate;
	}
	public String getSrchscDesc() {
		return srchscDesc;
	}
	public String getSrchscId() {
		return srchscId;
	}
	public char getUpdatedInd() {
		return updatedInd;
	}
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}
	public void setSrchscDesc(String srchscDesc) {
		this.srchscDesc = srchscDesc;
	}
	public void setSrchscId(String srchscId) {
		this.srchscId = srchscId;
	}
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}

}

