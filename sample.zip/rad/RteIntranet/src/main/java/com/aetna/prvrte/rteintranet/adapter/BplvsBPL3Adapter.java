/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.AdasvctDTO;
import com.aetna.prvrte.rteintranet.dto.BplvsDTO;
import com.aetna.prvrte.rteintranet.dto.SrchdtlDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.AdasvctVO;
import com.aetna.prvrte.rteintranet.vo.BplvsVO;

/**
 * @author N726899
 * 
 */
public class BplvsBPL3Adapter extends StoredProcedure {
	/**
	 * 
	 */
	public BplvsBPL3Adapter() {
	}

	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(BplvsBPL3Adapter.class);
	private static final String LS_RQSTDBNFT_CD = "LS_RQSTDBNFT_CD";
	private static final String LS_D_SEQ_NO = "LS_D_SEQ_NO";
	private static final String LS_SRCE_PSTD_DT = "LS_SRCE_PSTD_DT";
	private static final String LS_D_NO_QLFR_CD = "LS_D_NO_QLFR_CD";
	private static final String LS_D_NO = "LS_D_NO";
	private static final String LS_D_DSCRPTN_TXT = "LS_D_DSCRPTN_TXT";
	private static final String LS_D_ELPDLMT_CD = "LS_D_ELPDLMT_CD";
	private static final String LS_D_TYPE_CD = "LS_D_TYPE_CD";
	private static final String LS_BNFT_ID_CD = "LS_BNFT_ID_CD";
	private static final String LS_BPRO_NO = "LS_BPRO_NO";
	private static final String IN_BPLV_NO = "IN_BPLV_NO";
	private static final String LS_AUTHCERT_CD = "LS_AUTHCERT_CD";
	private static final String LS_IONTWK_CD = "LS_IONTWK_CD";
	private static final String LS_SVCTYP_CD = "LS_SVCTYP_CD";
	private static final String LS_D_USER_TXT = "LS_D_USER_TXT";
	private static final String LS_SQL_TYPE = "LS_SQL_TYPE";
	private static final String READ_CURSOR = "READ_CURSOR3";

	/**
	 * 
	 * @param datasource
	 * @param adasvctStoredProc
	 * @throws SQLException
	 */
	@SuppressWarnings("rawtypes")
	public BplvsBPL3Adapter(DataSource datasource, String storedProc)
			throws SQLException {
		super(datasource, storedProc);
		log.info(" ------------------> " +storedProc);
		declareParameter(new SqlParameter(LS_RQSTDBNFT_CD, Types.CHAR));   
		declareParameter(new SqlParameter(LS_D_SEQ_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(LS_SRCE_PSTD_DT, Types.DATE));
		declareParameter(new SqlParameter(LS_D_NO_QLFR_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_D_NO, Types.CHAR));
		declareParameter(new SqlParameter(LS_D_DSCRPTN_TXT, Types.CHAR));
		declareParameter(new SqlParameter(LS_D_ELPDLMT_CD, Types.CHAR));   
		declareParameter(new SqlParameter(LS_D_TYPE_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_BNFT_ID_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_BPRO_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(IN_BPLV_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(LS_AUTHCERT_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_IONTWK_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_SVCTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_D_USER_TXT, Types.CHAR));
		declareParameter(new SqlOutParameter(LS_SQL_TYPE, Types.INTEGER));
		//declareParameter(new SqlOutParameter(OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper()
		{
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;			//Used by ProcexDisplay, not on database
				BplvsVO bplvsVO=new BplvsVO();
				bplvsVO.setReqBenCd(rs.getString("BPLVS_RQSTDBNFT_CD"));
				bplvsVO.setdSeqNo(rs.getString("BPLVSD_SEQ_NO"));
				bplvsVO.setPostedDt(rs.getString("BPLVS_SRCE_PSTD_DT"));
				bplvsVO.setdNoQlfrCd(rs.getString("BPLVSD_NO_QLFR_CD"));
				bplvsVO.setdNo(rs.getString("BPLVSD_NO"));
				bplvsVO.setdDiscTxt(rs.getString("BPLVSD_DSCRPTN_TXT"));
				bplvsVO.setdElpDlmtCd(rs.getString("BPLVSD_ELPDLMT_CD"));
				bplvsVO.setdTypeCd(rs.getString("BPLVSD_TYPE_CD"));
				bplvsVO.setBic(rs.getString("BNFT_ID_CD"));
				bplvsVO.setProv(rs.getString("BPRO_NO"));
				bplvsVO.setLineVal(rs.getString("BPLV_NO"));
				bplvsVO.setAuthCertCd(rs.getString("BPLVS_AUTHCERT_CD"));
				bplvsVO.setIoNtwkCd(rs.getString("BPLVS_IONTWK_CD"));
				bplvsVO.setSvcType(rs.getString("BPLVS_SVCTYP_CD"));
				bplvsVO.setUserTxt(rs.getString("BPLVSD_USER_TXT"));
	            bplvsVO.setUpdatedInd(updatedInd);
				
				return bplvsVO;
			}
		}));
	}

	
	@SuppressWarnings("unchecked")
	public Map deleteBplvs(BplvsDTO bplvsDTO) throws ApplicationException {
		
		log.debug("Entered BplvsDeleteAdapter  - deleteBplvs");
		boolean isBplvsDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map bplvsMap = new HashMap();
		params.put(LS_RQSTDBNFT_CD, RteIntranetUtils.getTrimmedString(bplvsDTO.getReqBenCd()));
	 	params.put(LS_D_SEQ_NO, RteIntranetUtils.getTrimmedString(bplvsDTO.getdSeqNo()));
		params.put(LS_SRCE_PSTD_DT, RteIntranetUtils.getTrimmedString(bplvsDTO.getPostedDt()));
		params.put(LS_D_NO_QLFR_CD, RteIntranetUtils.getTrimmedString(bplvsDTO.getdNoQlfrCd()));
		params.put(LS_D_NO, RteIntranetUtils.getTrimmedString(bplvsDTO.getdNo()));
		params.put(LS_D_DSCRPTN_TXT, RteIntranetUtils.getTrimmedString(bplvsDTO.getdDiscTxt()));
		params.put(LS_D_ELPDLMT_CD, RteIntranetUtils.getTrimmedString(bplvsDTO.getdElpDlmtCd()));
		params.put(LS_D_TYPE_CD, RteIntranetUtils.getTrimmedString(bplvsDTO.getdTypeCd()));
	 	params.put(LS_BNFT_ID_CD, RteIntranetUtils.getTrimmedString(bplvsDTO.getBic()));
	 	params.put(LS_BPRO_NO, RteIntranetUtils.getTrimmedString(bplvsDTO.getProv()));
	 	params.put(IN_BPLV_NO, RteIntranetUtils.getTrimmedString(bplvsDTO.getLineVal()));
	 	params.put(LS_AUTHCERT_CD,  RteIntranetUtils.getTrimmedString(bplvsDTO.getAuthCertCd()));
	 	params.put(LS_IONTWK_CD,  RteIntranetUtils.getTrimmedString(bplvsDTO.getIoNtwkCd()));
		params.put(LS_SVCTYP_CD, RteIntranetUtils.getTrimmedString(bplvsDTO.getSvcType()));
		params.put(LS_D_USER_TXT, RteIntranetUtils.getTrimmedString(bplvsDTO.getUserTxt()));
	
		log.debug(params);	
		try {
			results = execute(params);
			log.debug("Bplvs Delete Adapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(LS_SQL_TYPE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) 
				isBplvsDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			bplvsMap.put("bplvsMsg", newMessage);
			bplvsMap.put("isBplvsDeleted", isBplvsDeleted);
			return bplvsMap;
		}catch (Exception exception){
			
			log.error("BplvsDeleteAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	
}
