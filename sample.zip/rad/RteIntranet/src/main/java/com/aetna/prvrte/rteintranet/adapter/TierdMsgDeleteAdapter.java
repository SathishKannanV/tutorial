package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.TierdMsgDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N624926
 * Cognizant_Offshore
 */
public class TierdMsgDeleteAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(TierdMsgDeleteAdapter.class);


	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public TierdMsgDeleteAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		declareParameter(new SqlParameter(DBConstants.TIERDMSG_TYPE_CD, Types.CHAR));// param1
		declareParameter(new SqlParameter(DBConstants.TIERDMSG_TIERST_CD, Types.CHAR));// param2
		declareParameter(new SqlParameter(DBConstants.TIERDMSG_EFF_DT, Types.DATE));// param3
		declareParameter(new SqlParameter(DBConstants.ERSPMSG_ID, Types.INTEGER));// param4
		declareParameter(new SqlOutParameter(DBConstants.SQLCODE, Types.INTEGER));// param OUT
	}
	
	/**
	 * Method to delete the TierdMsg data from data store.
	 * 
	 * @param tierdmsgDTO
	 * 
	 * @return Map of flag to delete the data from TierdMsg list and success or
	 *         error message.
	 * @exception ApplicationException
	 *             if deletion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map deleteTierdMsg(TierdMsgDTO tierdmsgDTO) throws ApplicationException {
		
		log.warn("Entered TierdMsgDeleteAdapter  - deleteTierdMsg");
		boolean isTierdMsgDeleted = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map tierdmsgMap = new HashMap();
		params.put(DBConstants.TIERDMSG_TYPE_CD, RteIntranetUtils.getTrimmedString(tierdmsgDTO.getTierdMsgtypCd()));
		params.put(DBConstants.TIERDMSG_TIERST_CD, RteIntranetUtils.getTrimmedString(tierdmsgDTO.getTierdTierstCd()));
		params.put(DBConstants.TIERDMSG_EFF_DT, RteIntranetUtils.getTrimmedString(tierdmsgDTO.getEffDt()));
		params.put(DBConstants.ERSPMSG_ID, String.valueOf(tierdmsgDTO.getMessageId()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("TierdMsgAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.SQLCODE));
			
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) 
				isTierdMsgDeleted = true;
			else {
				newMessage = "Deleting of rows failed with a SQLCODE code of " + sqlCode;
			}
			tierdmsgMap.put("tierdmsgMsg", newMessage);
			tierdmsgMap.put("isTierdMsgDeleted", isTierdMsgDeleted);
			return tierdmsgMap;
		}catch (Exception exception){
			
			log.error("TierdMsgAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	
}
