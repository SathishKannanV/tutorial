/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.BplvsDTO;
import com.aetna.prvrte.rteintranet.dto.ProcexDTO;
import com.aetna.prvrte.rteintranet.dto.SrchdtlDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.vo.AdasvctVO;
import com.aetna.prvrte.rteintranet.vo.BplvsVO;

/**
 * @author N657186
 *
 */
public interface BplvsService {

	Map getBplvsLookUpTable(String bicId, String prov,String lineVal,String svcType) throws ApplicationException ;

	Map addNewBplvs(BplvsDTO bplvsDTO)throws ApplicationException ;
	
	public Map deleteBplvs(BplvsDTO bplvsDTO)throws ApplicationException;
	Map addUpdateBplvs(BplvsDTO existBplvsDTO, List<BplvsDTO> bplvsDtoList, int index, char updateInd) throws ApplicationException ;

}
