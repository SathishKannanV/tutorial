package com.aetna.prvrte.rteintranet.service;

import java.util.Map;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;

public interface SbmletkService {

	Map getSbmletkLookUpTable(String convIdCode, String vanIdCd,String tranType,String postedDt,String seconds) throws ApplicationException ;
}
