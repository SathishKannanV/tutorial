/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.BplvsVO;
import com.aetna.prvrte.rteintranet.vo.ProcexVO;


/**
 * @author N731694
 * Cognizant_Offshore
 */
public class BplvsAdapter extends StoredProcedure{

	private final Log log = LogFactory.getLog(ProcexAdapter.class);
	private static final String LS_BNFT_ID_CD = "LS_BNFT_ID_CD";
	private static final String LS_BPRO_NO = "LS_BPRO_NO";
	private static final String IN_BPLV_NO = "IN_BPLV_NO";
	private static final String LS_SVCTYP_CD = "LS_SVCTYP_CD";
	private static final String LS_SQL_TYPE = "LS_SQL_TYPE";
	private static final String OUT_CODE = "OUT_CODE";
	private static final String READ_CURSOR = "READ_CURSOR3";
	
	
	public BplvsAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(LS_BNFT_ID_CD, Types.CHAR));   
		declareParameter(new SqlParameter(LS_BPRO_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(IN_BPLV_NO, Types.SMALLINT));
		declareParameter(new SqlParameter(LS_SVCTYP_CD, Types.CHAR));
		declareParameter(new SqlParameter(LS_SQL_TYPE, Types.DECIMAL));
		declareParameter(new SqlOutParameter(OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;			//Used by ProcexDisplay, not on database
				BplvsVO bplvsVO=new BplvsVO();
				bplvsVO.setReqBenCd(rs.getString("BPLVS_RQSTDBNFT_CD"));
				bplvsVO.setdSeqNo(rs.getString("BPLVSD_SEQ_NO"));
				bplvsVO.setPostedDt(rs.getString("BPLVS_SRCE_PSTD_DT"));
				bplvsVO.setdNoQlfrCd(rs.getString("BPLVSD_NO_QLFR_CD"));
				bplvsVO.setdNo(rs.getString("BPLVSD_NO"));
				bplvsVO.setdDiscTxt(rs.getString("BPLVSD_DSCRPTN_TXT"));
				bplvsVO.setdElpDlmtCd(rs.getString("BPLVSD_ELPDLMT_CD"));
				bplvsVO.setdTypeCd(rs.getString("BPLVSD_TYPE_CD"));
				bplvsVO.setBic(rs.getString("BNFT_ID_CD"));
				bplvsVO.setProv(rs.getString("BPRO_NO"));
				bplvsVO.setLineVal(rs.getString("BPLV_NO"));
				bplvsVO.setAuthCertCd(rs.getString("BPLVS_AUTHCERT_CD"));
				bplvsVO.setIoNtwkCd(rs.getString("BPLVS_IONTWK_CD"));
				bplvsVO.setSvcType(rs.getString("BPLVS_SVCTYP_CD"));
				bplvsVO.setUserTxt(rs.getString("BPLVSD_USER_TXT"));
	            bplvsVO.setUpdatedInd(updatedInd);
				
				return bplvsVO;
			}

		}));

	}
	
	
	
	@SuppressWarnings("unchecked")
	public Map getBplvsLookUpTable (String bicId, String prov,String lineVal,String svcType) throws ApplicationException {
		log.debug("Entered BplvsAdapter  - getBplvsLookUpTable");
		
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map bplvsMap = new HashMap();
		params.put(LS_BNFT_ID_CD, RteIntranetUtils.getTrimmedString(bicId));
		params.put(LS_BPRO_NO, RteIntranetUtils.getTrimmedString(prov));
		params.put(IN_BPLV_NO, RteIntranetUtils.getTrimmedString(lineVal));
		params.put(LS_SVCTYP_CD, RteIntranetUtils.getTrimmedString(svcType));
		String sqlType = "";
		
		
		// query by BIC and Service Type
		if (sqlType.equals(""))
			if (!bicId.equals("")) 
				if (!svcType.equals("")) 
					if (prov.equals ("")) 
						if (lineVal.equals("")){
							sqlType = "1";
							prov = "0";
							lineVal = "0";
						}

//query by BIC, Provision, and Service Type				
		if (sqlType.equals(""))
			if (!bicId.equals(""))
				if (!prov.equals(""))
					if (!svcType.equals(""))
						if (lineVal.equals("")){
							sqlType = "2";
							lineVal = "0";
						}

//query by BIC, Provision, Line Value, and Service Type
		if (sqlType.equals(""))
			if (!bicId.equals(""))
				if (!prov.equals(""))
					if (!lineVal.equals(""))
						if (!svcType.equals("")){
							sqlType = "3";
						}

//query by BIC and Provision
		if (sqlType.equals(""))
			if (!bicId.equals(""))
				if (!prov.equals(""))
					if (lineVal.equals(""))
						if (svcType.equals ("")){
							sqlType = "4";
							lineVal = "0";
							svcType = "0";
						}
		
		
		
		params.put(LS_SQL_TYPE, String.valueOf(sqlType));
		
		log.debug(params);
		Map results = null;
		
		List<BplvsVO> bplvsList= new LinkedList<BplvsVO>();
		String newMessage="";
		int noOfElements;
		try {
			log.debug("Bplvs Adapter: Executing stored procedure : " + "BicID : " + bicId + " ; Provision : "+prov
					+"; Line value : "+ lineVal +"Sql type"+sqlType);
					
		 results = execute(params);
			
			log.debug("BplvsAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(OUT_CODE));
			
			bplvsList = (List<BplvsVO>) results
					.get(READ_CURSOR);	
	
			noOfElements = bplvsList.size();
			//if (null != results) {
			if (bplvsList.isEmpty()){
				
				if ("0".equals(sqlCode))
					newMessage = "No Data on database for Bic: " + bicId + 
					" || Prov: " + prov + " || Line Val: " + lineVal + " || Svc Type Cd: " + svcType;
				else
					newMessage = "Problem in DB2. sqlcode: " + sqlCode + " || Bic: " + bicId+ 
					" || Prov: " + prov + " || Line Val: " + lineVal + " || Svc Type Cd: " + svcType; 
			} else {
				if (noOfElements > 1) {
			    	newMessage = "Data found on database for Bic:  "+bicId + 
							" || Prov: " + prov + " || Line Val: " + lineVal + " || Svc Type Cd: " + svcType + 
							" ||  Rows found: " + noOfElements;
				} else {
			    newMessage ="Data found on database for Bic:  "+bicId + 
						" || Prov: " + prov + " || Line Val: " + lineVal + " || Svc Type Cd: " + svcType + 
						" ||  Rows found: " + noOfElements;
				}
				
			}
			
			bplvsMap.put("newMessage", newMessage);
			bplvsMap.put("bplvsList",bplvsList);
			return bplvsMap;
		}catch (Exception exception){
			log.error("BplvsAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
		
		
		
}
