package com.aetna.prvrte.rteintranet.dto;

import java.io.Serializable;
/**
 * @author N726899
 * Cognizant_Offshore
 */
public class ErspmsgDTO implements Serializable {
	/**
	 * Constant serialized ID used for compatibility. 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Integer of messageId.
	 */
	private int messageId;
	/**
	 * String of messageTypeCd.
	 */
	private String messageTypeCd = "";
	/**
	 * String of shortText.
	 */
	private String shortText = "";
	/**
	 * String of fullText.
	 */
	private String fullText = "";
	/**
	 * String of userId.
	 */
	private String userId = "";
	/**
	 * String of postedDateTimeStamp.
	 */
	private String postedDateTimeStamp = "";
	/**
	 * char of updatedInd.
	 */
	private char updatedInd;
	/**
	 * Default Constructor.
	 */
	public ErspmsgDTO() {
		super();
	}

	/**
	 * Creates a new ErspmsgDTO
	 * 
	 * @param messageId
	 *            the value for {@link messageId}
	 * @param messageTypeCd
	 *            the value for {@link messageTypeCd}
	 * @param shortText
	 *            the value for {@link shortText}
	 * @param fullText
	 *            the value for {@link fullText}
	 * @param userId
	 *            the value for {@link userId}
	 * @param postedDateTimeStamp
	 *            the value for {@link postedDateTimeStamp}
	 * @param updatedInd
	 *            the value for {@link updatedInd}
	 */
	public ErspmsgDTO(int messageId, String messageTypeCd, String shortText,
			String fullText, String userId, String postedDateTimeStamp,
			char updatedInd) {
		super();
		this.messageId = messageId;
		this.messageTypeCd = messageTypeCd;
		this.shortText = shortText;
		this.fullText = fullText;
		this.userId = userId;
		this.postedDateTimeStamp = postedDateTimeStamp;
		this.updatedInd = updatedInd;
	}

	public int getMessageId() {
		return messageId;
	}

	/**
	 * @return the messageTypeCd
	 */
	public String getMessageTypeCd() {
		return messageTypeCd;
	}

	/**
	 * @param messageTypeCd the messageTypeCd to set
	 */
	public void setMessageTypeCd(String messageTypeCd) {
		this.messageTypeCd = messageTypeCd;
	}

	/**
	 * @return the shortText
	 */
	public String getShortText() {
		return shortText;
	}

	/**
	 * @param shortText the shortText to set
	 */
	public void setShortText(String shortText) {
		this.shortText = shortText;
	}

	/**
	 * @return the fullText
	 */
	public String getFullText() {
		return fullText;
	}

	/**
	 * @param fullText the fullText to set
	 */
	public void setFullText(String fullText) {
		this.fullText = fullText;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the postedDateTimeStamp
	 */
	public String getPostedDateTimeStamp() {
		return postedDateTimeStamp;
	}

	/**
	 * @param postedDateTimeStamp the postedDateTimeStamp to set
	 */
	public void setPostedDateTimeStamp(String postedDateTimeStamp) {
		this.postedDateTimeStamp = postedDateTimeStamp;
	}

	/**
	 * @return the updatedInd
	 */
	public char getUpdatedInd() {
		return updatedInd;
	}

	/**
	 * @param updatedInd the updatedInd to set
	 */
	public void setUpdatedInd(char updatedInd) {
		this.updatedInd = updatedInd;
	}

	/**
	 * @param messageId the messageId to set
	 */
	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}
}
