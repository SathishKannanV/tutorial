/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.RtebeplmDAO;
import com.aetna.prvrte.rteintranet.dto.RtebeplmDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N657186
 * Cognizant_Offshore
 */
@Service
public class RtebeplmServiceImpl implements RtebeplmService {

	@Autowired(required=true)
	private RtebeplmDAO rtebeplmDAO;
	
	
	@Override
	public Map getRtebeplmLookUpTable(RtebeplmDTO rtebeplmDTO)
			throws ApplicationException {
		
		return rtebeplmDAO.getRtebeplmLookUpTable(rtebeplmDTO);
	}

	@Override
	public Map deleteRtebeplm(RtebeplmDTO rtebeplmDTO)
			throws ApplicationException {
		
		return rtebeplmDAO.deleteRtebeplm(rtebeplmDTO);
	}


	@Override
	public Map addUpdateRtebeplm(RtebeplmDTO existRtebeplmDTO,
			List<RtebeplmDTO> rtebeplmDtoList, int index,char updateInd) throws ApplicationException {
		return rtebeplmDAO.addUpdateRtebeplm(existRtebeplmDTO,rtebeplmDtoList, index, updateInd);
	}
}
