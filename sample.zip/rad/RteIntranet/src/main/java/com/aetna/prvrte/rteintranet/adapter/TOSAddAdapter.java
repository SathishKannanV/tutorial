package com.aetna.prvrte.rteintranet.adapter;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.dto.TOSDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;



/**
 * @author N624926
 * Cognizant_Offshore
 */
public class TOSAddAdapter extends StoredProcedure{
	/**
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(TOSAddAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public TOSAddAdapter(DataSource datasource, String storedProc) throws SQLException{
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(DBConstants.LS_TOS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_TOS_EFF_DT, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_TOS_EXP_DT, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_TOS_STATUS_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_APPRVL_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_TOS_DSPLY_NM, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_TOS_SHRT_NM, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_TOS_NM, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_TOS_POSTED_DTS, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_TOS_LSTUPD_DTS, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_APPL_USER_ID, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_TOS_COMMNTS_TXT, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.LS_TOS_UPDRSN_TXT, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.OUT_ACTION_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.OUT_SQLCODE, Types.INTEGER));
	}
	
	
	/**
	 * Method to add new TOS to data store.
	 * 
	 * @param tosDTO
	 *            tosDTO object.
	 * @return Map of added TOS data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addNewTOS(TOSDTO tosDTO) throws ApplicationException {
		
		log.warn("Entered TOSAddAdapter  - addNewTOS");
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map tosMap = new HashMap();
		Date todaysDate = new Date(System.currentTimeMillis());
		String postedDate = todaysDate.toString();
		tosDTO.setDbPostedDate(postedDate+"-00.00.00.000000");
		tosDTO.setDbEffDate(postedDate);
		tosDTO.setDbLastUpdtDate(postedDate);
		tosDTO.setDbExpDate( "9999-12-31");
		tosDTO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
		params.put(DBConstants.LS_TOS_CD, RteIntranetUtils.getTrimmedString(tosDTO.getDbTosCd()));
		params.put(DBConstants.LS_TOS_EFF_DT, RteIntranetUtils.getTrimmedString(tosDTO.getDbEffDate()));
		params.put(DBConstants.LS_TOS_EXP_DT, RteIntranetUtils.getTrimmedString(tosDTO.getDbExpDate()));
		params.put(DBConstants.LS_TOS_STATUS_CD, RteIntranetUtils.getTrimmedString(tosDTO.getDbStatusCd()));
		params.put(DBConstants.LS_APPRVL_CD, RteIntranetUtils.getTrimmedString(tosDTO.getDbApprovalCd()));
		params.put(DBConstants.LS_TOS_DSPLY_NM, RteIntranetUtils.getTrimmedString(tosDTO.getDbDisplayName()));
		params.put(DBConstants.LS_TOS_SHRT_NM, RteIntranetUtils.getTrimmedString(tosDTO.getDbShortName()));
		params.put(DBConstants.LS_TOS_NM, RteIntranetUtils.getTrimmedString(tosDTO.getDbTosName()));
		params.put(DBConstants.LS_TOS_POSTED_DTS, RteIntranetUtils.getTrimmedString(tosDTO.getDbPostedDate()));
		params.put(DBConstants.LS_TOS_LSTUPD_DTS, RteIntranetUtils.getTrimmedString(tosDTO.getDbLastUpdtDate()));
		params.put(DBConstants.LS_APPL_USER_ID, RteIntranetUtils.getTrimmedString(tosDTO.getDbUserId()));
		params.put(DBConstants.LS_TOS_COMMNTS_TXT, RteIntranetUtils.getTrimmedString(tosDTO.getDbTosComments()));
		params.put(DBConstants.LS_TOS_UPDRSN_TXT, RteIntranetUtils.getTrimmedString(tosDTO.getDbUpdateReason()));
		log.warn(params);	
		
		try {
			results = execute(params);
			log.warn("TOSAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results .get(DBConstants.OUT_ACTION_CD));
			String sqlCode =  String.valueOf(results .get(DBConstants.OUT_SQLCODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				List<TOSDTO> tosList = new LinkedList<TOSDTO>();
				tosList.add(tosDTO);
				tosMap.put("tosList", tosList);
				if ("A".equalsIgnoreCase(actionCode)) {
					newMessage = "This row added to the database";
				}else {
					newMessage ="Row already exists on the database. It was updated with these values.";					
					tosDTO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_Y); 
				}				
				}
			else {
				newMessage = "Unable to add row to the database. SQLCODE = " + sqlCode;
			}
			tosMap.put("tosMessage", newMessage);
		return tosMap;
	}catch (Exception exception){
		log.error("TOSAdapter : generic error occured  "+exception);
		throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
	}

}

	/**
	 * Method to add/update list of TOS to data store.
	 * 
	 * @param existingTOS
	 *            
	 * @param tosDtoList
	 *            list of TOSDTO object.
	 * @param index
	 *            index to update the data
	 * @param updateInd
	 * 			  update indicator to update the data
	 * @return Map of flag to delete the data from TOS list, success or
	 *         error message and list of TOS.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	@SuppressWarnings("unchecked")
	public Map addUpdateTOS(TOSDTO modifiedTOS,
			List<TOSDTO> tosDtoList, int index, char updatedInd) throws ApplicationException{
		log.warn("Entered TOSAddAdapter  - addUpdateTOS");
		boolean isTOSAddorUpdated = false;
		String newMessage ="";
		Map results = null;
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map tosMap = new HashMap();
		params.put(DBConstants.LS_TOS_CD, RteIntranetUtils.getTrimmedString(modifiedTOS.getDbTosCd()));
		params.put(DBConstants.LS_TOS_EFF_DT, RteIntranetUtils.getTrimmedString(modifiedTOS.getDbEffDate()));
		params.put(DBConstants.LS_TOS_EXP_DT, RteIntranetUtils.getTrimmedString(modifiedTOS.getDbExpDate()));
		params.put(DBConstants.LS_TOS_STATUS_CD, RteIntranetUtils.getTrimmedString(modifiedTOS.getDbStatusCd()));
		params.put(DBConstants.LS_APPRVL_CD, RteIntranetUtils.getTrimmedString(modifiedTOS.getDbApprovalCd()));
		params.put(DBConstants.LS_TOS_DSPLY_NM, RteIntranetUtils.getTrimmedString(modifiedTOS.getDbDisplayName()));
		params.put(DBConstants.LS_TOS_SHRT_NM, RteIntranetUtils.getTrimmedString(modifiedTOS.getDbShortName()));
		params.put(DBConstants.LS_TOS_NM, RteIntranetUtils.getTrimmedString(modifiedTOS.getDbTosName()));
		params.put(DBConstants.LS_TOS_POSTED_DTS, RteIntranetUtils.getTrimmedString(modifiedTOS.getDbPostedDate()));//
		params.put(DBConstants.LS_TOS_LSTUPD_DTS, RteIntranetUtils.getTrimmedString(modifiedTOS.getDbLastUpdtDate()));
		params.put(DBConstants.LS_APPL_USER_ID, RteIntranetUtils.getTrimmedString(modifiedTOS.getDbUserId()));
		params.put(DBConstants.LS_TOS_COMMNTS_TXT, RteIntranetUtils.getTrimmedString(modifiedTOS.getDbTosComments()));
		params.put(DBConstants.LS_TOS_UPDRSN_TXT, RteIntranetUtils.getTrimmedString(modifiedTOS.getDbUpdateReason()));
		log.warn(params);	
		try {
			results = execute(params);
			log.warn("TOSAddAdapter: Executed stored procedure");
			String actionCode =  String.valueOf(results
					.get(DBConstants.OUT_ACTION_CD));
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_SQLCODE));
			if (ApplicationConstants.ZERO_0.equalsIgnoreCase(sqlCode)) {
				isTOSAddorUpdated = true;
				if ("A".equalsIgnoreCase(actionCode)) {
					
					if (updatedInd == ApplicationConstants.COPY)						
						tosDtoList.set(index, modifiedTOS);						
					else
						tosDtoList.add(modifiedTOS);
				}
				else
					tosDtoList.set(index, modifiedTOS);
				
				newMessage = "Rows added were placed at the bottom of the list. All rows that changed the database are highlighted.";
			} else {
				newMessage = "Adding/updating of rows failed with a SQLCODE code of " + sqlCode;
			}
			tosMap.put("tosMsg",newMessage);
			tosMap.put("tosDtoList",tosDtoList);
			tosMap.put("isTOSAddorUpdated", isTOSAddorUpdated);
			return tosMap;
		}catch (Exception exception){
			log.error("TOSAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}

	}

}