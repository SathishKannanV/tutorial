/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.BenafrqDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.BenafrqVO;

/**
 * This Adapter class is to call the stored procedure call to manipulated the
 * data in data store
 * 
 * @author N726899 Cognizant_Offshore
 */
public class BenafrqDisplayAdapter extends StoredProcedure {

	public BenafrqDisplayAdapter() {}

	/*
	 * Instance of Log Factory.
	 */
	private final Log log = LogFactory.getLog(BenafrqDisplayAdapter.class);
	
	
	/*
	 * Constructor to initialize the data source and stored procedure.
	 */
	@SuppressWarnings("rawtypes")
	public BenafrqDisplayAdapter(DataSource datasource, String storedProc)
			throws SQLException {
		super(datasource, storedProc);
		log.info("Loaded Stored procedure of BenafrqAdapter : " + storedProc);
		declareParameter(new SqlParameter(DBConstants.DEFACUM_ACCUM_CD, Types.CHAR));
		declareParameter(new SqlParameter(DBConstants.RTEBEPLM_BNFT_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(DBConstants.LS_SQLCODE, Types.INTEGER));

		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR4, new RowMapper() {
			/*
			 * (non-Javadoc)
			 * 
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet , int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				BenafrqVO benafrqVO = new BenafrqVO();
				benafrqVO.setBenafrqAfreqCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.BENAFRQ_AFREQ_CD)));
				benafrqVO.setBenafrqLmtTxt(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.BENAFRQ_LIMIT_TXT)));
				benafrqVO.setDefacumAccumCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.DEFACUM_ACCUM_CD)));
				benafrqVO.setEffDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.BENAFRQ_EFF_DT)));
				benafrqVO.setExpDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.BENAFRQ_EXP_DT)));
				benafrqVO.setHmobBenefitCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RTEBEPLM_BNFT_CD)));
				benafrqVO.setPostedDateTimestamp(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.BENAFRQ_POSTED_DTS)));
				benafrqVO.setRtebeplmEplcCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RTEBEPLM_EPLC_CD)));
				benafrqVO.setUserId(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.APPL_USER_ID)));
				benafrqVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
				return benafrqVO;
			}
		}));
	}
	
	/**
	 * Method to get the BENAFRQ list from data store.
	 * 
	 * @param benafrqDTO
	 * 			benafrqDTO object.
	 * @return Map of BENAFRQ list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getBenafrqLookUpList(BenafrqDTO benafrqDTO) throws ApplicationException {
		if (log.isDebugEnabled()) {
			log.warn("---- Entering getBenafrqLookUpList ---");
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, Object> params = new LinkedHashMap<String, Object>();
		List<BenafrqVO> benafrqList = new LinkedList<BenafrqVO>();
		String newMessage = "";
		try {
			String defacumAccumCd = RteIntranetUtils.getTrimmedString(benafrqDTO.getDefacumAccumCd());
			String hmobBenefitCd = RteIntranetUtils.getTrimmedString(benafrqDTO.getHmobBenefitCd());
			
			params.put(DBConstants.DEFACUM_ACCUM_CD, defacumAccumCd);
			params.put(DBConstants.RTEBEPLM_BNFT_CD, hmobBenefitCd);
			
			log.info("Params for getting Benafrq LookUp List : " + params);
			Map<String, Object> results = execute(params);
			String sqlCode = String.valueOf(results.get(DBConstants.LS_SQLCODE));
			benafrqList = (ArrayList<BenafrqVO>) results.get(DBConstants.READ_CURSOR4);
			if ("0".equals(sqlCode)) {
				if (benafrqList.isEmpty()) {
					newMessage = "No Data on database for HMO Accum Cd: " + defacumAccumCd + " , HMO Benefit Cd: " + hmobBenefitCd;
				} else {
					newMessage = "Data found on database for HMO Accum Cd: " + defacumAccumCd
												+ ", HMO Benefit Cd: " + hmobBenefitCd;;
					log.warn("-----------------------------> " + "Benafrq LookUp List count : [" + benafrqList.size() + "]");
				}
			} else {
				log.warn("-----------------------------> "	+ "Problem in DB2. Sqlcode: " + sqlCode);
				newMessage = "Problem in DB2. sqlcode: " + sqlCode + " HMO Accum Cd: " + defacumAccumCd
						+ ", HMO Benefit Cd: " + hmobBenefitCd;
			}
			resultMap.put("benafrqMsg", newMessage);
			resultMap.put("benafrqList", benafrqList);
			return resultMap;
		} catch (DataAccessException dae) {
			log.error("BenafrqDisplayAdapter : Data access excpetion occured " + dae);
			throw new ApplicationException(ApplicationConstants.ERR_IR_ACCESS, dae.getMessage(), dae);
		} catch (Exception exception) {
			log.error("BenafrqDisplayAdapter : generic error occured  " + exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC, exception.getMessage(), exception);
		} finally {

		}
	}
}
