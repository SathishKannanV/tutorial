package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.RtetpbrVO;


/**
 * @author N624926
 * Cognizant_Offshore
 */
public class RtetpbrAdapter extends StoredProcedure{
	/*
	 * Log factory initialization
	 */
	private final Log log = LogFactory.getLog(RtetpbrAdapter.class);
	
	/**
	 * 
	 * @param datasource
	 * @param storedProc
	 * @throws SQLException
	 */
	public RtetpbrAdapter(DataSource datasource, String storedProc) {

		super(datasource, storedProc);
		declareParameter(new SqlParameter(DBConstants.IN_RTETPBR_ID, Types.INTEGER));
		declareParameter(new SqlParameter(DBConstants.IN_RTETPBR_EFF_DT, Types.DATE));
		
		declareParameter(new SqlOutParameter(DBConstants.OUT_LS_SQLCODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(DBConstants.READ_CURSOR3, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;
				RtetpbrVO rtepbrVO = new RtetpbrVO();
				rtepbrVO.setIdNo(rs.getString(DBConstants.RTETPBR_ID));
				rtepbrVO.setBenrlCd(rs.getString(DBConstants.RTETPBR_BENRL_CD));
				rtepbrVO.setSvctypCd(rs.getString(DBConstants.RTETPBR_SVC_TYP_CD));
				rtepbrVO.setAcastosCd(rs.getString(DBConstants.RTETPBR_ACASTOS_CD));
				rtepbrVO.setAcasposCd(rs.getString(DBConstants.RTETPBR_ACASPOS_CD));				
				rtepbrVO.setEffDate(rs.getString(DBConstants.RTETPBR_EFF_DT));
				rtepbrVO.setExpDate(rs.getString(DBConstants.RTETPBR_EXPRTN_DT));
				rtepbrVO.setPostedDate(rs.getString(DBConstants.RTETPBR_PSTD_DTS));
				rtepbrVO.setUserId(rs.getString(DBConstants.RTETPBR_USER_ID));
				rtepbrVO.setValueTxt(rs.getString(DBConstants.RTETPBR_VALUE_TXT));
				rtepbrVO.setUpdatedInd(updatedInd);
				return rtepbrVO;
			}

		}));

	}
	
	/**
	 * Method to get the RTETPBR list from data store.
	 * 
	 * @param rtetpbrDTO
	 * 			rtetpbrDTO object.
	 * 
	 * @return Map of RTETPBR list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	@SuppressWarnings("unchecked")
	public Map getRtetpbrLookUpTable (String idNo ,  String effDate) throws ApplicationException {
		idNo = (idNo != null && !idNo.equals(("")) ? idNo : "0");
		log.warn("Entered ProcexAdapter  - getProcexLookUpTable");
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map rtetpbrMap = new HashMap();
		params.put(DBConstants.IN_RTETPBR_ID, RteIntranetUtils.getTrimmedString(idNo));
		params.put(DBConstants.IN_RTETPBR_EFF_DT, RteIntranetUtils.getTrimmedString(DBConstants.IN_RTETPBR_EFF_DT_VALUE));
		
		log.warn(params);
		Map results = null;
		
		List<RtetpbrVO> rtetpbrList = new LinkedList<RtetpbrVO>();
		String newMessage="";
		try {
			log.warn("RtetpbrAdapter: Executing stored procedure ");
			results = execute(params);
			log.warn("RtetpbrAdapter: Executed stored procedure");
			
			String sqlCode =  String.valueOf(results
					.get(DBConstants.OUT_LS_SQLCODE));
			
			rtetpbrList = (ArrayList<RtetpbrVO>) results
					.get(DBConstants.READ_CURSOR3);	
	
			if (rtetpbrList.isEmpty()){

				if (ApplicationConstants.ZERO_0.equals(sqlCode))
					newMessage = "No Data on database for ID NO: " + idNo
				+ ", EFF DATE: " + effDate;
				else newMessage = "Problem in DB2. sqlcode: " + effDate + " ID NO: " + idNo + " EFF DATE: " + effDate;
			
			} else newMessage = "Data found on database for ID NO: " + idNo + ", EFF DATE: " + effDate;
			rtetpbrMap.put("newMessage", newMessage);
			rtetpbrMap.put("rtetpbrList",rtetpbrList);
			return rtetpbrMap;
			
		} 
		catch (Exception exception){
			log.error("RtetpbrAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
		
		
}
}