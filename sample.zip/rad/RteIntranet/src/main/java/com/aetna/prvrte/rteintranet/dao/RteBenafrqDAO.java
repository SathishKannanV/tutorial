/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.BenafrqDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * 
 * <h1>RteBenafrqDAO</h1> The RteBenafrqDAO is responsible for handling the
 * storage, retrieval, and search data from/to data store.
 * 
 * @author N726899 Cognizant_Offshore
 * 
 */
public interface RteBenafrqDAO {
	/**
	 * Method to get the BENAFRQ list from data store.
	 * 
	 * @param benafrqDTO
	 * 			benafrqDTO object.
	 * @return Map of BENAFRQ list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	Map<String, Object> getBenafrqLookUpList(BenafrqDTO benafrqDTO) throws ApplicationException;
	/**
	 * Method to get the BENAFRQ list from data store.
	 * 
	 * @param benafrqDTO
	 * 			benafrqDTO object.
	 * @return Map of BENAFRQ list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	Map<String, Object> addBenafrqToDb(BenafrqDTO benafrqDTO) throws ApplicationException;
	/**
	 * Method to delete the BENAFRQ data from data store.
	 * 
	 * @param defacumAccumCd
	 *            String of default accum data.
	 * @param benafrqAfreqCd
	 *            String of frequency data.
	 * @param hmobBenefitCd
	 *            String of benefit data.
	 * @return Map of flag to delete the data from BENAFRQ list and success or
	 *         error message.
	 * @exception ApplicationException
	 *                if deletion fails.
	 */
	Map<String, Object> deleteBenafrq(String defacumAccumCd, String benafrqAfreqCd,String hmobBenefitCd)throws ApplicationException;
	
	/**
	 * Method to add/update list of BENAFRQ to data store.
	 * 
	 * @param benafrqDTO
	 *            benafrqDTO object.
	 * @param benafrqDTOList
	 *            list of benafrqDTO object.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from BENAFRQ list, success or
	 *         error message and list of BENAFRQ.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	Map<String, Object> addUpdateBenafrq(BenafrqDTO benafrqDTO,List<BenafrqDTO> benafrqDTOList, int index)throws ApplicationException;
}
