/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.RteBenafrqDAO;
import com.aetna.prvrte.rteintranet.dto.BenafrqDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/*
 * @see com.aetna.prvrte.rteintranet.service.RteBenafrqServiceImpl
 * @author N726899
 * Cognizant_Offshore
 * 
 */
@Service
public class RteBenafrqServiceImpl implements RteBenafrqService {
	@Autowired(required=true)
	private RteBenafrqDAO rteBenafrqDAO;

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteBenafrqService#getBenafrqLookUpList(com.aetna.prvrte.rteintranet.dto.BenafrqDTO)
	 */
	@Override
	public Map<String, Object> getBenafrqLookUpList(BenafrqDTO benafrqDTO) throws ApplicationException {
		return rteBenafrqDAO.getBenafrqLookUpList(benafrqDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteBenafrqService#addBenafrq(com.aetna.prvrte.rteintranet.dto.BenafrqDTO)
	 */
	@Override
	public Map<String, Object> addBenafrqToDb(BenafrqDTO benafrqDTO)throws ApplicationException {
		return rteBenafrqDAO.addBenafrqToDb(benafrqDTO);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteBenafrqService#deleteBenafrq(java.util.List, java.lang.String[])
	 */
	@Override
	public Map<String, Object> deleteBenafrq(String defacumAccumCd,String benafrqAfreqCd,String hmobBenefitCd)throws ApplicationException {
		return rteBenafrqDAO.deleteBenafrq(defacumAccumCd, benafrqAfreqCd,hmobBenefitCd);
	}

	/* (non-Javadoc)
	 * @see com.aetna.prvrte.rteintranet.service.RteBenafrqService#addUpdateBenafrq(java.util.List, java.lang.String[])
	 */
	@Override
	public Map<String, Object> addUpdateBenafrq(BenafrqDTO benafrqDTO,List<BenafrqDTO> benafrqDTOList, int index)throws ApplicationException {
		return rteBenafrqDAO.addUpdateBenafrq(benafrqDTO, benafrqDTOList, index);
	}

	
}
