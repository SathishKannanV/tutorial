/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.SrcherrVO;
import com.aetna.prvrte.rteintranet.vo.SrchscVO;


/**
 * @author N731694
 * Cognizant_Offshore
 */
public class SrcherrAdapter extends StoredProcedure{

	private final Log log = LogFactory.getLog(SrcherrAdapter.class);
	
	private static final String LS_SRCHERR_ID = "LS_SRCHERR_ID";
	private static final String OUT_CODE = "OUT_CODE";
	private static final String LS_SQL_TYPE = "LS_SQL_TYPE";
	private static final String READ_CURSOR = "READ_CURSOR3";
	
	
	public SrcherrAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(LS_SRCHERR_ID, Types.CHAR));  
		declareParameter(new SqlOutParameter(LS_SQL_TYPE, Types.INTEGER));
		
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;			
				SrcherrVO srcherrVO=new SrcherrVO();
				srcherrVO.setSrcherrCd(rs.getString("SRCHERR_CD"));
				srcherrVO.setSrcherrCustInd(rs.getString("SRCHERR_CUST_IND"));
				srcherrVO.setSrcherrDesc(rs.getString("SRCHERR_DESC"));
				srcherrVO.setEffDate(rs.getString("SRCHERR_EFF_DT"));
				srcherrVO.setExpDate(rs.getString("SRCHERR_EXP_DT"));
				srcherrVO.setPostedDate(rs.getString("SRCHERR_POSTED_DT"));
				srcherrVO.setUpdatedInd(updatedInd);
				
				return srcherrVO;
			}

		}));

	}
	
	
	
	@SuppressWarnings("unchecked")
	public Map getSrcherrLookUpTable (String srcherrCd) throws ApplicationException {
		log.debug("Entered SrchscAdapter  - getSrchscLookUpTable");
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map srcherrMap = new HashMap();
		//srchscId = (srchscId != null && !srchscId.equals(("")) ? srchscId : "0");
		params.put(LS_SRCHERR_ID,RteIntranetUtils.getTrimmedString(srcherrCd));
		
		log.debug(params);
		Map results = null;
		
		List<SrcherrVO> srcherrList= new LinkedList<SrcherrVO>();
		String newMessage="";
		int noOfElements;
		try {
			log.debug("Srchsc Adapter: Executing stored procedure :srcherrCd"+srcherrCd);
					
		 results = execute(params);
			
			log.debug("SrcherrAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(OUT_CODE));
			
			srcherrList = (List<SrcherrVO>) results
					.get(READ_CURSOR);	
	
			noOfElements = srcherrList.size();
			//if (null != results) {
			if (srcherrList.isEmpty()){
				
				if ("0".equals(sqlCode))
					newMessage = "No Data on database for srchcolCd " ;
			//		" || Second Search Id: " + srchscSecondId + " || Triple A Error Cd: " + srcherrCd + " || Member Search Column Cd " + srchcolCd;
				else
					newMessage = "Problem in DB2. sqlcode: " + sqlCode; 
			} else {
				if (noOfElements > 1) {
			    	newMessage = noOfElements + " Rows found for  srchcolCd " ;
				} else {
			    newMessage = noOfElements + " Row found for srchcolCd";
				}
				//newMessage = getMessage(newMessage, bicId, prov);
			} 
			/*}else{
				newMessage = "You must enter a Procex Code with or without combination of Rider Code and/or Service Type Code on the Look Up page.";
			}*/
			srcherrMap.put("newMessage", newMessage);
			srcherrMap.put("srcherrList",srcherrList);
			return srcherrMap;
		}catch (Exception exception){
			log.error("SrchscAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}
	

}
