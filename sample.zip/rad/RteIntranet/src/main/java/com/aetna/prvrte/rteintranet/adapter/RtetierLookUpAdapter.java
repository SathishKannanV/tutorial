/**
 * @author N657186
 * Cognizant_Offshore
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.dto.RtetierDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.DBConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;

/**
 * @author N657186
 *
 */
public class RtetierLookUpAdapter extends StoredProcedure{
private final Log log = LogFactory.getLog(RtetierLookUpAdapter.class);
	
	private static final String RTETIER_SAVINGS_CD = "RTETIER_SAVINGS_CD";
	private static final String RTETIER_CD = "RTETIER_CD";
	private static final String LS_SQLCODE = "LS_SQLCODE";
	private static final String READ_CURSOR = "READ_CURSOR1";
	
	
	public RtetierLookUpAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(RTETIER_SAVINGS_CD, Types.CHAR));
		declareParameter(new SqlParameter(RTETIER_CD, Types.CHAR));
		declareParameter(new SqlOutParameter(LS_SQLCODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException {
				char updatedInd = ApplicationConstants.UPDATE_IND_N;			//Used by RBBCDisplay, not on database
				RtetierDTO rtetierDTO = new RtetierDTO();
				rtetierDTO.setRtetierSavingsCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RTETIER_SAVINGS_CD)));
				rtetierDTO.setRtetierCd(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RTETIER_CD)));
				rtetierDTO.setEffDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RTETIER_EFF_DT)));
				rtetierDTO.setRtetierDescTxt(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RTETIER_DESC_TXT)));
				rtetierDTO.setExpDate(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RTETIER_EXP_DT)));
				rtetierDTO.setPostedDateTimestamp(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.RTETIER_POSTED_DTS)));
				rtetierDTO.setUserId(RteIntranetUtils.getTrimmedString(rs.getString(DBConstants.APPL_USER_ID)));
				rtetierDTO.setUpdatedInd(updatedInd);
				return rtetierDTO;
			}

		}));

	}
	
	@SuppressWarnings("unchecked")
	public Map getRtetierLookUpTable (RtetierDTO rtetierDTO) throws ApplicationException {
		log.warn("Entered RtetierLookUpAdapter  - getRtetierLookUp");
		//It fetches rtetier list based on the criteria selected by user
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map rtetierMap = new HashMap();
		String querySavingsCd = RteIntranetUtils.getTrimmedString(rtetierDTO.getRtetierSavingsCd());
		String queryCd = RteIntranetUtils.getTrimmedString(rtetierDTO.getRtetierCd());
		params.put(RTETIER_SAVINGS_CD, querySavingsCd);
		params.put(RTETIER_CD, queryCd);
		log.warn(params);
		Map results = null;
		
		List<RtetierDTO> rtetierList = new LinkedList<RtetierDTO>();
		String newMessage="";
		try {
			results = execute(params);
			log.warn("RtetierLookUpAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results.get(LS_SQLCODE));
			
			rtetierList = (List<RtetierDTO>) results.get(READ_CURSOR);	
			
			if (rtetierList.isEmpty()){
				
				if ("0".equals(sqlCode)) {
					newMessage = "No Data on database for Savings Cd: " + querySavingsCd
														+ ", Tier Code: " + queryCd;
				} else {
					newMessage = "Problem in DB2. sqlcode: " + sqlCode +
												" Savings Cd: " + querySavingsCd
												+ ", Tier Cd: " + queryCd; 
				}			  		  		  
			} else {
				newMessage = "Data found on database for Savings Cd: " + querySavingsCd
												+ ", Tier Cd: " + queryCd;
			}
			
			rtetierMap.put("rtetierMessage", newMessage);
			rtetierMap.put("rtetierList",rtetierList);
			return rtetierMap;
		}catch (Exception exception){
			log.error("RtetierLookUpAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
		
	}
}
