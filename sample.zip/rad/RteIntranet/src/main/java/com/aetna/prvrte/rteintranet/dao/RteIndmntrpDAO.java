/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import com.aetna.prvrte.rteintranet.dto.IndmntrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * 
 * <h1>RteIndmntrpService</h1> The RteIndmntrpService is responsible for handling
 * the business logic of INDMNTRP Look up.
 * 
 * @author N726899 Cognizant_Offshore
 * 
 */
public interface RteIndmntrpDAO {
	/**
	 * Method to get the INDMNTRP list from data store.
	 * 
	 * @param indmntrpDTO
	 * 			indmntrpDTO object.
	 * @return Map of INDMNTRP list and success or error message.
	 * 
	 * @exception ApplicationException if data not found in data store.
	 */
	Map<String, Object> getIndmntrpLookUpList(IndmntrpDTO indmntrpDTO) throws ApplicationException;
	/**
	 * Method to add new INDMNTRP to data store.
	 * 
	 * @param indmntrpDTO
	 *            indmntrpDTO object.
	 * @return Map of added INDMNTRP data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	Map<String, Object> addIndmntrpToDb(IndmntrpDTO indmntrpDTO) throws ApplicationException;
	/**
	 * Method to delete the INDMNTRP data from data store.
	 * 
	 * @param indmntrpDTO
	 *            indmntrpDTO object.
	 * @return Map of added INDMNTRP data and success or error message.
	 * 
	 * @exception ApplicationException
	 *                if insertion fails.
	 */
	Map<String, Object> deleteIndmntrp(IndmntrpDTO indmntrpDTO)throws ApplicationException;
	
	/**
	 * Method to add/update list of INDMNTRP to data store.
	 * 
	 * @param indmntrpDTO
	 *            indmntrpDTO object.
	 * @param indmntrpDTOList
	 *            list of indmntrpDTO object.
	 * @param index
	 *            index to update the data
	 * @return Map of flag to delete the data from INDMNTRP list, success or
	 *         error message and list of INDMNTRP.
	 * @exception ApplicationException
	 *                if insertion or update fails.
	 */
	Map<String, Object> addUpdateIndmntrp(IndmntrpDTO indmntrpDTO,	List<IndmntrpDTO> indmntrpDTOList, int index)throws ApplicationException;
}
