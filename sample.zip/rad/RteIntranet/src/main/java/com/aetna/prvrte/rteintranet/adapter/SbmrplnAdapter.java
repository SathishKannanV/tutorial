/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;






import javax.sql.DataSource;






import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;






import com.aetna.fs.enterprise.crypto.AetnaEnterpriseCrypto;
import com.aetna.fs.enterprise.crypto.AetnaEnterpriseCryptoException;
import com.aetna.fs.enterprise.crypto.FormatPreservingEncryption;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.SbmrplnVO;
import com.aetna.prvrte.rteintranet.vo.SbmsnrVO;


/**
 * @author N731694
 * Cognizant_Offshore
 */
public class SbmrplnAdapter extends StoredProcedure{

	private final Log log = LogFactory.getLog(SbmrplnAdapter.class);
	private static final String CNVRSTN_CD = "CNVRSTN_CD";
	private static final String VAN_ID_CD = "VAN_ID_CD";
	private static final String IN_TY_CD = "IN_TY_CD";
	//private static final String IN_PSTD_DT = "IN_PSTD_DT";
	
	private static final String OUT_CODE = "OUT_CODE";
	private static final String READ_CURSOR = "READ_CURSOR3";

	
	// SSN Encryption code using Voltage API framework
	@Autowired
	AetnaEnterpriseCrypto aec;
	
	String format="SSN";

	//AetnaEnterpriseCrypto aec = new AetnaEnterpriseCrypto();
	
	public void setAec(AetnaEnterpriseCrypto aec) {
		this.aec = aec;
	}






	public SbmrplnAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(CNVRSTN_CD, Types.CHAR));   
		declareParameter(new SqlParameter(VAN_ID_CD, Types.CHAR));
		declareParameter(new SqlParameter(IN_TY_CD, Types.CHAR));
		
		
		declareParameter(new SqlOutParameter(OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException 
					{
						SbmrplnVO sbmrplnVO=new SbmrplnVO();
						
						sbmrplnVO.setSeqNo(rs.getString("SBMRPLN_SEQ_NO"));
						sbmrplnVO.setPostedDt(rs.getString("SBMRPLN_PSTD_DT"));
						sbmrplnVO.setControlNo(rs.getString("SBMRPLN_CTL_NO"));
						sbmrplnVO.setSuffixNo(rs.getString("SBMRPLN_SFFX_NO"));
						sbmrplnVO.setAccountNo(rs.getString("SBMRPLN_ACCT_NO"));
						
						
						sbmrplnVO.setProductName(rs.getString("SBMRPLN_PRDT_NM"));
						sbmrplnVO.setCoverageLevelCode(rs.getString("SBMRPLN_CVGLVL_CD"));
						sbmrplnVO.setCoverageToDate(rs.getString("SBMRPLN_COVG_TO_DT"));
						sbmrplnVO.setInsuranceLineCd(rs.getString("SBMRPLN_INS_LN_CD"));
						sbmrplnVO.setPlanNetworkCd(rs.getString("SBMRPLN_PL_NTK_CD"));
						
						
						sbmrplnVO.setSiteCd(rs.getString("SBMRPLN_SITE_CD"));
						sbmrplnVO.setSubGroupCd(rs.getString("SBMRPLN_SUBGRP_CD"));
						sbmrplnVO.setCovgFromDate(rs.getString("SBMRPLN_CVG_FR_DT"));
						sbmrplnVO.setBenefitIdCd(rs.getString("BNFT_ID_CD"));
						sbmrplnVO.setPbnfSeqNo(rs.getString("PBNF_SEQ_NO"));
						
						
						
						sbmrplnVO.setPlanNo(rs.getString("SBMRPLN_PLAN_NO"));
						sbmrplnVO.setPlanSummaryCd(rs.getString("SBMRPLN_PLSMRY_CD"));
						sbmrplnVO.setPlanName(rs.getString("SBMRPLN_PLAN_NM"));
						sbmrplnVO.setPatientBirthdate(rs.getString("SBMRPLN_PTNTBRTH_DT"));
						sbmrplnVO.setPatientLastName(rs.getString("SBMRPLN_PTNT_LST_NM"));
						
						sbmrplnVO.setPatientFirstName(rs.getString("SBMRPLN_PTNT_FST_NM"));
						sbmrplnVO.setPatientMidName(rs.getString("SBMRPLN_PTNTMID_NM"));
						sbmrplnVO.setPatientTitle(rs.getString("SBMRPLN_PTNTTITL_NM"));
						sbmrplnVO.setSubsLastName(rs.getString("SBMRPLN_SUBSLAST_NM"));
						sbmrplnVO.setSubsFirstName(rs.getString("SBMRPLN_SUBS_FST_NM"));
						
						sbmrplnVO.setSubsMidName(rs.getString("SBMRPLN_SUBSMID_NM"));
						sbmrplnVO.setSubsTitle(rs.getString("SBMRPLN_SUBSTITL_NM"));
						sbmrplnVO.setRelationToSubsCode(rs.getString("SBMRPLN_RTPTSBS_CD"));
						sbmrplnVO.setPatientSexCode(rs.getString("SBMRPLN_PTNTSEX_CD"));
						sbmrplnVO.setMemberTermDate(rs.getString("SBMRPLN_MBRTRM_DT"));
						
						sbmrplnVO.setDepTermDate(rs.getString("SBMRPLN_DPNTTRM_DT"));
						sbmrplnVO.setMemberIdCd(rs.getString("SBMRPLN_MBR_ID_CD"));
						
						// SSN encryption - Voltage API
						//sbmrplnVO.setSubscriberIdCd(rs.getString("SBMRPLN_SUBS_ID_CD"));
						
						try {
							sbmrplnVO.setSubscriberIdCd(voltageApiEncryption(rs.getString("SBMRPLN_SUBS_ID_CD")));
						} catch (AetnaEnterpriseCryptoException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						
						sbmrplnVO.setDepIdCd(rs.getString("SBMRPLN_DEP_ID_CD"));
						sbmrplnVO.setCapLabName(rs.getString("SBMRPLN_CAP_LAB_NM"));
						
						sbmrplnVO.setCapXrayName(rs.getString("SBMRPLN_CAPXRAY_NM"));
						sbmrplnVO.setCapLabPhone(rs.getString("SBMRPLN_CAPLBPH_NO"));
						sbmrplnVO.setCapXrayPhone(rs.getString("SBMRPLN_CPXRYPH_NO"));
						sbmrplnVO.setCumbOrigEffDate(rs.getString("CUMB_ORGNLEFF_DT"));
						sbmrplnVO.setNetworkIdNo(rs.getString("SBMSNR_NTWK_ID_NO"));
						
						
						
						sbmrplnVO.setEmployerName(rs.getString("SBMSNR_ER_NM"));
						sbmrplnVO.setGroupCd(rs.getString("SBMRPLN_GRP_CD"));
						sbmrplnVO.setVanIdCd(sbmrplnVO.getVanIdCd());
						return sbmrplnVO;
			}

		}));

	}
	
 public String voltageApiEncryption(String value) throws AetnaEnterpriseCryptoException{
	 
	 FormatPreservingEncryption fpe =aec.getFormatPreservingEncryption(format);
	
		
		String string= value.substring(1);
		
		return fpe.encrypt(string);
		
	
}
	
	
	@SuppressWarnings("unchecked")
	public Map getSbmrplnEvntTracking (String convIdCode, String vanIdCd,String typeCd,String postedDt) throws ApplicationException {
		log.warn("Entered SbmrplnAdapter  - getSbmrplnEvntTracking");
	
		Map<String, String> params = new java.util.LinkedHashMap<String, String>();
		Map sbmrplnMap = new HashMap();
		params.put(CNVRSTN_CD, RteIntranetUtils.getTrimmedString(convIdCode));
		params.put(VAN_ID_CD, RteIntranetUtils.getTrimmedString(vanIdCd));
		params.put(IN_TY_CD, RteIntranetUtils.getTrimmedString(typeCd));
		
		log.warn(params);
		Map results = null;
		
		List<SbmrplnVO> sbmrplnList= new LinkedList<SbmrplnVO>();
		
		String newMessage="";
		int noOfElements;
		try {
			results = execute(params);
			log.warn("SbmrplnAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(OUT_CODE));
			sbmrplnList = (List<SbmrplnVO>) results
					.get(READ_CURSOR);	
		
			noOfElements = sbmrplnList.size();
			//if (null != results) {
			if (sbmrplnList.isEmpty()){
				
				if ("0".equals(sqlCode))
					newMessage = "No Data on SBMRPLN5 for Conversation ID: " + convIdCode + 
								" Van Id: " +  vanIdCd + 
								" Tran Type: " + typeCd ;
					
				else
					newMessage = "Problem in DB2. sqlcode: " + sqlCode + "  Conversation ID: " + convIdCode + 
								" Van Id: " +  vanIdCd + 
								" Tran Type: " + typeCd ; 
			} else {
				if (noOfElements > 1) {
			    	newMessage = "Data found for Conversation ID:"+ convIdCode + 
						" Van Id: " +  vanIdCd + 
						" Tran Type: " + typeCd;
				} else {
					newMessage = "Data found for Conversation ID:"+ convIdCode + 
							" Van Id: " +  vanIdCd + 
							" Tran Type: " + typeCd;
				}
				
			}
			log.warn("sbmrplnList size:"+ sbmrplnList.size());
			sbmrplnMap.put("newMessage", newMessage);
			sbmrplnMap.put("sbmrplnList",sbmrplnList);
			return sbmrplnMap;
		}catch (Exception exception){
			log.error("SbmrplnAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}

}
