/**
 * 
 */
package com.aetna.prvrte.rteintranet.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.prvrte.rteintranet.dao.SbmletkDAO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N731694
 * Cognizant_Offshore
 */
@Service
public class SbmletkServiceImpl implements SbmletkService {
	@Autowired(required=true)
	private SbmletkDAO sbmletkDAO;
	
	
	@Override
	public Map getSbmletkLookUpTable(String convIdCode, String vanIdCd,String tranType,String postedDt,String seconds)
			throws ApplicationException {
		
		return sbmletkDAO.getSbmletkLookUpTable(convIdCode, vanIdCd,tranType,postedDt,seconds);
	}




}
