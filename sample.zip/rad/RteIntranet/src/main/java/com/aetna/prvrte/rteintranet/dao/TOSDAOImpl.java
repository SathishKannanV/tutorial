/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.TOSAddAdapter;
import com.aetna.prvrte.rteintranet.adapter.TOSDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.TOSDisplayAdapter;
import com.aetna.prvrte.rteintranet.dto.TOSDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;

/**
 * @author N624926
 * Cognizant_Offshore
 */
@Repository
public class TOSDAOImpl implements TOSDAO {
	
	@Autowired(required=true)
	private TOSDisplayAdapter tosDisplayAdapter;

	@Autowired(required=true)
	private TOSAddAdapter tosAddAdapter;
	
	@Autowired(required=true)
	private TOSDeleteAdapter tosDeleteAdapter;
	
	
	/**
	 * 
	 * @param tosDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map getTOSLookUpTable(TOSDTO tosDTO)
			throws ApplicationException {
		
		return tosDisplayAdapter.getTOSLookUpTable(tosDTO);
	}

	
	/**
	 * 
	 * @param tosDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addNewTOS(TOSDTO tosDTO) throws ApplicationException {
		return tosAddAdapter.addNewTOS(tosDTO);
	}

	/**
	 * 
	 * @param tosDTO
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map deleteTOS(TOSDTO tosDTO) throws ApplicationException {
		return tosDeleteAdapter.deleteTOS(tosDTO);
	}

	/**
	 * 
	 * @param editedTOSDTO
	 * @param tosDtoList
	 * @param index
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Map addUpdateTOS(TOSDTO editedTOSDTO, List<TOSDTO> tosDtoList, int index, char updatedInd)
			throws ApplicationException {
		return tosAddAdapter.addUpdateTOS( editedTOSDTO, tosDtoList,  index,updatedInd);
	}


}
