/**
 * 
 */
package com.aetna.prvrte.rteintranet.web.controller;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aetna.prvrte.rteintranet.dto.IndmntrpDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.IndmntrpVO;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;

/**
 * <h1>Indmntrp Controller</h1> The Indmntrp Controller is responsible for handling
 * the actual request from DispatcherServlet and returning an appropriate
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * 
 * @author N726899 
 * 
 * Cognizant_Offshore
 */
@Controller
@RequestMapping(value = "/indmntrp/*")
public class IndmntrpController {
	/*
	 * Instance of logger for IndmntrpController.
	 */
	private static final Log log = LogFactory.getLog(IndmntrpController.class);
	/*
	 * Tile name of the indmntrp home view.
	 */
	public static final String INDMNTRP_HOME = ".indmntrpHome";
	/*
	 * Tile name of the indmntrp display view.
	 */
	public static final String INDMNTRP_DISPLAY = ".indmntrpDisplay";
	/*
	 * Tile name of the  add new indmntrp form view.
	 */
	public static final String INDMNTRP_ADD_NEW = ".addIndmntrp";
	
	/*
	 * Instance of Facade.
	 */
	@Autowired(required = true)
	private Facade facade;
	/*
	 * Model and view of success operation.
	 */
	private ModelAndView modelAndView;
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errorModelAndView;

	/**
	 * Method to display indmntrpLookup view.
	 * 
	 * @return view of indmntrpLookUp, if fails return error page
	 */
	@RequestMapping(value = "/indmntrpHome", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getIndmntrpLookUp(HttpServletRequest request) {
		try {
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView = new ModelAndView(INDMNTRP_HOME, "indmntrpVO", new IndmntrpVO());
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in IndmntrpController - getIndmntrpLookUp() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_LOOKUP_VIEW + "(IndmntrpController)" + RteIntranetUtils.getTrimmedString(e.getMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the indmntrpLookUp List from data store.
	 * 
	 * @param indmntrpVO
	 *            form view object of indmntrp.
	 * @return view of indmntrpDisplayForm, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/indmntrpLookUp", method = RequestMethod.POST)
	public ModelAndView getIndmntrpLookUpList(@ModelAttribute("indmntrpForm") IndmntrpVO indmntrpVO,
			HttpServletRequest request) {
		try {
			LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
			IndmntrpDTO indmntrpDTO = RTETranslator.toIndmntrpDTO(indmntrpVO);
			
			Map<String, Object> indmntrpMap = facade.getIndmntrpLookUpList(indmntrpDTO);
			//set AvasvctVOList in application state.
			List<IndmntrpVO> indmntrpList = (List<IndmntrpVO>) indmntrpMap.get("indmntrpList");
			facade.getApplicationState().setIndmntrpList(indmntrpList);
			lookUpTableListVO.setIndmntrpVOList(indmntrpList);
			modelAndView = new ModelAndView(INDMNTRP_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("indmntrpMsg",indmntrpMap.get("indmntrpMsg"));
			modelAndView.addObject("indmntrpList", indmntrpList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e) {
			log.error("Exception occured in IndmntrpController - getIndmntrpLookUpList() method:"	+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(IndmntrpController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to display get add new Indmntrp form home view.
	 * 
	 * @return view of addIndmntrpForm, if fails return error page
	 */
	@RequestMapping(value = "/addIndmntrpForm", method = RequestMethod.POST)
	public ModelAndView getAddNewIndmntrpFormHome(HttpServletRequest request) {
		try {
			String securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView = new ModelAndView(INDMNTRP_ADD_NEW, "indmntrpVO", new IndmntrpVO());
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in IndmntrpController - getAddNewIndmntrpFormHome() method:"	+ e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_VIEW + "(IndmntrpController)" + e.toString();
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}

	/**
	 * Method to get the indmntrpLookUp List from data store.
	 * 
	 * @param indmntrpVO
	 *            form view object of indmntrp.
	 * @return view of indmntrpDisplayForm, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addIndmntrp", method = RequestMethod.POST)
	public ModelAndView addIndmntrp(final HttpServletRequest request, @ModelAttribute("addIndmntrpForm") IndmntrpVO indmntrpVO) {
		try {
			IndmntrpDTO indmntrpDTO = RTETranslator.toIndmntrpDTO(indmntrpVO);
			Map<String, Object> indmntrpMap = facade.addIndmntrpToDb(indmntrpDTO);
			LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
			//set AvasvctVOList in application state.
			List<IndmntrpVO> indmntrpList = (List<IndmntrpVO>) indmntrpMap.get("indmntrpList");
			facade.getApplicationState().setIndmntrpList(indmntrpList);
			lookUpTableListVO.setIndmntrpVOList(indmntrpList);
			modelAndView = new ModelAndView(INDMNTRP_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("indmntrpMsg",indmntrpMap.get("indmntrpMsg"));
			modelAndView.addObject("indmntrpList",indmntrpList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e) {
			log.error("Exception occured in IndmntrpController - addIndmntrp() method:"+ e.getErrorMessage());
			String errorMsg = ApplicationConstants.ERROR_ADD_ROW + "(IndmntrpController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errorModelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			errorModelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
			return errorModelAndView;
		}
	}
	
	/**
	 * Method to get the indmntrpLookUp List from data store.
	 * @param request
	 *            request object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of indmntrpDisplayForm, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/deleteIndmntrp", method = RequestMethod.POST)
	public ModelAndView deleteIndmntrp(@ModelAttribute("indmntrpDisplayForm")LookUpTableListVO lookUpTableListVO,
			@RequestParam(required = false) String[] takeAction, HttpServletRequest request) {
		List<IndmntrpVO> indmntrpList = new LinkedList<IndmntrpVO>();
		try {
			indmntrpList = lookUpTableListVO.getIndmntrpVOList();
			int index;
			Map<String, Object> indmntrpMap = new HashedMap();
			String indmntrpMsg = "";
			if(takeAction != null && takeAction.length != 0){
				boolean isIndmntrpDeleted = false;
				if (indmntrpList != null && indmntrpList.size() != 0) {
					List<IndmntrpDTO> updatedIndmntrpList = RTETranslator.toIndmntrpDTOList(indmntrpList);
					for (int j = takeAction.length - 1; j >= 0; j--) {
						index = Integer.parseInt(takeAction[j]);
						IndmntrpDTO existingIndmntrp = (IndmntrpDTO) updatedIndmntrpList.get(index);
						if (existingIndmntrp.getDbUpdatedInd() != ApplicationConstants.COPY) {
							indmntrpMap = facade.deleteIndmntrp(existingIndmntrp);
							indmntrpMsg = (String) indmntrpMap.get("indmntrpMsg");
							isIndmntrpDeleted = (Boolean) indmntrpMap.get("isIndmntrpDeleted");
							if(isIndmntrpDeleted){
								indmntrpList.remove(index);
							}else{
								j = 0;
							}
						} else{
							indmntrpList.remove(index);
						}
						
					}
					if(isIndmntrpDeleted)
					indmntrpMsg = ApplicationConstants.ROWS_DELETED;
				
				}
			} else
				indmntrpMsg = ApplicationConstants.NO_ACTION_TAKEN;
			
			//update IndmntrpVOList in application state.
			facade.getApplicationState().setIndmntrpList(indmntrpList);
			modelAndView = new ModelAndView(INDMNTRP_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("indmntrpMsg",indmntrpMsg);
			modelAndView.addObject("indmntrpList",indmntrpList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in IndmntrpController - deleteIndmntrp() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(IndmntrpController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
		}
	}

	/**
	 * Method to get the indmntrpLookUp List from data store.
	 * 
	 * @param indmntrpVO
	 *            form view object of indmntrp.
	 * @param takeAction
	 *          List of takeAction to copy the row
	 * @return view of indmntrpDisplayForm, if fails return error page
	 */
	@RequestMapping(value="/copyIndmntrp", method = {RequestMethod.POST, RequestMethod.GET})
	public ModelAndView copyIndmntrp(@RequestParam(required = false) String[] takeAction,
			@ModelAttribute("indmntrpDisplayFormForm")LookUpTableListVO lookUpTableListVO, HttpServletRequest request){
		int index;
		String indmntrpMsg ="";
		List<IndmntrpVO> indmntrpList = new LinkedList<IndmntrpVO>();
		try {
			indmntrpList = lookUpTableListVO.getIndmntrpVOList();
			if(takeAction != null && takeAction.length != 0){
				if(indmntrpList != null && indmntrpList.size() != 0){
					for (int j = 0; j < takeAction.length; j++) {
						index = Integer.parseInt(takeAction[j]);
						IndmntrpVO existingIndmntrp = (IndmntrpVO) indmntrpList.get(index);
						IndmntrpVO copiedIndmntrpVO =  (IndmntrpVO) SerializationUtils.clone(existingIndmntrp);
						copiedIndmntrpVO.setDbUpdatedInd(ApplicationConstants.COPY);
						indmntrpList.add(copiedIndmntrpVO);
					}
					indmntrpMsg = ApplicationConstants.ROWS_COPIED;
				}
			} else {
				indmntrpMsg = ApplicationConstants.NO_ACTION_TAKEN;
			}
			//update AvasvctVOList in application state.
			facade.getApplicationState().setIndmntrpList(indmntrpList);
			lookUpTableListVO.setIndmntrpVOList(indmntrpList);
			modelAndView = new ModelAndView(INDMNTRP_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("indmntrpMsg",indmntrpMsg);
			modelAndView.addObject("indmntrpList",indmntrpList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (Exception e) {
			log.error("Exception occured in IndmntrpController - copyIndmntrp() method:" + e.getMessage());
			String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(IndmntrpController)" + RteIntranetUtils.getTrimmedString(e.getMessage());
			modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);
			modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);
			return modelAndView;
		}
	}

	/**
	 * Method to get the indmntrpLookUp List from data store.
	 * 
	 * @param takeAction
	 *            list of selected indexes from view.
	 * @param request
	 *            request object.
	 * @return view of indmntrpDisplayForm, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addUpdateIndmntrp", method =  {RequestMethod.POST , RequestMethod.GET})
	public ModelAndView addUpdateIndmntrp(@ModelAttribute("indmntrpDisplayForm")LookUpTableListVO lookUpTableListVO,
			@RequestParam(required = false) String[] takeAction, HttpServletRequest request) {
		int index;
		String indmntrpMsg ="";
		List<IndmntrpVO> indmntrpList = new LinkedList<IndmntrpVO>();
		List<IndmntrpVO> modifiedIndmntrpList = new LinkedList<IndmntrpVO>();
		try {
			modifiedIndmntrpList = lookUpTableListVO.getIndmntrpVOList();
			indmntrpList = facade.getApplicationState().getIndmntrpList();
			if(takeAction != null && takeAction.length != 0){
				for(IndmntrpVO indmntrpVO : indmntrpList){
					if(indmntrpVO.getDbUpdatedInd() == ApplicationConstants.UPDATE_IND_Y){
						indmntrpVO.setDbUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				if(modifiedIndmntrpList != null && modifiedIndmntrpList.size() != 0
						&& indmntrpList != null && indmntrpList.size() != 0){
					Map<String, Object> indmntrpMap = new HashedMap();
					List<IndmntrpDTO> indmntrpDTOList = RTETranslator.toIndmntrpDTOList(indmntrpList);
					for (int j = 0; j < takeAction.length; j++) {
						index = Integer.parseInt(takeAction[j]);
						IndmntrpDTO updatedIndmntrpDTO = RTETranslator.toIndmntrpDTO(modifiedIndmntrpList.get(index));
						indmntrpMap = facade.addUpdateIndmntrp(updatedIndmntrpDTO, indmntrpDTOList, index);
						List<IndmntrpDTO> procexDtoList1 = (List<IndmntrpDTO>) indmntrpMap.get("indmntrpList");
						indmntrpList = RTETranslator.toIndmntrpVOList(procexDtoList1);
						boolean isIndmntrpAddorUpdated = (Boolean) indmntrpMap.get("isIndmntrpAddorUpdated");
						indmntrpMsg = (String) indmntrpMap.get("indmntrpMsg") ;
						if(isIndmntrpAddorUpdated){
							j = takeAction.length;
						} 
					}
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);
				}
			} else {
				indmntrpMsg = ApplicationConstants.NO_ACTION_TAKEN;
			}
			//update IndmntrpVOList in application state.
			facade.getApplicationState().setIndmntrpList(indmntrpList);
			
			lookUpTableListVO.setIndmntrpVOList(indmntrpList);
			modelAndView = new ModelAndView(INDMNTRP_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("lookUpTableListVO", lookUpTableListVO);
			modelAndView.addObject("indmntrpMsg",indmntrpMsg);
			modelAndView.addObject("indmntrpList",indmntrpList);
			String securityLevel ="";
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			modelAndView.addObject("securityLevel", securityLevel);
			return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in IndmntrpController - addUpdateIndmntrp() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_GET_LOOKUP + "(IndmntrpController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
		}
	}
	/**
	 * Method to export Indmntrp look up table to excel work book
	 * 
	 * @param lookUpTableListVO
	 *            list of indmntrp object.
	 * @param response
	 *            response object to return
	 * @return exported file to view.
	 */
	@RequestMapping(value = "/indmntrpExport", method = RequestMethod.POST)
	public ModelAndView indmntrpExport(HttpServletResponse response){
		List<IndmntrpVO> indmntrpList = new LinkedList<IndmntrpVO>();
		LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
		String indmntrpMsg="";
		try{
			indmntrpList = facade.getApplicationState().getIndmntrpList();
			if(indmntrpList != null && indmntrpList.size() != 0){
				// Key map to create header
				Map<String,String> keyMap = new LinkedHashMap<String,String>();
				keyMap.put("dbIndmntyCd", "Indemnity Code");
				keyMap.put("dbIndmntyShrtNm", "Short Name");
				keyMap.put("dbIndmntyNm", "Name");
				keyMap.put("dbIndmntyRFRLInd", "Referral Ind");
				keyMap.put("dbIndmntyPRCRTInd", "Precert Ind");
				keyMap.put("dbPcpSelReqInd", "PCP Sel Req Ind");
				
				RteIntranetUtils.exportToExcel(response, indmntrpList, keyMap);
				indmntrpMsg = ApplicationConstants.EXPORT_SUCCESS;
			} else {
				indmntrpMsg = ApplicationConstants.NO_DATA;
			}
			lookUpTableListVO.setIndmntrpVOList(indmntrpList);
	        modelAndView = new ModelAndView(INDMNTRP_DISPLAY,"lookUpTableListVO", lookUpTableListVO);
	        modelAndView.addObject("indmntrpMsg",indmntrpMsg);
		    return modelAndView;
		} catch (ApplicationException e){
            log.error("Exception occured in IndmntrpController - indmntrpExport() method:"+e.getErrorMessage());
            String errorMsg = ApplicationConstants.ERROR_EXPOT_TABLE + "(IndmntrpController)" + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
            modelAndView = new ModelAndView(ApplicationConstants.ERROR_PAGE);                 
            modelAndView.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);                
            return modelAndView;
       }
	}
}
