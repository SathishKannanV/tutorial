/**
 * 
 */
package com.aetna.prvrte.rteintranet.adapter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.SbmsnrVO;
import com.aetna.prvrte.rteintranet.vo.SubmsnVO;


/**
 * @author N731694
 * Cognizant_Offshore
 */
public class SbmsnrAdapter extends StoredProcedure{

	private final Log log = LogFactory.getLog(SbmsnrAdapter.class);
	private static final String CNVRSTN_CD = "CNVRSTN_CD";
	private static final String VAN_ID_CD = "VAN_ID_CD";
	private static final String IN_TY_CD = "IN_TY_CD";
	private static final String IN_PSTD_DT = "IN_PSTD_DT";
	
	private static final String OUT_CODE = "OUT_CODE";
	private static final String READ_CURSOR = "READ_CURSOR3";
	
	
 	public SbmsnrAdapter(DataSource datasource, String storedProc) {
		super(datasource, storedProc);
		
		declareParameter(new SqlParameter(CNVRSTN_CD, Types.CHAR));   
		declareParameter(new SqlParameter(VAN_ID_CD, Types.CHAR));
		declareParameter(new SqlParameter(IN_TY_CD, Types.CHAR));
		declareParameter(new SqlParameter(IN_PSTD_DT, Types.CHAR));
		
		declareParameter(new SqlOutParameter(OUT_CODE, Types.INTEGER));
		
		declareParameter(new SqlReturnResultSet(READ_CURSOR, new RowMapper(){
			
			/* (non-Javadoc)
			 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
			 */
			public Object mapRow(final ResultSet rs, final int arg1)
					throws SQLException 
					{
						SbmsnrVO sbmsnrVO=new SbmsnrVO();
						
						sbmsnrVO.setAlphaSearchInd(rs.getString("SBMSNR_ALPHSRC_IND"));
						sbmsnrVO.setSbmtPvdrLastName(rs.getString("SBMSNR_SBPRLAST_NM"));
						sbmsnrVO.setSbmtPvdrFirstName(rs.getString("SBMSNR_SBPR_FST_NM"));
						sbmsnrVO.setSbmtPvdrMidName(rs.getString("SBMSNR_SBPRMID_NM"));
						sbmsnrVO.setSbmtPvdrTitle(rs.getString("SBMSNR_SBPRTITL_NM"));
						
						
						sbmsnrVO.setSbmtPvdrAddr1(rs.getString("SBMSNR_SPADDR1_TXT"));
						sbmsnrVO.setSbmtPvdrAddr2(rs.getString("SBMSNR_SPADDR2_TXT"));
						sbmsnrVO.setSbmtPvdrCity(rs.getString("SBMSNR_SBPRCITY_NM"));
						sbmsnrVO.setSbmtPvdrState(rs.getString("SBMSNR_SBPRV_ST_CD"));
						sbmsnrVO.setSbmPvdrZipCd(rs.getString("SBMSNR_SBPR_ZIP_CD"));
						
						
						sbmsnrVO.setSpCommunication1No(rs.getString("SBMSNR_SPRVCOMM_NO"));
						sbmsnrVO.setAssistantPhoneNo(rs.getString("SBMSNR_ASTNCPHN_NO"));
						sbmsnrVO.setRespTypeCd(rs.getString("SBMSNR_RSPNS_TY_CD"));
						sbmsnrVO.setEffDate(rs.getString("SBMSNR_EFF_DT"));
						sbmsnrVO.setRespTime(rs.getString("SBMSNR_RSPNS_TM"));
						
						
						
						sbmsnrVO.setPostedDt(rs.getString("SBMSNR_PSTD_DT"));
						sbmsnrVO.setClaimOfficeCd(rs.getString("SBMSNR_CLMOFF_CD"));
						sbmsnrVO.setProviderTypeCd(rs.getString("SBMSNR_PRVTY_CD"));
						sbmsnrVO.setPostedTime(rs.getString("SBMSNR_PSTD_TM"));
						sbmsnrVO.setProductName(rs.getString("SBMSNR_UNTPRVAS_NM"));
						
						sbmsnrVO.setSbmsnrTypeCd(rs.getString("SBMSNR_TY_CD"));
						sbmsnrVO.setPayorCobCd(rs.getString("SBMSNR_PAYORCOB_CD"));
						sbmsnrVO.setMedUnitIdCd(rs.getString("MEDUNIT_ID_CD"));
						sbmsnrVO.setSubsIdQualCd(rs.getString("SBMSNR_SBSCRBIQ_CD"));
						sbmsnrVO.setDepIdQualCode(rs.getString("SBMSNR_DPNDNTIQ_CD"));
						
						sbmsnrVO.setTransactionTypeCd(rs.getString("SBMSNR_TRNSCTNT_CD"));
						sbmsnrVO.setConvIdCode(rs.getString("SUBMSN_CNVRSTN_CD"));
						sbmsnrVO.setVanIdCd(rs.getString("SUBMSN_VAN_ID_CD"));
						sbmsnrVO.setTranType(rs.getString("SUBMSN_TY_CD"));
						sbmsnrVO.setEmployeeId(rs.getString("SBMSNR_EMPLOYE_IDN"));
						
						sbmsnrVO.setSpCommNoQualCd(rs.getString("SBMSNR_SPCNQLF_CD"));
						sbmsnrVO.setSubsPhoneNo(rs.getString("SBMSNR_SBSCRBRT_NO"));
						sbmsnrVO.setDepsPhoneNo(rs.getString("SBMSNR_DPNDNTTL_NO"));
						sbmsnrVO.setPatientAddr1(rs.getString("SBMSNR_PTNTAD1_TXT"));
						sbmsnrVO.setPatientAddr2(rs.getString("SBMSNR_PTNTAD2_TXT"));
						
						sbmsnrVO.setPatientCity(rs.getString("SBMSNR_PTNTCITY_NM"));
						sbmsnrVO.setPatientState(rs.getString("SBMSNR_PTNTST_CD"));
						sbmsnrVO.setPatientZipCd(rs.getString("SBMSNR_PTNTZIP_CD"));
						sbmsnrVO.setClaimOfficeName(rs.getString("CLMOFF_NM"));
						sbmsnrVO.setClaimOfficeAddr1(rs.getString("CLMOFF_ADDRLN1_TXT"));
						
						sbmsnrVO.setClaimOfficeAddr2(rs.getString("CLMOFF_ADDRLN2_TXT"));
						sbmsnrVO.setClaimOffLocationCd(rs.getString("CLMOFF_LOC_CD"));
						sbmsnrVO.setClaimOfficeState(rs.getString("CLMOFF_ST_CD"));
						sbmsnrVO.setClaimOfficeZipCd(rs.getString("CLMOFF_ZIP_CD"));
						sbmsnrVO.setCobPrimSecCd(rs.getString("COB_PRIM_SEC_CD"));
						
						
						
						sbmsnrVO.setCobCarrierName(rs.getString("CUMBOC_CARRIER_NM"));
						sbmsnrVO.setCobPolicyNo(rs.getString("CUMBOC_POLICY_NO"));
						sbmsnrVO.setCobEffDate(rs.getString("CUMBOC_EFFECTIV_DT"));
						sbmsnrVO.setCobExpDate(rs.getString("CUMBOC_EXPIRATN_DT"));
						sbmsnrVO.setFamilyLevelInd(rs.getString("SBMNSR_FAMLVL_IND"));
						return sbmsnrVO;
			}

		}));

	}
	
	
	
	@SuppressWarnings("unchecked")
	public Map getSbmsnrEvntTracking (String convIdCode, String vanIdCd,String typeCd,String postedDt) throws ApplicationException {
		log.debug("Entered SbrsrxbAdapter  - getSbrsrxbEvntTracking");
	
		Map<String, String> params = new java.util.HashMap<String, String>();
		Map sbmsnrMap = new HashMap();
		params.put(CNVRSTN_CD, RteIntranetUtils.getTrimmedString(convIdCode));
		params.put(VAN_ID_CD, RteIntranetUtils.getTrimmedString(vanIdCd));
		params.put(IN_TY_CD, RteIntranetUtils.getTrimmedString(typeCd));
		params.put(IN_PSTD_DT, RteIntranetUtils.getTrimmedString(postedDt));
		
	
		
		log.debug(params);
		Map results = null;
		
		List<SbmsnrVO> sbmsnrList= new LinkedList<SbmsnrVO>();
		String newMessage="";
	
		try {
			results = execute(params);
			log.debug("SbmsnrAdapter: Executed stored procedure");
			String sqlCode =  String.valueOf(results
					.get(OUT_CODE));
			sbmsnrList = (List<SbmsnrVO>) results
					.get(READ_CURSOR);	
	
			if ("0".equals(sqlCode))
			{
				if (null==sbmsnrList ||sbmsnrList.isEmpty()) {
				newMessage = "No Data for Conversation ID: " + convIdCode + 
							" Van Id: " +  vanIdCd + 
							" Tran Type: " + typeCd + 
							" or Posted Date: " + postedDt;
				}
			else
			{
				newMessage = "Data found for Conversation ID: " + convIdCode +
					" Van Id: " +  vanIdCd + 
					" Tran Type: " + typeCd + 
					" and Posted Date: " + postedDt;
			}
		} else {
			
		    	newMessage = "Problem in DB2. sqlcode: " + sqlCode ;
		}
				
			
			sbmsnrMap.put("newMessage", newMessage);
			sbmsnrMap.put("sbmsnrList",sbmsnrList);
			return sbmsnrMap;
		}catch (Exception exception){
			log.error("SbmsnrAdapter : generic error occured  "+exception);
			throw new ApplicationException(ApplicationConstants.ERR_GENERIC,exception.getMessage(),exception);
		}
	}

}
