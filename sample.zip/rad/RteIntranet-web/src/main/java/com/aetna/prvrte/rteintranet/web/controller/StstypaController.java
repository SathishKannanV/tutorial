package com.aetna.prvrte.rteintranet.web.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.aetna.prvrte.rteintranet.dto.StstypaDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.facade.Facade;
import com.aetna.prvrte.rteintranet.translator.RTETranslator;
import com.aetna.prvrte.rteintranet.util.ApplicationConstants;
import com.aetna.prvrte.rteintranet.util.RteIntranetUtils;
import com.aetna.prvrte.rteintranet.vo.LookUpTableListVO;
import com.aetna.prvrte.rteintranet.vo.StstypaVO;


/**
 * The StstypaController is responsible for handling
 * ModelAndView the request and return a ModelAndView object which the
 * DispatcherServlet will render as view
 * 
 * @author N624926
 * Cognizant_Offshore
 */

@Controller
@RequestMapping(value = "/ststypa/*")
	public class StstypaController {

	/*
	 * Log factory initialization
	 */
	private static final Log log = LogFactory.getLog(StstypaController.class);
	/*
	 * Tile name of the ststypa Home view.
	 */
	public static final String STSTYPA_HOME = ".ststypaHome";
	/*
	 * Tile name of the ststypa Display view.
	 */
	public static final String STSTYPA_LOOKUP = ".ststypaLookUpDisplay";
	/*
	 * Tile name of the Add New ststypa Form view.
	 */
	public static final String STSTYPA_ADD = ".ststypaAdd";
	/*
	 * Constant name used for COPY indicator.
	 */
	public static final char COPY = 'C';
	/**
	 * Declare a private method mav
	 */
	private ModelAndView mav;

	/**
	 * Declare a private method facade
	 */
	@Autowired(required=true)
	private Facade facade;
	/*
	 * Model and view of failure operation.
	 */
	private ModelAndView errormav;
	
	
	/**
	 * Method to getStstypaLookUpHome view
	 * 
	 * @param model
	 * 
	 * @return view of ststypaLookUp, if fails return error page
	 */
	@RequestMapping(value="/ststypaHome", method ={ RequestMethod.POST , RequestMethod.GET})
	public ModelAndView getStstypaLookUpHome(final HttpServletRequest request,Model model) {	   
		log.warn("Entered StstypaController - getStstypaLookUpHome()");
		String securityLevel ="";
		try {
		securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
		ModelAndView mav = new ModelAndView(STSTYPA_HOME, "ststypaVO",  new StstypaVO());
		mav.addObject("securityLevel", securityLevel);
		log.warn("StstypaController - securityLevel: "+ securityLevel);
		log.warn("Exit from StstypaController - getStstypaLookUpHome()");
		return mav;
		} catch (ApplicationException e){
			log.error("Exception occured in StstypaController - getStstypaLookUpHome() method:"+e.getErrorMessage());
			String errorMsg ="Error encountered when extracting data from the database (GatherProcex). "+
					RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	/**
	 * Method to get the ststypaLookUp List from data store.
	 * 
	 * @param ststypaVO
	 *            form view object of ststypa.
	 * @return view of ststypaDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/GatherStstypa", method = RequestMethod.POST)
	public ModelAndView getStstypaLookUpTable(HttpServletRequest request,@ModelAttribute("ststypaForm")StstypaVO ststypaVO){
		String securityLevel ="";
		ModelAndView mav ;
		Map ststypaResultMap = new HashMap();
		List<StstypaVO> ststypaList = new LinkedList<StstypaVO>();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		try{
			StstypaDTO ststypaDTO = RTETranslator.toStstypaDTO(ststypaVO);
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			ststypaResultMap = facade.getStstypaLookUpTable(ststypaDTO);
			List<StstypaDTO> ststypaDTOList = (List<StstypaDTO>) ststypaResultMap.get("ststypaList");
			ststypaList = (List<StstypaVO>) RTETranslator.toStstypaVOList(ststypaDTOList);
			lookUpListVO.setStstypaVOList(ststypaList);
			facade.getApplicationState().setStstypaList(ststypaList);
			mav = new ModelAndView(STSTYPA_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("ststypaMessage", ststypaResultMap.get("newMessage"));
			mav.addObject("securityLevel", securityLevel);
			log.warn("getStstypaLookUpTable - ststypaMessage: "+ ststypaResultMap.get("newMessage"));
			log.warn("Exit from StstypaController - getStstypaLookUpTable()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in StstypaController - getStstypaLookUpTable() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="getStstypaLookUpTable() :"+ApplicationConstants.ERROR_GET_LOOKUP + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	
	/**
	 * Method to display get add new Ststypa form home view.
	 * 
	 * @return view of loadAddNewStstypaRowScreen, if fails return error page
	 */
	@RequestMapping(value="/AddNewStstypaRow")
	public ModelAndView loadAddNewStstypaRowScreen(final HttpServletRequest request,Model model) {	 
		log.warn("Entered StstypaController - loadAddNewStstypaRowScreen()");
		ModelAndView mav = new ModelAndView(STSTYPA_ADD, "ststypaVO",  new StstypaVO());
		try {
			mav.addObject("securityLevel", RteIntranetUtils.getUserSecurityLevel(request));
		} catch (ApplicationException e) {
			log.error("Exception occured in StstypaController - loadAddNewStstypaRowScreen() method:"+e.getErrorMessage());
			
			String errorMsg ="Error encountered when extracting data from the database (loadAddNewStstypaRowScreen). "+
					e.getErrorMessage();
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		log.warn("Exit from StstypaController - loadAddNewStstypaRowScreen()");
		return mav;
	}
	
	
	/**
	 * Method to add the data database
	 * 
	 * @param ststypaVO form view object of Ststypa.
	 * @return view of ststypaDisplay, if fails return error page
	 * 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/AddStstypa", method = RequestMethod.POST)
	public ModelAndView addNewStstypa(final HttpServletRequest request,@ModelAttribute("addStstypaForm")StstypaVO ststypaVO){
		log.warn("Entered StstypaController - addNewStstypa()");
		ModelAndView mav ;
		String securityLevel ="";
		Map ststypaResultMap = new HashMap();
		LookUpTableListVO lookUpListVO = new LookUpTableListVO();
		List<StstypaDTO> ststypaDtoList = new LinkedList<StstypaDTO>();
		List<StstypaVO> ststypaVoList = new LinkedList<StstypaVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			ststypaVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_Y);
			StstypaDTO ststypaDTO = RTETranslator.toStstypaDTO(ststypaVO);
			ststypaResultMap = facade.addNewStstypa(ststypaDTO);
			if(ststypaResultMap.get("ststypaList")!=null){
				ststypaDtoList = (List<StstypaDTO>) ststypaResultMap.get("ststypaList");
				ststypaVoList = RTETranslator.toStstypaVOList(ststypaDtoList);
			}
			lookUpListVO.setStstypaVOList(ststypaVoList);
			facade.getApplicationState().setStstypaList(ststypaVoList);
			mav = new ModelAndView(STSTYPA_LOOKUP, "lookUpListVO", lookUpListVO);
			mav.addObject("securityLevel", securityLevel);
			mav.addObject("ststypaMessage", ststypaResultMap.get("ststypaMessage"));
			log.warn("addNewStstypa - ststypaMessage: "+ ststypaResultMap.get("ststypaMessage"));
			log.warn("Exit from StstypaController - addNewStstypa()");			
			return mav;	
		}catch (ApplicationException e){
			log.error("Exception occured in StstypaController - addNewStstypa() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addNewStstypa() :"+ApplicationConstants.ERROR_ADD_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to delete the Ststypa List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of ststypaDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteStstypa", method = RequestMethod.POST)
	public ModelAndView deleteStstypa(final HttpServletRequest request,@ModelAttribute("ststypaDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String ststypaMsg = "";
		boolean isStstypaDeleted = true;
		String securityLevel ="";
		Map ststypaResultMap = new HashMap();
		List<StstypaVO> ststypaList = new LinkedList<StstypaVO>();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			ststypaList = lookUpListVO.getStstypaVOList();
			int i;
			if ((ststypaList != null) && (takeAction != null)) {
				for(StstypaVO ststypaVO : ststypaList){
					if(ststypaVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						ststypaVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = takeAction.length - 1; j >= 0; j--) {
					i = Integer.parseInt(takeAction[j]);
					StstypaVO editedStstypa = (StstypaVO) ststypaList.get(i);
					if (editedStstypa.getUpdatedInd() != ApplicationConstants.COPY) {
						StstypaDTO ststypaDTO = RTETranslator.toStstypaDTO(editedStstypa);
						ststypaResultMap = facade.deleteStstypa(ststypaDTO);
						ststypaMsg = (String) ststypaResultMap.get("ststypaMsg");
						isStstypaDeleted = (Boolean) ststypaResultMap.get("isStstypaDeleted");
						if(isStstypaDeleted == true){
							ststypaList.remove(i);
						}else{
							j = 0;
						}
					}else{
						ststypaList.remove(i);
					}				
			}
				if(isStstypaDeleted == true)
					ststypaMsg = "Rows selected were Deleted in the database/list";
		}else
			ststypaMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setStstypaList(ststypaList);
			lookUpListVO.setStstypaVOList(ststypaList);
			mav = new ModelAndView(STSTYPA_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("ststypaMessage",ststypaMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("deleteStstypa - ststypaMessage: "+ ststypaMsg);
		    log.warn("Exit from StstypaController - deleteStstypa()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in StstypaController - deleteStstypa() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="deleteStstypa() :"+ApplicationConstants.ERROR_DELETE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}

	
	/**
	 * Method to copy the Ststypa List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of ststypaDisplay, if fails return error page
	 */
	@RequestMapping(value="/copyStstypa", method = RequestMethod.POST)
	public ModelAndView copyStstypa(final HttpServletRequest request,@ModelAttribute("ststypaDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		ModelAndView mav ;
		String ststypaMsg = "";
		String securityLevel ="";
		int i;
		List<StstypaVO> ststypaList = new LinkedList<StstypaVO>();
		try{
			//String postedDate =RteIntranetUtils.getPostedDate(); //Initialize Posted Date to today's date
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			ststypaList = lookUpListVO.getStstypaVOList();
			if ((ststypaList != null) && (takeAction != null)) {
				for(StstypaVO ststypaVO : ststypaList){
					if(ststypaVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						ststypaVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				for (int j = 0; j < takeAction.length; j++) {
					
					i = Integer.parseInt(takeAction[j]);
					StstypaVO existingStstypa = (StstypaVO) ststypaList.get(i);
					StstypaVO copyStstypa = new StstypaVO(  "0" , existingStstypa.getStateCd(),existingStstypa.getCollectionCode() , existingStstypa.getIndividualCode() , existingStstypa.getEffDate() ,
							existingStstypa.getExpDate() , existingStstypa.getPostedDate() , existingStstypa.getVersionReleaseCode() , COPY);
					ststypaList.add(copyStstypa);
				}
				ststypaMsg = "Copied rows were placed at the bottom of the list and highlighted.";
			}else
				ststypaMsg = "Take action was not selected for any of the displayed rows";
			facade.getApplicationState().setStstypaList(ststypaList);
			lookUpListVO.setStstypaVOList(ststypaList);
			mav = new ModelAndView(STSTYPA_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("ststypaMessage",ststypaMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("copyStstypa - ststypaMessage: "+ ststypaMsg);
		    log.warn("Exit from StstypaController - copyStstypa()");
			return mav;		
		}catch (Exception e){
			log.error("Exception occured in StstypaController - copyStstypa() method:"+e.getMessage());
			String errorMsg ="copyStstypa() :"+ApplicationConstants.ERROR_COPY_ROW + RteIntranetUtils.getTrimmedString(e.getMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
	}
	
	
	/**
	 * Method to Add/Update the Ststypa List from data store.
	 * @param lookUpListVO
	 *            lookUpListVO object from view
	 * @param takeAction
	 * 			List of selected index.
	 * @return view of ststypaDisplay, if fails return error page
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addUpdateStstypa", method = RequestMethod.POST)
	public ModelAndView addUpdateStstypa(final HttpServletRequest request,@ModelAttribute("ststypaDisplayForm")LookUpTableListVO lookUpListVO, @RequestParam(required = false) String[] takeAction){
		log.warn("Entered from StstypaController - addUpdateStstypa()");
		ModelAndView mav ;
		String ststypaMsg = "";
		List<StstypaVO> updatedStstypaList = facade.getApplicationState().getStstypaList();
		String securityLevel ="";
		List<StstypaDTO> updatedStstypaDtoList = new LinkedList<StstypaDTO>();
		List<StstypaVO> ststypaVoList = new LinkedList<StstypaVO>();
		List<StstypaVO> modifiedStstypaVoList = new LinkedList<StstypaVO>();
		List<StstypaDTO> ststypaDtoList = new LinkedList<StstypaDTO>(); 
		boolean isStstypaAddOrUpdated = false;
		Map ststypaResultMap = new HashMap();
		try{
			securityLevel = RteIntranetUtils.getUserSecurityLevel(request);
			 ststypaVoList = facade.getApplicationState().getStstypaList();
			 modifiedStstypaVoList = lookUpListVO.getStstypaVOList();
			int i;
			Date todaysDate = new Date(System.currentTimeMillis());
			String postedDate = todaysDate.toString();
			if (takeAction != null && takeAction.length != 0) {
				if(ststypaVoList != null && ststypaVoList.size() != 0 
						&& modifiedStstypaVoList.size() != 0 && modifiedStstypaVoList != null){
				for(StstypaVO ststypaVO : ststypaVoList){
					if(ststypaVO.getUpdatedInd()==ApplicationConstants.UPDATE_IND_Y){
						ststypaVO.setUpdatedInd(ApplicationConstants.UPDATE_IND_N);
					}
				}
				ststypaDtoList = RTETranslator.toStstypaDTOList(ststypaVoList);
				for (int j = 0; j < takeAction.length; j++) {
					char updatedInd = ApplicationConstants.UPDATE_IND_Y;
					i = Integer.parseInt(takeAction[j]);
					StstypaVO selectedStstypa = (StstypaVO)ststypaVoList.get(i);
					StstypaVO editedStstypa = (StstypaVO) modifiedStstypaVoList.get(i);
					StstypaVO editedStstypaVO = new StstypaVO(  editedStstypa.getId() , editedStstypa.getStateCd(),editedStstypa.getCollectionCode() , editedStstypa.getIndividualCode() , editedStstypa.getEffDate() ,
							editedStstypa.getExpDate() ,postedDate , editedStstypa.getVersionReleaseCode() , updatedInd);
					StstypaDTO editedStstypaDTO = RTETranslator.toStstypaDTO(editedStstypaVO);
					ststypaResultMap = facade.addUpdateStstypa(editedStstypaDTO, ststypaDtoList, i , selectedStstypa.getUpdatedInd());
					updatedStstypaDtoList = (List<StstypaDTO>) ststypaResultMap.get("ststypaDtoList");
					updatedStstypaList = RTETranslator.toStstypaVOList(updatedStstypaDtoList);
					isStstypaAddOrUpdated = (Boolean) ststypaResultMap.get("isStstypaAddorUpdated");
					ststypaMsg = (String) ststypaResultMap.get("ststypaMsg") ;
					if(isStstypaAddOrUpdated!= true){
						j = takeAction.length;
					}
				}
				lookUpListVO.setStstypaVOList(updatedStstypaList);
				facade.getApplicationState().setStstypaList(updatedStstypaList);
				} else {
					throw new ApplicationException(ApplicationConstants.SESSION_EXPIRED);	
				}
		}else{
			ststypaMsg = "Take action was not selected for any of the displayed rows";
			lookUpListVO.setStstypaVOList(ststypaVoList);
			facade.getApplicationState().setStstypaList(ststypaVoList);
		}
			mav = new ModelAndView(STSTYPA_LOOKUP, "lookUpListVO", lookUpListVO);
		    mav.addObject("ststypaMessage",ststypaMsg);
		    mav.addObject("securityLevel", securityLevel);
		    log.warn("addUpdateStstypa - ststypaMessage: "+ ststypaMsg);
		    log.warn("Exit from StstypaController - addUpdateStstypa()");
			return mav;
		}catch (ApplicationException e){
			log.error("Exception occured in StstypaController - addUpdateStstypa() method:"+RteIntranetUtils.getTrimmedString(e.getErrorMessage()));
			String errorMsg ="addUpdateStstypa() :"+ApplicationConstants.ERROR_ADD_UPDATE_ROW + RteIntranetUtils.getTrimmedString(e.getErrorMessage());
			errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);			
			errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE, errorMsg);			
			return errormav;
		}
		
	}

	
	/**
     * Method to export Ststypa look up table to excel work book
     * 
      * @param lookUpTableListVO
     *            list of ststypa object.
     * @param response
     *            response object to return
     * @return exported file to view.
     */
     @RequestMapping(value = "/ststypaExport", method = RequestMethod.POST)
     public ModelAndView ststypaExport(HttpServletResponse response){
           List<StstypaVO> ststypaList = new LinkedList<StstypaVO>();
           LookUpTableListVO lookUpTableListVO = new LookUpTableListVO();
           String ststypaMsg="";
           try{
                 ststypaList = facade.getApplicationState().getStstypaList();
                 if(ststypaList != null && ststypaList.size() != 0){
                 // Key map to create header
                 Map<String,String> keyMap = new LinkedHashMap<String,String>();
                 keyMap.put("stateCd", "State Code");
                 keyMap.put("collectionCode", "Collection Code");
                 keyMap.put("individualCode", "Individual CD");
                 keyMap.put("versionReleaseCode", "Version Release Code");
                 keyMap.put("effDate", "Effective Date");
                 keyMap.put("expDate", "Expiration Date");
                 keyMap.put("postedDate", "Posted Date");
                 keyMap.put("id", "Id");
                 RteIntranetUtils.exportToExcel(response, ststypaList, keyMap);
                 ststypaMsg = "LookUp table exported successfully.";
                 } else {
                       ststypaMsg = "No data found.";
                 }
                 lookUpTableListVO.setStstypaVOList(ststypaList);
                 mav = new ModelAndView(STSTYPA_LOOKUP,"lookUpTableListVO", lookUpTableListVO);
                 mav.addObject("ststypaMessage",ststypaMsg);
                 return mav;
           }catch (ApplicationException e) {
                 log.error("Exception occured in StstypaController - ststypaExport() method:" + e.getMessage());
                 String errorMsg = "Error encountered while export to excel. ";
                 errorMsg.concat(e.toString());
                 errormav = new ModelAndView(ApplicationConstants.ERROR_PAGE);
                 errormav.addObject(ApplicationConstants.EXCP_ERR_MESSAGE,errorMsg);
                 return errormav;
           }
     }


}
