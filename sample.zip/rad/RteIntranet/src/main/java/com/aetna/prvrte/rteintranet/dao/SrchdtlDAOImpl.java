/**
 * 
 */
package com.aetna.prvrte.rteintranet.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aetna.prvrte.rteintranet.adapter.SrchcolAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrchcolDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrchcolUpdateAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrchdtlAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrchdtlDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrchdtlUpdateAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrcherrAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrcherrDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrcherrUpdateAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrchresAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrchresDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrchresUpdateAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrchscAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrchscDeleteAdapter;
import com.aetna.prvrte.rteintranet.adapter.SrchscUpdateAdapter;
import com.aetna.prvrte.rteintranet.dto.SrchcolDTO;
import com.aetna.prvrte.rteintranet.dto.SrchdtlDTO;
import com.aetna.prvrte.rteintranet.dto.SrcherrDTO;
import com.aetna.prvrte.rteintranet.dto.SrchresDTO;
import com.aetna.prvrte.rteintranet.dto.SrchscDTO;
import com.aetna.prvrte.rteintranet.exception.ApplicationException;
import com.aetna.prvrte.rteintranet.vo.SrchcolVO;
import com.aetna.prvrte.rteintranet.vo.SrchdtlVO;
import com.aetna.prvrte.rteintranet.vo.SrcherrVO;
import com.aetna.prvrte.rteintranet.vo.SrchresVO;
import com.aetna.prvrte.rteintranet.vo.SrchscVO;

/**
 * @author N731694
 * Cognizant_Offshore
 */
@Repository
public class SrchdtlDAOImpl implements SrchdtlDAO {
	
	@Autowired(required=true)
	private SrchdtlAdapter srchdtlAdapter;
	
	@Autowired(required=true)
	private SrchdtlDeleteAdapter srchdtlDeleteAdapter;
	@Autowired(required=true)
	private SrchdtlUpdateAdapter srchdtlUpdateAdapter;
	@Autowired(required=true)
	private SrchcolAdapter srchcolAdapter;
	@Autowired(required=true)
	private SrchscAdapter srchscAdapter;
	@Autowired(required=true)
	private SrcherrAdapter srcherrAdapter;
	@Autowired(required=true)
	private SrchresAdapter srchresAdapter;
	
	@Autowired(required=true)
	private SrchcolDeleteAdapter srchcolDeleteAdapter;
	@Autowired(required=true)
	private SrchscDeleteAdapter srchscDeleteAdapter;
	@Autowired(required=true)
	private SrcherrDeleteAdapter srcherrDeleteAdapter;
	@Autowired(required=true)
	private SrchresDeleteAdapter srchresDeleteAdapter;
	@Autowired(required=true)
	private SrchcolUpdateAdapter srchcolUpdateAdapter;
	@Autowired(required=true)
	private SrchscUpdateAdapter srchscUpdateAdapter;
	@Autowired(required=true)
	private SrcherrUpdateAdapter srcherrUpdateAdapter;
	@Autowired(required=true)
	private SrchresUpdateAdapter srchresUpdateAdapter;
	
	
	@Override
	public Map getSrchdtlLookUpTable(String srchscFirstId, String srchscSecondId,String srcherrCd,String srchcolCd)
			throws ApplicationException {
		
		return srchdtlAdapter.getSrchdtlLookUpTable(srchscFirstId, srchscSecondId,srcherrCd,srchcolCd);
	}
	@Override
	public Map<String, Object> deleteSrchdtl(List<SrchdtlVO> srchdtlVOList,
			String[] selectedIndexes) throws ApplicationException {
		// TODO Auto-generated method stub
		return srchdtlDeleteAdapter.deleteSrchdtl(srchdtlVOList,selectedIndexes);
	}
	
	@Override
	public Map deleteSrchdtl(SrchdtlDTO srchdtlDTO) throws ApplicationException {
		return srchdtlDeleteAdapter.deleteSrchdtl(srchdtlDTO);
	}

	@Override
	public Map addUpdateSrchdtl(SrchdtlDTO existSrchdtlDTO,
			List<SrchdtlDTO> srchdtlDtoList, int index, char updateInd)
			throws ApplicationException {
		// TODO Auto-generated method stub
		return srchdtlUpdateAdapter.addUpdateSrchdtl(existSrchdtlDTO, srchdtlDtoList,index,updateInd);
	}
	@Override
	public Map getSrchcolLookUpTable(String srchcolCd)
			throws ApplicationException {
		
		return srchcolAdapter.getSrchcolLookUpTable(srchcolCd);
	}
	
	@Override
	public Map getSrchscLookUpTable(String srchscId)
			throws ApplicationException {
		
		return srchscAdapter.getSrchscLookUpTable(srchscId);
	}
	@Override
	public Map getSrcherrLookUpTable(String srcherrCd)
			throws ApplicationException {
		
		return srcherrAdapter.getSrcherrLookUpTable(srcherrCd);
	}
	@Override
	public Map getSrchresLookUpTable(String srchresCd)
			throws ApplicationException {
		
		return srchresAdapter.getSrchresLookUpTable(srchresCd);
	}


	

	@Override
	public Map deleteSrchcol(SrchcolDTO srchcolDTO) throws ApplicationException {
		return srchcolDeleteAdapter.deleteSrchcol(srchcolDTO);
	}
	@Override
	public Map deleteSrchsc(SrchscDTO srchscDTO) throws ApplicationException {
		return srchscDeleteAdapter.deleteSrchsc(srchscDTO);
	}

	@Override
	public Map deleteSrcherr(SrcherrDTO srcherrDTO) throws ApplicationException {
		return srcherrDeleteAdapter.deleteSrcherr(srcherrDTO);
	}

	@Override
	public Map deleteSrchres(SrchresDTO srchresDTO) throws ApplicationException {
		return srchresDeleteAdapter.deleteSrchres(srchresDTO);
	}


	
	@Override
	public Map addUpdateSrchcol(SrchcolDTO editedSrchcolDTO,
			List<SrchcolDTO> srchcolDtoList, int index,char updateInd)
			throws ApplicationException {
		return srchcolUpdateAdapter.addUpdateSrchcol( editedSrchcolDTO, srchcolDtoList,  index, updateInd);
	}
	@Override
	public Map addUpdateSrchsc(SrchscDTO editedSrchscDTO,
			List<SrchscDTO> srchscDtoList, int index,char updateInd)
			throws ApplicationException {
		return srchscUpdateAdapter.addUpdateSrchsc( editedSrchscDTO, srchscDtoList,  index, updateInd);
	}

	@Override
	public Map addUpdateSrcherr(SrcherrDTO editedSrcherrDTO,
			List<SrcherrDTO> srcherrDtoList, int index,char updateInd)
			throws ApplicationException {
		return srcherrUpdateAdapter.addUpdateSrcherr( editedSrcherrDTO, srcherrDtoList,  index, updateInd);
	}
	@Override
	public Map addUpdateSrchres(SrchresDTO editedSrchresDTO,
			List<SrchresDTO> srchresDtoList, int index, char updateInd)
			throws ApplicationException {
		// TODO Auto-generated method stub
		return srchresUpdateAdapter.addUpdateSrchres( editedSrchresDTO, srchresDtoList,  index, updateInd);
	}
	


}
