/**
 * 
 */
package com.aetna.prvrte.rteintranet.dto;

import java.io.Serializable;

/**
 * @author N624926
 * Cognizant_Offshore
 */

public class TOSDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6544395452532564980L;
	private String dbTosCd = ""; 
	private String dbEffDate = ""; 
	private String dbExpDate = "";
	private String dbStatusCd = "";
	private String dbApprovalCd = "";  
	private String dbDisplayName = "";
	private String dbShortName = ""; 
	private String dbTosName = ""; 
	private String dbPostedDate = "";
	private String dbLastUpdtDate = ""; 
	private String dbUserId = ""; 
	private String dbTosComments = ""; 
	private String dbUpdateReason = "";
	private char dbUpdatedInd;
	
	public TOSDTO() {
		super();
	}
	
	public TOSDTO(String tosCd, String effDate, String expDate, String statusCd,
					String approvalCd, String displayName, String shortName, String tosName,
					String postedDate, String lastUpdtDate, String userId, String tosComments,
					String updateReason, char updatedInd) {
		super();
		this.dbTosCd = tosCd;
		this.dbEffDate = effDate;
		this.dbExpDate = expDate;
		this.dbStatusCd = statusCd;
		this.dbApprovalCd = approvalCd;
		this.dbDisplayName = displayName;
		this.dbShortName = shortName;
		this.dbTosName = tosName;
		this.dbPostedDate = postedDate;
		this.dbLastUpdtDate = lastUpdtDate;
		this.dbUserId = userId;
		this.dbTosComments = tosComments;
		this.dbUpdateReason = updateReason;
		this.dbUpdatedInd = updatedInd;
		
	}
	
	/**
	 * @return the dbTosCd
	 */
	public String getDbTosCd() {
		return dbTosCd;
	}
	/**
	 * @param dbTosCd the dbTosCd to set
	 */
	public void setDbTosCd(String dbTosCd) {
		this.dbTosCd = dbTosCd;
	}
	/**
	 * @return the dbEffDate
	 */
	public String getDbEffDate() {
		return dbEffDate;
	}
	/**
	 * @param dbEffDate the dbEffDate to set
	 */
	public void setDbEffDate(String dbEffDate) {
		this.dbEffDate = dbEffDate;
	}
	/**
	 * @return the dbExpDate
	 */
	public String getDbExpDate() {
		return dbExpDate;
	}
	/**
	 * @param dbExpDate the dbExpDate to set
	 */
	public void setDbExpDate(String dbExpDate) {
		this.dbExpDate = dbExpDate;
	}
	/**
	 * @return the dbStatusCd
	 */
	public String getDbStatusCd() {
		return dbStatusCd;
	}
	/**
	 * @param dbStatusCd the dbStatusCd to set
	 */
	public void setDbStatusCd(String dbStatusCd) {
		this.dbStatusCd = dbStatusCd;
	}
	/**
	 * @return the dbApprovalCd
	 */
	public String getDbApprovalCd() {
		return dbApprovalCd;
	}
	/**
	 * @param dbApprovalCd the dbApprovalCd to set
	 */
	public void setDbApprovalCd(String dbApprovalCd) {
		this.dbApprovalCd = dbApprovalCd;
	}
	/**
	 * @return the dbDisplayName
	 */
	public String getDbDisplayName() {
		return dbDisplayName;
	}
	/**
	 * @param dbDisplayName the dbDisplayName to set
	 */
	public void setDbDisplayName(String dbDisplayName) {
		this.dbDisplayName = dbDisplayName;
	}
	/**
	 * @return the dbShortName
	 */
	public String getDbShortName() {
		return dbShortName;
	}
	/**
	 * @param dbShortName the dbShortName to set
	 */
	public void setDbShortName(String dbShortName) {
		this.dbShortName = dbShortName;
	}
	/**
	 * @return the dbTosName
	 */
	public String getDbTosName() {
		return dbTosName;
	}
	/**
	 * @param dbTosName the dbTosName to set
	 */
	public void setDbTosName(String dbTosName) {
		this.dbTosName = dbTosName;
	}
	/**
	 * @return the dbPostedDate
	 */
	public String getDbPostedDate() {
		return dbPostedDate;
	}
	/**
	 * @param dbPostedDate the dbPostedDate to set
	 */
	public void setDbPostedDate(String dbPostedDate) {
		this.dbPostedDate = dbPostedDate;
	}
	/**
	 * @return the dbLastUpdtDate
	 */
	public String getDbLastUpdtDate() {
		return dbLastUpdtDate;
	}
	/**
	 * @param dbLastUpdtDate the dbLastUpdtDate to set
	 */
	public void setDbLastUpdtDate(String dbLastUpdtDate) {
		this.dbLastUpdtDate = dbLastUpdtDate;
	}
	/**
	 * @return the dbUserId
	 */
	public String getDbUserId() {
		return dbUserId;
	}
	/**
	 * @param dbUserId the dbUserId to set
	 */
	public void setDbUserId(String dbUserId) {
		this.dbUserId = dbUserId;
	}
	/**
	 * @return the dbTosComments
	 */
	public String getDbTosComments() {
		return dbTosComments;
	}
	/**
	 * @param dbTosComments the dbTosComments to set
	 */
	public void setDbTosComments(String dbTosComments) {
		this.dbTosComments = dbTosComments;
	}
	/**
	 * @return the dbUpdateReason
	 */
	public String getDbUpdateReason() {
		return dbUpdateReason;
	}
	/**
	 * @param dbUpdateReason the dbUpdateReason to set
	 */
	public void setDbUpdateReason(String dbUpdateReason) {
		this.dbUpdateReason = dbUpdateReason;
	}
	/**
	 * @return the dbUpdatedInd
	 */
	public char getDbUpdatedInd() {
		return dbUpdatedInd;
	}
	/**
	 * @param dbUpdatedInd the dbUpdatedInd to set
	 */
	public void setDbUpdatedInd(char dbUpdatedInd) {
		this.dbUpdatedInd = dbUpdatedInd;
	}


}
